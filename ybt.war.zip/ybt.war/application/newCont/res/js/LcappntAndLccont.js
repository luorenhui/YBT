
afterVueSelect.idtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcappnt.idtype;
	if (idtype != "X"){
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"renewCount", null);
		$("#appntrenewCount").attr("disabled",true);
	}else {
		$("#appntrenewCount").attr("disabled",false);
	}
	if (idtype != "I"){
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"startingDate", null);
	$("#appntstartingDate").attr("disabled",true);
	}else {
	$("#appntstartingDate").attr("disabled",false);
	}
	if (idtype == "H" || idtype == "C"){
		//证件有效止期置灰  证件长期有效按钮置灰
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"appntenddate", null);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"islongitems", new Array());
		$("#appntenddate").attr("disabled",true);
		$("#appntislongitemmeli").attr("disabled",true);
		}else {
			if(vueobj["testdivchange"].formdata.lcappnt.islongitems.length==0){
		$("#appntenddate").attr("disabled",false);
		$("#appntislongitemmeli").attr("disabled",false);
			}
		}
};
/**
 * 投保人 通讯地址同 居住地址
 */
afterVueSelect.postalflag = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (obj.is("[type='checkbox']:checked")) {

		for ( var key in topvue.form_elements.lcappnt) {

			if (topvue.form_elements.lcappnt[key].name == 'postprovince') {
				bindSameElement.call(this, this.formdata, "homeprovince",
						this.formdata, "postprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postcity') {
				bindSameElement.call(this, this.formdata, "homecity",
						this.formdata, "postcity",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'postdistrict') {
				bindSameElement.call(this, this.formdata, "homedistrict",
						this.formdata, "postdistrict",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'postaladdress') {
				bindSameElement.call(this, this.formdata, "homeaddress",
						this.formdata, "postaladdress",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'zipcode') {
				bindSameElement.call(this, this.formdata, "homezipcode",
						this.formdata, "zipcode",
						topvue.form_elements.lcappnt[key]);

			}

		}
	} else {

		for ( var key in topvue.form_elements.lcappnt) {

			if (topvue.form_elements.lcappnt[key].name == 'postprovince') {
				unbindSameElement.call(this, "homeprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postcity') {
				unbindSameElement.call(this, "homecity",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postdistrict') {
				unbindSameElement.call(this, "homedistrict",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postaladdress') {
				unbindSameElement.call(this, "homeaddress",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'zipcode') {
				unbindSameElement.call(this, "homezipcode",
						topvue.form_elements.lcappnt[key]);
			}

		}

	}

};

//证件长期有效
afterVueSelect.appntislongitemmeli = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcappnt.idtype;
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
		+ form_element.name + "']");
	if(idtype != "H" && idtype != "C"){
	if (obj.is("[type='checkbox']:checked")){
		topvue.$set(topvue.formdata.lcappnt,"appntenddate","9999-01-01");
//		$("#lcappnt_tabinfoform").data('bootstrapValidator').resetField($("#appntenddate"));
		$("#appntenddate").attr("disabled",true);
	}else {
		$("#appntenddate").attr("disabled",false);
	}
	}
}




//行业类别
commonCombobox_option.commonCombobox_appntindustry = {
	url : path + '/newCont/codeselect/occupation/AL.do',
	valueField : "occupationcode1",
	// 显示在输入框的
	inputText : "occupationname1",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname1" ]
};
//行业代码
commonCombobox_option.commonCombobox_appntindustrycode = {
	url : path + '/newCont/codeselect/occupation/#appntindustrytype/AL.do',
	valueField : "occupationcode2",
	// 显示在输入框的
	inputText : "occupationname2",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname2" ]
};
 
//职业代码
commonCombobox_option.commonCombobox_appntoccupationcode = {
	url : path + '/newCont/codeselect/occupationocc/#appntoccupationtype/AL.do',
	valueField : "occupationcode",
	// 显示在输入框的
	inputText : "occupationname",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname" ]
};

beforesubmitvueform.lcappnt_tabinfoform = function(){
	var topvue = getTopvueObj(this);
	if(topvue.formdata.lccont&&topvue.formdata.lccont.commonchannel=="SC"||
			topvue.formdata.lccont&&topvue.formdata.lccont.commonchannel=="RS"){
		if(topvue.formdata.lccont.anotherholder=="Y"){
			alert("购物车流程不支持此联名账户的签署确认方式")
			return false;
		}
	}
	if(topvue.formdata.lcappnt.idtype!= "H" && topvue.formdata.lcappnt.idtype!= "C"){
		if(!(new Date(topvue.formdata.lcappnt.appntenddate)>new Date())){
			alert("证件有效止期必须大于今天");
			return false;
		}
		
	}
	if(topvue.formdata.lcappnt.idtype== "I"){
		  var date = new Date();
	       var seperator1 = "-";
	       var year = date.getFullYear();
	       var month = date.getMonth() + 1;
	       var strDate = date.getDate();
	       if (month >= 1 && month <= 9) {
	           month = "0" + month;
	       }
	       if (strDate >= 0 && strDate <= 9) {
	           strDate = "0" + strDate;
	       }
	       var currentdate = year + seperator1 + month + seperator1 + strDate;
		
		if(topvue.formdata.lcappnt.startingDate==null 
				|| topvue.formdata.lcappnt.startingDate=="" ){
			alert("证件有效起期不可为空");
			return false;
		}
		
		if((new Date(topvue.formdata.lcappnt.startingDate)>new Date(currentdate))){
			alert("证件有效起期必须小于等于当前日期");
			return false;
		}
		if((new Date(topvue.formdata.lcappnt.startingDate))>=
			(new Date(topvue.formdata.lcappnt.appntenddate))){
			alert("证件有效起期必须小于证件有效止期");
			return false;
		}	
	}
	if(topvue.formdata.lcappnt.idtype== "X"){
		if(topvue.formdata.lcappnt.renewCount==null 
				|| topvue.formdata.lcappnt.renewCount=="" ){
			alert("证件为港澳台通行证，换证次数不可为空");
			return false;
		}
		var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.lcappnt.renewCount)).slice(-2);//01
		topvue.$set(topvue.formdata.lcappnt,"renewCount",newrenewcount);
	}
	if(null!=topvue.formdata.subFormData.lccont) {
		initData(getActivePanelDIV(), true);
		var pflag = topvue.formdata.lccont.pageflag;
		fillinObj(topvue, topvue.formdata, topvue.formdata.subFormData, false, 0);
		topvue.formdata.lccont.pageflag = pflag;
		checkPaperChange = true;
	}
	return true;
}

//After save lccont & lcappnt infos
aftersubmitvueform.lcappnt_tabinfoform = function(){
	var recording = initFormdata.newContApply.recording;	
	console.log("***checking Recording flag***=======" + recording);
	if(recording == "Y"){
		console.log("***current Recording changing operation***");
		var topvue = getTopvueObj(this);
		topvue.form_elementsBYID.lccont.proposalcontno.cssClass = "disabled";
		$("#proposalcontno").attr("disabled",true);
		console.log("***diabled proposalcontno***");
	}
	var proposalcontno =vueobj["testdivchange"].formdata.lccont.proposalcontno;
	if(proposalcontno !=null && proposalcontno !=""){
		$('#newcompanyCode').combobox("disable");
		$('#newcitycode').combobox("disable");		
	}
	console.log("***aftersubmitvueform.lcappnt_tabinfoform***");
	return true;
}
//IPS的warningInfo提示框 
afterloadNewElements.lccont_tabinfo=function(){
	var topvue = getTopvueObj(this);
	if(topvue.formdata.quotation.warningInfo.length>0){
		var warningInfo=topvue.formdata.quotation.warningInfo[0].code;
		if(warningInfo=="FPS0026"||warningInfo=="FPS0127"||warningInfo=="FPS0128"){
			alert("未获取到有效的建议书信息，请手动录入投保相关内容");
		}
	}
} 
afterloadNewElements.lcappnt_tabinfo=function(){
	
	setTimeout(function(){
		if(($("#appntrenewCount").is(":visible")||$("#appntrenewCount").length>0)){
   		 $("#appntrenewCountTitle").remove();
   		$("#appntrenewCount").parent().append("<small id='appntrenewCountTitle' class='help-block' style='color: red;'>请注意，" +
   				"请按证件上的换证次数填写，例如：01。</small>");
		 }
	},50);
} 