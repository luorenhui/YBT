/**
 * 需要每个被保人显示的的告知录入项
 */
var noticeinfotype = {
	"lcinsured" : {
		"0":"lcinsured",
		"default":"lcinsuredmulti"
	},
	"noticeDrinkInsu" : "true",
	"noticeInsuinfo" : "true",
	"noticeSmokeInsu" : "true",
	"noticePregnancyInsu" : "true",
//	"noticeinfantInsu" : "true",
	"noticeincomeInsu" : "true",
	"noticeliabilityInsu" : "true",
	"noticelifeInsu" : "true",
	"noticelifeInsuTwo" : "true",
	"noticesimpleInsu" : "true",
//	"noticeminorInsu" : "true",
	"noticeDetaileInsu" : "true",
	"noticeHeightWeightInsu" : "true"
};

var showdilog="";
/**
 * 仅显示一次的
 */
var onlyOneShowtype = {
	"noticeinfantInsu" : "true",
	"noticeminorInsu" : "true"
};


/**
 * 
 * @param noticeid
 * @param type
 *            1主被保險人 2附屬
 */
function hiddenNoticeELements(topvue, noticeid, type, noticeinfoType) {
	if (!noticeinfoType) {
		noticeinfoType = "i";
	}

	var insuquestion = "insuquestion";
	if (noticeinfoType == "q") {

		insuquestion = "noticeInfo";
	}

	if (noticeinfoType == "a") {

		insuquestion = "appntquestion";
	}

	var questionID = noticeid + noticeinfoType + type;
	try {
		// topvue.form_elementsBYID.commonFormNotice[noticeid].insuquestion[questionID].elementstatus="02";
		if (topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID].elementstatus == "02") {
			console.info(noticeid + " 该条告知配置不显示不作处理");

		} else {

			topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID],
				"elementstatus", "04");


		}

	} catch (e) {
		console.info(" error : 告知：" + noticeid + " 所属子元素节点ID配置未找到被保人问题，"
			+ " 请检查告知formelement 的告知配置项 请按照约定进行ID设置 " + noticeid + noticeinfoType
			+ type + " exception:" + e);
	}

	// topvue

}

function showNoticeELements(topvue, noticeid, type, noticeinfoType) {
	if (!noticeinfoType) {
		noticeinfoType = "i";
	}
	var questionID = noticeid + noticeinfoType + type;
	var insuquestion = "insuquestion";
	if (noticeinfoType == "q") {

		insuquestion = "noticeInfo";
	}
	if (noticeinfoType == "a") {

		insuquestion = "appntquestion";
	}
	try {
		if (topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID].elementstatus == "02") {
			console.info(noticeid + " 该条告知配置不显示不作处理");

		} else {

			topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID],
				"elementstatus", "01");

		}
		// topvue.form_elementsBYID.commonFormNotice[noticeid].insuquestion[questionID].elementstatus="02";

	} catch (e) {
		console.info(" error : 告知：" + noticeid + " 所属子元素节点ID配置未找到被保人问题，"
			+ " 请检查告知formelement 的告知配置项 请按照约定进行ID设置 " + noticeid + noticeinfoType
			+ type + " exception:" + e);
	}

	// topvue

}


function showFather(topvue, noticeid) {
	if (topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
		//		topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus  = "04";
		topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid],
			"elementstatus", "01");
	}

}

function hiddenFather(topvue, noticeid) {
	if (topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
		topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid],
			"elementstatus", "04");
	}
}


function hiddenSubRiskFather(topvue, noticeid, risk) {
	if (topvue.form_elementsBYID['subNotice_' + risk.riskcode][noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
		topvue.$set(topvue.form_elementsBYID['subNotice_' + risk.riskcode][noticeid],
			"elementstatus", "04");
	}
}
//隐藏婴幼儿告知
function hiddenAllinfant(topvue, noticeid) {
	hiddenFather(topvue, "notice30");
	hiddenFather(topvue, "notice31");
	hiddenNoticeELements(topvue, "notice30", "1", "i");
	hiddenNoticeELements(topvue, "notice30", "1", "q");
	hiddenNoticeELements(topvue, "notice30", "2", "q");
	hiddenNoticeELements(topvue, "notice31", "1", "a");
	hiddenNoticeELements(topvue, "notice31", "1", "i");
}

//显示婴幼儿告知
function showAllinfant(topvue) {
	showFather(topvue, "notice30");
	showFather(topvue, "notice31");
	showNoticeELements(topvue, "notice30", "1", "i");
	showNoticeELements(topvue, "notice30", "1", "q");
	showNoticeELements(topvue, "notice30", "2", "q");
	showNoticeELements(topvue, "notice31", "1", "a");
	showNoticeELements(topvue, "notice31", "1", "i");
}
/**
 * 控制婴幼儿问题 是否显示
 * @param topvue
 */
function hiddenAllInsuTwo(topvue) {
	hiddenNoticeELements(topvue, "notice1", "3", "q");
	hiddenNoticeELements(topvue, "notice1", "4", "q");
	hiddenNoticeELements(topvue, "notice2", "4", "q");
	hiddenNoticeELements(topvue, "notice2", "5", "q");
	hiddenNoticeELements(topvue, "notice2", "6", "q");
	hiddenNoticeELements(topvue, "notice2", "2", "i");
}

//显示所有的 第二被保人 问题
function showAllInsuTwo(topvue) {
	showNoticeELements(topvue, "notice1", "3", "q");
	showNoticeELements(topvue, "notice1", "4", "q");
	showNoticeELements(topvue, "notice2", "4", "q");
	showNoticeELements(topvue, "notice2", "5", "q");
	showNoticeELements(topvue, "notice2", "6", "q");
	showNoticeELements(topvue, "notice2", "2", "i");

}
/**
 * 控制第二被保人问题 是否显示
 * @param topvue
 */
function checkInsuTwoNotice(topvue) {
	var formdata = topvue.formdata;
	if (formdata['lcinsured']
		&& formdata['lcinsured'].lcinsuredtwoflag
		&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
		&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
		showAllInsuTwo(topvue);
	} else {
		hiddenAllInsuTwo(topvue);

	}
}
function checkinfantNotice(topvue) {
	var formdata = topvue.formdata;
	if (formdata['lcinsured']
		&& formdata['lcinsured'].lcinsuredage
		&& formdata['lcinsured'].lcinsuredage < 2) {
		showAllinfant(topvue);
	} else {
		hiddenAllinfant(topvue);

	}
}
//隐藏未成年人告知
function hiddenAllsimple(topvue, noticeid) {
	hiddenFather(topvue, "notice49");
	hiddenFather(topvue, "notice50");
	hiddenFather(topvue, "notice51");
	hiddenFather(topvue, "notice52");
	hiddenNoticeELements(topvue, "notice50", "1", "q");
	hiddenNoticeELements(topvue, "notice51", "1", "q");
	hiddenNoticeELements(topvue, "notice52", "1", "q");
}

//显示未成年人告知
function showAllsimple(topvue) {
	showFather(topvue, "notice49");
	showFather(topvue, "notice50");
	showFather(topvue, "notice51");
	showFather(topvue, "notice52");
	showNoticeELements(topvue, "notice50", "1", "q");
	showNoticeELements(topvue, "notice51", "1", "q");
	showNoticeELements(topvue, "notice52", "1", "q");
}
/**
 * 控制未成年人问题 是否显示
 * @param topvue
 */
function checksimpleNotice(topvue) {
	var formdata = topvue.formdata;
	if (formdata['lcinsured']
		&& formdata['lcinsured'].lcinsuredage
		&& formdata['lcinsured'].lcinsuredage < 18) {
		showAllsimple(topvue);
	} else {
		hiddenAllsimple(topvue);

	}
}




afterloadNewElements.lcbnf_tabinfo = function(url, form_element) {

	try {
// 		 this.$nextTick(function(){
// 		     setTimeout(function(){
// 		    	 for (var i=0;i<$("input[id^='bnfrenewCount']").length;i++){
// 		    		 if(($("#bnfrenewCount\\["+i+"\\]").is(":visible") && $("#bnfrenewCountTitle"+i+"").length <= 0)){
// 	    		   		$("#bnfrenewCount\\["+i+"\\]").parent().append("<small id='bnfrenewCountTitle"+i+"' class='help-block zhq' style='color: red;'>请注意，" +
// 	    		   				"请按证件上的换证次数填写，例如：01。</small>");
// 	    				 }
// 	    	 }
// 		     },200);
// 			});
// 			$("input[value='增加新受益人']").click(function(){
// 				 setTimeout(function(){
// 					 if(($("#bnfrenewCount\\["+(vueobj["testdivchange"].formdata['bnf'].length-1)+"\\]").is(":visible")
// 							 && $("#bnfrenewCountTitle"+(vueobj["testdivchange"].formdata['bnf'].length-1)+"").length <= 0)){
// 					 $("#bnfrenewCount\\["+(vueobj["testdivchange"].formdata['bnf'].length-1)+"\\]").parent().append("<small id='bnfrenewCountTitle"+(vueobj["testdivchange"].formdata['bnf'].length-1)+"' class='help-block zhq' style='color: red;'>请注意，" +
// 	   				"请按证件上的换证次数填写，例如：01。</small>");
// 					 }
// 				 },200);
// })
		
		var topvue = getTopvueObj(this);
		showBelongInsu(topvue);
	} catch (e) {

		console.info("afterloadNewElements.lcbnf_tabinfo : " + e);
	}

};

afterloadNewElements.subriskcode_tabinfo = function(url, form_element) {

	try {
		var topvue = getTopvueObj(this);
		showBelongInsu(topvue);
	} catch (e) {
		console.info("afterloadNewElements.subriskcode_tabinfo : " + e);
	}

};

/***
 * 控制特殊告知显示
 * @param topvue
 * @returns {Boolean}
 */
function showELementSByInsu(topvue) {
	try {

		var formdata = topvue.formdata;
		var lcappntsex = formdata['lcappnt'].appntsex;
		var lcinsuredsex = formdata['lcinsured'].lcinsuredsex;
		if (lcappntsex == '1' && lcinsuredsex == '1') {
			showFather(topvue, "notice28");
			showFather(topvue, "notice29");
			showNoticeELements(topvue, "notice28", "1", "a");
			showNoticeELements(topvue, "notice28", "1", "i");
			showNoticeELements(topvue, "notice28", "1", "q");
			showNoticeELements(topvue, "notice29", "1", "a");
			showNoticeELements(topvue, "notice29", "1", "i");
		} else {
			if (lcappntsex == '1') {
				showFather(topvue, "notice28");
				showNoticeELements(topvue, "notice28", "1", "a");
				showNoticeELements(topvue, "notice28", "1", "q");
				hiddenNoticeELements(topvue, "notice28", "1", "i");
				showFather(topvue, "notice29");
				showNoticeELements(topvue, "notice29", "1", "a");
				hiddenNoticeELements(topvue, "notice29", "1", "i");
			} else if (lcinsuredsex == '1') {
				showFather(topvue, "notice28");
				showNoticeELements(topvue, "notice28", "1", "q");
				showNoticeELements(topvue, "notice28", "1", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "a");
				showFather(topvue, "notice29");
				hiddenNoticeELements(topvue, "notice29", "1", "a");
				showNoticeELements(topvue, "notice29", "1", "i");
			} else {
				hiddenFather(topvue, "notice28");
				hiddenNoticeELements(topvue, "notice28", "1", "a");
				hiddenNoticeELements(topvue, "notice28", "1", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "q");
				hiddenFather(topvue, "notice29");
				hiddenNoticeELements(topvue, "notice29", "1", "a");
				hiddenNoticeELements(topvue, "notice29", "1", "i");
			}
		}

	} catch (e) {
		// TODO: handle exception
	}

	return true;
}
/***
 * 控制特殊告知显示
 * @param topvue
 * @returns {Boolean}
 */
var maininsuAge = "";
var twoinsuAge = "";
function showELementSByInsuTWo(topvue) {
	try {
		if (!topvue.form_elements.commonFormNotice) {
			return true;
		}
		var formdata = topvue.formdata;
		var lcappntsex = formdata['lcappnt'].appntsex;
		var lcinsuredsex = formdata['lcinsured'].lcinsuredsex;
		var hasInsuTwoFlag = false;
		try {
			if (formdata['lcinsured']
				&& formdata['lcinsured'].lcinsuredtwoflag
				&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
				&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
				twoinsuAge = getAgeFromBrithday(topvue.formdata.lcinsuredtwo.lcinsuredbirthday); // 年龄
				hasInsuTwoFlag = true;
			}
		} catch (e) {
			console.info("error : 附属被保险人 年龄 获取 失败 " + e);
		}
		var twoinsuSex = '0';
		if (hasInsuTwoFlag) {
			twoinsuSex = topvue.formdata.lcinsuredtwo.lcinsuredsex;

		}
		if (lcappntsex == '1' && lcinsuredsex == '1' && twoinsuSex == '1') {
			showFather(topvue, "notice28");
			showFather(topvue, "notice29");
			showNoticeELements(topvue, "notice28", "1", "a");
			showNoticeELements(topvue, "notice28", "1", "i");
			showNoticeELements(topvue, "notice28", "2", "i");
			hiddenNoticeELements(topvue, "notice28", "1", "q");
			showNoticeELements(topvue, "notice28", "2", "q");
			showNoticeELements(topvue, "notice28", "3", "q");
			showNoticeELements(topvue, "notice28", "4", "q");
			showNoticeELements(topvue, "notice29", "1", "a");
			showNoticeELements(topvue, "notice29", "1", "i");
			showNoticeELements(topvue, "notice29", "2", "i");
		} else {
			if (lcappntsex == '1' && lcinsuredsex == '1') {
				showFather(topvue, "notice28");
				showNoticeELements(topvue, "notice28", "1", "a");
				showNoticeELements(topvue, "notice28", "2", "q");
				showNoticeELements(topvue, "notice28", "1", "i");
				showNoticeELements(topvue, "notice28", "3", "q");
				hiddenNoticeELements(topvue, "notice28", "2", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "q");
				hiddenNoticeELements(topvue, "notice28", "4", "q");
				showFather(topvue, "notice29");
				showNoticeELements(topvue, "notice29", "1", "a");
				showNoticeELements(topvue, "notice29", "1", "i");
				hiddenNoticeELements(topvue, "notice29", "2", "i");

			} else if (lcappntsex == '1' && twoinsuSex == '1') {

				showFather(topvue, "notice28");
				showNoticeELements(topvue, "notice28", "1", "a");
				showNoticeELements(topvue, "notice28", "2", "q");
				hiddenNoticeELements(topvue, "notice28", "1", "i");
				hiddenNoticeELements(topvue, "notice28", "3", "q");
				showNoticeELements(topvue, "notice28", "2", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "q");
				showNoticeELements(topvue, "notice28", "4", "q");
				showFather(topvue, "notice29");
				showNoticeELements(topvue, "notice29", "1", "a");
				hiddenNoticeELements(topvue, "notice29", "1", "i");
				showNoticeELements(topvue, "notice29", "2", "i");
			} else if (lcinsuredsex == '1' && twoinsuSex == '1') {
				showFather(topvue, "notice28");
				hiddenNoticeELements(topvue, "notice28", "1", "a");
				hiddenNoticeELements(topvue, "notice28", "2", "q");
				showNoticeELements(topvue, "notice28", "1", "i");
				showNoticeELements(topvue, "notice28", "3", "q");
				showNoticeELements(topvue, "notice28", "2", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "q");
				showNoticeELements(topvue, "notice28", "4", "q");
				showFather(topvue, "notice29");
				hiddenNoticeELements(topvue, "notice29", "1", "a");
				showNoticeELements(topvue, "notice29", "1", "i");
				showNoticeELements(topvue, "notice29", "2", "i");
			} else if (lcappntsex == '1') {
				showFather(topvue, "notice28");
				showNoticeELements(topvue, "notice28", "1", "a");
				showNoticeELements(topvue, "notice28", "2", "q");
				hiddenNoticeELements(topvue, "notice28", "1", "i");
				hiddenNoticeELements(topvue, "notice28", "3", "q");
				hiddenNoticeELements(topvue, "notice28", "2", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "q");
				hiddenNoticeELements(topvue, "notice28", "4", "q");
				showFather(topvue, "notice29");
				showNoticeELements(topvue, "notice29", "1", "a");
				hiddenNoticeELements(topvue, "notice29", "1", "i");
				hiddenNoticeELements(topvue, "notice29", "2", "i");
			} else if (lcinsuredsex == '1') {
				showFather(topvue, "notice28");
				hiddenNoticeELements(topvue, "notice28", "1", "a");
				hiddenNoticeELements(topvue, "notice28", "2", "q");
				showNoticeELements(topvue, "notice28", "1", "i");
				showNoticeELements(topvue, "notice28", "3", "q");
				hiddenNoticeELements(topvue, "notice28", "2", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "q");
				hiddenNoticeELements(topvue, "notice28", "4", "q");
				showFather(topvue, "notice29");
				hiddenNoticeELements(topvue, "notice29", "1", "a");
				showNoticeELements(topvue, "notice29", "1", "i");
				hiddenNoticeELements(topvue, "notice29", "2", "i");
			} else if (twoinsuSex == '1') {
				showFather(topvue, "notice28");
				hiddenNoticeELements(topvue, "notice28", "1", "a");
				hiddenNoticeELements(topvue, "notice28", "2", "q");
				hiddenNoticeELements(topvue, "notice28", "1", "i");
				hiddenNoticeELements(topvue, "notice28", "3", "q");
				showNoticeELements(topvue, "notice28", "2", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "q");
				showNoticeELements(topvue, "notice28", "4", "q");
				showFather(topvue, "notice29");
				hiddenNoticeELements(topvue, "notice29", "1", "a");
				hiddenNoticeELements(topvue, "notice29", "1", "i");
				showNoticeELements(topvue, "notice29", "2", "i");
			} else {

				hiddenFather(topvue, "notice28");
				hiddenNoticeELements(topvue, "notice28", "1", "a");
				hiddenNoticeELements(topvue, "notice28", "2", "q");
				hiddenNoticeELements(topvue, "notice28", "1", "i");
				hiddenNoticeELements(topvue, "notice28", "3", "q");
				hiddenNoticeELements(topvue, "notice28", "2", "i");
				hiddenNoticeELements(topvue, "notice28", "1", "q");
				hiddenNoticeELements(topvue, "notice28", "4", "q");
				hiddenFather(topvue, "notice29");
				hiddenNoticeELements(topvue, "notice29", "1", "a");
				hiddenNoticeELements(topvue, "notice29", "1", "i");
				hiddenNoticeELements(topvue, "notice29", "2", "i");
			}
		}
		//婴幼儿告知
		if (hasInsuTwoFlag) {
			if (maininsuAge <= 2 && twoinsuAge <= 2) {
				showFather(topvue, "notice30");
				showFather(topvue, "notice31");
				showNoticeELements(topvue, "notice30", "1", "i");
				showNoticeELements(topvue, "notice30", "2", "i");
				showNoticeELements(topvue, "notice30", "1", "q");
				showNoticeELements(topvue, "notice30", "2", "q");
				showNoticeELements(topvue, "notice31", "1", "i");
				showNoticeELements(topvue, "notice31", "2", "i");
			} else if (twoinsuAge <= 2) {
				showFather(topvue, "notice30");
				showFather(topvue, "notice31");
				hiddenNoticeELements(topvue, "notice30", "1", "i");
				showNoticeELements(topvue, "notice30", "2", "i");
				showNoticeELements(topvue, "notice30", "1", "q");
				showNoticeELements(topvue, "notice30", "2", "q");
				hiddenNoticeELements(topvue, "notice31", "1", "i");
				showNoticeELements(topvue, "notice31", "2", "i");
			} else {
				hiddenFather(topvue, "notice30");
				hiddenFather(topvue, "notice31");
				hiddenNoticeELements(topvue, "notice30", "1", "i");
				hiddenNoticeELements(topvue, "notice30", "2", "i");
				hiddenNoticeELements(topvue, "notice30", "1", "q");
				hiddenNoticeELements(topvue, "notice30", "2", "q");
				hiddenNoticeELements(topvue, "notice31", "1", "i");
				hiddenNoticeELements(topvue, "notice31", "2", "i");
			}
		} else {
			if (maininsuAge <= 2) {
				showFather(topvue, "notice30");
				showFather(topvue, "notice31");
				showNoticeELements(topvue, "notice30", "1", "i");
				hiddenNoticeELements(topvue, "notice30", "2", "i");
				showNoticeELements(topvue, "notice30", "1", "q");
				showNoticeELements(topvue, "notice30", "2", "q");
				showNoticeELements(topvue, "notice31", "1", "i");
				hiddenNoticeELements(topvue, "notice31", "2", "i");
			} else {
				hiddenFather(topvue, "notice30");
				hiddenFather(topvue, "notice31");
				hiddenNoticeELements(topvue, "notice30", "1", "i");
				hiddenNoticeELements(topvue, "notice30", "2", "i");
				hiddenNoticeELements(topvue, "notice30", "1", "q");
				hiddenNoticeELements(topvue, "notice30", "2", "q");
				hiddenNoticeELements(topvue, "notice31", "1", "i");
				hiddenNoticeELements(topvue, "notice31", "2", "i");
			}
		}
		if (hasInsuTwoFlag) {
			if (maininsuAge < 18 || twoinsuAge < 18) {
				showFather(topvue, "notice49");
				showFather(topvue, "notice50");
				showFather(topvue, "notice51");
				showFather(topvue, "notice52");
				showNoticeELements(topvue, "notice50", "1", "q");
				showNoticeELements(topvue, "notice51", "1", "q");
				showNoticeELements(topvue, "notice52", "1", "q");
			} else {
				hiddenFather(topvue, "notice49");
				hiddenFather(topvue, "notice50");
				hiddenFather(topvue, "notice51");
				hiddenFather(topvue, "notice52");
				hiddenNoticeELements(topvue, "notice50", "1", "q");
				hiddenNoticeELements(topvue, "notice51", "1", "q");
				hiddenNoticeELements(topvue, "notice52", "1", "q");
			}
		} else {
			if (maininsuAge < 18) {
				showFather(topvue, "notice49");
				showFather(topvue, "notice50");
				showFather(topvue, "notice51");
				showFather(topvue, "notice52");
				showNoticeELements(topvue, "notice50", "1", "q");
				showNoticeELements(topvue, "notice51", "1", "q");
				showNoticeELements(topvue, "notice52", "1", "q");
			} else {
				hiddenFather(topvue, "notice49");
				hiddenFather(topvue, "notice50");
				hiddenFather(topvue, "notice51");
				hiddenFather(topvue, "notice52");
				hiddenNoticeELements(topvue, "notice50", "1", "q");
				hiddenNoticeELements(topvue, "notice51", "1", "q");
				hiddenNoticeELements(topvue, "notice52", "1", "q");
			}
		}
		//吸烟smoke
		if (hasInsuTwoFlag) {
			/*showFather(topvue,"notice21");*/
			showNoticeELements(topvue, "notice21", "2", "i");
			showNoticeELements(topvue, "notice21", "5", "q");
			showNoticeELements(topvue, "notice21", "6", "q");
			showNoticeELements(topvue, "notice21", "7", "q");
			showNoticeELements(topvue, "notice21", "8", "q");
		} else {
			/*hiddenFather(topvue,"notice21");*/
			hiddenNoticeELements(topvue, "notice21", "2", "i");
			hiddenNoticeELements(topvue, "notice21", "5", "q");
			hiddenNoticeELements(topvue, "notice21", "6", "q");
			hiddenNoticeELements(topvue, "notice21", "7", "q");
			hiddenNoticeELements(topvue, "notice21", "8", "q");
		}
		//饮酒drink
		if (hasInsuTwoFlag) {
			/*	showFather(topvue,"notice22");*/
			showNoticeELements(topvue, "notice22", "2", "i");
			showNoticeELements(topvue, "notice22", "7", "q");
			showNoticeELements(topvue, "notice22", "8", "q");
			showNoticeELements(topvue, "notice22", "9", "q");
			showNoticeELements(topvue, "notice22", "10", "q");
			showNoticeELements(topvue, "notice22", "11", "q");
			showNoticeELements(topvue, "notice22", "12", "q");
		} else {
			/*hiddenFather(topvue,"notice22");*/
			hiddenNoticeELements(topvue, "notice22", "2", "i");
			hiddenNoticeELements(topvue, "notice22", "7", "q");
			hiddenNoticeELements(topvue, "notice22", "8", "q");
			hiddenNoticeELements(topvue, "notice22", "9", "q");
			hiddenNoticeELements(topvue, "notice22", "10", "q");
			hiddenNoticeELements(topvue, "notice22", "11", "q");
			hiddenNoticeELements(topvue, "notice22", "12", "q");
		}
		//保险公司
		if (hasInsuTwoFlag) {
			/*	showFather(topvue,"notice22");*/
			showNoticeELements(topvue, "notice40", "2", "i");
			showNoticeELements(topvue, "notice40", "12", "q");
			showNoticeELements(topvue, "notice40", "13", "q");
			showNoticeELements(topvue, "notice40", "14", "q");
			showNoticeELements(topvue, "notice40", "15", "q");
			showNoticeELements(topvue, "notice40", "16", "q");
			showNoticeELements(topvue, "notice40", "17", "q");
			showNoticeELements(topvue, "notice40", "18", "q");
			showNoticeELements(topvue, "notice40", "19", "q");
			showNoticeELements(topvue, "notice40", "20", "q");
			showNoticeELements(topvue, "notice40", "21", "q");
			showNoticeELements(topvue, "notice40", "22", "q");
			showNoticeELements(topvue, "notice40", "23", "q");
		} else {
			/*hiddenFather(topvue,"notice22");*/
			hiddenNoticeELements(topvue, "notice40", "2", "i");
			hiddenNoticeELements(topvue, "notice40", "12", "q");
			hiddenNoticeELements(topvue, "notice40", "13", "q");
			hiddenNoticeELements(topvue, "notice40", "14", "q");
			hiddenNoticeELements(topvue, "notice40", "15", "q");
			hiddenNoticeELements(topvue, "notice40", "16", "q");
			hiddenNoticeELements(topvue, "notice40", "17", "q");
			hiddenNoticeELements(topvue, "notice40", "18", "q");
			hiddenNoticeELements(topvue, "notice40", "19", "q");
			hiddenNoticeELements(topvue, "notice40", "20", "q");
			hiddenNoticeELements(topvue, "notice40", "21", "q");
			hiddenNoticeELements(topvue, "notice40", "22", "q");
			hiddenNoticeELements(topvue, "notice40", "23", "q");
		}
	} catch (e) {
		// TODO: handle exception
	}

	return true;

}




//多被保人控制显示与否0男1女
//女性告知notice28(23),notice29(24)
//婴幼儿告知notice30(25),notice31(26)
//未成年告知notice49(42),notice50(43),notice51(44),notice52(45)
function isBaby(age) {
	if (age <= 2)
		return true
	else
		return false

}
function isAdult(age) {
	if (age < 18)
		return false
	else
		return true
}
//身高体重
//新产品页面改造前，原来页面存值告知回显特殊处理
function statureAndAvoirdupois(topvue){
	var RC_index = null;
	// var R0_index = 0;
	for (var i = 0; i < topvue.formdata.sublcpols.length; i++){
		if (topvue.formdata.sublcpols[i].riskcode=='@RC'){
			RC_index = i+1;
		}
		// if (topvue.formdata.sublcpols.riskcode=='@R0'){
		// 	R0_index = i+1;
		// }
	}
	var stature = null;
	var avoirdupois = null;
	if (topvue.formdata.sublcpols.length>0&&topvue.formdata.sublcpols[0].riskcode!=undefined){
		for (var i = 0; i < topvue.formdata.lcinsuredmulti.length; i++) {
			var stature1 = topvue.formdata.lcinsuredmulti[i].stature;
			var avoirdupois1 = topvue.formdata.lcinsuredmulti[i].avoirdupois;
			if (stature1!=null&&avoirdupois1!=null){
				stature = stature1;
				avoirdupois = avoirdupois1;
			}
		}
	}else{
		var stature2 = topvue.formdata.lcinsured.stature;
		var avoirdupois2 = topvue.formdata.lcinsured.avoirdupois;
		if (stature2!=null&&avoirdupois2!=null){
			stature = stature2;
			avoirdupois = avoirdupois2;
		}
	}
	if (topvue.formdata.noticeHeightWeightInsus.length!=0){
		for (var i = 0; i < topvue.formdata.noticeHeightWeightInsus.length; i++) {
			if (null==topvue.formdata.noticeHeightWeightInsus[i].noticeinfo1){
				if (stature!=null){
					if (i==RC_index){
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeHeightWeightInsus[i], "noticeinfo1", stature);
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeHeightWeightInsus[i], "noticeinfo2", avoirdupois);
						console.log("新产品页面改造前，@RC保存的告知index:"+RC_index+"，身高:"+stature+"体重:"+avoirdupois);
					}else{
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeHeightWeightInsus[i], "noticeinfo1", stature);
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeHeightWeightInsus[i], "noticeinfo2", avoirdupois);
						console.log("1新产品页面改造前，主险保存的告知，身高:"+stature+"体重:"+avoirdupois);
					}
				}
			}
		}
	}else{
		if (stature!=null&&null==topvue.formdata.noticeHeightWeightInsu.noticeinfo1){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeHeightWeightInsu, "noticeinfo1", stature);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeHeightWeightInsu, "noticeinfo2", avoirdupois);
			console.log("2新产品页面改造前，主险保存的告知，身高:"+stature+"体重:"+avoirdupois);
		}
	}
}
function checkELementSByInsuMuti(topvue, specialRisk) {
	var maininsuAge = topvue.formdata.lcinsured.lcinsuredage; // 主被保险人年龄
	var maininsuSex = topvue.formdata.lcinsured.lcinsuredsex; // 主被保险人性别
	var appntAge = getAgeFromBrithday(topvue.formdata.lcappnt.appntbirthday); // 投保人年龄
	var appntSex = topvue.formdata.lcappnt.appntsex; // 投保人性别

	var main_mutinum = topvue.formdata.mainriskinsus.length; //除去主被保人的多被保人个数
	var mutinum = topvue.formdata.subriskinsus.length; //附加险被保人的多被保人个数

	var main_mutiage_container = []; //年龄 主险被保人
	var main_mutisex_container = []; //0男1女 主险被保人
	
	var mutiage_container = []; //年龄 附加险被保人
	var mutisex_container = []; //0男1女 附加险被保人

	
	//主被保人
	for (var i = 0; i < main_mutinum; i++) {
		main_mutiage_container.push(getAgeFromBrithday(topvue.formdata.mainriskinsus[i].lcinsuredbirthday));
		main_mutisex_container.push(topvue.formdata.mainriskinsus[i].lcinsuredsex);

		// if(i==0){
		// 	main_mutiage_container.push(maininsuAge);
		// 	main_mutisex_container.push(maininsuSex);
		// }else{
		// 	if (!topvue.formdata.lcinsuredmulti[i-1].lcinsuredidno) {
		// 		main_mutinum = main_mutinum - 1;
		// 		continue;
		// 	}
		//
		// 	main_mutiage_container.push(getAgeFromBrithday(topvue.formdata.lcinsuredmulti[i-1].lcinsuredbirthday));
		// 	main_mutisex_container.push(topvue.formdata.lcinsuredmulti[i-1].lcinsuredsex);
		// }
		
	}
	
	//附属被保人
	for (var i = 0; i < mutinum; i++) {
		mutiage_container.push(getAgeFromBrithday(topvue.formdata.subriskinsus[i].lcinsuredbirthday));
		mutisex_container.push(topvue.formdata.subriskinsus[i].lcinsuredsex)

		// if (topvue.formdata.lcinsuredmulti.length>0){
		// 	if (!topvue.formdata.lcinsuredmulti[i-1+topvue.formdata.mainriskinsus.length].lcinsuredidno) {
		// 		mutinum = mutinum - 1;
		// 		continue;
		// 	}
		// 	mutiage_container.push(getAgeFromBrithday(topvue.formdata.lcinsuredmulti[i-1+topvue.formdata.mainriskinsus.length].lcinsuredbirthday));
		// 	mutisex_container.push(topvue.formdata.lcinsuredmulti[i-1+topvue.formdata.mainriskinsus.length].lcinsuredsex);
		// }
	}
	//这里特殊处理，因为该产品没有主被保人告知，和投保人告知
	//放在校验是否全部隐藏逻辑里不合理，但不放在逻辑里以后不完整
	//	maininsuSex=0
	//maininsuAge=19
	//	appntSex=0
	//	appntAge=19

	//@RC女性告知特殊处理
	for (var i = 0; i < topvue.formdata.sublcpols.length; i++){
		var riskcode = topvue.formdata.sublcpols[i].riskcode;
		var riskbelong = topvue.formdata.sublcpols[i].riskbelong;
		for (let j = 0; j < topvue.formdata.subriskinsus.length; j++) {
			var sex = topvue.formdata.subriskinsus[j].lcinsuredsex;
			var subriskid = topvue.formdata.subriskinsus[j].lcinsuredid;
			if (specialRisk != undefined) {
				if(riskcode=="@RC"&&subriskid==riskbelong&&sex!="1"){
					hiddenSubRiskFather(topvue, "notice28", specialRisk);
					hiddenSubRiskFather(topvue, "notice29", specialRisk);
				}
			}
		}
	}


	//主险女性告知控制
	/*全是男的隐藏所有告知*/
	if (appntSex != "1" && main_mutisex_container.indexOf("1") == -1) {
		hiddenFather(topvue, "notice28");
		hiddenFather(topvue, "notice29");
		/*if (specialRisk != undefined) {

			hiddenSubRiskFather(topvue, "notice28", specialRisk);
			hiddenSubRiskFather(topvue, "notice29", specialRisk);
		}*/ 
	} else {
//		//主被保人
//		if (main_mutisex_container[0] != "1") {
//			$("input[name='AS23_noticeinfos0.insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("input[name='AS24_noticeinfos0.insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("input[name='AS23_noticePregnancyInsu" + (0) + ".noticeinfo1']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("#div_notice28q123").hide();
//
//			$("#insuTextHead_23_1").hide();
//		}
		if (appntSex != "1") {
			$("input[name='AS23_noticeinfos[0].owneryesorno']").parentsUntil("div.form-group-div").parent("div").hide();
			$("input[name='AS24_noticeinfos[0].owneryesorno']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("#div_notice28q123").hide();
		}
		
		//主险被保人
		for (var i = 0; i < main_mutinum; i++) {
			if (main_mutisex_container[i] != "1") {

				//				AS23_noticeinfos2.insuredyesorno
				$("input[name='AS23_noticeinfos[" + (i) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS24_noticeinfos[" + (i) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS23_noticeinfos" + (i) + ".insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS24_noticeinfos" + (i) + ".insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS23_noticePregnancyInsu" + (i) + ".noticeinfo1']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS24_noticePregnancyInsu" + (i) + ".noticeinfo1']").parentsUntil("div.form-group-div").parent("div").hide();
				$("#insuTextHead_23_" + (i + 1)).hide();

			//				$("#div_multipregnanttime"+i).parent().parent().parent().hide();
			}
		}
		//特殊处理，如果投保人是女性，告知配置不显示。被保人是男性，需要隐藏女性告知
		if (topvue.form_elementsBYID.commonFormNotice["notice28"].child_elements.appntquestion.length!=0&&topvue.form_elementsBYID.commonFormNotice["notice28"].child_elements.appntquestion[0].elementstatus=='02'&&main_mutisex_container.indexOf("1") == -1){
			hiddenFather(topvue, "notice28");
			hiddenFather(topvue, "notice29");
		}
		
	}
	//附加险被保人女性告知，目前是一个附加险对应一个被保人
	if (specialRisk != undefined  ) {
		if(mutisex_container.indexOf("1") == -1){
			hiddenSubRiskFather(topvue, "notice28", specialRisk);
			hiddenSubRiskFather(topvue, "notice29", specialRisk);
		}else{
			for (var i = 0; i < mutinum; i++) {
				if (mutisex_container[i] != "1") {
					//				AS23_noticeinfos2.insuredyesorno
					$("input[name='AS23_noticeinfos[" + (i + main_mutinum) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS24_noticeinfos[" + (i + main_mutinum) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS23_noticeinfos" + (i + main_mutinum) + ".insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS24_noticeinfos" + (i + main_mutinum) + ".insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS23_noticePregnancyInsu" + (i + main_mutinum) + ".noticeinfo1']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS24_noticePregnancyInsu" + (i + main_mutinum) + ".noticeinfo1']").parentsUntil("div.form-group-div").parent("div").hide();
					$("#insuTextHead_23_" + (i + 1+ main_mutinum)).hide();

					//				$("#div_multipregnanttime"+i).parent().parent().parent().hide();
				}
			}

		}

	}
	
	

	//未成年告知
	var AllAdult = true
	//附加险
	var sub_AllAdult = true
	//主险被保人
	for (var i = 0; i < main_mutinum; i++) {
		if (!isAdult(main_mutiage_container[i])) {
			AllAdult = false
		}
	}
	
	for (var i = 0; i < mutinum; i++) {
		if (!isAdult(mutiage_container[i])) {
			sub_AllAdult = false
		}
	}

	//主险被保人未成年告知
	if (isAdult(appntAge) && AllAdult) {
		hiddenFather(topvue, "notice49");
		hiddenFather(topvue, "notice50");
		hiddenFather(topvue, "notice51");
		hiddenFather(topvue, "notice52");

		
	} else {
//		if (isAdult(maininsuAge)) {
//			$("input[name='AS42_noticeinfos[0].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("input[name='AS43_noticeinfos[0].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("input[name='AS44_noticeinfos[0].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("input[name='AS45_noticeinfos[0].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("#insuTextHead_42_1").hide();
//			$("#insuTextHead_43_1").hide();
//			$("#insuTextHead_44_1").hide();
//			$("#insuTextHead_45_1").hide();
//		}
		
		for (var i = 0; i < main_mutinum; i++) {
			if (main_mutiage_container[i] >= 18) {
				$("input[name='AS42_noticeinfos[" + (i ) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS43_noticeinfos[" + (i ) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS44_noticeinfos[" + (i ) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS45_noticeinfos[" + (i ) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("#insuTextHead_42_" + (i + 1)).hide();
				$("#insuTextHead_43_" + (i + 1)).hide();
				$("#insuTextHead_44_" + (i + 1)).hide();
				$("#insuTextHead_45_" + (i + 1)).hide();
			}
		}

		
	}
	
	//附加险被保人未成年告知，目前是一个附加险对应一个被保人
	if (specialRisk != undefined) {
		
		if(sub_AllAdult){
			hiddenSubRiskFather(topvue, "notice49", specialRisk);
			hiddenSubRiskFather(topvue, "notice50", specialRisk);
			hiddenSubRiskFather(topvue, "notice51", specialRisk);
			hiddenSubRiskFather(topvue, "notice52", specialRisk);
		}else{
			for (var i = 0; i < mutinum; i++) {
				if (mutiage_container[i] >= 18) {
					$("input[name='AS42_noticeinfos[" + (i  +main_mutinum) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS43_noticeinfos[" + (i  +main_mutinum) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS44_noticeinfos[" + (i  +main_mutinum) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS45_noticeinfos[" + (i  +main_mutinum) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("#insuTextHead_42_" + (i + 1 +main_mutinum)).hide();
					$("#insuTextHead_43_" + (i + 1 +main_mutinum)).hide();
					$("#insuTextHead_44_" + (i + 1 +main_mutinum)).hide();
					$("#insuTextHead_45_" + (i + 1 +main_mutinum)).hide();
				}
			}
		}

	}
	
	
	
	//婴儿告知 notice30(25),notice31(26)
	var AllNotBaby = true
	var sub_AllNotBaby = true
	for (var i = 0; i < main_mutinum; i++) {
		if (isBaby(main_mutiage_container[i])) {
			AllNotBaby = false
		}
	}
	
	for (var i = 0; i < mutinum; i++) {
		if (isBaby(mutiage_container[i])) {
			sub_AllNotBaby = false
		}
	}

	////主险被保人婴幼儿告知
	if (!isBaby(appntAge)  && AllNotBaby) {
		hiddenFather(topvue, "notice30");
		hiddenFather(topvue, "notice31");
		
	} else {
//		if (!isBaby(maininsuAge)) {
//			//			$("input[name='AS25_noticeinfos[0].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
//			$("input[name='AS26_noticeinfos[0].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
//
//			$("input[name='AS25_noticeinfantInsu" + (0) + ".noticeinfo1']").parentsUntil("div.form-group-div").parent("div").hide();
//			$("input[name='AS25_noticeinfantInsu" + (0) + ".noticeinfo2']").parentsUntil("div.form-group-div").parent("div").hide();
//
//			$("#insuTextHead_25_1").hide();
//		}
		for (var i = 0; i < main_mutinum; i++) {
			if (main_mutiage_container[i] > 2) {
				//				$("input[name='AS25_noticeinfos["+(i+1)+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS26_noticeinfos[" + (i) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS25_noticeinfantInsu" + (i) + ".noticeinfo1']").parentsUntil("div.form-group-div").parent("div").hide();
				$("input[name='AS25_noticeinfantInsu" + (i) + ".noticeinfo2']").parentsUntil("div.form-group-div").parent("div").hide();
				$("#insuTextHead_25_" + (i + 1)).hide();
			}
		}
		
	}

	//附加险被保人婴幼儿告知，目前是一个附加险对应一个被保人
	if (specialRisk != undefined) {
		
		if(sub_AllNotBaby){
			hiddenSubRiskFather(topvue, "notice30", specialRisk);
			hiddenSubRiskFather(topvue, "notice31", specialRisk);
		}else{

			for (var i = 0; i < mutinum; i++) {
				if (mutiage_container[i] > 2) {
					//				$("input[name='AS25_noticeinfos["+(i+1)+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS26_noticeinfos[" + (i  +main_mutinum) + "].insuredyesorno']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS25_noticeinfantInsu" + (i  +main_mutinum) + ".noticeinfo1']").parentsUntil("div.form-group-div").parent("div").hide();
					$("input[name='AS25_noticeinfantInsu" + (i  +main_mutinum) + ".noticeinfo2']").parentsUntil("div.form-group-div").parent("div").hide();
					$("#insuTextHead_25_" + (i +1 +main_mutinum)).hide();
				}
			}
		}
		//特殊处理附加险对应的被保人不是婴幼儿隐藏告知，这是是附加险对应一个被保人情况
		for (let i = 0; i < topvue.formdata.subriskinsus.length; i++) {
			if (topvue.formdata.subriskinsus[i].lcinsuredid==specialRisk.riskbelong){
				if (topvue.formdata.subriskinsus[i].lcinsuredage>2){
					hiddenSubRiskFather(topvue, "notice30", specialRisk);
					hiddenSubRiskFather(topvue, "notice31", specialRisk);
				}
			}
		}

	}


}
var afterInitTab = {

};
// 告知加载后的处理
afterInitTab.notice_tabinfo = function() {
	var topvue = getTopvueObj(this);
	if (this.formdata.newContApply.investment != 'N') {
		if ($("#tab_notice_tabinfo").attr("class") == "active") { //所有逻辑卸载这里，避免多余的触发
			if ($("#notice_tabinfoform").data('bootstrapValidator') != null &&
				$("#notice_tabinfoform").data('bootstrapValidator') != undefined) {
				$("#notice_tabinfoform").data('bootstrapValidator').resetForm();
			}
			if (this.formdata.newContApply.investment == 'M') {
				//HideFirstInsu(topvue);
				try {
					//checkELementSByInsuMuti(topvue);
				} catch (e) {}
			}

		}

	}
	
	$(".maintoice_content").show();
	
}
var investment = "";
afterloadNewElements.notice_tabinfo = function(url, form_element) {
	showdilog= layer.load(0, {
			  shade: [0.1,'#fff'] //0.1透明度的白色背景
		   });
	console.info(" 告知加载后的处理");


	var topvue = getTopvueObj(this);
	setMainriskAndSubRisk(topvue.formdata);
	maininsuAge = getAgeFromBrithday(topvue.formdata.lcinsured.lcinsuredbirthday);
	investment = this.formdata.newContApply.investment;


	//	else{
	//		checkInsuTwoNotice(topvue);
	//		showELementSByInsuTWo(topvue);//之前其他人写的这个判断不是可配置化，优化为配置化显示隐藏
	//	}


	var showElement = 0;
	for (var index in topvue.form_elements.commonFormNotice) {
		if (topvue.form_elements.commonFormNotice[index].elementstatus == '01') {
			showElement++;
		}
	}
	if (showElement == 0) {
		$(".maintoice_content").hide();
		$("#notice_submit").trigger("click");
	} else {
		$("#tab_notice_tabinfo").removeClass("disabled");
		$("#notice_tabinfo").removeClass("disabled");
	}
	nextTick(this, function() {

		if (topvue.formdata.newContApply.investment == 'N') {
			checksimpleNotice(topvue);
			checkinfantNotice(topvue);
			showELementSByInsu(topvue);
			statureAndAvoirdupois(topvue);
		} else if (topvue.formdata.newContApply.investment == 'M') {
			statureAndAvoirdupois(topvue);
			checkELementSByInsuMuti(topvue);
		}
		if ($("#notice52q145").is(":visible")) {
			$("#notice52q145").attr("disabled", "disabled");
		}
		layer.close(showdilog);
		 $("#notice_submit").attr("style","display:block;");		 
		 var interval3 = setInterval(function() {
			 layer.close(showdilog);
			 $("#notice_submit").attr("style","display:block;");
			}, 1000); 
	});
	if (investment == "W") {
		var interval2 = setInterval(function() {
			if ($("#notice2i1\\[1\\]").is(":visible")) {
				$('[value="Y"][id^="notice"]').parent().css({
					"display" : "inline"
				});
				$('[value="N"][id^="notice"]').parent().css({
					"display" : "inline"
				});
				$('[value="Y"][id^="notice"]').parent().css({
					"padding-left" : "20px"
				});
				$('[value="N"][id^="notice"]').parent().css({
					"padding-left" : "60px"
				});
				clearInterval(interval2);
			}
		}, 300);
	}
	//关闭遮罩层，显示告知保存按钮
	/*layer.close(showdilog);
	 $("#notice_submit").attr("style","display:block;");*/

	
};

function nextTick(_this, func) {
	_this.$nextTick(func);
}


//告知提交前 清空所有不显示的数据
beforesubmitvueform.notice_tabinfoform = function($event) {
	var topvue = getTopvueObj(this);
	//	v-bind:elementstatus ="form_element.elementstatus"
	//$("#notice_tabinfoform").find("input[elementstatus][elementstatus!='01'][value!='']").val('').trigger("click");
	// if ($("[href='#subrisk_1']").attr('aria-expanded') === 'true'){
	// 	console.log("subrisk_1");
	// 	$("#subrisk_1").find("input:checked[type='radio'][elementstatus]:hidden[value!=''],input[type!='radio'][elementstatus]:hidden[value!='']").val('').click();
	// } else if ($("[href='#subrisk_0']").attr('aria-expanded') === 'true'){
	// 	console.log("subrisk_0");
	// 	$("#subrisk_0").find("input:checked[type='radio'][elementstatus]:hidden[value!=''],input[type!='radio'][elementstatus]:hidden[value!='']").val('').click();
	// }else if ($("[href='#normal_notice']").attr('aria-expanded') === 'true'){
	// 	console.log("normal_notice");
	// 	$("#normal_notice").find("input:checked[type='radio'][elementstatus]:hidden[value!=''],input[type!='radio'][elementstatus]:hidden[value!='']").val('').click();
	// }else if ($("[href='#subrisk_2']").attr('aria-expanded') === 'true'){
	// 	console.log("subrisk_2");
	// 	$("#subrisk_2").find("input:checked[type='radio'][elementstatus]:hidden[value!=''],input[type!='radio'][elementstatus]:hidden[value!='']").val('').click();
	// }

	//$("#notice_tabinfoform").find("input[type!='radio'][elementstatus][elementstatus!='01'][value!='']").val('').click();

	//	if($("#notice_tabinfoform").find("[elementstatus][elementstatus!='01']").length==0){
	//		
	//		
	////		this.$set(this.formdata.newContApply,"currentSIDIndex",7);
	//		
	//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit_tabinfo");
	////		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
	////		$("#tab_notice_tabinfo").removeClass("active");
	////		$("#tab_notice_tabinfo").addClass("disabled");
	////		$("#notice_tabinfo").removeClass("active");
	////		$("#notice_tabinfo").addClass("disabled");
	////		$("#tab_contsubmit_tabinfo").addClass("active");
	////		$("#contsubmit_tabinfo").addClass("active");
	//	}else{

	//	}
	//if($("#notice_tabinfoform").find("[elementstatus][elementstatus='01']").length==0){
	//		
	//		
	//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit");
	//		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
	// con
	//	}else{
	//		 
	//		
	//	}
	//提交前校验当前页
	$("#notice_tabinfoform").data('bootstrapValidator').resetForm();
	$("#notice_tabinfoform").data('bootstrapValidator').validate();
	var flag = $("#notice_tabinfoform").data('bootstrapValidator').isValid();

	if (flag){
		flag=checknoticeDetaile(topvue);
		if (flag){
			return true;
		}else{
			event.preventDefault();//阻止事件的默认行为
			event.stopPropagation();//阻止该dom节点往上冒泡
			return false;
		}
	}

};

aftersubmitvueform.notice_tabinfoform = function() {


	//	if($("#notice_tabinfoform").find("[name^='noticeinfo'][elementstatus][elementstatus='01']").length==0){
	//		
	//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit");
	//		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
	//		this.$set(this.formdata.newContApply,"contsubmit", false);
	//		$('#tab_contsubmit_tabinfo').trigger("click");
	//		this.$set(this.form_elementsBYID.INSHinsuranceContInput['notice_tabinfo'],
	//				"elementstatus", "04");
	//		
	//		
	//	}else{
	//		 
	//		
	//	}
	try {
		var proposalcontno = vueobj["testdivchange"].formdata.lccont.proposalcontno;
		buttonControl(proposalcontno);
	} catch (e) {}
	return true;
};
//主要工资来源
commonCombobox_option.commonCombobox_incomesource = {
	url : path + '/newCont/codeselect/common/appntincomesource',
	valueField : "code",
	relateType : "vue",
	// 显示在输入框的
	inputText : "codename",
	textShow : [ "codename" ]
};

afterVueSelect.notice32q2 = function(form_element) {
	var topvue = getTopvueObj(this);
	if (vueobj["testdivchange"].formdata.noticeincomeInsu.noticeinfo2 != "4") {
		hiddenNoticeELements(topvue, "notice32", "3", "q");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeincomeInsu, "noticeinfo3", null);
	} else {
		showNoticeELements(topvue, "notice32", "3", "q");
	}

}

function minorInsu() {
	var topvue = getTopvueObj(this);
	var b = parseInt(topvue.formdata.noticeminorInsu.noticeinfo1);
	var c = parseInt(topvue.formdata.noticeminorInsu.noticeinfo2);
	if (isNaN(c)) {
		c = 0;
		// topvue.formdata.noticeminorInsu.noticeinfo2=0;
	}
	if (isNaN(b)) {
		b = 0;
		// topvue.formdata.noticeminorInsu.noticeinfo1=0;
	}
	var d = 0;

	if ($("#notice52q145").is(":visible")){
		if (maininsuAge < 10 || (twoinsuAge != "" && twoinsuAge < 10) || check10()) {
			d = parseInt(200000 - b - c);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeminorInsu, "noticeinfo3", d);
		} else if ((maininsuAge >= 10 && maininsuAge < 18) || (twoinsuAge != "" && twoinsuAge >= 10 && twoinsuAge < 18) || !check10()) {
			d = parseInt(500000 - b - c);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeminorInsu, "noticeinfo3", d);
		}
	} else{
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeminorInsu, "noticeinfo3", null);
	}
	if (d < 0) {
		if ($("#notice52q145").next().text() == "不能为负数") {

		} else {
			$("#notice52q145").after("<small class='help-block' style='color: red;'>不能为负数</small>");
		}
	} else {
		$("#notice52q145").next().remove();
	}
	$("#notice50q143").blur(function() {
		if (b < 0) {
			if ($("#notice50q143").next().text() == "不能为负数") {

			} else {
				$("#notice50q143").after("<small class='help-block' style='color: red;'>不能为负数</small>");
			}
		} else {
			$("#notice50q143").next().remove();
		}
	})

	$("#notice51q144").blur(function() {
		if (c < 0) {
			if ($("#notice51q144").next().text() == "不能为负数") {

			} else {
				$("#notice51q144").after("<small class='help-block' style='color: red;'>不能为负数</small>");
			}
		} else {
			$("#notice51q144").next().remove();
		}
	})

}

//function minorInsu(index ){
//	
//	var b = topvue.formdata.noticeminorInsus[index].noticeinfo1;
//	var c = topvue.formdata.noticeminorInsus[index].noticeinfo2;
//	
//	if (isNaN(c)) {
//		topvue.formdata.noticeminorInsus[index].noticeinfo2 = 0;
//	}
//	if (isNaN(b)) {
//		topvue.formdata.noticeminorInsus[index].noticeinfo1= 0;
//	}
//	
////	var 
//	
//}
afterVueSelect.notice51q1 = function(form_element) {
	
	
//	if(topvue.formdata.newContApply.investment == 'M'){
//		var topvue = getTopvueObj(this);
//		var id = $(this.$el).find("input").attr("id");
//		var index = $(this.$el).find("input").attr("id").substring(10);
//		
// 
//
//		minorInsu.call(this, form_element);
//		
//	}else{
	var that = this; 
	this.$nextTick(function() {
		minorInsu.call(that);
		console.log("minorInsunotice51q1");
	});
		
//	}
	
 
}
afterVueSelect.notice50q1 = function(form_element) {
	var that = this;
	this.$nextTick(function() {
		minorInsu.call(that);
		console.log("minorInsunotice50q1");

	});
//	if(topvue.formdata.newContApply.investment == 'M'){
//		var topvue = getTopvueObj(this);
//		var id = $(this.$el).find("input").attr("id");
//		var index = $(this.$el).find("input").attr("id").substring(10);
//		minorInsu.call(this, form_element);
//		
//	}else{
// 		minorInsu();
//	} 
}
afterVueSelect.notice30i1 = function(form_element) {
	var topvue = getTopvueObj(this);
	var form = $(this.$el).parentsUntil("form").parent("form");
	if (vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno != null && vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno != "Y") {
		if (vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno2 != null && vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno2 == "Y") {

		} else {
			//重置校验
			form.data('bootstrapValidator').resetField($('#notice30q125'));
			form.data('bootstrapValidator').resetField($('#notice30q225'));
			//置灰输入框并清空值
			$('#notice30q125').attr("disabled", true);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeinfantInsu, "noticeinfo1", null);
			$('#notice30q225').attr("disabled", true);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeinfantInsu, "noticeinfo2", null);
		}
	} else {
		if (vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno2 != null && vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno2 == "Y") {

		} else {
			$('#notice30q125').removeAttr("disabled");
			$('#notice30q225').removeAttr("disabled");
		}

	}
}
afterVueSelect.notice30i2 = function(form_element) {
	var topvue = getTopvueObj(this);
	var form = $(this.$el).parentsUntil("form").parent("form");

	if (vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno2 != null && vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno2 != "Y") {
		if (vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno != null && vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno == "Y") {

		} else {
			//重置校验
			form.data('bootstrapValidator').resetField($('#notice30q125'));
			form.data('bootstrapValidator').resetField($('#notice30q225'));
			//置灰输入框并清空值
			$('#notice30q125').attr("disabled", true);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeinfantInsu, "noticeinfo1", null);
			$('#notice30q225').attr("disabled", true);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeinfantInsu, "noticeinfo2", null);
		}

	} else {
		if (vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno != null && vueobj["testdivchange"].formdata.noticeinfos[25].insuredyesorno == "Y") {

		} else {
			$('#notice30q125').removeAttr("disabled");
			$('#notice30q225').removeAttr("disabled");
		}
	}
}
//是否负债，负债打开输入框，否则置灰必录项
afterVueSelect.notice33i1 = function(form_element) {
	var topvue = getTopvueObj(this);
	var form = $(this.$el).parentsUntil("form").parent("form");

	if (vueobj["testdivchange"].formdata.noticeinfos[28].insuredyesorno != "Y") {
		//重置校验
		form.data('bootstrapValidator').resetField($('#notice33q128'));
		form.data('bootstrapValidator').resetField($('#notice33q228'));
		//置灰输入框并清空值
		$('#notice33q128').attr("disabled", true);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeliabilityInsu, "noticeinfo1", null);
		$('#notice33q228').attr("disabled", true);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeliabilityInsu, "noticeinfo2", null);
	} else {
		$('#notice33q128').removeAttr("disabled");
		$('#notice33q228').removeAttr("disabled");
	}
}

function ClearAll() {
	$("#notice_tabinfoform input").val("");
	$('#notice_tabinfoform input[type=radio]:checked').prop("checked", false);
}


function HideFirstInsu(topvue) {
	$("#noticeinsumulti\\[0\\]").parentsUntil("div.form-group-div").parent("div").hide();
	$("span:contains(被保险人 Proposed Insured)").hide()
	$("#notice2hide0").hide();
	$("#notice2hide1").hide();
	$("#notice2hide16").hide();
	$("#notice2hide17").hide();
	$("#notice2hide34").hide();
}

//用来判定多被保人是否有小于10岁
function check10() {
	var mutinum = vueobj["testdivchange"].formdata.lcinsuredmulti.length;
	for (var i = 0; i < mutinum; i++) {
		if (getAgeFromBrithday(vueobj["testdivchange"].formdata.lcinsuredmulti[i].lcinsuredbirthday) < 10)
			return true;
	}
	return false;
}


function setMainriskAndSubRisk(formdata) {
	var MainRiskInsu = new Array();

	formdata.mainriskinsus.splice(0);
	formdata.mainriskinsus.push(formdata.lcinsured);

	for (var index in formdata.lcinsuredmulti) {

		if (formdata.lcinsuredmulti[index].lcinsuredidno != undefined
			&& formdata.lcinsuredmulti[index].lcinsuredidno != ''
			&& formdata.lcinsuredmulti[index].mainriskflag == '1') {

			formdata.mainriskinsus.push(formdata.lcinsuredmulti[index]);

		}
	}
	if (formdata.lcinsuredtwo
		&& formdata.lcinsuredtwo.lcinsuredidno != undefined
		&& formdata.lcinsuredtwo.lcinsuredidno != ''
		&& formdata.lcinsuredtwo.mainriskflag == '1') {
		formdata.mainriskinsus.push(formdata.lcinsuredtwo);

	}
	formdata.subriskinsus.splice(0);

	// for (var index in formdata.lcinsuredmulti) {
	//
	// 	if (formdata.lcinsuredmulti[index].mainriskflag == '2') {
	//
	// 		formdata.subriskinsus.push(formdata.lcinsuredmulti[index]);
	//
	// 	}
	// }
	// if (formdata.lcinsuredtwo && formdata.lcinsuredtwo.mainriskflag == '2') {
	// 	formdata.subriskinsus.push(formdata.lcinsuredtwo);
	//
	// }
	// if (formdata.lcinsured.mainriskflag=='3'){
	// 	formdata.subriskinsus.push(formdata.lcinsured);
	// }
	//不重复添加被保人
	var lcinsuredlist = new Array();
	for(var a in formdata.sublcpols){
		var insuid = formdata.sublcpols[a].riskbelong;
		if (insuid=='1'&&lcinsuredlist.indexOf(insuid)=='-1'){
			lcinsuredlist.push(insuid);
			formdata.subriskinsus.push(formdata.lcinsured);
		}
		for (var b in formdata.lcinsuredmulti){
			if (insuid=='0'&&formdata.lcinsuredmulti[b].relationtoappnt=='00'){
				formdata.subriskinsus.push(formdata.lcinsuredmulti[b]);
			}
			if (insuid==formdata.lcinsuredmulti[b].lcinsuredid && lcinsuredlist.indexOf(insuid)=='-1'){
				lcinsuredlist.push(insuid);
				formdata.subriskinsus.push(formdata.lcinsuredmulti[b]);
			}
		}
	}
}





vueMethods.getInsuName = function(index_insu) {

	var formdata = this.formdata;



	if (formdata.lcinsuredmulti && formdata.lcinsuredmulti.length > index_insu) {
		return formdata.lcinsuredmulti[index_insu].lcinsuredname;
	}
	if (formdata.lcinsuredtwo && index_insu == 0) {
		return formdata.lcinsuredtwo.lcinsuredname;

	}
}

/**
 * 获取主险被保人
 */
vueMethods.getMainRiskInsu = function(formdata) {


	var MainRiskInsu = new Array();
	MainRiskInsu.push(formdata.lcinsured);

	for (var index in formdata.lcinsuredmulti) {

		if (formdata.lcinsuredmulti[index].lcinsuredidno != undefined
			&& formdata.lcinsuredmulti[index].lcinsuredidno != ''
			&& formdata.lcinsuredmulti[index].mainriskflag != '2') {

			MainRiskInsu.push(formdata.lcinsuredmulti[index]);

		}
	}
	if (formdata.lcinsuredtwo
		&& formdata.lcinsuredtwo.lcinsuredidno != undefined
		&& formdata.lcinsuredtwo.lcinsuredidno != ''
		&& formdata.lcinsuredtwo.mainriskflag != '2') {
		MainRiskInsu.push(formdata.lcinsuredtwo);

	}
	return MainRiskInsu;
}
/***
 * 获取附加险被保人
 */
vueMethods.getSubRiskInsu = function(formdata) {


	var subRiskInsus = new Array();

	// for (var index in formdata.lcinsuredmulti) {
	//
	// 	if (formdata.lcinsuredmulti[index].mainriskflag == '2') {
	//
	// 		subRiskInsus.push(formdata.lcinsuredmulti[index]);
	//
	// 	}
	// }
	// if (formdata.lcinsuredtwo
	// 	&& formdata.lcinsuredtwo.mainriskflag == '2') {
	// 	subRiskInsus.push(formdata.lcinsuredtwo);
	//
	// }
	// if (formdata.lcinsured.mainriskflag=='3'){
	// 	subRiskInsus.push(formdata.lcinsured);
	// }
	//不重复添加被保人
	var lcinsuredlist = new Array();
	for(var a in formdata.sublcpols){
		var insuid = formdata.sublcpols[a].riskbelong;
		if (insuid=='1'&&lcinsuredlist.indexOf(insuid)=='-1'){
			lcinsuredlist.push(insuid);
			subRiskInsus.push(formdata.lcinsured);
		}
		for (var b in formdata.lcinsuredmulti){
			if (insuid=='0'&&formdata.lcinsuredmulti[b].relationtoappnt=='00'){
				subRiskInsus.push(formdata.lcinsuredmulti[b]);
			}
			if (insuid==formdata.lcinsuredmulti[b].lcinsuredid && lcinsuredlist.indexOf(insuid)=='-1'){
				lcinsuredlist.push(insuid);
				subRiskInsus.push(formdata.lcinsuredmulti[b]);
			}
		}
	}
	return subRiskInsus;
}
vueMethods.getSubRiskInsu = function() {


	var topvue = getTopvueObj(this);
	var formdata = topvue.formdata;
	var subRiskInsus = new Array();

	// for (var index in formdata.lcinsuredmulti) {
	//
	// 	if (formdata.lcinsuredmulti[index].mainriskflag == '2') {
	//
	// 		subRiskInsus.push(formdata.lcinsuredmulti[index]);
	//
	// 	}
	// }
	// if (formdata.lcinsuredtwo &&
	// 	formdata.lcinsuredtwo.mainriskflag == '2') {
	// 	subRiskInsus.push(formdata.lcinsuredtwo);
	//
	// }
	// if (formdata.lcinsured.mainriskflag=='3'){
	// 	subRiskInsus.push(formdata.lcinsured);
	// }
	//不重复添加被保人
	var lcinsuredlist = new Array();
	for(var a in formdata.sublcpols){
		var insuid = formdata.sublcpols[a].riskbelong;
		if (insuid=='1'&&lcinsuredlist.indexOf(insuid)=='-1'){
			lcinsuredlist.push(insuid);
			subRiskInsus.push(formdata.lcinsured);
		}
		for (var b in formdata.lcinsuredmulti){
			if (insuid=='0'&&formdata.lcinsuredmulti[b].relationtoappnt=='00'){
				subRiskInsus.push(formdata.lcinsuredmulti[b]);
			}
			if (insuid==formdata.lcinsuredmulti[b].lcinsuredid && lcinsuredlist.indexOf(insuid)=='-1'){
				lcinsuredlist.push(insuid);
				subRiskInsus.push(formdata.lcinsuredmulti[b]);
			}
		}
	}
	return subRiskInsus;
}
/**
 * 获取特殊的附加险
 */
vueMethods.getSubSpecialRisk = function(formdata) {

	var specialRisks = new Array();

	for (var index in formdata.sublcpols) {


		if (formdata.sublcpols[index].riskcode == '@F1'
			|| formdata.sublcpols[index].riskcode == '@WTF'|| formdata.sublcpols[index].riskcode == '@RC' ||formdata.sublcpols[index].riskcode == '@R0'||formdata.sublcpols[index].riskcode == '@X2') {

			specialRisks.push(formdata.sublcpols[index]); 

		}

	}
	var vue_obj = this;

	//	vue_obj.$set("specialRisks",specialRisks ,formdata);

	return specialRisks;

}

//其他被保险人
/***
 * 附加险被保人告知特殊处理
 */
vueMethods.getNoticeElements = function($event, specialRisk, specialRisk_index) {
	//	String otherInsuNo=request.getParameter("otherInsuNo");
	//	String otherInsuNoID=request.getParameter("otherInsuNoID");
	var topvue = getTopvueObj(this);
	//切换附加险时，对当前页进行校验
	$("#notice_tabinfoform").data('bootstrapValidator').resetForm();
	$("#notice_tabinfoform").data('bootstrapValidator').validate();
	var flag = $("#notice_tabinfoform").data('bootstrapValidator').isValid();

	if (flag){
		flag=checknoticeDetaile(topvue);
		if (flag){
			var vue_obj = this;
			var showdilog = layer.load(2, {
				shade : 0.3, //0.2透明度的白色背景
			});

			var initUrl = path + "/newCont/common/init/OtherInsuNotice/INSH/" + this.formdata.newContApply.transno + ".do?subriskcode=" + specialRisk.riskcode;
			$.ajax({
				type : "POST",
				url : initUrl, // 后台请求URL地址
				data : {
					"formdata" : JSON.stringify(this.formdata)
				},
				//			dataType: "json" ,
				//			contentType :"application/json;charset=UTF-8" ,
				success : function(data) {
					//				vue_obj.$set("form_elements",'otherNotice_'+otherinsure.lcinsuredidno
					//						,);

					fillformelements(vue_obj, data.form_elements);
					setIDIndexForEachElement(vue_obj, vue_obj.form_elements, vue_obj.form_elementsBYID);
					//specialNoticeControl.call(vue_obj,otherinsure);

					vue_obj.$nextTick(function() {

						initData(getActivePanelDIV(), true);
						statureAndAvoirdupois(topvue);
						checkELementSByInsuMuti(vue_obj, specialRisk);
					
						layer.close(showdilog);

					});

				},
				error : function() {
					alert("系统异常");
					layer.close(showdilog);
				}
			});
		}else{
			event.preventDefault();//阻止事件的默认行为
			event.stopPropagation();//阻止该dom节点往上冒泡
		}
	}else{
		event.preventDefault();//阻止事件的默认行为
		event.stopPropagation();//阻止该dom节点往上冒泡

	}



	//if (this.form_elements["subNotice_" + specialRisk.riskcode].length > 0) {
		//specialNoticeControl.call(vue_obj,otherinsure);
	//	checkELementSByInsuMuti(vue_obj, specialRisk);
	//} else {

	//			this.form_elements['otherNotice_'+otherinsure.lcinsuredidno].push(this.form_elements.commonFormNotice[index]);
	//}


};

//详细告知校验
function checknoticeDetaile(topvue){

	var code_index = null;
	if ($("[href='#subrisk_0']").attr('aria-expanded') === 'true'){
		code_index = 0;
	}else if($("[href='#subrisk_1']").attr('aria-expanded') === 'true'){
		code_index = 1;
	}else if($("[href='#subrisk_2']").attr('aria-expanded') === 'true'){
		code_index = 2;
	}
	var health = false;
	var riskcode = null;
	if (null!=code_index) {
		riskcode = topvue.formdata.sublcpols[code_index].riskcode;
	}
	if (undefined!=topvue.form_elements['subNotice_'+riskcode]){
		//最后一个配置详细告知(@R0)
		for (var index in topvue.form_elements['subNotice_'+riskcode]) {
				if (topvue.form_elements['subNotice_'+riskcode][index].elementstatus=='01'&&topvue.form_elements['subNotice_'+riskcode][index].child_elements.insuquestion.length!=0) {
					for (let i = 0; i < topvue.formdata.noticeinfos[index].impartContentInsus.length; i++) {
						if (null!=topvue.formdata.noticeinfos[index].impartContentInsus[i]){
							if (topvue.formdata.noticeinfos[index].impartContentInsus[i].riskcode==riskcode&&topvue.formdata.noticeinfos[index].impartContentInsus[i].insuredyesorno == 'Y') {
								health = true;
							}
						}
					}

				}
		}
		for (let i = 0; i < topvue.formdata.noticeDetaileInsus.length; i++) {
			if (null!=topvue.formdata.noticeDetaileInsus[i]){
				if (topvue.formdata.noticeDetaileInsus[i].riskcode==riskcode){
					if (health){
						if (riskcode == '@R0') {
							if (isNull(topvue.formdata.noticeDetaileInsus[i].noticeinfo2)){
								alert("请录入被保人告知详细情况！");
								return false;
							}
						}
						if (riskcode !='@R0') {
							if (isNull(topvue.formdata.noticeDetaileInsus[i].noticeinfo1)){
								alert("请录入被保人告知详细情况！");
								return false;
							}
						}
					}else{
						if (riskcode == '@R0') {
							if (!isNull(topvue.formdata.noticeDetaileInsus[i].noticeinfo2)){
								alert("无健康告知项被保人不允许录入告知详细情况！");
								return false;
							}
						}
						if (riskcode != '@R0') {
							if (!isNull(topvue.formdata.noticeDetaileInsus[i].noticeinfo1)){
								alert("无健康告知项被保人不允许录入告知详细情况！");
								return false;
							}
						}
					}
				}
			}

		}

	}else{
		for (var index in topvue.form_elements.commonFormNotice) {
			if (topvue.form_elements.commonFormNotice[index].elementstatus=='01'&&(topvue.form_elements.commonFormNotice[index].child_elements.insuquestion.length!=0||topvue.form_elements.commonFormNotice[index].child_elements.appntquestion.length!=0)) {
				if (undefined!=topvue.formdata.noticeinfos[index].impartContentInsus&&topvue.formdata.noticeinfos[index].impartContentInsus.length!=0){
					for (let i = 0; i < topvue.formdata.noticeinfos[index].impartContentInsus.length; i++) {
						if (null!=topvue.formdata.noticeinfos[index].impartContentInsus[i]){
							if (topvue.formdata.noticeinfos[index].impartContentInsus[i].insuredyesorno == 'Y') {
								health = true;
							}
						}
					}
				}else{
					if (topvue.formdata.noticeinfos[index].insuredyesorno == 'Y') {
						health = true;
					}
					// //投保人告知校验
					// if (topvue.formdata.noticeinfos[index].owneryesorno == 'Y') {
					// 	health = true;
					// }
				}

			}
		}
		if (topvue.formdata.noticeDetaileInsus.length!=0){
			for (let i = 0; i < topvue.formdata.noticeDetaileInsus.length; i++) {
				if (i==0){
					if (null!=topvue.formdata.noticeDetaileInsus[i]){
						if (health){
							if (isNull(topvue.formdata.noticeDetaileInsus[i].noticeinfo1)){
								alert("请录入被保人告知详细情况！");
								return false;
							}
						}else{
							if (!isNull(topvue.formdata.noticeDetaileInsus[i].noticeinfo1)){
								alert("无健康告知项被保人不允许录入告知详细情况！");
								return false;
							}
						}
					}
				}
			}
		}else {
			if (null!=topvue.formdata.noticeDetaileInsu){
				if (health){
					if (isNull(topvue.formdata.noticeDetaileInsu.noticeinfo1)){
						alert("请录入被保人告知详细情况！");
						return false;
					}
				}else{
					if (!isNull(topvue.formdata.noticeDetaileInsu.noticeinfo1)){
						alert("无健康告知项被保人不允许录入告知详细情况！");
						return false;
					}
				}
			}
		}
	}
	return true;
}
function isNull(str){
	if (str === '') return true;
	if (str === null) return true;
	const regu = '^[ ]+$';
	const re = new RegExp(regu);
	return re.test(str)
}
/***
 * 主线被保人，除主被保人的相应的告知输入信息 
 */
vueMethods.checkMainInsuContent = function(index) {

	var topvue = getTopvueObj(this);
	var formdata = topvue.formdata;
	var form_elements = topvue.form_elements;

	if (form_elements.commonFormNotice[index].child_elements.noticeInfo.length > 0) {

		if (noticeinfotype[form_elements.commonFormNotice[index].child_elements.noticeInfo[0]['groupid']]) {

			return true;
		}
	}

	return false;


}


function  getformdata(formdata ,groupid,n ){
	
	if(noticeinfotype[groupid]){
		
		if(noticeinfotype[groupid] instanceof Object){
			
			if(noticeinfotype[groupid][n]){
				return formdata[noticeinfotype[groupid][n]];
			}else{
				
				addEmptyEleToFormData(formdata, noticeinfotype[groupid]["default"], n-1);
				return formdata[noticeinfotype[groupid]["default"]][n-1]  ;
			}
		}else{
			//默认为 单被保人的 对象+s
			addEmptyEleToFormData(formdata, groupid +"s", n);
			return 	formdata[groupid +"s"][n];
			
		}
		
	}
	
	return  formdata[groupid][n];
}
/**
 * 获取绑定的formdata 的具体对象， index 表示除主被保人外第几被保人
 */
vueMethods.getMainInsuContentFormdata = function(index, n) {

	var topvue = getTopvueObj(this);
	var formdata = topvue.formdata;
	var form_elements = topvue.form_elements;
	var groupid= form_elements.commonFormNotice[index].child_elements.noticeInfo[0]['groupid'] ;


	return getformdata(formdata ,groupid,n );

}



/***
 * 获取告知对应的formdata 对于特殊产品
 */
vueMethods.checkInsuContent = function(specialRisk, index) {

	var topvue = getTopvueObj(this);
	var formdata = topvue.formdata;
	var form_elements = topvue.form_elements;


	if (form_elements['subNotice_' + specialRisk.riskcode][index].child_elements.noticeInfo.length > 0) {

		if (noticeinfotype[form_elements['subNotice_' + specialRisk.riskcode][index].child_elements.noticeInfo[0]['groupid']]) {
			return true;
		}
	}

	return false;


}


/***
 * 附加险被保人  告知填入信息的 formdata 绑定
 */
vueMethods.getInsuContentFormdata = function(specialRisk, index, n) {

	var topvue = getTopvueObj(this);
	var formdata = topvue.formdata;
	var form_elements = topvue.form_elements;

	var groupid= form_elements['subNotice_' + specialRisk.riskcode][index].child_elements.noticeInfo[0]['groupid'] ;
	

	return getformdata(formdata ,groupid,n );

}

/***
 * 获取告知对应的formdata 对于特殊产品
 */
vueMethods.getImpartContformdate = function(index, n) {

	var topvue = getTopvueObj(this);
	var formdata = topvue.formdata;
	if (formdata['noticeinfos'][index]['impartContentInsus'] == undefined) {

		formdata['noticeinfos'][index]['impartContentInsus'] = [];

	}

	for (var i = formdata['noticeinfos'][index]['impartContentInsus'].length; i <= n; i++) {
		formdata['noticeinfos'][index]['impartContentInsus'].push({});
	}


	return formdata['noticeinfos'][index]['impartContentInsus'][n];
}

/***
 * 多被保人场景下 投保单级别的告知输入项的控制及投保人输入部分控制
 */
vueMethods.checkShowAppnt = function(index) {

	var topvue = getTopvueObj(this);
	var formdata = topvue.formdata;
	var form_elements = topvue.form_elements;
	if ((form_elements.commonFormNotice[index].child_elements)&&(
			formdata.newContApply.investment=='N'||(form_elements.commonFormNotice[index].child_elements.noticeInfo[0]
			&&onlyOneShowtype[form_elements.commonFormNotice[index].child_elements.noticeInfo[0]['groupid']]))) {

		return true ;

	}

 

	return false;
}


 
vueMethods.setInforiskcode = function(elements,riskcode,formdata,insuindex,index,allform_elements) {


	if(allform_elements.elementstatus=='01'){
		formdata.riskcode=riskcode;
	}
 

	return elements;
}

 
vueMethods.setriskcode = function(elements,riskcode,formdata,insuindex,index,allform_elements) {


	if(undefined!=formdata.impartContentInsus[insuindex]){
		if(allform_elements.elementstatus=='01'){
			formdata.impartContentInsus[insuindex].riskcode=riskcode;


		}else{
			// console.log(index);
		}
	}


	return elements;
}

/***
 * 获取告知对应的formdata 对于特殊产品
 */
vueMethods.checkShowInsu = function(index) {

	var topvue = getTopvueObj(this);
	var formdata = topvue.formdata;
	var form_elements = topvue.form_elements;
	if ((form_elements.commonFormNotice[index].child_elements)&&(
			formdata.newContApply.investment=='N'||(form_elements.commonFormNotice[index].child_elements.noticeInfo[0]
			&&noticeinfotype[form_elements.commonFormNotice[index].child_elements.noticeInfo[0]['groupid']]))) {

		return true ;

	}
	
	return false;
}

