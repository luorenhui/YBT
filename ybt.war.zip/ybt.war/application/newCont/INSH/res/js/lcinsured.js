var sameFieldLcinusred={
	"lcinsuredname"	:"appntname",
	"lcinsurednativeplace"	:"nativeplace",//国籍
	"lcinsuredsex"	:"appntsex",//性别
	"lcinsuredroccupationcode"	:"occupationcode",//职业代码
	"lcinsuredidtype"	:"idtype",//证件类型
	"lcinsuredidno"	:"idno",//证件号码
	"lcinsuredcompany"	:"company",//工作单位及名称
	"lcinsuredbirthday"	:"appntbirthday",//出生日期
	"insureidenddate"	:"appntenddate",//证件有效止期
	"rgtaddress"	:"rgtaddress",//个人年收入(万元)
	"lcinsuredresponsibility"	:"responsibility",// 行业代码
	"lcinsuredbirthcounty":"birthcounty",
	"lcinsuredotherresponsibility"	:"otherresponsibility",// 被保人职位
	"industrytype"	:"industrytype",// 行业类别
	"banksccflag":"banksccflag",
	"bankcustomertype":"bankcustomertype",
	"marry":"marry",
	"domicile":"domicile",
	"jobinfo":"occualias",
	"otherjob":"parttimejob",
	"mainincome":"appntincomesource",
	"otherincome":"appntincomeother",
	"islongitems":"islongitems",//证件长期有效
	"startingDate"	:"startingDate"//证件有效始期
	//"renewCount"	:"renewCount"//换证次数
};

var sameFieldLcinusredAddress={
		"zipcode"	:"zipcode",//联系地址邮政编码 
		"mobile"	:"mobile",//移动电话
		"homezipcode"	:"homezipcode",//
		"homeprovince"	:"homeprovince",//
		"homephone"	:"homephone",//家庭电话
		"homedistrict"	:"homedistrict",//居住地址区
		"homecity"	:"homecity",//居住地址市
		"homeaddress"	:"homeaddress",//居住地址
		"email"	:"email",
   //	"postalflags"	:"postalflags",
		"countrycodetel_tel":"countrycodetel_tel",
		"areacodetel":"areacodetel",
		"countrycodetel_mob":"countrycodetel_mob",
		"employcountry":"employcountry",
		"employprovince":"employprovince",
		"employcity":"employcity",
		"employarea":"employarea",
		"employdetails":"employdetails",
		"employareacodetel":"employareacodetel",
		"employphone":"employphone",
		"countrycode_loy":"countrycode_loy",
		"employphonecountry":"employphonecountry",
		"homephonecountry":"homephonecountry",
		"countrycodetel_tel":"countrycodetel_tel",
		"areacodetel":"areacodetel",
		"homephone":"homephone",
		"addresscountry":"addresscountry",
		"mobilephonecountry":"mobilephonecountry"
	};

var onlysameFieldLcinusredAddress={
		"zipcode"	:"zipcode",//联系地址邮政编码
		"addresscountry":"addresscountry",
		"homeprovince"	:"homeprovince",//通讯地址省
		"homedistrict"	:"homedistrict",//通讯地址区
		"homecity"	:"homecity",//通讯地址市
		"homeaddress"	:"homeaddress"//通讯地址
		 
	};

//选择了身份证类型时
afterVueSelect.lcinsuredidtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcinsured.lcinsuredidtype;
	//非本人才进来
	if($('#lcinsuredrelationtoappntinsh').val() != "00"){
		/*if (idtype == "X"){
			$("#insuredrenewCount").attr("disabled",false);			
		}else {
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"renewCount", null);
			$("#insuredrenewCount").attr("disabled",true);	
		}*/
		if (idtype != "I"){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"startingDate", null);
			$("#insuredstartingDate").attr("disabled",true);
		}else {
			$("#insuredstartingDate").attr("disabled",false);
		}
	}
};

afterVueSelect.inshlcinsuredidtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
		//第二被保人
		var idtype1= topvue.formdata.lcinsuredtwo.lcinsuredidtype;
		if($('#inshlcinsuredrelationtoappntinsh').val() != "00"){
		/*if((idtype1 !=null && idtype1 != "") && (idtype1 == "X")){
			$("#insuredrenewCount1").attr("disabled",false);			
		}else{
			 vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"renewCount", null);
			$("#insuredrenewCount1").attr("disabled",true);
		}*/
		if((idtype1 !=null && idtype1 != "") && idtype1 != "I"){
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"startingDate", null);//证件有效始期
			$("#insuredstartingDate1").attr("disabled",true);
		}else{
			$("#insuredstartingDate1").attr("disabled",false);
		}
		}
};
		//多被保人
afterVueSelect.multilcinsuredidtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
		var idtype2 = null;
		if(index !=null && index != ""){
			idtype2= topvue.formdata.lcinsuredmulti[index].lcinsuredidtype;
			if($("#multilcinsuredrelationtoappntinsh\\["+index+"\\]").val() != "00"){
			/*if ((idtype2 !=null && idtype2 != "") && (idtype2 == "X")){ 
				$("#insuredrenewCount1\\["+index+"\\]").attr("disabled",false);
			}else {
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[index],"renewCount", null);//证件有效始期
			$("#insuredrenewCount1\\["+index+"\\]").attr("disabled",true);
			}*/
			if ((idtype2 !=null && idtype2 != "") && idtype2 != "I"){
		    vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[index],"startingDate", null);
				$("#insuredstartingDate1\\["+index+"\\]").attr("disabled",true);
			}else {
				$("#insuredstartingDate1\\["+index+"\\]").attr("disabled",false);
			}
	}
		}
};
//证件长期有效
afterVueSelect.lcinsuredislongitemmeli = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
		+ form_element.name + "']");
	//非本人时执行
	if($('#lcinsuredrelationtoappntinsh').val() != "00" && $('#lcinsuredrelationtoappntinsh').val() != "" ){
		if (obj.is("[type='checkbox']:checked")){
			topvue.$set(topvue.formdata.lcinsured,"insureidenddate","9999-12-31");
			$("#lcinsured_tabinfoform").data('bootstrapValidator').resetField($("#lcinsuredidenddate"));
			$("#lcinsuredidenddate").attr("disabled",true);
		}else {
			$("#lcinsuredidenddate").attr("disabled",false);
		}
	}
}
afterVueSelect.twolcinsuredislongitem = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
		+ form_element.name + "']");
	if($('#inshlcinsuredrelationtoappntinsh').val() != "00" && $('#inshlcinsuredrelationtoappntinsh').val() != "" ){
		if (obj.is("[type='checkbox']:checked")){
			topvue.$set(topvue.formdata.lcinsuredtwo,"insureidenddate","9999-12-31");
			$("#lcinsured_tabinfoform").data('bootstrapValidator').resetField($("#inshlcinsuredidenddate"));
			$("#inshlcinsuredidenddate").attr("disabled",true);
		}else {
			$("#inshlcinsuredidenddate").attr("disabled",false);
		}
	}
}
afterVueSelect.multilcinsuredislongitem = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
	var obj = $("#multilcinsuredislongitem\\["+index+"\\]");
	if($("#multilcinsuredrelationtoappntinsh\\["+index+"\\]").val() != "00" && $("#multilcinsuredrelationtoappntinsh\\["+index+"\\]").val() != "" ){
		if (obj.is("[type='checkbox']:checked")){
			topvue.$set(topvue.formdata.lcinsuredmulti[index],"insureidenddate","9999-12-31");
			$("#multilcinsuredidenddate\\["+index+"\\]").attr("disabled",true);
		}else {
			$("#multilcinsuredidenddate\\["+index+"\\]").attr("disabled",false);
		}
	}
}

commonCombobox_option.commonCombobox_lcinsuredwhetherGpgcMul = {
		"data" : [ {
			"value" : "01",
			"text" : "祖孙"					
		}, {
			"value" : "02",
			"text" : "非祖孙"
		} ]
		,afterClick : function(ele,$target,value,text,comboboxObj){
				var topvue = getTopvueObj(this);
				let gpgcIndex = $target[0].id.split("[")[1].substring(0,1);
				if(value == '02'){ //非祖孙
					$('#multilcinsuredrelation\\['+gpgcIndex+'\\]').removeAttr("disabled");
					$('#multilcinsuredrelation\\['+gpgcIndex+'\\]').val("");
					vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[gpgcIndex],"otherrelationtoappnt", "");
					
				}else if(value == '01'){
					$('#multilcinsuredrelation\\['+gpgcIndex+'\\]').attr("disabled",true);
					$('#multilcinsuredrelation\\['+gpgcIndex+'\\]').val("祖孙");
					vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[gpgcIndex],"otherrelationtoappnt", "祖孙");
				}else{
					$('#multilcinsuredrelation\\['+gpgcIndex+'\\]').attr("disabled",true);
					$('#multilcinsuredrelation\\['+gpgcIndex+'\\]').val("");
					vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[gpgcIndex],"otherrelationtoappnt", "");
				}
		}
}

commonCombobox_option.commonCombobox_lcinsuredwhetherGpgc = {
		"data" : [ {
			"value" : "01",
			"text" : "祖孙"					
		}, {
			"value" : "02",
			"text" : "非祖孙"
		} ]
		,afterClick : function(ele,$target,value,text,comboboxObj){
				
				if(value == '02'){ //非祖孙
					
					$('#lcinsuredrelation').removeAttr("disabled");
					$('#lcinsuredrelation').val("");
					vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", "");
					
				}else if(value == '01'){
					$('#lcinsuredrelation').attr("disabled",true);
					$('#lcinsuredrelation').val("祖孙");
					vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", "祖孙");
				}else{
					$('#lcinsuredrelation').attr("disabled",true);
					$('#lcinsuredrelation').val("");
					vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", "");
				}
		}
}


/**
 * 投保人 同被保人
 */
afterVueSelect.lcinsuredrelationtoappntinsh = function(form_element) {
	
	if($('#lcinsuredrelationtoappntinsh').val() == '30'){
		$('#lcinsuredwhetherGpgc').combobox("enable");
	}else{
		$('#lcinsuredwhetherGpgc').combobox("disable");
		$('#lcinsuredwhetherGpgc').combobox("clear");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"whetherGpgc", "");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", "");
	}
	$('#lcinsuredrelation').attr("disabled",true);
	

	var topvue = getTopvueObj(this);
 
	var form =$(this.$el)
	.parentsUntil("form").parent("form");
	if (this.formdata.relationtoappnt=="00") {

		for ( var key in topvue.form_elements.lcinsured) {
			
			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {
		
				bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusred[targetName],
						topvue.formdata.lcinsured,targetName,targetElement);
			}
			
			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
				
				bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredAddress[targetName],
						topvue.formdata.lcinsuredaddress,targetName,targetElement);
			}

		}
		
		
		topvue.$nextTick(function () { 
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});
		
		
		$("#lcinsuredpostalflag").hide();
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "");

	} else {
		
		
		
		for ( var key in topvue.form_elements.lcinsured) {
			
			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {
		
				unbindSameElement.call(topvue, sameFieldLcinusred[targetName],
						targetElement);
			}
			
			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
				
				unbindSameElement.call(topvue, sameFieldLcinusredAddress[targetName],
						targetElement);
			}

		}
		$("#lcinsuredpostalflag").show();
//		topvue.$set(topvue.form_elementsBYID.lcinsured,"lcinsuredpostalflag","01");

		//2.投被保险人为本人，修改为非本人选项，则系统会清空被保险人信息，需要重新填写  （ 00为本人）
		if($('#lcinsuredrelationtoappntinsh').val() != "00" && $('#lcinsuredrelationtoappntinsh').val() != "" ){
			//清空主被保人信息	输入框处理		
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredbirthday", null);//出生日期
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredcompany", null);//单位/学校/幼儿园名称
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"rgtaddress", null);//个人年收入(万元)
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredresponsibility", null);//工作内容
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"domicile", null);//户籍所在地
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherjob", null);//兼职
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherincome", null);//其他
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"otherrelationtoappnt", null);//投保人与被保人其它关系
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredname", null);//被保人姓名			
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"bankcustomercode", null);//银行客户编码
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"bankcustomertype", null);//银行客户类型
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredidno", null);//证件号码
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"renewCount", null);//换证次数
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"startingDate", null);//证件有效始期
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"insureidenddate", new Array());//证件有效止期
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"islongitems", new Array());//证件长期有效
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredotherresponsibility", null);//职位
			//清空被保人地址信息
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employphone", null);//电话
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"homeaddress", null);//详细地址
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"homephone", null);//固定电话
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employdetails", null);//详细地址			
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employareacodetel", null);//区号
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"email", null);//E-mail
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"zipcode", null);//邮政编码
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"areacodetel", null);//固定电话区号
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"mobile", null);//移动电话
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employcountry", null);//地址所属国家/地区
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"addresscountry", null);//地址所属国家/地区
			
			topvue.$nextTick(function () { 
				try {
			//下拉框处理
			//清空被保人信息			
			$('#lcinsuredroccupationcodeinsh').combobox("clear");//职业代码
			$('#lcinsuredmarry').combobox("clear");//婚姻状况
			$('#lcinsuredbankcustomertype').combobox("clear");//银行客户类型
			$('#lcinsuredjobinfo').combobox("clear");//职业说明
			$('#lcinsuredmainincome').combobox("clear");//主要收入来源
			$('#lcinsuredsex').combobox("clear");//性别
			$('#lcinsuredidtype').combobox("clear");//证件类型
			$('#lcinsurednativeplace').combobox("clear");//国籍/地区
			$('#lcinsuredbanksccflag').combobox("clear");//银行特类客户标记
			if($('#lcinsuredrelationtoappntinsh').val() != "30"){
				$('#lcinsuredwhetherGpgc').combobox("clear");//是否祖孙
			}
			//清空被保人地址信息			
			$('#lcinsuredpostalflag').combobox("clear");// 同投保人地址
			$('#lcinsuredemploycountry').combobox("clear");// 地址所属国家/地区	
			$('#lcinsuredemployprovince').combobox("clear");// 地址省			
			$('#lcinsuredemploycity').combobox("clear");//地址市	
			$('#lcinsuredemployarea').combobox("clear");// 地址区				
			$('#lcinsuredcountrycode_loy').combobox("clear");// 电话国家/地区代码
			$('#lcinsuredemployphonecountry').combobox("clear");// 电话所在国家/地区	
			$('#lcinsuredaddresscountry').combobox("clear");// 地址所属国家/地区			
			$('#lcinsuredcountrycode_anzlinsh1').combobox("clear");//移动电话国家/地区代码	
			$('#lcinsuredcountrycode_anzlinsh').combobox("clear");// 固定电话国家/地区代码				
			$('#lcinsuredhomeprovince').combobox("clear");// 地址省	
			$('#lcinsuredhomecityinsh').combobox("clear");// 地址市			
			$('#lcinsuredhomedistrictinsh').combobox("clear");//地址区
			$('#lcinsuredmobilephonecountry').combobox("clear");// 移动电话所在国家/地区
			$('#lcinsuredhomephonecountry').combobox("clear");// 固定电话所在国家/地区
			
				} catch (e) {
				}
			});
			
		}
	}

};


/**
 * 投保人 同被保人
 */
 
afterVueSelect.lcinsuredtwoflag = function(form_element) {
	
	/*setTimeout(function(){
 		if($("#insuredrenewCount1").is(":visible")){
 			 $(".zh").remove();
			 $("input[id^='insuredrenewCount']").parent().append("<small class='help-block zh' style='color: red;'>请注意，" +
			   				"请按证件上的换证次数填写，例如：01。</small>");
			 }
	},50);*/
	
	var formdata = this.formdata;
	if(   formdata['lcinsured']
		&&formdata['lcinsured'].lcinsuredtwoflag
		&&formdata['lcinsured'].lcinsuredtwoflag.length>=1
		&&formdata['lcinsured'].lcinsuredtwoflag[0]=='lcinsuredtwoflag'){
		
		return true;
	}else{
 
		return false;
	}
	
};

/**
 * 投保人地址同被保人地址
 */
afterVueSelect.lcinsuredpostalflag = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (topvue.formdata.lcinsured.relationtoappnt!="00") {
		
		
		if (obj.is("[type='checkbox']:checked")) {
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "0");
			for ( var key in topvue.form_elements.lcinsured) {
				
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredaddress,targetName,targetElement);
				}
			}
		
		} else {
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "");
			for ( var key in topvue.form_elements.lcinsured) {
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					unbindSameElement.call(topvue, onlysameFieldLcinusredAddress[targetName],
							targetElement);
				}
			}
		}
		
		
	}	
};

//dbs_city  dbs_province dbs_area 被保人通讯地址省
commonCombobox_option.commonCombobox_insuredemployprovince ={

	url :  path + '/newCont/codeselect/allprovinceid/province.do',
	valueField : "provinceid",
	// 显示在输入框的
	inputText : "provincename",
	textShow : [ "provincename" ]
};

//dbs_city  dbs_province dbs_area 被保人通讯地址
commonCombobox_option.commonCombobox_insuredemploycity  =  {
	url :  path + '/newCont/codeselect/allcity/#lcinsuredemployprovince.do',
	valueField : "cityid",
	// 显示在输入框的
	inputText : "cityname",
	textShow : [ "cityname" ]
};

//dbs_city  dbs_province dbs_area 被保人通讯地址
commonCombobox_option.commonCombobox_insuredemploydistrict = {

	url :  path + '/newCont/codeselect/allcounty/#lcinsuredemploycity.do',
	valueField : "countyid",
	// 显示在输入框的
	inputText : "countyname",
	textShow : [ "countyname" ]
};

//dbs_city  dbs_province dbs_area 被保人居住地址(省)
commonCombobox_option.commonCombobox_insuredhomeprovince = {

	url :  path + '/newCont/codeselect/allprovinceid/province.do',
	valueField : "provinceid",
	// 显示在输入框的
	inputText : "provincename",
	textShow : [ "provincename" ]
};
//dbs_city  dbs_province dbs_area 被保人居住地址(市)
commonCombobox_option.commonCombobox_insuredhomecity = {
	url :  path + '/newCont/codeselect/allcity/#lcinsuredhomeprovince.do',
	valueField : "cityid",
	// 显示在输入框的
	inputText : "cityname",
	textShow : [ "cityname" ]
};
//dbs_city  dbs_province dbs_area 被保人居住地址(区)
commonCombobox_option.commonCombobox_insuredhomedistrict = {
	url :  path + '/newCont/codeselect/allcounty/#lcinsuredhomecityinsh.do',
	valueField : "countyid",
	// 显示在输入框的
	inputText : "countyname",
	textShow : [ "countyname" ]
};

commonCombobox_option.commonCombobox_banksccflag = {
		"data" : [ {
			"value" : "N",
			"text" : "否"					
		}, {
			"value" : "Y",
			"text" : "是"
		} ]
	};
commonCombobox_option.commonCombobox_bankcustomertype = {

	url : path + '/newCont/codeselect/common/bankcustomertype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText :  "codename" ,
	textShow : [ "codename" ]
	
};
commonCombobox_option.commonCombobox_relation_insh = {

		url : path + '/newCont/codeselect/common/relation_insh',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "codename" ,
		textShow : [ "codename" ]
		
	};
commonCombobox_option.commonCombobox_occualias={
	url : path + '/LdcodeController/selectDistinctCodeAlias.do?codetype=occupationinsh',
	valueField : "comcode",
	// 显示在输入框的
	inputText : "codealias",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codealias" ]
},

//INSH职业代码
commonCombobox_option.commonCombobox_jobinfoinsh ={
	url : path + '/LdcodeController/code/#lcinsuredjobinfo.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "code","codename" ]
};

//居住地址国家变化时改变居住地址省市区下拉状态 
afterVueSelect.lcinsuredroccupationcodeinsh = function(form_element) {
	var occupat = $('#lcinsuredjobinfo').val();
	var occupationcode = $('#lcinsuredroccupationcodeinsh').val();
	try {
		if(occupat!=null&&occupationcode!=''&&occupat.indexOf("K")!=-1 
				&& occupationcode!=null&&occupationcode!=''&& occupationcode.indexOf("K04")==-1){
			addressHiddenOne();
		}else{
			addressShowOne();
		}
	} catch (e) {
		
	}
}
//居住地址国家变化时改变居住地址省市区下拉状态  
afterVueSelect.inshlcinsuredroccupationcodeinsh = function(form_element) {
	var occupat = $('#inshlcinsuredjobinfo').val();
	var occupationcode = $('#inshlcinsuredroccupationcodeinsh').val();
	try {
		if(occupat!=null&&occupationcode!=''&&occupat.indexOf("K")!=-1 
				&& occupationcode!=null&&occupationcode!=''&& occupationcode.indexOf("K04")==-1){
			addressHiddenTwo();
		}else{
			addressShowTwo();
		}
	} catch (e) {
		
	}
}
         




function addressShowOne(){
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"insutshowflag", "Y");	
	$("#lcinsuredcompanyinsh").removeAttr("disabled");
}

function addressHiddenOne(){
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"insutshowflag", "N");
	
	
	
	$("#lcinsuredcompanyinsh").attr("disabled","disabled");
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employphonecountry", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"countrycode_loy", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employareacodetel", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employphone", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employcountry", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employprovince", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employcity", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employarea", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredcompany", "");
}

function addressShowTwo(){
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"insutwoshowflag", "Y");	
	$("#inshlcinsuredcompanyinsh").removeAttr("disabled");
}

function addressHiddenTwo(){
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"insutwoshowflag", "N");
	$("#inshlcinsuredcompanyinsh").attr("disabled","disabled");
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employphonecountry", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"countrycode_loy", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employareacodetel", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employphone", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employcountry", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employprovince", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employcity", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employarea", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"lcinsuredcompany", "");
}
//居住地址国家变化时改变居住地址省市区下拉状态 
afterVueSelect.lcinsuredaddresscountry = function(form_element) {
	if($('#lcinsuredrelationtoappntinsh').val()=="00"){
		return;
	}
	if($("#lcinsuredpostalflag").is("[type='checkbox']:checked")){
		return;
	}
	if($('#lcinsuredaddresscountry').val() != 'CN'){
		if($('#lcinsuredaddresscountry').val()!=""&&
				$('#lcinsuredaddresscountry').val()!=null&&
				$('#lcinsuredaddresscountry').val()!=undefined){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"homeprovince", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"homecity", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"homedistrict",null);
			$('#lcinsuredhomeprovince').combobox("clear");
			$('#lcinsuredhomecityinsh').combobox("clear");
			$('#lcinsuredhomedistrictinsh').combobox("clear");
		}
		
		
		$('#lcinsuredhomeprovince').combobox("disable");
		
		$('#lcinsuredhomecityinsh').combobox("disable");
		
		$('#lcinsuredhomedistrictinsh').combobox("disable");		
	}else{
		$('#lcinsuredhomeprovince').combobox("enable");
		$('#lcinsuredhomecityinsh').combobox("enable");
		$('#lcinsuredhomedistrictinsh').combobox("enable");
	}
}
//单位/学校地址国家变化时改变单位/学校地址省市区下拉状态
afterVueSelect.lcinsuredemploycountry = function(form_element) {
	if($('#lcinsuredrelationtoappntinsh').val()=="00"){
		return;
	}
	if($('#lcinsuredemploycountry').val() != 'CN'){		
		
		if($('#lcinsuredemploycountry').val()!=""&&
				$('#lcinsuredemploycountry').val()!=null&&
				$('#lcinsuredemploycountry').val()!=undefined){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employprovince", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employcity", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employarea",null);
			$('#lcinsuredemployprovince').combobox("clear");
			$('#lcinsuredemploycity').combobox("clear");
			$('#lcinsuredemployarea').combobox("clear");
		}
//		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employprovince", null);
//		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employcity", null);
//		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employarea",null);
//		$('#lcinsuredemployprovince').combobox("clear");
		$('#lcinsuredemployprovince').combobox("disable");
//		$('#lcinsuredemploycity').combobox("clear");
		$('#lcinsuredemploycity').combobox("disable");
//		$('#lcinsuredemployarea').combobox("clear");
		$('#lcinsuredemployarea').combobox("disable");
	}else{
		$('#lcinsuredemployprovince').combobox("enable");
		$('#lcinsuredemploycity').combobox("enable");
		$('#lcinsuredemployarea').combobox("enable");				
	}
	
}
//主要来源 不为其他为置灰
afterVueSelect.lcinsuredmainincome = function(form_element) {
	if($('#lcinsuredrelationtoappntinsh').val()=="00"){
		return;
	}
	if($("#lcinsuredmainincome").val()=='4'){
		$('#lcinsuredotherincome').removeAttr("disabled");
	}else{
		$('#lcinsuredotherincome').attr("disabled",true);
		$('#lcinsuredotherincome').val("");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherincome", "");
	}

	
}

//根据身份证号，同步出生日期
afterVueSelect.lcinsuredidno = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");
	/*var form = $(this.$el).parentsUntil("form").parent("form");*/
	if($("#lcinsuredidtype").val() != "I" && $("#lcinsuredidtype").val() != "J"){
		return;
	}
	if($("#lcinsuredidtype").val() == "I"||$("#lcinsuredidtype").val() == "J"){
		if (obj.is("[id='lcinsuredidno']")){
//			topvue.$set(topvue.formdata.lcinsured,"insureidenddate","2099-01-01"); 
			var idno = $("#lcinsuredidno").val();
			var birthday = idno.substring(6,14);
			var year = birthday.substring(0,4);
			var mon = birthday.substring(4,6);
			var day = birthday.substring(6);
			var formatBirth = year + "-" + mon + "-" + day;
			topvue.$set(topvue.formdata.lcinsured,"lcinsuredbirthday",formatBirth);
			
		}
	/*	//重置出生日期的校验
		if($("#lcinsuredidno").val().length == 18){
			form.data('bootstrapValidator').resetField($('#lcinsuredbirthday'));
//			$.fn.bootstrapValidator.validators.lcinsured_idno;
		}*/
	}
	
}

$.fn.bootstrapValidator.validators.lcinsured_idno = {
		validate : function(validator, $field, options) {
			var topvueobj = getTopvueObj(options.vueobj);
			var lcinsured = topvueobj.formdata.lcinsured;
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			if (null!=lcinsured.lcinsuredidno){
				if(lcinsured.lcinsuredidno.length==18||(lcinsured.lcinsuredidtype!="I"&&lcinsured.lcinsuredidtype!="J")){
					form.data('bootstrapValidator').resetField($("#lcinsuredbirthday"));
					form.data('bootstrapValidator').updateStatus($field, "VALID");
					form.find("input[id*='lcinsuredidno']").each(function() {
						if (!form.data('bootstrapValidator').isValidField($(this))) {
							form.data('bootstrapValidator').revalidateField($(this));
						}

					});
					return true;
				}
			}
			return false;
		}
	};
	bootstrap_valid.lcinsured_idno = function(validitem) {

		var vueobj = this;
		var validobj = {
			message : "当前证件类型下证件号码必须为18位，请重新输入",
			vueobj : vueobj
		};

		return validobj;

	};
	
	
	/*第二被保人*/
	/**
	 * 第二被保人地址同投保人地址
	 */
	afterVueSelect.inshlcinsuredpostalflag = function(form_element) {

		var topvue = getTopvueObj(this);
		var obj = $("[name='" + form_element.groupid + this.elementindex + "."
				+ form_element.name + "']");

		if (topvue.formdata.lcinsuredtwo.relationtoappnt!="00") {
			
			
			if (obj.is("[type='checkbox']:checked")) {
//				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "0");
				for ( var key in topvue.form_elements.lcinsuredtwoinsh) {
					
					var targetName= topvue.form_elements.lcinsuredtwoinsh[key].name;
					var targetElement= topvue.form_elements.lcinsuredtwoinsh[key];
					if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredtwoinsh[key].name]!=undefined) {
						bindSameElement.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
								topvue.formdata.lcinsuredtwoaddress,targetName,targetElement);
					}
				}
			
			} else {
//				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "");
				for ( var key in topvue.form_elements.lcinsuredtwoinsh) {
					var targetName= topvue.form_elements.lcinsuredtwoinsh[key].name;
					var targetElement= topvue.form_elements.lcinsuredtwoinsh[key];
					if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredtwoinsh[key].name]!=undefined) {
						unbindSameElement.call(topvue, onlysameFieldLcinusredAddress[targetName],
								targetElement);
					}
				}
			}				
		}	
	};
	
	commonCombobox_option.commonCombobox_occualias1={
			url : path + '/LdcodeController/selectDistinctCodeAlias.do?codetype=occupationinsh',
			valueField : "comcode",
			delayLoadDataFlag : true,
			// 显示在输入框的
			inputText : "codealias",
			// 显示在下拉列表的项，默认空，空则全部显示
			textShow : [ "codealias" ]
		};
	//INSH职业代码
	commonCombobox_option.commonCombobox_jobinfoinsh1 ={
		url : path + '/LdcodeController/code/#inshlcinsuredjobinfo.do',
		valueField : "code",
		delayLoadDataFlag : true,
		// 显示在输入框的
		inputText : "codename",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow : [ "code","codename" ],
	};
	
	commonCombobox_option.commonCombobox_occualiasmul={
			url : path + '/LdcodeController/selectDistinctCodeAlias.do?codetype=occupationinsh',
			valueField : "comcode",
			delayLoadDataFlag : true,
			// 显示在输入框的
			inputText : "codealias",
			// 显示在下拉列表的项，默认空，空则全部显示
			textShow : [ "codealias" ]
		};
	//INSH职业代码
	commonCombobox_option.commonCombobox_jobinfoinshmul ={
		url : path + '/LdcodeController/code/#lcinsuredmulti.jobinfo',
		valueField : "code",
		delayLoadDataFlag : true,
		relateType: "vue",
		// 显示在输入框的
		inputText : "codename",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow : [ "code","codename" ],
	};
	
	//dbs_city  dbs_province dbs_area 第二被保人通讯地址省
	commonCombobox_option.commonCombobox_insuredemployprovince1 ={

		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		delayLoadDataFlag : true,
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
	};
	//dbs_city  dbs_province dbs_area 第二被保人通讯地址
	commonCombobox_option.commonCombobox_insuredemploycity1  =  {
		url :  path + '/newCont/codeselect/allcity/#inshlcinsuredemployprovince.do',
		valueField : "cityid",
		delayLoadDataFlag : true,
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
	};
	//dbs_city  dbs_province dbs_area 第二被保人通讯地址
	commonCombobox_option.commonCombobox_insuredemploydistrict1 = {

		url :  path + '/newCont/codeselect/allcounty/#inshlcinsuredemploycity.do',
		valueField : "countyid",
		delayLoadDataFlag : true,
		// 显示在输入框的
		inputText : "countyname",
		textShow : [ "countyname" ]
	};

	//dbs_city  dbs_province dbs_area 第二被保人居住地址(省)
	commonCombobox_option.commonCombobox_insuredhomeprovince1={

		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		delayLoadDataFlag : true,
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
	};
	//dbs_city  dbs_province dbs_area 第二被保人居住地址(市)
	commonCombobox_option.commonCombobox_insuredhomecity1 ={

		url :  path + '/newCont/codeselect/allcity/#inshlcinsuredhomeprovince.do',
		valueField : "cityid",
		delayLoadDataFlag : true,
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
	};		
	//dbs_city  dbs_province dbs_area 第二被保人居住地址(区)
	commonCombobox_option.commonCombobox_insuredhomedistrict1 = {

		url :  path + '/newCont/codeselect/allcounty/#inshlcinsuredhomecityinsh.do',
		 valueField : "countyid",
		 delayLoadDataFlag : true,
			// 显示在输入框的
		inputText : "countyname",
		textShow : [ "countyname" ]
	};
	commonCombobox_option.commonCombobox_relation_insh_one = {

			url : path + '/newCont/codeselect/common/lcinsuredtwo/relation_insh',
			valueField : "code",
			relateType: "vue",
			// 显示在输入框的
			inputText :  "codename" ,
			textShow : [ "codename" ]
			
		};
	//居住地址国家变化时改变居住地址省市区下拉状态
	afterVueSelect.inshlcinsuredaddresscountry = function(form_element) {
		if($('#inshlcinsuredrelationtoappntinsh').val()=="00"){
			return;
		}
		if($("#inshlcinsuredpostalflag").is("[type='checkbox']:checked")){
			return;
		}
		if($('#inshlcinsuredaddresscountry').val() != 'CN'){
			if($('#inshlcinsuredaddresscountry').val()!=""&&
					$('#inshlcinsuredaddresscountry').val()!=null&&
					$('#inshlcinsuredaddresscountry').val()!=undefined){
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"homeprovince", null);
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"homecity", null);
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"homedistrict",null);
				$('#inshlcinsuredhomeprovince').combobox("clear");
				$('#inshlcinsuredhomecityinsh').combobox("clear");
				$('#inshlcinsuredhomedistrictinsh').combobox("clear");
			}
			
			
			$('#inshlcinsuredhomeprovince').combobox("disable");
			
			$('#inshlcinsuredhomecityinsh').combobox("disable");
			
			$('#inshlcinsuredhomedistrictinsh').combobox("disable");		
		}else{
			$('#inshlcinsuredhomeprovince').combobox("enable");
			$('#inshlcinsuredhomecityinsh').combobox("enable");
			$('#inshlcinsuredhomedistrictinsh').combobox("enable");
		}
	};
	//主要来源 不为其他为置灰
	afterVueSelect.inshlcinsuredmainincome = function(form_element) {
		if($('#inshlcinsuredrelationtoappntinsh').val()=="00"){
			return;
		}
		if($("#inshlcinsuredmainincome").val()=='4'){
			$('#inshlcinsuredotherincome').removeAttr("disabled");
		}else{
			$('#inshlcinsuredotherincome').attr("disabled",true);
			$('#inshlcinsuredotherincome').val("");
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"otherincome", "");
		}		
	};
	//单位/学校地址国家变化时改变单位/学校地址省市区下拉状态
	afterVueSelect.inshlcinsuredemploycountry = function(form_element) {
		if($('#inshlcinsuredrelationtoappntinsh').val()=="00"){
			return;
		}
		if($('#inshlcinsuredemploycountry').val() != 'CN'){		
			
			if($('#inshlcinsuredemploycountry').val()!=""&&
					$('#inshlcinsuredemploycountry').val()!=null&&
					$('#inshlcinsuredemploycountry').val()!=undefined){
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employprovince", null);
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employcity", null);
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"employarea",null);
				$('#inshlcinsuredemployprovince').combobox("clear");
				$('#inshlcinsuredemploycity').combobox("clear");
				$('#inshlcinsuredemployarea').combobox("clear");
			}
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employprovince", null);
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employcity", null);
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"employarea",null);
//			$('#lcinsuredemployprovince').combobox("clear");
			$('#inshlcinsuredemployprovince').combobox("disable");
//			$('#lcinsuredemploycity').combobox("clear");
			$('#inshlcinsuredemploycity').combobox("disable");
//			$('#lcinsuredemployarea').combobox("clear");
			$('#inshlcinsuredemployarea').combobox("disable");
		}else{
			$('#inshlcinsuredemployprovince').combobox("enable");
			$('#inshlcinsuredemploycity').combobox("enable");
			$('#inshlcinsuredemployarea').combobox("enable");				
		}
		
	};




	var sameFieldLcinusredtwo={
			"lcinsuredname"	:"appntname",
			"lcinsurednativeplace"	:"nativeplace",//国籍
			"lcinsuredsex"	:"appntsex",//性别
			"lcinsuredroccupationcode"	:"occupationcode",//职业代码
			"lcinsuredidtype"	:"idtype",//证件类型
			"lcinsuredidno"	:"idno",//证件号码
			"lcinsuredcompany"	:"company",//工作单位及名称
			"lcinsuredbirthday"	:"appntbirthday",//出生日期
			"insureidenddate"	:"appntenddate",//证件有效止期
			"rgtaddress"	:"rgtaddress",//个人年收入(万元)
			"lcinsuredresponsibility"	:"responsibility",// 行业代码
			"lcinsuredbirthcounty":"birthcounty",
			"lcinsuredotherresponsibility"	:"otherresponsibility",// 被保人职位
			"industrytype"	:"industrytype",// 行业类别
			"banksccflag":"banksccflag",
			"bankcustomertype":"bankcustomertype",
			"marry":"marry",
			"domicile":"domicile",
			"jobinfo":"occualias",
			"otherjob":"parttimejob",
			"mainincome":"appntincomesource",
			"otherincome":"appntincomeother",
			"islongitems":"islongitems",//证件长期有效
			"startingDate"	:"startingDate"//证件有效始期
			//"renewCount"	:"renewCount"//换成次数

		};

	var sameFieldLcinusredtwoAddress={
			"zipcode"	:"zipcode",//联系地址邮政编码 
			"mobile"	:"mobile",//移动电话
			"homezipcode"	:"homezipcode",//
			"homeprovince"	:"homeprovince",//
			"homephone"	:"homephone",//家庭电话
			"homedistrict"	:"homedistrict",//居住地址区
			"homecity"	:"homecity",//居住地址市
			"homeaddress"	:"homeaddress",//居住地址
			"email"	:"email",
	   //	"postalflags"	:"postalflags",
			"countrycodetel_tel":"countrycodetel_tel",
			"areacodetel":"areacodetel",//lcinsuredtwoaddress.areacodetel
			"countrycodetel_mob":"countrycodetel_mob",
			"employcountry":"employcountry",
			"employprovince":"employprovince",
			"employcity":"employcity",
			"employarea":"employarea",
			"employdetails":"employdetails",
			"employareacodetel":"employareacodetel",
			"employphone":"employphone",
			"countrycode_loy":"countrycode_loy",
			"employphonecountry":"employphonecountry",
			"homephonecountry":"homephonecountry",
			"countrycodetel_tel":"countrycodetel_tel",
			"areacodetel":"areacodetel",
			"homephone":"homephone",
			"addresscountry":"addresscountry",
			"mobilephonecountry":"mobilephonecountry"
		};
	/**
	 * 投保人 同被保人
	 */
	afterVueSelect.inshlcinsuredrelationtoappntinsh = function(form_element) {
		
		if($('#inshlcinsuredrelationtoappntinsh').val() == '30'){
		$('#inshlcinsuredrelation').removeAttr("disabled");
		
	}else{
		$('#inshlcinsuredrelation').attr("disabled",true);
		$('#inshlcinsuredrelation').val("");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"otherrelationtoappnt", "");
	}

		var topvue = getTopvueObj(this);
	 
		var form =$(this.$el)
		.parentsUntil("form").parent("form");
		if (this.formdata.relationtoappnt=="00") {

			for ( var key in topvue.form_elements.lcinsuredtwoinsh) {
				
				var targetName= topvue.form_elements.lcinsuredtwoinsh[key].name;
				var targetElement= topvue.form_elements.lcinsuredtwoinsh[key];
				if (sameFieldLcinusredtwo[topvue.form_elements.lcinsuredtwoinsh[key].name]!=undefined) {
			
					bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusredtwo[targetName],
							topvue.formdata.lcinsuredtwo,targetName,targetElement);
				}
				
				if (sameFieldLcinusredtwoAddress[topvue.form_elements.lcinsuredtwoinsh[key].name]!=undefined) {
					
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredtwoAddress[targetName],
							topvue.formdata.lcinsuredtwoaddress,targetName,targetElement);
				}

			}
			
			
			topvue.$nextTick(function () { 
				try {
					form.data('bootstrapValidator').resetForm();
				} catch (e) {
				}
			});					
			$("#inshlcinsuredpostalflag").hide();
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwoaddress,"postalflags", "");

		} else {	
			for ( var key in topvue.form_elements.lcinsuredtwoinsh) {
				
				var targetName= topvue.form_elements.lcinsuredtwoinsh[key].name;
				var targetElement= topvue.form_elements.lcinsuredtwoinsh[key];
				if (sameFieldLcinusredtwo[topvue.form_elements.lcinsuredtwoinsh[key].name]!=undefined) {
			
					unbindSameElement.call(topvue, sameFieldLcinusredtwo[targetName],
							targetElement);
				}
				
				if (sameFieldLcinusredtwoAddress[topvue.form_elements.lcinsuredtwoinsh[key].name]!=undefined) {
					
					unbindSameElement.call(topvue, sameFieldLcinusredtwoAddress[targetName],
							targetElement);
				}

			}
			$("#inshlcinsuredpostalflag").show();
		}
	};
	
	/**
	 * 投保人 同被保人
	 */
	afterVueSelect.relationtomaininsured = function(form_element) {
		
		if($('#relationtomaininsured').val() == '30'){
		$('#relationtomaininsuredother').removeAttr("disabled");
		
	}else{
		$('#relationtomaininsuredother').attr("disabled",true);
		$('#relationtomaininsuredother').val("");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"otherrelatoinsu", "");
	}
};
	

	
  //--------------------------------------------------------------- INSH 多被保人 处理逻辑 开始 ---------------------------------------------------
  	

	/**
	 * 多被保人职业代码处理 
	 */
	afterVueSelect. multilcinsuredroccupationcodeinsh = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	var eleName = this.namepref +this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;

     obj=$("input[name='"+eleName+"']");
	if(topvue.formdata['lcinsuredmulti']){
		var occupat = $("input[name='lcinsuredmulti"+this.elementindex+".jobinfo']").val();
		var occupationcode =  obj.val();
		try {
			if(occupat!=null&&occupationcode!=''&&occupat.indexOf("K")!=-1 
					&& occupationcode!=null&&occupationcode!=''&& occupationcode.indexOf("K04")==-1){
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"insutshowflag-"+this.elementindex, "N");
				$("input[name='lcinsuredmulti"+this.elementindex+".lcinsuredcompany']").attr("disabled","disabled");
				var index = this.elementindex.replace(/[^0-9]/ig,"");
				vueobj.testdivchange.formdata.lcinsuredmulti[index].lcinsuredcompany="";
				vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.countrycode_loy="";
				vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.employareacodetel="";
				vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.employphone="";
				vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.employcountry="";
				vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.employprovince="";
				vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.employcity="";
				vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.employarea="";
				
			}else{
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"insutshowflag-"+this.elementindex, "Y");
				$("input[name='lcinsuredmulti"+this.elementindex+".lcinsuredcompany']").removeAttr("disabled");
				
			}
		} catch (e) {
			
		}
	}				
   }
	
	//多被保人学校单位地址省
	commonCombobox_option.commonCombobox_insuredemployprovincemul ={

		url :  path + '/newCont/codeselect/allprovinceid/province',
		valueField : "provinceid",
		delayLoadDataFlag : true,
		relateType: "vue",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
	};
	//多被保人学校单位地址市
	commonCombobox_option.commonCombobox_insuredemploycitymul  =  {
		url :  path + '/newCont/codeselect/allcity/#lcinsuredmulti.lcaddress.employprovince',
		valueField : "cityid",
		delayLoadDataFlag : true,
		relateType: "vue",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
	};
	//多被保人学校单位地址区
	commonCombobox_option.commonCombobox_insuredemploydistrictmul = {

		url :  path + '/newCont/codeselect/allcounty/#lcinsuredmulti.lcaddress.employcity',
		valueField : "countyid",
		delayLoadDataFlag : true,
		relateType: "vue",
		// 显示在输入框的
		inputText : "countyname",
		textShow : [ "countyname" ]
	};

	//多被保人居住地址(省)
	commonCombobox_option.commonCombobox_insuredhomeprovincemul={

		url :  path + '/newCont/codeselect/allprovinceid/province',
		valueField : "provinceid",
		delayLoadDataFlag : true,
		relateType: "vue",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
	};
	//多被保人居住地址(市)
	commonCombobox_option.commonCombobox_insuredhomecitymul ={

		url :  path + '/newCont/codeselect/allcity/#lcinsuredmulti.lcaddress.homeprovince',
		valueField : "cityid",
		delayLoadDataFlag : true,
		relateType: "vue",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
	};		
	//多被保人居住地址(区)
	commonCombobox_option.commonCombobox_insuredhomedistrictmul = {

		url :  path + '/newCont/codeselect/allcounty/#lcinsuredmulti.lcaddress.homecity',
		 valueField : "countyid",
		 delayLoadDataFlag : true,
		 relateType: "vue",
			// 显示在输入框的
		inputText : "countyname",
		textShow : [ "countyname" ]
	};
	
	
	
	
	
	
	//同投保人居住地址
	afterVueSelect.multilcinsuredpostalflag = function(form_element) {

		var topvue = getTopvueObj(this);
		var obj = $("#"+form_element.id);
		
		
		if(topvue.formdata['lcinsuredmulti']){
			var index = getElementIntex(this); 
			var relationtoappnt = topvue.formdata.lcinsuredmulti[index].relationtoappnt;
			if (relationtoappnt=="00") {
				return;
			}
			var eleName = this.namepref 
				+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
			
			obj=$("input[name='"+eleName+"']");
		
			if (obj.is("[type='checkbox']:checked")) {
				
				for ( var key in topvue.form_elements.lcinsuredmultiinsh) {
					
					var targetName= topvue.form_elements.lcinsuredmultiinsh[key].name;
					var targetElement= topvue.form_elements.lcinsuredmultiinsh[key];
					var index = getIndex(eleName);
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
					if(targetName.indexOf("zip")>0){
						var tttt="";
					}
					if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredmultiinsh[key].name]!=undefined) {
						bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
								topvue.formdata.lcinsuredmulti[index].lcaddress,targetName,targetElement,targetObj);
					}
				}
			
			} else {
				for ( var key in topvue.form_elements.lcinsuredmultiinsh) {
	 
					var targetName= topvue.form_elements.lcinsuredmultiinsh[key].name;
					var targetElement= topvue.form_elements.lcinsuredmultiinsh[key];
					var index = getIndex(eleName);
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
					if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredmultiinsh[key].name]!=undefined) {
						try {
							if(targetName=='homeprovince'||targetName=='homecity'||targetName=='homedistrict'){							
								var addresscountry=$("input[name='lcinsuredmulti["+index+"].lcaddress.addresscountry']").val();
								if(addresscountry==undefined||addresscountry!='CN'){
									continue;
								}
							}					
						} catch (e) {
							
						}
						unbindSameElementByJqobj.call(topvue, onlysameFieldLcinusredAddress[targetName],
								targetElement,targetObj);
					}
				}
			}
			
		}	
	};
	
	/**
	 * 投保人 同被保人
	 */
	afterVueSelect.multilcinsuredrelationtoappntinsh = function(form_element) {
		var topvue = getTopvueObj(this);
		var obj = $("#"+form_element.id);
		var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
		var relationtoappnt=$("input[name='lcinsuredmulti"+this.elementindex+".relationtoappnt']").val();
		var index = this.elementindex.replace(/[^0-9]/ig,"");
		if(relationtoappnt == '30'){
//		$("input[name='lcinsuredmulti"+this.elementindex+".otherrelationtoappnt']").attr("disabled",false);
			$('#multilcinsuredwhetherGpgc\\['+index+'\\]').combobox("enable");
		}else{
			$('#multilcinsuredwhetherGpgc\\['+index+'\\]').combobox("disable");
			$('#multilcinsuredwhetherGpgc\\['+index+'\\]').combobox("clear");
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[index],"whetherGpgc", "");
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[index],"otherrelationtoappnt", "");
			
//			$("input[name='lcinsuredmulti"+this.elementindex+".otherrelationtoappnt']").attr("disabled",true);
//			
//			vueobj.testdivchange.formdata.lcinsuredmulti[index].otherrelationtoappnt="";
		}	 
		$('#multilcinsuredrelation\\['+index+'\\]').attr("disabled",true);
		
		
		var form =$(this.$el).parentsUntil("form").parent("form");
		if (relationtoappnt=="00") {
		
			for ( var key in topvue.form_elements.lcinsuredmultiinsh) {
				
				var targetName= topvue.form_elements.lcinsuredmultiinsh[key].name;
				var targetElement= topvue.form_elements.lcinsuredmultiinsh[key];
				
				if (sameFieldLcinusredtwo[topvue.form_elements.lcinsuredmultiinsh[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
					bindSameElementByJqobj.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusredtwo[targetName],
							topvue.formdata.lcinsuredmulti[index],targetName,targetElement,targetObj);
				}
				
				if (sameFieldLcinusredtwoAddress[topvue.form_elements.lcinsuredmultiinsh[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,"lcaddress."+targetName)+"']");
					bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredtwoAddress[targetName],
							topvue.formdata.lcinsuredmulti[index].lcaddress,targetName,targetElement,targetObj);
				}

			}
						
			topvue.$nextTick(function () { 
				try {
					form.data('bootstrapValidator').resetForm();
				} catch (e) {
				}
			});
			
			$("input[name='lcinsuredmulti"+this.elementindex+".lcaddress.postalflags']").hide();
			vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.postalflags=""

		} else {																				
			for ( var key in topvue.form_elements.lcinsuredmultiinsh) {			
				var targetName= topvue.form_elements.lcinsuredmultiinsh[key].name;
				var targetElement= topvue.form_elements.lcinsuredmultiinsh[key];
				var index = getIndex(eleName);
				
				if (sameFieldLcinusredtwo[topvue.form_elements.lcinsuredmultiinsh[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
					try {
						if(targetName=='otherincome'){
							var mainincome=$("input[name='lcinsuredmulti["+index+"].mainincome']").val();
							if(mainincome==undefined||mainincome!='4'){
								continue;
							}
						}
					} catch (e) {
						
					}									
					unbindSameElementByJqobj.call(topvue, sameFieldLcinusredtwo[targetName],
							targetElement,targetObj);
				}
				
				if (sameFieldLcinusredtwoAddress[topvue.form_elements.lcinsuredmultiinsh[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,"lcaddress."+targetName)+"']");
					try {
						if(targetName=='employprovince'||targetName=='employcity'||targetName=='employarea'){
							var employcountry=$("input[name='lcinsuredmulti["+index+"].lcaddress.employcountry']").val();
							if(employcountry==undefined||employcountry!='CN'){
								continue;
							}
						}						
					} catch (e) {
						
					}
					try {
						if(targetName=='homeprovince'||targetName=='homecity'||targetName=='homedistrict'){
							var postalflags=$("input[name='lcinsuredmulti["+index+"].lcaddress.postalflags']");
							if(postalflags.is("[type='checkbox']:checked")){
								continue;
							}
							
							var addresscountry=$("input[name='lcinsuredmulti["+index+"].lcaddress.addresscountry']").val();
							if(addresscountry==undefined||addresscountry!='CN'){
								continue;
							}
						}					
					} catch (e) {
						
					}										
					unbindSameElementByJqobj.call(topvue, sameFieldLcinusredtwoAddress[targetName],
							targetElement,targetObj);
				}

			}
			var indexs = getElementIntex(this);
			var idtype2 = null;
			if(indexs !=null && indexs != ""){
				idtype2= topvue.formdata.lcinsuredmulti[indexs].lcinsuredidtype;
				/*if ((idtype2 !=null && idtype2 != "") && (idtype2 == "X")){
					$("#insuredrenewCount1\\["+indexs+"\\]").attr("disabled",false);
				}else {
					vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[indexs],"renewCount", null);//证件有效始期
					$("#insuredrenewCount1\\["+indexs+"\\]").attr("disabled",true);
				}*/
				if ((idtype2 !=null && idtype2 != "") && idtype2 != "I"){
					vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[indexs],"startingDate", null);
					$("#insuredstartingDate1\\["+indexs+"\\]").attr("disabled",true);
				}else {
					$("#insuredstartingDate1\\["+indexs+"\\]").attr("disabled",false);
				}
			}
			$("input[name='lcinsuredmulti"+this.elementindex+".lcaddress.postalflags']").show();
		}
	};

	/**
	 * 与第一被保人关系 
	 */
	afterVueSelect.multirelationtomaininsured = function(form_element) {		
		var topvue = getTopvueObj(this);
		var obj = $("#"+form_element.id);
		var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
		var relationtoappnt=$("input[name='lcinsuredmulti"+this.elementindex+".relatoinsu']").val();

		if(relationtoappnt == '30'){
		$("input[name='lcinsuredmulti"+this.elementindex+".otherrelatoinsu']").attr("disabled",false);
		}else{
		$("input[name='lcinsuredmulti"+this.elementindex+".otherrelatoinsu']").attr("disabled",true);
		var index = this.elementindex.replace(/[^0-9]/ig,"");
		vueobj.testdivchange.formdata.lcinsuredmulti[index].otherrelatoinsu="";
		}

		var form =$(this.$el).parentsUntil("form").parent("form");
		//与第一被保人关系同本人
		var relationtoinsu = $("input[name='lcinsuredmulti"+this.elementindex+".relatoinsu']").val();
		if (relationtoinsu=='00'){
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredname',topvue.formdata.lcinsured.lcinsuredname);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsurednativeplace',topvue.formdata.lcinsured.lcinsurednativeplace);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredsex',topvue.formdata.lcinsured.lcinsuredsex);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredroccupationcode',topvue.formdata.lcinsured.lcinsuredroccupationcode);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredidtype',topvue.formdata.lcinsured.lcinsuredidtype);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredidno',topvue.formdata.lcinsured.lcinsuredidno);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredcompany',topvue.formdata.lcinsured.lcinsuredcompany);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredbirthday',topvue.formdata.lcinsured.lcinsuredbirthday);
			this.$set(topvue.formdata.lcinsuredmulti[index],'insureidenddate',topvue.formdata.lcinsured.insureidenddate);
			this.$set(topvue.formdata.lcinsuredmulti[index],'rgtaddress',topvue.formdata.lcinsured.rgtaddress);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredresponsibility',topvue.formdata.lcinsured.lcinsuredresponsibility);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredbirthcounty',topvue.formdata.lcinsured.lcinsuredbirthcounty);
			this.$set(topvue.formdata.lcinsuredmulti[index],'lcinsuredotherresponsibility',topvue.formdata.lcinsured.lcinsuredotherresponsibility);
			this.$set(topvue.formdata.lcinsuredmulti[index],'industrytype',topvue.formdata.lcinsured.industrytype);
			this.$set(topvue.formdata.lcinsuredmulti[index],'banksccflag',topvue.formdata.lcinsured.banksccflag);
			this.$set(topvue.formdata.lcinsuredmulti[index],'bankcustomertype',topvue.formdata.lcinsured.bankcustomertype);
			this.$set(topvue.formdata.lcinsuredmulti[index],'marry',topvue.formdata.lcinsured.marry);
			this.$set(topvue.formdata.lcinsuredmulti[index],'domicile',topvue.formdata.lcinsured.domicile);
			this.$set(topvue.formdata.lcinsuredmulti[index],'jobinfo',topvue.formdata.lcinsured.jobinfo);
			this.$set(topvue.formdata.lcinsuredmulti[index],'otherjob',topvue.formdata.lcinsured.otherjob);
			this.$set(topvue.formdata.lcinsuredmulti[index],'mainincome',topvue.formdata.lcinsured.mainincome);
			this.$set(topvue.formdata.lcinsuredmulti[index],'otherincome',topvue.formdata.lcinsured.otherincome);
			this.$set(topvue.formdata.lcinsuredmulti[index],'startingDate',topvue.formdata.lcinsured.startingDate);
//			this.$set(topvue.formdata.lcinsuredmulti[index],'renewCount',topvue.formdata.lcinsured.renewCount);
			
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'zipcode',topvue.formdata.lcinsuredaddress.zipcode);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'mobile',topvue.formdata.lcinsuredaddress.mobile);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'homezipcode',topvue.formdata.lcinsuredaddress.homezipcode);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'homeprovince',topvue.formdata.lcinsuredaddress.homeprovince);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'homephone',topvue.formdata.lcinsuredaddress.homephone);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'homedistrict',topvue.formdata.lcinsuredaddress.homedistrict);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'homecity',topvue.formdata.lcinsuredaddress.homecity);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'homeaddress',topvue.formdata.lcinsuredaddress.homeaddress);
			this.$set(topvue.formdata.lcinsuredmulti[index],'email',topvue.formdata.lcinsuredaddress.email);

			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'countrycodetel_tel',topvue.formdata.lcinsuredaddress.countrycodetel_tel);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'areacodetel',topvue.formdata.lcinsuredaddress.areacodetel);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'countrycodetel_mob',topvue.formdata.lcinsuredaddress.countrycodetel_mob);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'employprovince',topvue.formdata.lcinsuredaddress.employprovince);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'employcountry',topvue.formdata.lcinsuredaddress.employcountry);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'employcity',topvue.formdata.lcinsuredaddress.employcity);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'employarea',topvue.formdata.lcinsuredaddress.employarea);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'employdetails',topvue.formdata.lcinsuredaddress.employdetails);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'employareacodetel',topvue.formdata.lcinsuredaddress.employareacodetel);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'employphone',topvue.formdata.lcinsuredaddress.employphone);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'countrycode_loy',topvue.formdata.lcinsuredaddress.countrycode_loy);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'employphonecountry',topvue.formdata.lcinsuredaddress.employphonecountry);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'homephonecountry',topvue.formdata.lcinsuredaddress.homephonecountry);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'countrycodetel_tel',topvue.formdata.lcinsuredaddress.countrycodetel_tel);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'areacodetel',topvue.formdata.lcinsuredaddress.areacodetel);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'homephone',topvue.formdata.lcinsuredaddress.homephone);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'addresscountry',topvue.formdata.lcinsuredaddress.addresscountry);
			this.$set(topvue.formdata.lcinsuredmulti[index].lcaddress,'mobilephonecountry',topvue.formdata.lcinsuredaddress.mobilephonecountry);

			topvue.$nextTick(function () {
				try {
					form.data('bootstrapValidator').resetForm();
				} catch (e) {
				}
			});

		}
};


//主要来源 不为其他为置灰
afterVueSelect.multilcinsuredmainincome = function(form_element) {
	
	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	var eleName = this.namepref +this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;	
	//判定关系
	var relationtoappnt=$("input[name='lcinsuredmulti["+num+"].relationtoappnt']").val();
	obj=$("input[name='"+eleName+"']").val();
	if(relationtoappnt=="00"){
		return;
	}
	if(obj=='4'){
		$("input[name='lcinsuredmulti"+this.elementindex+".otherincome']").attr("disabled",false);
	}else{
		$("input[name='lcinsuredmulti"+this.elementindex+".otherincome']").attr("disabled",true);
		var num = getElementIntex(this);
		vueobj.testdivchange.formdata.lcinsuredmulti[num].otherincome="";
	}

	
}
	
//多被保人学校单位住址信息
afterVueSelect.multilcinsuredemploycountry= function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	var eleName = this.namepref+this.form_element.groupid+'.'+ this.form_element.name;
	var num = this.namepref.replace(/[^0-9]/ig,"")
	//判定关系
	var relationtoappnt=$("input[name='lcinsuredmulti["+num+"].relationtoappnt']").val();
	obj=$("input[name='"+eleName+"']").val();
	if(relationtoappnt=="00"){
		return;
	}
	
	if(obj!= 'CN' ){		
		
		if(obj!=""&&obj!=null&&obj!=undefined){
			vueobj.testdivchange.formdata.lcinsuredmulti[num].lcaddress.employprovince="";
			vueobj.testdivchange.formdata.lcinsuredmulti[num].lcaddress.employcity="";
			vueobj.testdivchange.formdata.lcinsuredmulti[num].lcaddress.employarea="";
			$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employprovince']").combobox("clear");
			$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employcity']").combobox("clear");
			$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employarea']").combobox("clear");
		}
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employprovince']").combobox("disable");
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employcity']").combobox("disable");
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employarea']").combobox("disable");
	}else{
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employprovince']").combobox("enable");
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employcity']").combobox("enable");
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.employarea']").combobox("enable");			
	}
	
};

//多被保人家庭地址信息
afterVueSelect.multilcinsuredaddresscountry = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	var eleName = this.namepref+this.form_element.groupid+'.'+ this.form_element.name;
	var num = this.namepref.replace(/[^0-9]/ig,"")
	//判定关系
	var relationtoappnt=$("input[name='lcinsuredmulti["+num+"].relationtoappnt']").val();
	obj=$("input[name='"+eleName+"']").val();
	if(relationtoappnt=="00"){
		return;
	}
	 var postalflags=$("input[name='lcinsuredmulti["+num+"].lcaddress.postalflags']");
	if(postalflags.is("[type='checkbox']:checked")){
		return;
	}
	if(obj!= 'CN'){		
		if(obj!=""&&obj!=null&&obj!=undefined){
			vueobj.testdivchange.formdata.lcinsuredmulti[num].lcaddress.homeprovince="";
			vueobj.testdivchange.formdata.lcinsuredmulti[num].lcaddress.homecity="";
			vueobj.testdivchange.formdata.lcinsuredmulti[num].lcaddress.homedistrict="";
			$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homeprovince']").combobox("clear");
			$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homecity']").combobox("clear");
			$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homedistrict']").combobox("clear");
		}
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homeprovince']").combobox("disable");
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homecity']").combobox("disable");
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homedistrict']").combobox("disable");
	}else{
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homeprovince']").combobox("enable");
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homecity']").combobox("enable");
		$("input[name='lcinsuredmulti\\["+num+"\\].lcaddress.homedistrict']").combobox("enable");			
	}
};








commonCombobox_option.commonCombobox_maininsuredflag = {
	"data" : [ {
		"value" : "Y",
		"text" : "是"
	} ]
},
commonCombobox_option.commonCombobox_mainriskflag = {
	"data" : [ {
		"value" : "1",
		"text" : "主险所属被保人"
	},{
		"value" : "3",
		"text" : "主附加险所属被保人"
	} ]
},
commonCombobox_option.commonCombobox_mainriskflag1 = {
	"data" : [ {
		"value" : "1",
		"text" : "主险所属被保人"
	}, {
		"value" : "2",
		"text" : "附加险所属被保人"
	}]
},
commonCombobox_option.commonCombobox_maininsuredflag1 = {
	"data" : [ {
		"value" : "Y",
		"text" : "是"
	}, {
		"value" : "N",
		"text" : "不是"
	} ]
},	
//与第一被保人关系（包含同本人）
commonCombobox_option.commonCombobox_relation_insh_mul = {

		url : path + '/newCont/codeselect/common/lcinsuredmul1/relation_insh',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "codename" ,
		textShow : [ "codename" ]
		
	};


//--------------------------------------------------------------- INSH 多被保人 处理逻辑 结束 ---------------------------------------------------	
	
	//根据身份证号，同步出生日期
	afterVueSelect.inshlcinsuredidno = function(form_element) {
		var topvue = getTopvueObj(this);
		var obj = $("[name='" + form_element.groupid + this.elementindex + "."
				+ form_element.name + "']");
		/*var form = $(this.$el).parentsUntil("form").parent("form");*/
		if($("#inshlcinsuredidtype").val() != "I" && $("#inshlcinsuredidtype").val() != "J"){
			return;
		}
		if($("#inshlcinsuredidtype").val() == "I"||$("#inshlcinsuredidtype").val() == "J"){
			if (obj.is("[id='inshlcinsuredidno']")){
//				topvue.$set(topvue.formdata.lcinsured,"insureidenddate","2099-01-01"); 
				var idno = $("#inshlcinsuredidno").val();
				var birthday = idno.substring(6,14);
				var year = birthday.substring(0,4);
				var mon = birthday.substring(4,6);
				var day = birthday.substring(6);
				var formatBirth = year + "-" + mon + "-" + day;
				topvue.$set(topvue.formdata.lcinsuredtwo,"lcinsuredbirthday",formatBirth);
				
			}
		/*	//重置出生日期的校验
			if($("#lcinsuredidno").val().length == 18){
				form.data('bootstrapValidator').resetField($('#lcinsuredbirthday'));
//				$.fn.bootstrapValidator.validators.lcinsured_idno;
			}*/
		}
		
	}

	$.fn.bootstrapValidator.validators.lcinsuredtwo_idno = {
			validate : function(validator, $field, options) {
				var topvueobj = getTopvueObj(options.vueobj);
				var lcinsured = topvueobj.formdata.lcinsuredtwo;
				var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
				if (null!=lcinsured.lcinsuredidno){
					if(lcinsuredtwo.lcinsuredidno.length==18||(lcinsuredtwo.lcinsuredidtype!="I"&&lcinsuredtwo.lcinsuredidtype!="J")){
						form.data('bootstrapValidator').resetField($("#lcinsuredbirthday"));
						form.data('bootstrapValidator').updateStatus($field, "VALID");
						form.find("input[id*='lcinsuredidno']").each(function() {
							if (!form.data('bootstrapValidator').isValidField($(this))) {
								form.data('bootstrapValidator').revalidateField($(this));
							}

						});
						return true;
					}
				}
				return false;
			}
		};
		bootstrap_valid.lcinsuredtwo_idno = function(validitem) {

			var vueobj = this;
			var validobj = {
				message : "当前证件类型下证件号码必须为18位，请重新输入",
				vueobj : vueobj
			};

			return validobj;

		};
		
		
		
		
		var temp_birthday="";

		afterloadNewElements.lcinsured_tabinfo=function(){
			
			setTimeout(function(){
				if(($("#lcinsuredidtype").is(":visible")||$("#lcinsuredidtype").length>0)){
		   		 $("#lcinsuredidtypeTitle").remove();
		   		$("#lcinsuredidtype").parent().append("<small id='lcinsuredidtypeTitle' class='help-block' style='color: red;'>请注意，" +
		   				"此处选择的被保险证件类型，需和其之后通过手机银行上传的证件文件（e.g.,图片）的类型保持一致。若被保险人选择了“身份证”，则需上传其身份证的图片，不能上传户口本上有证件号码的图片。</small>");
				 }
			},50);
			var _this=this;
			var topvue = getTopvueObj(this);
			temp_birthday=topvue.formdata.lcinsured.lcinsuredbirthday;
			setTimeout(function(){
				if(($("#lcinsuredname").is(":visible")||$("#lcinsuredname").length>0)){
					$("#lcinsurednameTitle").remove();
					$("#lcinsuredname").parent().append("<small id='lcinsurednameTitle' class='help-block' style='color: red;'>请确保此处输入被保险人姓名和其证件姓名完全一致。若使用身份证，请输入中文姓名！</small>");
				}
				if(($("#inshlcinsuredname").is(":visible")||$("#inshlcinsuredname").length>0)){
					$("#inshlcinsurednameTitle").remove();
					$("#inshlcinsuredname").parent().append("<small id='inshlcinsurednameTitle' class='help-block' style='color: red;'>请确保此处输入被保险人姓名和其证件姓名完全一致。若使用身份证，请输入中文姓名！</small>");
				}
		    	/*if($("#insuredrenewCount").is(":visible")){
		    		 $(".zh").remove();
					 $("input[id^='insuredrenewCount']").parent().append("<small class='help-block zh' style='color: red;'>请注意，" +
					   				"请按证件上的换证次数填写，例如：01。</small>");
					 }*/
			},50);
			/* $("input[value='增加新被保人']").click(function(){
				 _this.$nextTick(function(){
			 		 $(".zh").remove();
					 $("input[id^='insuredrenewCount']").parent().append("<small class='help-block zh' style='color: red;'>请注意，" +
					   				"请按证件上的换证次数填写，例如：01。</small>");
			 })
			 })*/
		}
		
		beforesubmitvueform.lcinsured_tabinfoform=function(){
			var topvue = getTopvueObj(this);
			//校验主附险主被保人个数			
			
			if(temp_birthday!=""){
				if(topvue.formdata.lcinsured.lcinsuredbirthday!=temp_birthday){
					if(confirm("客户证件生日与建议书系统的录入生日不一致，请点击【确认】保存或【取消】修改证件信息。")){
					}else{
						return false;
					}
				}
			}
			
			if(topvue.formdata['lcinsuredmulti']){
				var lcinsuredlist = topvue.formdata.lcinsuredmulti;
				var count_1=0;
				var count_2=0;
				var count_3=0;
				var count_4=0;
				for (var i = 0; i < lcinsuredlist.length; i++) {
					if(lcinsuredlist[i].mainriskflag=='1'){
						if(lcinsuredlist[i].maininsuredflag=='Y'){
							count_1++;
						}
					}else if(lcinsuredlist[i].mainriskflag=='2'){
						if(lcinsuredlist[i].maininsuredflag=='Y'){
							count_2++; //附加险所属主被保人
						}else{
							count_3++; //附加险所属其他被保人
						}											
					}else if(lcinsuredlist[i].mainriskflag=='3'){
						count_4++; //主附加险所属主被保人
					}
				}
				// if(topvue.formdata.lcinsured.mainriskflag=='3'){
				// 	if(count_1>0){
				// 		alert("主险的主被保人个数不能大于1个");
				// 		return false;
				// 	}
				// 	if(count_2>0){
				// 		alert('附加险的主被保人个数不能大于1个');
				// 		return false;
				// 	}
				//
				// }else{

					if(topvue.formdata.newContApply.riskcode=="@Z0"){
						if(count_1>0){
							alert('主险的主被保人个数不能大于1个');
							return false;
						}
						if(count_3>0&&count_4<0){
							alert('此产品附加险所属被保人需为主被保人');
							return false;
						}
					}else{
						if(count_1>0){
							alert('主险的主被保人个数不能大于1个');
							return false;
						}
						if(count_2>1){
							alert('附加险的主被保人个数不能大于1个');
							return false;
						}
						if(count_2==0&&count_3>0){
							alert('如果已填写附加险所属被保人，附加险所属主被保人信息不能为空');
							return false;
						}
					}

					
				// }
			}
			
			
			//3.保存被保险人信息时， 若投被保险人信息非同一人时，请检查投保人和被保险人的证件号码是否相同，
			//若相同，则报错“投保人和被保险人证件号码相同，请检查投被保险人关系是否填写正确！”		  00为本人		
			if (topvue.formdata.lcinsured.relationtoappnt!="00"&&topvue.formdata.lcinsured.relationtoappnt!= "") {
					var idno= topvue.formdata.lcappnt.idno;//投保人证件号码
					var lcinsuredidno= topvue.formdata.lcinsured.lcinsuredidno;////被保人证件号码
					if(idno!=""&&lcinsuredidno!=""){
						if(idno.trim()==lcinsuredidno.trim()){
							alert("投保人和被保险人证件号码相同，请检查投被保险人关系是否填写正确！");
							return false;
						}
					}
			}
			//证件起期和换证次数的校验
			var date = new Date();
		    var seperator1 = "-";
		    var year = date.getFullYear();
		    var month = date.getMonth() + 1;
		    var strDate = date.getDate();
		    if (month >= 1 && month <= 9) {
		        month = "0" + month;
		    }
		    if (strDate >= 0 && strDate <= 9) {
		        strDate = "0" + strDate;
		    }
		    var currentdate = year + seperator1 + month + seperator1 + strDate;
			//主被保人
			if(topvue.formdata.lcinsured.lcinsuredidtype =="I"){
				
				if(topvue.formdata.lcinsured.startingDate==null 
						|| topvue.formdata.lcinsured.startingDate=="" ){
						alert("证件有效起期不能为空");
						return false;
				}
					if(new Date(topvue.formdata.lcinsured.startingDate)>new Date(currentdate)){
						alert("证件有效起期必须小于等于当前日期");
						return false;
					}
					if(new Date(topvue.formdata.lcinsured.startingDate)>=
						new Date(topvue.formdata.lcinsured.appntenddate)){
						alert("证件有效起期必须小于证件有效止期");
						return false;
					}	
				
			}
			/*if(topvue.formdata.lcinsured.lcinsuredidtype== "X" ){
			
				if(topvue.formdata.lcinsured.renewCount==null 
						|| topvue.formdata.lcinsured.renewCount=="" ){
					alert("证件为港澳台通行证，换证次数不可为空");
					return false;
				}
				var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.lcinsured.renewCount)).slice(-2);//01
				topvue.$set(topvue.formdata.lcinsured,"renewCount",newrenewcount);
			}*/
			//第二被保人
			if(topvue.formdata.lcinsuredtwo.lcinsuredidtype!=null && topvue.formdata.lcinsuredtwo.lcinsuredidtype!=""){
				if(topvue.formdata.lcinsuredtwo.lcinsuredidtype== "I"){
				if(topvue.formdata.lcinsuredtwo.startingDate==null 
						|| topvue.formdata.lcinsuredtwo.startingDate=="" ){
					alert("证件有效起期不可为空");
					return false;
				}
				
				if(new Date(topvue.formdata.lcinsuredtwo.startingDate)>new Date(currentdate)){
					alert("有效起期必须小于等于当前日期");
					return false;
				}
				if((new Date(topvue.formdata.lcinsuredtwo.startingDate))>=
					(new Date(topvue.formdata.lcinsuredtwo.insureidenddate))){
					alert("有效起期必须小于有效止期");
					return false;
				}	
				}
			}
		/*if((topvue.formdata.lcinsuredtwo.lcinsuredidtype!=null && topvue.formdata.lcinsuredtwo.lcinsuredidtype!="")&&
				topvue.formdata.lcinsuredtwo.lcinsuredidtype== "X"){
			
			if(topvue.formdata.lcinsuredtwo.renewCount==null 
					|| topvue.formdata.lcinsuredtwo.renewCount=="" ){
				alert("证件为港澳台通行证，换证次数不可为空");
				return false;
			}
			var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.lcinsuredtwo.renewCount)).slice(-2);//01
			topvue.$set(topvue.formdata.lcinsuredtwo,"renewCount",newrenewcount);
		}*/
			//多被保人
			var lcinsuredlist = topvue.formdata.lcinsuredmulti;
			for(var i=0;i<lcinsuredlist.length;i++){
			
				if(lcinsuredlist[i].lcinsuredidtype!=null && lcinsuredlist[i].lcinsuredidtype!=""){
					
					if(lcinsuredlist[i].lcinsuredidtype== "I"){
					if(lcinsuredlist[i].startingDate==null 
							|| lcinsuredlist[i].startingDate=="" ){
						alert("证件有效起期不可为空");
						return false;
					}
					
					if(new Date(lcinsuredlist[i].startingDate)>new Date(currentdate)){
						alert("有效起期必须小于等于当前日期");
						return false;
					}
					if((new Date(lcinsuredlist[i].startingDate))>=
						(new Date(lcinsuredlist[i].insureidenddate))){
						alert("有效起期必须小于有效止期");
						return false;
					}	
				}
				}
				/*if((lcinsuredlist[i].lcinsuredidtype!=null && lcinsuredlist[i].lcinsuredidtype!="")&&
						lcinsuredlist[i].lcinsuredidtype== "X"){
					if(lcinsuredlist[i].renewCount==null 
							|| lcinsuredlist[i].renewCount=="" ){
						alert("证件为港澳台通行证，换证次数不可为空");
						return false;
					}
					var newrenewcount = (Array(2).join(0) + parseInt(lcinsuredlist[i].renewCount)).slice(-2);//01
					topvue.$set(lcinsuredlist[i],"renewCount",newrenewcount);
					
				}*/
			}
			
			return true;
		}
		
		aftersubmitvueform.lcinsured_tabinfoform = function() {	
			var topvue = getTopvueObj(this);
		   console.log("lcinsured_tabinfoform==="+topvue.formdata.newContApply.investment);
			//汇丰多被保人
		   if(topvue.formdata.newContApply.investment=='M'){				
			  belonglcinsuredClear();
				console.log(vueobj["testdivchange"].formdata.newContApply.insChangeFlag);
				if(vueobj["testdivchange"].formdata.newContApply.insChangeFlag){
					ClearAll();									
				}
			}
		   return true;
		};
	