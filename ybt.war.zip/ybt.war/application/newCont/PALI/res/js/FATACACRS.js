/***
 * fataca控制
 */
	vueMethods.getFatacElements=function () {
		var elments  =[];

		return elments;
	};
	 
	var facataCRS={
			"zhongprovince"	:"postprovince",//通讯地址省
			"zhongcity"	:"postcity",//通讯地址市
			"zhongcountry"	:"postdistrict",//通讯地址区
			"zhongdetails"	:"postdetails"//通讯地址
		};
	/**
	 * 同投保人居住地址
	 */
	afterVueSelect.taxinhomeflag1 = function(form_element) {
		var topvue = getTopvueObj(this);
		var obj = $("[name='" + form_element.groupid + this.elementindex + "."+ form_element.name + "']");
			if (obj.is("[type='checkbox']:checked")) {
				for ( var key in topvue.form_elements.FATACACRS) {
					var targetName= topvue.form_elements.FATACACRS[key].name;
					var targetElement= topvue.form_elements.FATACACRS[key];
					if (facataCRS[topvue.form_elements.FATACACRS[key].name]!=undefined) {
						bindSameElement.call(topvue, topvue.formdata.lcappntaddress, facataCRS[targetName],
								topvue.formdata.taxinInfo,targetName,targetElement);
					}
				}
			} else {
				for ( var key in topvue.form_elements.FATACACRS) {
					var targetName= topvue.form_elements.FATACACRS[key].name;
					var targetElement= topvue.form_elements.FATACACRS[key];
					if (facataCRS[topvue.form_elements.FATACACRS[key].name]!=undefined) {
						unbindSameElement.call(topvue, facataCRS[targetName],targetElement);
			    	}
				}
			}
	};
	
	//现居住地址（中文）控制
	afterVueSelect.taxtinnowcountry= function(form_element) {
		var topvue = getTopvueObj(this);
		if(topvue.formdata.taxinInfo.nowcountry!="CN"){
			topvue.$set(topvue.formdata.taxinInfo,"nowprovince","");
			$("#taxtinnowprovince").combobox('disable');
			//this.$set(topvue.form_elements.FATACACRS[5], "cssClass", topvue.form_elements.FATACACRS[3].cssClass+ " disabled");
			topvue.$set(topvue.formdata.taxinInfo,"nowcity","");
			$("#taxtinnowcity").combobox('disable');
			//this.$set(topvue.form_elements.FATACACRS[10], "cssClass", topvue.form_elements.FATACACRS[7].cssClass+ " disabled");	
		}
		else {
//			this.$set(topvue.form_elements.FATACACRS[5], "cssClass", "null");
			$("#taxtinnowprovince").combobox('enable');
//			this.$set(topvue.form_elements.FATACACRS[10], "cssClass", "null");
			$("#taxtinnowcity").combobox('enable');
		}
		
	};
	//出生地地址（中文）控制
	afterVueSelect.taxinzhongcountry2= function(form_element) {
		var topvue = getTopvueObj(this);
		if(topvue.formdata.taxinInfo.zhongcountry2!="CN"){
			topvue.$set(topvue.formdata.taxinInfo,"zhongprovince","");
			$("#taxinzhongprovince").combobox('disable');
//			this.$set(topvue.form_elements.FATACACRS[23], "cssClass", topvue.form_elements.FATACACRS[23].cssClass+ " disabled");
			topvue.$set(topvue.formdata.taxinInfo,"zhongcity","");
			$("#taxinzhongcity").combobox('disable');
//			this.$set(topvue.form_elements.FATACACRS[24], "cssClass", topvue.form_elements.FATACACRS[24].cssClass+ " disabled");	
		}
		else {
//			this.$set(topvue.form_elements.FATACACRS[23], "cssClass", "null");
			$("#taxinzhongprovince").combobox('enable');
//			this.$set(topvue.form_elements.FATACACRS[24], "cssClass", "null");
			$("#taxinzhongcity").combobox('enable');
		}
		
	};
	afterVueSelect.taxtinnowcountryPALI= function(form_element) {
		var topvue = getTopvueObj(this);
		if(topvue.formdata.taxinInfoPALI.nowcountry!="CN"){
			topvue.$set(topvue.formdata.taxinInfoPALI,"nowprovince","");
			$("#taxtinnowprovincePALI").combobox('disable');
//			this.$set(topvue.form_elements.FATACACRS[34], "cssClass", topvue.form_elements.FATACACRS[34].cssClass+ " disabled");
			topvue.$set(topvue.formdata.taxinInfoPALI,"nowcity","");
			$("#taxtinnowcityPALI").combobox('disable');
//			this.$set(topvue.form_elements.FATACACRS[37], "cssClass", topvue.form_elements.FATACACRS[37].cssClass+ " disabled");	
		}
		else {
//			this.$set(topvue.form_elements.FATACACRS[34], "cssClass", "null");
			$("#taxtinnowprovincePALI").combobox('enable');
//			this.$set(topvue.form_elements.FATACACRS[37], "cssClass", "null");
			$("#taxtinnowcityPALI").combobox('enable');
		}
		
	};
	//出生地地址（中文）控制
	afterVueSelect.taxinzhongcountry2PALI= function(form_element) {
		var topvue = getTopvueObj(this);
		if(topvue.formdata.taxinInfoPALI.zhongcountry2!="CN"){
			topvue.$set(topvue.formdata.taxinInfoPALI,"zhongprovince","");
			$("#taxinzhongprovincePALI").combobox('disable');
//			this.$set(topvue.form_elements.FATACACRS[53], "cssClass", topvue.form_elements.FATACACRS[53].cssClass+ " disabled");
			topvue.$set(topvue.formdata.taxinInfoPALI,"zhongcity","");
			$("#taxinzhongcityPALI").combobox('disable');
//			this.$set(topvue.form_elements.FATACACRS[54], "cssClass", topvue.form_elements.FATACACRS[54].cssClass+ " disabled");	
		}
		else {
//			this.$set(topvue.form_elements.FATACACRS[53], "cssClass", "null");
			$("#taxinzhongprovincePALI").combobox('enable');
//			this.$set(topvue.form_elements.FATACACRS[54], "cssClass", "null");
			$("#taxinzhongcityPALI").combobox('enable');
		}
		
	};
	
	/**
	 *  FATACACRS 加载后的处理
	 */
//	afterloadNewElements.FATACACRS_tabinfo = function(url, form_element) {
//		console.info( " FATACACRS 加载后的处理");
//		var topvue = getTopvueObj(this);
//		if(!checkCRSShow.call(topvue)){
//			//清除数据
//			if(topvue.formdata.lcappnt!=undefined){
//				
//				topvue.formdata.lcappnt.taxtype="";
//				topvue.formdata.lcappnt.multnation="";
//				topvue.formdata.lcappnt.usGreenCardFlag="";
//				topvue.formdata.lcappnt.taxtins=[];
//			}
//			
//			//清除数据
//			if(topvue.formdata.lcinsured!=undefined){
//				
//				topvue.formdata.lcinsured.taxtype="";
//				topvue.formdata.lcinsured.multnation="";
//				topvue.formdata.lcinsured.usGreenCardFlag="";
//				topvue.formdata.lcinsured.taxtins=[];
//			}
//			
//			
//			topvue.formdata.newContApply.fatacFlag="1";
//			topvue.$nextTick(function () { 
//				$("#FATACACRS_submit").trigger("click");
//			});
//			
//		}else{
//			topvue.formdata.newContApply.fatacFlag="0";
//		}
//	};
//	function checkCRSShow(){
// 
////		this.formdata.sublcpols;
//		var flag = false;
//		if(this.formdata.sublcpols!=undefined
//				&&this.formdata.lcpol!=undefined){
//			
//			
//			if(this.formdata.lcpol.insuyear=="1Y"){
////				return false;
//			}else{
//				flag=flag||true;
//			}
//			
//			for ( var index in this.formdata.sublcpols) {
//				
//				if(this.formdata.sublcpols[index]!=undefined
//						&&this.formdata.sublcpols[index].insuyear=="1Y"){
////					return false;
//				}else{
//					flag=flag||true;
//				}
//			}
//			
//		}
//		
//		return flag;
//	
//		
//	}
	
//	vueMethods.checkCRS=function () {
//		
//		
//		return checkCRSShow.call(this);
//	};
	/**
	 * 绿卡控制
	 */
//	vueMethods.checkAppntGreencardAndmult=function (formdata , address) {
//		
//		if(formdata.taxtype=='2'||formdata.taxtype=='3'){
//			return true;
//		}
//		
//		
//		if(formdata.nativeplace!='CN'){
//			return true;
//		}
//		
////		if(formdata.birthcounty=='CN'||formdata.birthcounty=='HK'
////			||formdata.birthcounty=='MO'||formdata.birthcounty=='TW'||formdata.birthcounty==""
////				||){
////			
////		}else{
////			return true;
////		}
//		
//		if(formdata.idtype=='X'){
//			return true;
//		}
//
//		
//		if(!checkPhone(address)){
//			return true;
//		}
//		
// 
//		return false;
//	};	
	
	
	
//	vueMethods.checkInsuGreencardAndmult=function (formdata  , address) {
//		
//		if(formdata.taxtype=='2'||formdata.taxtype=='3'){
//			return true;
//		}
//		
//		
//		if(formdata.lcinsurednativeplace!='CN'){
//			return true;
//		}
		
//		if(formdata.lcinsuredbirthcounty=='CN'||formdata.lcinsuredbirthcounty=='HK'
//			||formdata.lcinsuredbirthcounty=='MO'||formdata.lcinsuredbirthcounty=='TW'){
//			
//		}else{
//			return true;
//		}
		
//		if(formdata.lcinsuredidtype=='X'){
//			return true;
//		}
//
//		
//		if(!checkPhone(address)){
//			return true;
//		}
// 
//		return false;
//	};
//	
//	
//	function checkPhone(address){
//		 //固定电话国家代码
//		
//		var flag=true;
//		if(address.countrycodetel_tel==undefined 
//				||address.countrycodetel_tel==null 
//				||address.countrycodetel_tel=="" 
//				||address.countrycodetel_tel=="86"){
////			return true;
//		}else{
//			flag =flag&&false;
//		}
//	
//		//移动电话国家代码
//		
//		if(address.countrycodetel_mob==undefined 
//				||address.countrycodetel_mob==null 
//				||address.countrycodetel_mob=="" 
//				||address.countrycodetel_mob=="86"){
////			return true;
//		}else{
//			flag =flag&&false;
//		}
////		if(address.countrycodetel_mob=="86"){
////			return true;
////		} 
//		
//		return flag;
//	}
	
/*	afterVueSelect.taxtinflag = function(form_element) {
		var element_taxtin,element_notinreasonflag;
		for ( var key in this.form_elements) {
			
			
			if(this.form_elements[key].name=""){
				
			}
		}
		if(this.formdata.taxtinflag=="01"){
			
		}
		if(this.formdata.taxtinflag=="02"){
			
		}
		
	};*/
	
	//dbs_city  dbs_province dbs_area 永久居住地址省

	commonCombobox_option.commonCombobox_fatacacrsprovince1 ={

		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
	};
	commonCombobox_option.commonCombobox_fatacacrsprovince1PALI ={

			url :  path + '/newCont/codeselect/allprovinceid/province.do',
			valueField : "provinceid",
			// 显示在输入框的
			inputText : "provincename",
			textShow : [ "provincename" ]
		};
	
	//dbs_city  dbs_province dbs_area 永久居住地址市

	commonCombobox_option.commonCombobox_fatacacrscity1 = {

		url :  path + '/newCont/codeselect/allcity/#taxtinnowprovince.do',
		valueField : "cityid",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
	};
	
	commonCombobox_option.commonCombobox_fatacacrscity1PALI = {

			url :  path + '/newCont/codeselect/allcity/#taxtinnowprovincePALI.do',
			valueField : "cityid",
			// 显示在输入框的
			inputText : "cityname",
			textShow : [ "cityname" ]
		};
	
	
	commonCombobox_option.commonCombobox_fatacacrsprovince ={

			url :  path + '/newCont/codeselect/allprovinceid/province.do',
			valueField : "provinceid",
			// 显示在输入框的
			inputText : "provincename",
			textShow : [ "provincename" ]
		};
	commonCombobox_option.commonCombobox_fatacacrsprovince2PALI ={

			url :  path + '/newCont/codeselect/allprovinceid/province.do',
			valueField : "provinceid",
			// 显示在输入框的
			inputText : "provincename",
			textShow : [ "provincename" ]
		};
		//dbs_city  dbs_province dbs_area 永久居住地址市

		commonCombobox_option.commonCombobox_fatacacrscity = {

			url :  path + '/newCont/codeselect/allcity/#taxinzhongprovince.do',
			valueField : "cityid",
			// 显示在输入框的
			inputText : "cityname",
			textShow : [ "cityname" ]
		};
		commonCombobox_option.commonCombobox_fatacacrscity2PALI = {

				url :  path + '/newCont/codeselect/allcity/#taxinzhongprovincePALI.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			};

	commonCombobox_option.commonCombobox_fatacacountry={

			url : path + '/newCont/codeselect/common/iss_country',
			valueField : "code",
			/*mutually_exclusive:true,*/
			relateType : "vue",
			// 显示在输入框的
			inputText  :   "codename" ,
			textShow   : [ "codename" ]
			
		};
	commonCombobox_option.commonCombobox_fatacacountryPALI={

			url : path + '/newCont/codeselect/common/iss_country',
			valueField : "code",
			/*mutually_exclusive:true,*/
			relateType : "vue",
			// 显示在输入框的
			inputText  :   "codename" ,
			textShow   : [ "codename" ]
			
		};
	commonCombobox_option.commonCombobox_fatacacountry1={

		url : path + '/newCont/codeselect/common/iss_country',
		valueField : "code",
		/*mutually_exclusive:true,*/
		relateType : "vue",
		// 显示在输入框的
		inputText  :   "codename" ,
		textShow   : [ "codename" ]
		
	};
	commonCombobox_option.commonCombobox_fatacacountry1PALI={

			url : path + '/newCont/codeselect/common/iss_country',
			valueField : "code",
			/*mutually_exclusive:true,*/
			relateType : "vue",
			// 显示在输入框的
			inputText  :   "codename" ,
			textShow   : [ "codename" ]
			
		};
	commonCombobox_option.commonCombobox_fatacacountry2={

			url : path + '/newCont/codeselect/common/iss_country',
			valueField : "code",
			/*mutually_exclusive:true,*/
			relateType : "vue",
			// 显示在输入框的
			inputText  :   "codename" ,
			textShow   : [ "codename" ]
			
		};
	commonCombobox_option.commonCombobox_fatacacountry2PALI={

			url : path + '/newCont/codeselect/common/iss_country',
			valueField : "code",
			/*mutually_exclusive:true,*/
			relateType : "vue",
			// 显示在输入框的
			inputText  :   "codename" ,
			textShow   : [ "codename" ]
			
		};
	
	
	
	
	// 
	commonCombobox_option.commonCombobox_anzlTax = {

		url : path + '/newCont/codeselect/common/anzlTax',
		valueField : "code",
		// 显示在输入框的
		relateType: "vue",
		inputText : "codename",
		textShow : [ "codename" ]
	};
	// 
	commonCombobox_option.commonCombobox_noanzlTax = {

			url : path + '/newCont/codeselect/common/noanzlTax',
			valueField : "code",
			// 显示在输入框的
			relateType: "vue",
			inputText : "codename",
			textShow : [ "codename" ]
		};
	//
	commonCombobox_option.commonCombobox_taxtype = {

		url : path + '/newCont/codeselect/common/taxtin_insh',
		valueField : "code",
		// 显示在输入框的
		relateType: "vue",
		inputText : "codename",
		textShow : [ "codename" ]
	};
	commonCombobox_option.commonCombobox_usGreenCardFlag = {
			"data" : [ {
				"value" : "Y",
				"text" : "是"
			}, {
				"value" : "N",
				"text" : "否"
			} ]
		};
	commonCombobox_option.commonCombobox_multnation = {
			"data" : [ {
				"value" : "Y",
				"text" : "是"
			}, {
				"value" : "N",
				"text" : "否"
			} ]
		};
beforesubmitvueform.FATACACRS_tabinfoform=function(){
	var topvue = getTopvueObj(this);
	if(null!=topvue.formdata.subFormData.lccont) {
		initData(getActivePanelDIV(), true);
		var pflag = topvue.formdata.lccont.pageflag;
		fillinObj(topvue, topvue.formdata, topvue.formdata.subFormData, false, 0);
		topvue.formdata.lccont.pageflag = pflag;
		checkPaperChange = true;
	}
	return true;
}