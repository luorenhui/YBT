var vue_config = [];
var vueobj={};
var afterVueSelect={};
var bootstrap_valid={};
var afterloadNewElements={};
var beforesubmitvueform={};
var aftersubmitvueform={};
/** 
 * vue 增加方法  init
 */
var vueMethods ={};
vueMethods.tab_toggle_check=function(activeid){
	
};
vueMethods.addWord=function (){
	 this.$nextTick(function(){		
   	 for (var i=0;i<$("input[id^='bnfrenewCount']").length;i++){
   		 if(($("#bnfrenewCount\\["+i+"\\]").is(":visible") && $("#bnfrenewCountTitle"+i+"").length <= 0)){
		   		$("#bnfrenewCount\\["+i+"\\]").parent().append("<small id='bnfrenewCountTitle"+i+"' class='help-block zhq' style='color: red;'>请注意，" +
		   				"请按证件上的换证次数填写，例如：01。</small>");
				 }
	 }
    },200);	
};

vueMethods.checkFormDisabled=function (appflag,flag){
	if(flag =='5'){
		return true;
	}
	if( appflag=='01'|| appflag=='10'||
							 appflag==null|| appflag==''
							|| appflag=='undefined'){
		return false;
	}
	
	return true;
};

//电子签名radio控制
vueMethods.checkESignRadioDisabled = function (lccont,flag,uploadflag){
	var appflag = lccont.appflag;
	var chargecode = lccont.chargecode;
	var polApplyDate = lccont.polapplydate;
    var recording=lccont.recording;
    var esignflag = lccont.eSignFlag;
	/*var date = new Date();
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	if(month < 10){
		month = "0" + month;
	}
	var day = date.getDate();
	if(day < 10){
		day = "0" + day;
	}
	var today = year+month+day;*/
	
	if(flag == '5'){
		return true;
	}
	if(recording=='Y'){ 
		return true;
	}
	if(appflag == null || appflag == '' 
		|| polApplyDate == null || polApplyDate==''||uploadflag=='Y'||(esignflag=='P'&&uploadflag=="F") 
			/*|| chargecode == null || chargecode == ''*/){
		return true;
	}
	
	/*if(appflag == '01' || appflag =='10' ||appflag == '07'){
		return true;
	}else */
	if(appflag == '02' || appflag == '12' || appflag == '14'){
		/*if(chargecode == null || chargecode == 'W' || chargecode =='F' || chargecode == 'S' || chargecode =='E'){
			return false;
		}*/
		if(chargecode != 'C'){
			return false;
		}
	}else if(appflag =='04'){
		if(chargecode == null || chargecode == 'S' ){
			return false;
		}
	}else if(appflag =='05' || appflag =='06'){
		if(chargecode == null || chargecode == 'C' ){
			return false;
		}
	}else if(appflag == '09' || appflag == '13'){
		if(chargecode == null || chargecode == 'W' ){
			return false;
		} 
	}/*else if(appflag == '14'){
		if(chargecode == 'W' || chargecode == 'F' || chargecode == 'S' ||chargecode == 'E'){
			return false;
		}
	}else if(appflag == '12'){
		if(chargecode == 'W' || chargecode=='F' || chargecode=='S' || chargecode=='E'){
			return false;
		}
	}else if(appflag == '13'){
		if(chargecode == 'W'){
			return false;
		}
	}*/
	
	return true;
};

function getAge(birthday)
{
    //出生时间 毫秒
    var birthDayTime = new Date(birthday).getTime(); 
    //当前时间 毫秒
    var nowTime = new Date().getTime(); 
    //一年毫秒数(365 * 86400000 = 31536000000)
    return Math.ceil((nowTime-birthDayTime)/31536000000);
}

var tempVal = "";
//更新保单电子签名标记   
vueMethods.insertElectronicSignature=function (lccont, value){

	if(tempVal == value){ 
		return;
	}else{
		tempVal = value;
	}
	
	buttonControl(lccont.proposalcontno);
	if(vueobj["testdivchange"].formdata.lcnotConclusion&&vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="Y"){
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"eSignFlag",vueobj["testdivchange"].formdata.lccontTemp.eSignFlag);
		layer.msg("<span style='font-size:20px'>投保单号："+lccont.proposalcontno+"的影像文件已成功发送至保险公司，不能更改签署方式</span>",{offset:"t", time:10000,anim:6});
		return;
	}
	
	//tablet不支持的证件类型提示RM走纸质签的
	//身份证 护照 港澳台通行证  户口本 外国人永久居留证  港澳台居住证 被保人&另一持有人出生证
	var arr = ["I", "P", "X", "H","K","J","C"];
	
	var formdata=vueobj["testdivchange"].formdata;
	var lcappntIdType=formdata.lcappnt==null?null:formdata.lcappnt.idtype;
	var lcinsuredIdType=formdata.lcinsured==null?null:formdata.lcinsured.lcinsuredidtype;
	var lcinsuredtwoIdType=formdata.lcinsuredtwo==null?null:formdata.lcinsuredtwo.lcinsuredidtype;
	var anotherHolderIdType=formdata.ldcustomeraccount==null?null:formdata.ldcustomeraccount.anotherHolderIdType;
	//出生证 判断成年人不能电子签
	var lcinsuredbirthday=formdata.lcinsured==null?null:formdata.lcinsured.lcinsuredbirthday;
	var lcinsuredtwobirthday=formdata.lcinsuredtwo==null?null:formdata.lcinsuredtwo.lcinsuredbirthday;
	
	console.log("投保人证件类型:"+lcappntIdType+"," +
	"被保人1证件类型:"+lcinsuredIdType+",被保人2证件类型:"+lcinsuredtwoIdType+",另一持有人证件类型:"+anotherHolderIdType);
	if("E"==value){
		if(null!=lcappntIdType&&arr.toString().indexOf(lcappntIdType)<0||"C"==lcappntIdType||
		   null!=lcinsuredIdType&&arr.toString().indexOf(lcinsuredIdType)<0||
		   null!=lcinsuredtwoIdType&&arr.toString().indexOf(lcinsuredtwoIdType)<0||
		   null!=anotherHolderIdType&&arr.toString().indexOf(anotherHolderIdType)<0||
		   null!=lcinsuredbirthday&&"C"==lcinsuredIdType&&getAge(lcinsuredbirthday)>=18||
		   null!=lcinsuredtwobirthday&&"C"==lcinsuredtwoIdType&&getAge(lcinsuredtwobirthday)>=18){
		   layer.msg("<span style='font-size:20px'>此客户的证件暂时不支持使用电子签署认证，请走纸质流程！</span>",{offset:"t", time:10000,anim:6});
		}
	}

	//纸质 
	if("P"==value){
		$(function () { $("[data-toggle='popover']").popover("show"); });
		$.ajax({
			type : "POST",
			url:path+'/SFPJsonSend/JsonSend.do',
			data: {"transNo":formdata.lccont.transno},
			dataType : "json",
			success:function(data) {
				try {
					var response=JSON.parse(data);
					if(response.status=="SUCCESS"){
						alert("成功/Succeed");
					}else if(response.errorInfo[0].code!="OIM0042"){
						alert("同步SFP失败/Failed to update \n"+data);
					}else{
						 alert("双录停止失败！");
					}
				} catch (e) {
					alert("双录停止失败！");
				}
				
			},
			 error:function(){ 
				 alert("双录停止失败！");
			 }
		});
	}
	$.ajax({
		  url: path + "/newContEnter/selectUploadFlag.do",
		  data: {"proposalcontno":lccont.proposalcontno},
		  type: "post", 
		  success : function (data) {
			  if(data.success){
					var showdilog= layer.load(0, {
						  shade: [0.1,'#fff'] //0.1透明度的白色背景
					   });
					$.ajax({
					 	url: path + "/newContEnter/updateEsFlag.do",
				        data: {"transno":lccont.transno,"eSignFlag":value,"proposalcontno":lccont.proposalcontno},
				        type: "post", 
				        success : function (data) {
				            if(data.success){
	//			              layer.alert(data.msg);
				              buttonControl(lccont.proposalcontno);
				              vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"eSignFlag",value);
				        	  esignTable('Y');
				        	  layer.close(showdilog);
				          	  console.log(data.msg);
					         
				          	  $.ajax({
					        	 	url: path + "/AllianzController/esignTypeNotifyMELI.do",
					        	 	data: {"proposalcontno":lccont.proposalcontno,"operator":lccont.operator},
					        	 	type: "post", 
					        	 	success : function (data) {
					        	 		if(!data.success){
					        	 			alert(data.msg);
					        	 		}else{
					        	 			console.log("esign Type Notice Request Send Success.");
					        	 		}  
					        	 	},
					        	 	error : function (data){
					                    console.log("esign Type Notice Request Send Error.");
					                }
					            });
				         
				          }else{
				        	  layer.close(showdilog);
				          	layer.alert(data.msg);
				          }
				      },
				      error : function (data){
				    	  layer.close(showdilog);
				          alert("系统繁忙,请稍后再试！");
				      }
				  });
			 }else{
			        $("input[name='eSignFlag'][value='E']").prop("checked",true);
			    	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"eSignFlag","E");
			    	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcnotConclusion,"uploadflag","Y");
			        return;
			 }
		  },
		  error : function (data){
		      alert("系统繁忙,请稍后再试！");
		  }
	 });
	
};

	// vue_config.push({id : "testdivchange", url : path + "/vue/common/test.do",initFunction:pageinit});
	vue_config.push({
		id : "testdivchange",
		url : "/newCont/enter/get/tab/"+initFormdata.newContApply.insurancecom+"/insuranceContInput"

	});
	/**
	合并校验
	**/
//	var bootstrap_valid = {
//
//			ageFromBrithDay: function(validitem   ){
//        	 	var min =getRealValueFromVueObj.call( validitem.vueobj,validitem.min);
//		 		var max =getRealValueFromVueObj.call( validitem.vueobj,validitem.max);
//		 		var validobj= {
//		 				message:validitem.tempmessage + "年龄必须大于"+ min+ "小于"+ max,
//		 				minage:min,
//		 				maxage:max
//		 		};
//			 
//		 		return validobj;
//                 
//         }
//	
//	};
/**
 * 合并 变化 校验 
 */ 
combineCheckID["lccont_tabinfo"]="lcappnt_tabinfo";

 
		/***
		 * 下拉框配置
		 */
		var commonCombobox_option = {
			commonCombobox_notice : {
				"data" : [ {
					"value" : "N",
					"text" : "否"					
				}, {
					"value" : "Y",
					"text" : "是"
				} ]
			},
			commonCombobox_elementstatus : {
				"data" : [ {
					"value" : "01",
					"text" : "显示"
				}, {
					"value" : "02",
					"text" : "不显示"
				} ]
			},
			commonCombobox_country : {

				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]
				
			},
			commonCombobox_fataca : {
				"data" : [ {
					"value" : "01",
					"text" : "显示"
				}, {
					"value" : "02",
					"text" : "不显示"
				} ]
			},
			commonCombobox_IDtype : {
				url : path + '/newCont/codeselect/common/idtype',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
			
			/*commonCombobox_IDtype1 : {
				url : path + '/newCont/codeselect/id/idtype/#lccont.grpcontno',
				valueField : "idtype",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ],
			afterselect : function() {

				var idtype = $("#idtype").val();
				var grpcontno = vueobj["testdivchange"].formdata.lccont.grpcontno;	
				$.ajax({
					url : path + '/LdcodeController/selectidIndo.do',
					type : "POST",
					data : {
						"idtype" : idtype,
						"cifid": grpcontno
					},
					success : function(data) {						
						vueobj["testdivchange"].$set(
								vueobj["testdivchange"].formdata.lcappnt,
								"idno", data.idno);	
						vueobj["testdivchange"].$set(
								vueobj["testdivchange"].formdata.lcappnt,
								"appntenddate", data.expiredate);
					},
				});													
			  
			 },
			},*/
			
			commonCombobox_sex : {
				"data" : [ {
					"value" : "0",
					"text" : "男"
				}, {
					"value" : "1",
					"text" : "女"
				} ]
			},
			commonCombobox_bnforder : {
				"data" : [ {
					"value" : "1",
					"text" : "第一顺序"
				}, {
					"value" : "2",
					"text" : "第二顺序"
				} , {
					"value" : "3",
					"text" : "第三顺序"
				} ]
			},
			commonCombobox_lcinsuredtype : {
				url : path + '/newCont/codeselect/common/lcinsuredtype',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
			commonCombobox_insuredrelaToInsu : {
				url : path + '/newCont/codeselect/common/anzl_relation',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
			/*commonCombobox_bnfrelationship : {
				"data" : [ {
					"value" : "01",
					"text" : "父子"
				}, {
					"value" : "02",
					"text" : "母子"
				} ]
			},*/
			commonCombobox_lcinsuredrelationship : {
				"data" : [ {
					"value" : "01",
					"text" : "本人"
				}, {
					"value" : "02",
					"text" : "非本人"
				} ]
			},
			commonCombobox_insurancecom : {
				url : path + '/newContEnter/selectFromLacom.do',
				valueField : "agentcom",
				// 显示在输入框的
				inputText : "name",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : ["agentcom", "name" ]
			},
			
			commonCombobox_anotherHolderIdType : {
				url : path
						+ '/LdcodeController/selectIdTypeByCodetype.do?codetype=idtype',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]
			},
			commonCombobox_getpolmode : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : '1',
					codename : '同时发送电子和纸质保单'
				}, {
					code : '2',
					codename : '电子保单'
				} ]
			},
			commonCombobox_custtype : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : 'RCC',
					codename : '否'
				}, {
					code : 'NonRCC',
					codename : '是'
				} ]
			},
			commonCombobox_newbankaccno : {
				url : path + '/newCont/codeselect/selectAppntAccNoCNY/#grpcontno.do',
				valueField : "accountnumber",
				// 显示在输入框的
				inputText : "accountnumber",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "accountnumber" ],
				textShowFormat: function(textShow,linedata){
					var accountvalid='';
					if(linedata.accountvalid=='1'){
						accountvalid ='A';
					}else if(linedata.accountvalid=='2'){
						accountvalid ='D';
					}
					if(linedata.accountstatus=="Y"){
						return  "(联-"+accountvalid+")"+linedata.accountnumber;
					}else{
						return  "(个-"+accountvalid+")"+linedata.accountnumber;
					}  					
				},
				afterselect : function() {
					var newbankaccno = $("#newbankaccno").val();
					var grpcontno = $("#grpcontno").val();
					$.ajax({
						url : path + '/newContEnter/selectLdcustomeraccount.do',
						type : "POST",
						data : {
							"bankaccno" : newbankaccno,
							"cifid": grpcontno
						},
						success : function(data) {
							if(data.accountstatus=='Y'){
								console.log("-----联名账户----");
								$("#div_anotherHolderIdType").show();
								$("#div_anotherHolderIdNo").show();
								$("#div_anotherHolderName").show();
								$("#div_anotherHoldercountry").show();
									
							}else{
								$("#div_anotherHolderIdType").hide();
								$("#div_anotherHolderIdNo").hide();
								$("#div_anotherHolderName").hide();
								$("#div_anotherHoldercountry").hide();
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.ldcustomeraccount,
										"anotherHolderIdType", "");	
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.ldcustomeraccount,
										"anotherHolderIdNo", "");	
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.ldcustomeraccount,
										"anotherHolderName", "");
								
//								$("input[name='anotherHolderFlag']").prop("checked",false);
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.ldcustomeraccount,
										"anotherHolderCountry", ""); 
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.lccont,
										"anotherholder", "");
							} 
							vueobj["testdivchange"].$set(
									vueobj["testdivchange"].formdata.lccont,
									"accountbalance", data.accountbalance);
							if(initFormdata.newContApply.enterWay!="pEnter"){
								vueobj["testdivchange"].$set(
									vueobj["testdivchange"].formdata.lccont,
									"accountBranch", data.accountBranch);
							}
							vueobj["testdivchange"].$set(
									vueobj["testdivchange"].formdata.newContApply,
									"accountStatus", data.accountstatus);
						},
					});
				},
			 
		 },
		 
		
			//行业类别
			commonCombobox_lcinsuredindustry : {
				url : path + '/newCont/codeselect/occupation/AL.do',
				valueField : "occupationcode1",
				// 显示在输入框的
				inputText : "occupationname1",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname1" ]
			},
			//行业代码
			commonCombobox_lcinsuredindustrycode : {
				url : path + '/newCont/codeselect/occupation/#lcinsuredindustry/AL.do',
				valueField : "occupationcode2",
				// 显示在输入框的
				inputText : "occupationname2",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname2" ]
			},
			//行业代码
			commonCombobox_lcinsuredindustrycode1 : {
				url : path + '/newCont/codeselect/occupation/#lcinsuredindustry1/AL.do',
				valueField : "occupationcode2",
				// 显示在输入框的
				inputText : "occupationname2",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname2" ]
			},
			//职业代码
			commonCombobox_occupationcode : {
				url : path + '/newCont/codeselect/occupationocc/#lcinsuredindustrycode/AL.do',
				valueField : "occupationcode",
				// 显示在输入框的
				inputText : "occupationname",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname" ]
			},
			//职业代码
			commonCombobox_occupationcode1 : {
				url : path + '/newCont/codeselect/occupationocc/#lcinsuredindustrycode1/AL.do',
				valueField : "occupationcode",
				// 显示在输入框的
				inputText : "occupationname",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname" ]
			},
			
			//MELI职业代码   url:path + '/newContEnter/selectByLdoccupationVo.do',
			commonCombobox_occupationcodemeli : {
				url:path + '/newContEnter/selectByLdoccupationVo.do',
				valueField : "occupationcode",
				// 显示在输入框的
				inputText : "occupationname",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname" ]
			}
			,
			//MELI职位及工作内容
			commonCombobox_responsibilitymeli : {
				url:path + '/LdcodeController/selectLcodeByCodetype.do?codetype=responsibility',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]
			},
			//婚姻状况
			commonCombobox_marry :{
				url : path + '/LdcodeController/selectIdTypeByCodetype.do?codetype=marry',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]
			},
			//主要收入来源
			commonCombobox_appntincomesource :{
				url : path + '/LdcodeController/selectIdTypeByCodetype.do?codetype=appntincomesource',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]/*,
				afterselect: function(){
					if($('#appntincomesource').val() != '4'){
						$('#appntincomeother').attr("disabled",true);
						$('#appntincomeother').val("");
					}else{
						$('#appntincomeother').removeAttr("disabled");
					}
				}*/
			},
			//INSH投保人出生地国家下拉
			commonCombobox_birthcountry : {
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]/*,
				afterselect : function(){
					if($('#birthcountyinsh').val() != 'CN'){
						$('#appntbirthprovince').combobox("clear");
						$('#appntbirthprovince').combobox("disable");
						$('#appntcity').combobox("clear");
						$('#appntcity').combobox("disable");
					}else{
						$('#appntbirthprovince').combobox("enable");
						$('#appntcity').combobox("enable");
					}
				}*/
				
			},
			//INSH职业代码说明
			commonCombobox_occualias :{
				url : path + '/LdcodeController/selectDistinctCodeAlias.do?codetype=occupationinsh',
				valueField : "comcode",
				// 显示在输入框的
				inputText : "codealias",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codealias" ]
			},
			//INSH职业代码
			commonCombobox_occupationcodeinsh :{
				url : path + '/LdcodeController/code/#occualias.do',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]
			},
			/*commonCombobox_occupationcode : {
				url : path + '/newContEnter/selectByLdoccupationVo.do',
				valueField : "occupationcode",
				// 显示在输入框的
				inputText : "occupationname",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname" ]
			},*/
			commonCombobox_creditgrade : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : '1',
					codename : '农村'
				}, {
					code : '2',
					codename : '城镇'
				} ]
			},
			commonCombobox_jade : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : 'Y',
					codename : '是'
				}, {
					code : 'N',
					codename : '否'
				} ]
			},
			commonCombobox_multiplenativeplaceflag :{
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : 'Y',
					codename : '多重国籍'
				}, {
					code : 'N',
					codename : '非多重国籍'
				} ]/*,
				afterselect: function(){
					if($('#multiplenativeplaceflag').val() != 'Y'){
						$('#nativeplace2').combobox("clear");
						$('#nativeplace2').combobox("disable");	
						$('#nativeplace3').combobox("clear");
						$('#nativeplace3').combobox("disable");	
					}else{
						$('#nativeplace2').combobox("enable");
						$('#nativeplace3').combobox("enable");	
					}
				}*/
			}
			,
			commonCombobox_goaltype : {
				url : path
						+ '/LdcodeController/selectIdTypeByCodetype.do?codetype=goaltype',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]
			},
			//投保人通讯地址国家下拉
			commonCombobox_zactladdrcountry : {
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]/*,
				afterselect : function(){
					if($('#zactladdrcountry').val() != 'CN'){
						$('#appntpostprovinceinsh').combobox("clear");
						$('#appntpostprovinceinsh').combobox("disable");
						$('#appntpostcityinsh').combobox("clear");
						$('#appntpostcityinsh').combobox("disable");
						$('#appntpostdistrictinsh').combobox("clear");
						$('#appntpostdistrictinsh').combobox("disable");
					}else if($('#appntpostprovinceinsh_combobox').val() != '' && $('#appntpostprovinceinsh_combobox').val() !=undefined){
						return;
					}else{
						$('#appntpostprovinceinsh').combobox("enable");
						$('#appntpostcityinsh').combobox("enable");
						$('#appntpostdistrictinsh').combobox("enable");
					}
				}*/
				
			},
			//dbs_city  dbs_province dbs_area 投保人联系地址省
			commonCombobox_appntpostprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 投保人联系地址市
			commonCombobox_appntpostcity : {

				url :  path + '/newCont/codeselect/allcity/#appntpostprovinceinsh.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 投保人联系地址区
			commonCombobox_appntpostdistrict : {

				url :  path + '/newCont/codeselect/allcounty/#appntpostcityinsh.do',
				valueField : "countyid",
				// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			//投保人居住地址国家下拉
			commonCombobox_homecountry : {
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]
				
			},
			//dbs_city  dbs_province dbs_area 投保人居住地址省
			commonCombobox_appnthomeprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 投保人居住地址市
			commonCombobox_appnthomecity : {

				url :  path + '/newCont/codeselect/allcity/#homeprovince.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 投保人居住地址区
			commonCombobox_appnthomedistrict : {

				url :  path + '/newCont/codeselect/allcounty/#homecity.do',
				 valueField : "countyid",
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			 
		    //行业
		    commonCombobox_businesstype_insh : {

					url : path + '/newCont/codeselect/common/businesstype_insh.do',
					valueField : "code",
					// 显示在输入框的
					inputText :  "codename" ,
					textShow : [ "codename" ]
					
				},
				//永久居住地址国家下拉
				commonCombobox_permanentcountry : {
					url : path + '/newCont/codeselect/common/iss_country',
					valueField : "code",
					relateType: "vue",
					// 显示在输入框的
					inputText :  "codename" ,
					textShow : [ "codename" ]/*,
					afterselect : function(){
						if($('#permanentcountry').val() != 'CN'){
							$('#permanentprovince').combobox("clear");
							$('#permanentprovince').combobox("disable");
							$('#permanentcity').combobox("clear");
							$('#permanentcity').combobox("disable");
							$('#permanentarea').combobox("clear");
							$('#permanentarea').combobox("disable");
						}else if($('#permanentprovince_combobox').val() != '' && $('#permanentprovince_combobox').val() !=undefined){
							return;
						}else{
							$('#permanentprovince').combobox("enable");
							$('#permanentcity').combobox("enable");
							$('#permanentarea').combobox("enable");
						}
					}*/
					
				},
			//dbs_city  dbs_province dbs_area 永久居住地址省
			commonCombobox_permanentprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 永久居住地址市
			commonCombobox_permanentcity : {

				url :  path + '/newCont/codeselect/allcity/#permanentprovince.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 永久居住地址区
			commonCombobox_permanentarea : {

				url :  path + '/newCont/codeselect/allcounty/#permanentcity.do',
				 valueField : "countyid",
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			//曾居住地址国家下拉
			commonCombobox_previouscountry : {
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]/*,
				afterselect : function(){
					if($('#previouscountry').val() != 'CN'){
						$('#previousprovince').combobox("clear");
						$('#previousprovince').combobox("disable");
						$('#previouscity').combobox("clear");
						$('#previouscity').combobox("disable");
						$('#previousarea').combobox("clear");
						$('#previousarea').combobox("disable");
					}else{
						$('#previousprovince').combobox("enable");
						$('#previouscity').combobox("enable");
						$('#previousarea').combobox("enable");
					}
				}*/
				
			},
			//dbs_city  dbs_province dbs_area 曾居住地址省
			commonCombobox_previousprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 曾居住地址市
			commonCombobox_previouscity : {

				url :  path + '/newCont/codeselect/allcity/#previousprovince.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 曾居住地址区
			commonCombobox_previousarea : {

				url :  path + '/newCont/codeselect/allcounty/#previouscity.do',
				 valueField : "countyid",
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			//单位、学校国家下拉
			commonCombobox_employcountry : {

				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]/*,
				afterselect : function(){
					if($('#employcountry').val() != 'CN'){
						$('#employprovince').combobox("clear");
						$('#employprovince').combobox("disable");
						$('#employcity').combobox("clear");
						$('#employcity').combobox("disable");
						$('#employarea').combobox("clear");
						$('#employarea').combobox("disable");
					}else{
						$('#employprovince').combobox("enable");
						$('#employcity').combobox("enable");
						$('#employarea').combobox("enable");
					}
				}*/
				
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址省
			commonCombobox_employprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址市
			commonCombobox_employcity : {

				url :  path + '/newCont/codeselect/allcity/#employprovince.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址区
			commonCombobox_employarea : {

				url :  path + '/newCont/codeselect/allcounty/#employcity.do',
				 valueField : "countyid",
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址省
			commonCombobox_appntbirthprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址市
			commonCombobox_appntcity : {

				url :  path + '/newCont/codeselect/allcity/#appntbirthprovince.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			
			//dbs_city  dbs_province dbs_area 第二被保人联系地址省
			commonCombobox_insuredpostprovince1 : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			
			//dbs_city  dbs_province dbs_area 第二被保人联系地址市
			commonCombobox_insuredpostcity1 : {

				url :  path + '/newCont/codeselect/allcity/#insuredpostprovince1.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			
			//dbs_city  dbs_province dbs_area 第二被保人联系地址
			commonCombobox_insuredpostdistrict1 : {

				url :  path + '/newCont/codeselect/allcounty/#insuredpostcity1.do',
				valueField : "countyid",
				// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			
			//dbs_city  dbs_province dbs_area 第二被保人居住地址(省)
			commonCombobox_insuredhomeprovince1 : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 第二被保人居住地址(市)
			commonCombobox_insuredhomecity1 : {

				url :  path + '/newCont/codeselect/allcity/#insuredhomeprovince1.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},			
			//dbs_city  dbs_province dbs_area 第二被保人居住地址(区)
			commonCombobox_insuredhomedistrict1 : {

				url :  path + '/newCont/codeselect/allcounty/#insuredhomecity1.do',
				 valueField : "countyid",
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			
			//dbs_city  dbs_province dbs_area 是否参加当地医疗保险
			commonCombobox_insuredsociomedical : {

				url :  path + '/newCont/codeselect/common/anzl_sociomedical.do',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
			//开户行省
			commonCombobox_lccontprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//开户行市
			commonCombobox_lccontcity : {

				url :  path + '/newCont/codeselect/allcity/#lccontareaprovince.do',
				valueField : "cityid",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			commonCombobox_countrycode_anzl : {

				url :  path + '/newCont/codeselect/common/countrycode_anzl.do',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
       //根据保险产品加载对应的网点及地区						
			commonCombobox_cityname_all : {

				url :  path + '/newCont/codeselect/serachCity/#newContApply.insurancecom/#newContApply.riskcode',
				valueField : "citycode",
				relateType: "vue",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			commonCombobox_companyCode_all : {

				url :  path + '/newCont/codeselect/serachcompanyCode/#newContApply.insurancecom/#newContApply.riskcode/#lccont.citycode',
				valueField : "comcode",
				relateType: "vue",
				// 显示在输入框的
				inputText : "comname",
				textShow : [ "comname" ]
			}
		};
	
    /**
     * 下面是进行插件初始化
     * 你只需传入相应的键值对
     * */
    


/**
 * 自定义 校验
 */
var bootstrap_valid={
	 
};
/**
 *   值变化钩子
 */

		
//		/**
//		 * 同被保人
//		 */
//		afterVueSelect.relationtoappnt=function(form_element){
//			 
//			var topvue = getTopvueObj(this);
//			if(topvue.formdata.lcinsured["relationtoappnt"]=="01"){
//				
//				topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",topvue.formdata.lcappnt.appntname); 
//				
////				topvue.formdata.lcinsured["lcinsuredname"]=topvue.formdata.lcappnt.appntname;
//			}else{
////				topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",""); 
//				
//			}
//			
//		}

function afterVueInitDataLoad(){
	if(this.formdata.newContApply.subrisklist
			&&this.formdata.newContApply.subrisklist.length>0){
		
	}else{
		this.$set(this.form_elementsBYID.MELIinsuranceContInput['subriskcode_tabinfo'],
				"elementstatus", "04");//04 不显示
	}	
	
}
		
