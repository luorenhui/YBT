afterloadNewElements.krisk_tabinfo = function(url, form_element) {

		setTimeout(function(){
			if(($("#AutoPayFlag").is(":visible")||$("#AutoPayFlag").length>0)){
				  $("#AutoPayFlagTitle").remove();
			      $("#AutoPayFlag").parent().append("<small id='AutoPayFlagTitle' class='help-block'>" +
				      		"<b style='color:red'>此选项须征求客户意见后选择 ,并告知客户该选择项的实际意义和作用</b><br>" +
				      		"<b style='color:red'>*保险费自动垫交：</b>*投保人未按时交纳续期保费，若保单当时已具有足够现金价值，保险公司将以该合同基本保险金额对应的现金价值扣除尚未偿还的各项欠款之后的余额自动垫交到期应交的保险费，使保单继续有效。垫交保险费视作保单贷款，并自保险费自动垫交发生之日起以保单贷款利率予以计息。"
				      		+"<br><b style='color:red'>*合同中止：</b>*投保人未按时交纳续期保费，保险合同暂时失去效力。" +
				      		"</small>");
			}
		},50);

};
//保险产品
commonCombobox_option.commonCombobox_riskcode = {
	///#lccont.insurancecom
	url:path + '/newCont/codeselect/searchrisk/#newContApply.insurancecom',
	valueField : "riskcode",
	relateType: "vue",
	// 显示在输入框的
	inputText : "riskname",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : ["riskname"],
	
	afterselect:function(){
		var vueobjtemp =vue_config[vue_config.length-1].vueobj;
		var riskData = this.data;
		var risktype = "";
		
		riskData.forEach(function(val,index,array){
			if($("#riskcode").val()==val.riskcode){
				risktype=val.risktype;
				return;
			}
		});

		vueobjtemp.formdata['investmentrisk']=risktype=="01"?"true":"false";

	}
};





//年金/生存保险金领取年龄
commonCombobox_option.commonCombobox_inshAnnuityGetYearage = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/InshAnnuityGetYearage.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};
//年金/生存保险金领取期间
commonCombobox_option.commonCombobox_survivalInsurancePeriod = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/survivalInsurancePeriod.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};
//额外年金领取年龄
commonCombobox_option.commonCombobox_extragetyear = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/extragetyear.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};


//风险标识
commonCombobox_option.commonCombobox_MortalityFlag = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/MortalityFlag.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};

//保险期间
commonCombobox_option.commonCombobox_insuyears = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/insuyear.do',
	valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};
//缴费期间
commonCombobox_option.commonCombobox_payendyears = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/payendyear.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};
//年金领取方式
commonCombobox_option.commonCombobox_BonusGetYearFlag = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/BonusGetYearFlag.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};


//INSH年金领取方式
commonCombobox_option.commonCombobox_InshAnnuityGetYearFlag = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/InshAnnuityGetYearFlag.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};


//缴费方式
commonCombobox_option.commonCombobox_payintvs = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/payintv.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};

//红利给付方式
commonCombobox_option.commonCombobox_bonuspayment = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/bonuspayment.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};


//投资账户类型
commonCombobox_option.commonCombobox_investmentaccount = {
	    url: path + '/newCont/codeselect/searchRiskParamsdef/#newContApply.riskcode/InvestmentAccount',
	    valueField: "paramscode",
	    relateType: "vue",
	    mutually_exclusive:true,
	    // 显示在输入框的
	    inputText: "paramsname",
	    // 显示在下拉列表的项，默认空，空则全部显示
	    textShow: ["paramsname"]
};

//续期保费逾期
commonCombobox_option.commonCombobox_AutoPayFlag = {
	    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/AutoPayFlag.do',
	    valueField: "paramscode",
	    // 显示在输入框的
	    inputText: "paramsname",
	    // 显示在下拉列表的项，默认空，空则全部显示
	    textShow: ["paramsname"]
};

//产品类型
commonCombobox_option.commonCombobox_producttype = {
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/producttype.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};

//产品计划
commonCombobox_option.commonCombobox_productplanning = {
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/productplanning.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]

};

//年金累积生息
commonCombobox_option.commonCombobox_CashAccumulation = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/CashAccumulation.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//自动申请续保
commonCombobox_option.commonCombobox_AutoRenewal = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/AutoRenewal.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//申请使用优选体费用
commonCombobox_option.commonCombobox_PremiumRate = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/PremiumRate.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//自动转换
commonCombobox_option.commonCombobox_autorebalance = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/AutoRebalance.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};

//投资生效期
commonCombobox_option.commonCombobox_investmentStartDateFlag = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/investdateformanu.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};




//年金帐户帐号开户省
commonCombobox_option.commonCombobox_areaprovince = {
		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
};

//年金帐户帐号开户市
commonCombobox_option.commonCombobox_areacity = {
		url :  path + '/newCont/codeselect/allcity/#AccountAreaProvince.do',
		valueField : "cityid",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
};



//主险保存后
aftersubmitvueform.krisk_tabinfoform = function() {
 
	if(this.form_elementsBYID.MELIinsuranceContInput['subriskcode_tabinfo']["elementstatus"]!='01'){
		
		if(this.formdata.newContApply.currentSIDIndex>6){
			
		}else{
			this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
			this.$set(this.formdata.newContApply,"currentSIDIndex",6);
			$('#tab_FATACACRS_tabinfo').trigger("click");
		}
		
 
	}else{
		 
		
	}
	if(this.formdata.newContApply.currentSIDIndex> 6){
		
		if(!checkCRSShow.call(this)){
			this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
			this.$set(this.formdata.newContApply,"currentSIDIndex",6);
			this.$set(this.formdata.newContApply,"FATACACRS",false);
			
			$('#tab_FATACACRS_tabinfo').trigger("click");
		}
	}
	
	return true; 
};



//提交前 判断
beforesubmitvueform.krisk_tabinfoform = function() {
	var krisk_flag=false;
	var topvue = getTopvueObj(this);
	
	if(topvue.form_elementsBYID.krisk["prem"].elementstatus=="01"){
		 var prem=$("#prem").val().trim();
		 if(prem==0){
			alert("保费输入有误，请重新输入！");
			return false;
		 }
	}
	
	//缴费方式为年缴时，续期保费逾期选项不能选择不适用
	if(topvue.form_elementsBYID.krisk["payintv"]!=undefined&&topvue.form_elementsBYID.krisk["payintv"].elementstatus=="01"&&$("#payintv").val().trim()!=null
	  &&topvue.form_elementsBYID.krisk["AutoPayFlag"]!=undefined&&topvue.form_elementsBYID.krisk["AutoPayFlag"].elementstatus=="01"&&$("#AutoPayFlag").val().trim()!=null
		){
	    var payintv=$("#payintv").val();
	    var AutoPayFlag=$("#AutoPayFlag").val();
	    if(payintv=='Y'&&AutoPayFlag==0){
		   alert("缴费方式为年交时，续期保费逾期选项不能选择不适用，请修改！");
		   return false;
	    }
	    if(payintv=='S'&&AutoPayFlag!=0){
	   	   alert("缴费方式为趸交时，续期保费逾期选项只能选择不适用，请修改！");
	   	   return false;
	    }
	}
	
	//ips提示
	if(confirm(("请注意，此页面上的产品投保信息若有修改，您可以点击【确认】保存银保通录入的投保信息，但请检查建议书系统是否需要更新建议书（IPS No:"+topvue.formdata.lccont.ipsno+"）"))){
		krisk_flag=true;
	}else{
		krisk_flag=false;
	}
	if(null!=topvue.formdata.subFormData.lccont) {
		initData(getActivePanelDIV(), true);
		var pflag = topvue.formdata.lccont.pageflag;
		fillinObj(topvue, topvue.formdata, topvue.formdata.subFormData, false, 0);
		topvue.formdata.lccont.pageflag = pflag;
		checkPaperChange = true;
	}
	return true&&krisk_flag;
};

//aftersubmitvueform.lcbnf_tabinfoform = function() {
//	 
//	if(this.form_elementsBYID.ANZLinsuranceContInput['subriskcode_tabinfo']["elementstatus"]!='01'){
//		
//		
//		
// 
//	}else{
//		 
//		
//	}
//	if(this.formdata.newContApply.currentSIDIndex>6){
//		
//	}else{
////		this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
////		this.$set(this.formdata.newContApply,"currentSIDIndex",6);
//		$('#tab_FATACACRS_tabinfo').trigger("click");
//	}
//	return true; 
//};