var sameFieldLcinusred={
	"lcinsuredname"	:"appntname",
	"lcinsurednativeplace"	:"nativeplace",//国籍
	"lcinsuredsex"	:"appntsex",//性别
	"lcinsuredroccupationcode"	:"occupationcode",//职业代码
	"lcinsuredidtype"	:"idtype",//证件类型
	"lcinsuredidno"	:"idno",//证件号码
	"lcinsuredcompany"	:"company",//工作单位及名称
	"lcinsuredbirthday"	:"appntbirthday",//出生日期
	"renewCount"	:"renewCount",//换证次数
	"startingDate"	:"startingDate",//证件有效始期
	"insureidenddate"	:"appntenddate",//证件有效止期
	"rgtaddress"	:"rgtaddress",//个人年收入(万元)
	"lcinsuredresponsibility"	:"responsibility",// 职位及工作内容
	//"lcinsuredbirthcounty":"birthcounty",
	"political" :"political", //是否外国政要
//	"lcinsuredidsubmit" : "idsubmit", //证件递交
	"topmanagement":"topmanagement",  //是否国际组织高级管理人员
	"islongitems":"islongitems"//证件长期有效
	//"jade":"jade" //尚玉客户
	/*"lcinsuredotherresponsibility"	:"otherresponsibility",// 被保人职位
	"industrytype"	:"industrytype",// 行业类别
	"banksccflag":"banksccflag",
	"bankcustomertype":"bankcustomertype",
	"marry":"marry",
	"domicile":"domicile",
	"jobinfo":"occualias",
	"otherjob":"parttimejob"*/
};
var sameFieldLcinusredAddress={
		"zipcode"	:"zipcode",//联系地址邮政编码
		"mobile"	:"mobile",//移动电话
		"zipcode"	:"zipcode",//
		"postprovince"	:"postprovince",//居住地址省
		"postdistrict"	:"postdistrict",//居住地址区
		"postcity"	:"postcity",//居住地址市
		"postdetails"	:"postdetails",//居住地址
		"email"	:"email", //E-mail
		"areacodetel" : "areacodetel", //固定电话区号
		"phone"	:"phone"//家庭电话
//		"postalflags"	:"postalflags",
/*		"countrycodetel_tel":"countrycodetel_tel",
		"areacodetel":"areacodetel",
		"countrycodetel_mob":"countrycodetel_mob",
		"employcountry":"employcountry",
		"employprovince":"employprovince",
		"employcity":"employcity" ,
		"employarea":"employarea",
		"employdetails":"employdetails",
		"employareacodetel":"employareacodetel",
		"employphone":"employphone",
		"countrycode_loy":"countrycode_loy",
		"employphonecountry":"employphonecountry",
		"homephonecountry":"homephonecountry",
		"countrycodetel_tel":"countrycodetel_tel",
		"areacodetel":"areacodetel",
		"homephone":"homephone",
		"addresscountry":"addresscountry",
		"mobilephonecountry":"mobilephonecountry"*/
	};

var onlysameFieldLcinusredAddress={
		"zipcode":"zipcode",//联系地址邮政编码
		"postprovince" : "postprovince",//通讯地址省
		"postcity": "postcity",//通讯地址市
		"postdistrict" : "postdistrict",//通讯地址区
		"postdetails":"postdetails"//通讯详细地址
		 
	};

//证件长期有效
afterVueSelect.lcinsuredislongitemmeli = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");
	if($('#lcinsuredrelationtoappntmeli').val() != "00" && $('#lcinsuredrelationtoappntmeli').val() != "" ){
		if (obj.is("[type='checkbox']:checked")){
			topvue.$set(topvue.formdata.lcinsured,"insureidenddate","9999-01-01");
			$("#lcinsured_tabinfoform").data('bootstrapValidator').resetField($("#lcinsuredidenddate"));
			$("#lcinsuredidenddate").attr("disabled",true);
		}else {
			$("#lcinsuredidenddate").attr("disabled",false);
		}
	}
}
//根据身份证号，同步出生日期
afterVueSelect.lcinsuredidno = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");
	if($("#lcinsuredidtype").val() != "I"&&$("#lcinsuredidtype").val() != "J"){
		return;
	}
	if($("#lcinsuredidtype").val() == "I"||$("#lcinsuredidtype").val() == "J"){
		if (obj.is("[id='lcinsuredidno']")){
//			topvue.$set(topvue.formdata.lcinsured,"insureidenddate","2099-01-01"); 
			var idno = $("#lcinsuredidno").val();
			var birthday = idno.substring(6,14);
			var year = birthday.substring(0,4);
			var mon = birthday.substring(4,6);
			var day = birthday.substring(6);
			var formatBirth = year + "-" + mon + "-" + day;
			topvue.$set(topvue.formdata.lcinsured,"lcinsuredbirthday",formatBirth);
		}
	}
	
}

/**
 * 投保人 同被保人
 */
afterVueSelect.lcinsuredrelationtoappntmeli = function(form_element) {
	
	if($('#lcinsuredrelationtoappntmeli').val() == '07'){
//	$("#lcinsuredrelation").show();
	$('#lcinsuredrelationmeli').removeAttr("disabled");
	
	}else{
		$('#lcinsuredrelationmeli').attr("disabled",true);
		$('#lcinsuredrelationmeli').val("");
	//	$("#lcinsuredrelation").hide();
	}

	var topvue = getTopvueObj(this);
 
	var form =$(this.$el)
	.parentsUntil("form").parent("form");
	if (this.formdata.relationtoappnt=="00") {

		for ( var key in topvue.form_elements.lcinsured) {
			
			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {
		
				bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusred[targetName],
						topvue.formdata.lcinsured,targetName,targetElement);
			}
			
			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
				
				bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredAddress[targetName],
						topvue.formdata.lcinsuredaddress,targetName,targetElement);
			}

		}
		
		
		topvue.$nextTick(function () { 
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});
		
		
		$("#lcinsuredpostalflag").hide();
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "");

	} else {
		
		
		
		for ( var key in topvue.form_elements.lcinsured) {
			
			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {
		
				unbindSameElement.call(topvue, sameFieldLcinusred[targetName],
						targetElement);
			}
			
			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
				
				unbindSameElement.call(topvue, sameFieldLcinusredAddress[targetName],
						targetElement);
			}

		}
		$("#lcinsuredpostalflag").show();
//		topvue.$set(topvue.form_elementsBYID.lcinsured,"lcinsuredpostalflag","01");
		
		//2.投被保险人为本人，修改为非本人选项，则系统会清空被保险人信息，需要重新填写  （ 00为本人）
		if($('#lcinsuredrelationtoappntmeli').val() != "00" && $('#lcinsuredrelationtoappntmeli').val() != "" ){
			//清空被保人信息	  输入框		
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"islongitems", new Array());//证件长期有效
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"rgtaddress", null);//个人年收入(万元)
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", null);//投保人与被保人其它关系
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"renewCount", null);//换证次数
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"startingDate", null);//证件有效始期
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"insureidenddate", null);//证件有效止期
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredidtype", null);//证件类型
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredbirthday", null);//出生日期
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredname", null);//被保人姓名
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredcompany", null);//工作单位及名称
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredidno", null);//证件号码
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredroccupationcode", null);//职业代码
			 //清空被保人地址信息
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"email", null);//E-mail
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"areacodetel", null);//固定电话区号
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"phone", null);//固定电话
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"zipcode", null);//邮政编码
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postdetails", null);//详细地址
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"mobile", null);//移动电话
			
			topvue.$nextTick(function () { 
				try {
			//下拉框处理
			//清空被保人信息			
			$('#lcinsuredpoliticalmeli').combobox("clear");//是否外国政要
			$('#lcinsuredtype').combobox("clear");//被保人类型
			$('#lcinsuredresponsibilitymeli').combobox("clear");//职务及工作内容
			$('#lcinsuredtopmanagementmeli').combobox("clear");//是否国际组织高级管理人员
			$('#lcinsuredidtype').combobox("clear");//证件类型
			$('#lcinsuredsex').combobox("clear");//性别
			$('#lcinsuredoccupationcodemeli').combobox("clear");//职业代码
			$('#lcinsurednativeplace').combobox("clear");//国籍/地区
			 //清空被保人地址信息			
			$('#lcinsuredpostalflag').combobox("clear");// 同投保人地址
			$('#lcinsuredhomeprovincemeli').combobox("clear");// 省/直辖市	
			$('#lcinsuredhomedistrictmeli').combobox("clear");// 区/县
			$('#lcinsuredhomecitymeli').combobox("clear");// 市
				} catch (e) {
				}
			});
		}
	}

};




/**
 * 投保人 同被保人
 */
 
afterVueSelect.lcinsuredtwoflag = function(form_element) {
	
	var formdata = this.formdata;
	if(   formdata['lcinsured']
		&&formdata['lcinsured'].lcinsuredtwoflag
		&&formdata['lcinsured'].lcinsuredtwoflag.length>=1
		&&formdata['lcinsured'].lcinsuredtwoflag[0]=='lcinsuredtwoflag'){
		
		return true;
	}else{
 
		return false;
	}
	
};

/**
 * 投保人地址同被保人地址
 */
afterVueSelect.lcinsuredpostalflag = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (topvue.formdata.lcinsured.relationtoappnt!="00") {
		
		
		if (obj.is("[type='checkbox']:checked")) {
			
			for ( var key in topvue.form_elements.lcinsured) {
				
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredaddress,targetName,targetElement);
				}
			}
		
		} else {
			for ( var key in topvue.form_elements.lcinsured) {
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					unbindSameElement.call(topvue, onlysameFieldLcinusredAddress[targetName],
							targetElement);
				}
			}
		}
		
		
	}
	

};
//选择了身份证类型时
afterVueSelect.lcinsuredidtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcinsured.lcinsuredidtype;
	if($('#lcinsuredrelationtoappntmeli').val() != "00"){
	if (idtype== "I"){
		$("#insuredstartingDate").attr("disabled",false);
	}else {
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"startingDate", null);//证件有效始期
		$("#insuredstartingDate").attr("disabled",true);
	} 
	if (idtype== "X"){
		$("#insuredrenewCount").attr("disabled",false);
	}else {
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"renewCount", null);//证件有效始期
		$("#insuredrenewCount").attr("disabled",true);
	} 
	}
};

/*//dbs_city  dbs_province dbs_area 被保人通讯地址省
commonCombobox_option.commonCombobox_insuredemployprovince ={

	url :  path + '/newCont/codeselect/allprovinceid/province.do',
	valueField : "provinceid",
	// 显示在输入框的
	inputText : "provincename",
	textShow : [ "provincename" ]
};
//dbs_city  dbs_province dbs_area 被保人通讯地址
commonCombobox_option.commonCombobox_insuredemploycity  =  {
	url :  path + '/newCont/codeselect/allcity/#lcinsuredemployprovince.do',
	valueField : "cityid",
	// 显示在输入框的
	inputText : "cityname",
	textShow : [ "cityname" ]
};
//dbs_city  dbs_province dbs_area 被保人通讯地址
commonCombobox_option.commonCombobox_insuredemploydistrict = {

	url :  path + '/newCont/codeselect/allcounty/#lcinsuredemploycity.do',
	valueField : "countyid",
	// 显示在输入框的
	inputText : "countyname",
	textShow : [ "countyname" ]
};*/

//dbs_city  dbs_province dbs_area 被保人居住地址(省)
commonCombobox_option.commonCombobox_insuredhomeprovince = {

	url :  path + '/newCont/codeselect/allprovinceid/province.do',
	valueField : "provinceid",
	// 显示在输入框的
	inputText : "provincename",
	textShow : [ "provincename" ]
};
//dbs_city  dbs_province dbs_area 被保人居住地址(市)
commonCombobox_option.commonCombobox_insuredhomecity = {
	url :  path + '/newCont/codeselect/allcity/#lcinsuredhomeprovincemeli.do',
	valueField : "cityid",
	// 显示在输入框的
	inputText : "cityname",
	textShow : [ "cityname" ]
};
//dbs_city  dbs_province dbs_area 被保人居住地址(区)
commonCombobox_option.commonCombobox_insuredhomedistrict = {
	url :  path + '/newCont/codeselect/allcounty/#lcinsuredhomecitymeli.do',
	valueField : "countyid",
	// 显示在输入框的
	inputText : "countyname",
	textShow : [ "countyname" ]
};

	//投保人与被保人关系
commonCombobox_option.commonCombobox_relation_meli = {
//	url:path + '/LdcodeController/selectLcodeByCodetype.do?codetype=relationformanu',
	url : path + '/newCont/codeselect/common/relationformanu',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText :  "codename" ,
	textShow : [ "codename" ]
	
};
//MELI 证件递交
commonCombobox_option.commonCombobox_idsubmit = {
	valueField : "code",
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ],
	data : [ {
		code : 'Y',
		codename : '是'
	}, {
		code : 'N',
		codename : '否'
	} ]
};
$.fn.bootstrapValidator.validators.lcinsured_idno = {
		validate : function(validator, $field, options) {
			var topvueobj = getTopvueObj(options.vueobj);
			var lcinsured = topvueobj.formdata.lcinsured;
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			if (null!=lcinsured.lcinsuredidno){
				if(lcinsured.lcinsuredidno.length==18||(lcinsured.lcinsuredidtype!="I"&&lcinsured.lcinsuredidtype!="J")){
					form.data('bootstrapValidator').resetField($("#lcinsuredbirthday"));

					form.data('bootstrapValidator').updateStatus($field, "VALID");
					form.find("input[id*='lcinsuredidno']").each(function() {
						if (!form.data('bootstrapValidator').isValidField($(this))) {
							form.data('bootstrapValidator').revalidateField($(this));
						}

					});
					return true;
				}
			}
			return false;
		}
	};
	bootstrap_valid.lcinsured_idno = function(validitem) {

		var vueobj = this;
		var validobj = {
			message : "当前证件类型下证件号码必须为18位，请重新输入",
			vueobj : vueobj
		};

		return validobj;

	};
	var temp_birthday="";

	afterloadNewElements.lcinsured_tabinfo=function(){
		
		setTimeout(function(){
			if(($("#lcinsuredidtype").is(":visible")||$("#lcinsuredidtype").length>0)){
	   		 $("#lcinsuredidtypeTitle").remove();
	   		$("#lcinsuredidtype").parent().append("<small id='lcinsuredidtypeTitle' class='help-block' style='color: red;'>请注意，" +
	   				"此处选择的被保险证件类型，需和其之后通过手机银行上传的证件文件（e.g.,图片）的类型保持一致。若被保险人选择了“身份证”，则需上传其身份证的图片，不能上传户口本上有证件号码的图片。</small>");
			 }
			if(($("#insuredrenewCount").is(":visible")||$("#insuredrenewCount").length>0)){
		   		 $("#insuredrenewCountTitle").remove();
		   		$("#insuredrenewCount").parent().append("<small id='insuredrenewCountTitle' class='help-block' style='color: red;'>请注意，" +
		   				"请按证件上的换证次数填写，例如：01。</small>");
				 }
		},50);
		
		var topvue = getTopvueObj(this);
		temp_birthday=topvue.formdata.lcinsured.lcinsuredbirthday;
	}
	
	//提交前
	beforesubmitvueform.lcinsured_tabinfoform=function(){
		var flag=true;
		
		var topvue = getTopvueObj(this);
		if(temp_birthday!=""){
			if(topvue.formdata.lcinsured.lcinsuredbirthday!=temp_birthday){
				if(confirm("客户证件生日与建议书系统的录入生日不一致，请点击【确认】保存或【取消】修改证件信息。")){
					flag=true;
				}else{
					flag=false;
				}
			}
		}
		  var date = new Date();
	       var seperator1 = "-";
	       var year = date.getFullYear();
	       var month = date.getMonth() + 1;
	       var strDate = date.getDate();
	       if (month >= 1 && month <= 9) {
	           month = "0" + month;
	       }
	       if (strDate >= 0 && strDate <= 9) {
	           strDate = "0" + strDate;
	       }
	       var currentdate = year + seperator1 + month + seperator1 + strDate;
		if(!(new Date(topvue.formdata.lcinsured.insureidenddate)>=new Date(currentdate))){
			alert("证件有效止期必须大于等于今天")
			flag=false;
		}
		if(topvue.formdata.lcinsured.lcinsuredidtype== "I"&&(
				   topvue.formdata.lccont&&topvue.formdata.lccont.managecom=="407"||
				   topvue.formdata.lccont&&topvue.formdata.lccont.managecom=="107")){
			
			if(flag&&(topvue.formdata.lcinsured.startingDate==null 
					|| topvue.formdata.lcinsured.startingDate=="" )){
				alert("证件有效起期不可为空");
				flag=false;
			}
			
			if(flag&&(new Date(topvue.formdata.lcinsured.startingDate)>new Date(currentdate))){
				alert("证件有效起期必须小于等于当前日期");
				flag=false;
			}
			if(flag&&((new Date(topvue.formdata.lcinsured.startingDate))>=
				(new Date(topvue.formdata.lcinsured.insureidenddate)))){
				alert("证件有效起期必须小于证件有效止期");
				flag=false;
			}	
		}
		
		if(topvue.formdata.lcinsured.lcinsuredidtype== "X"){
			if(topvue.formdata.lcinsured.renewCount==null 
					|| topvue.formdata.lcinsured.renewCount=="" ){
				alert("证件为港澳台通行证，换证次数不可为空");
				return false;
			}
			var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.lcinsured.renewCount)).slice(-2);//01
			topvue.$set(topvue.formdata.lcinsured,"renewCount",newrenewcount);
		}
		//3.保存被保险人信息时， 若投被保险人信息非同一人时，请检查投保人和被保险人的证件号码是否相同，
		//若相同，则报错“投保人和被保险人证件号码相同，请检查投被保险人关系是否填写正确！”		  00为本人		 
		if (topvue.formdata.lcinsured.relationtoappnt!="00"&&topvue.formdata.lcinsured.relationtoappnt!= "") {
				var idno= topvue.formdata.lcappnt.idno;//投保人证件号码
				var lcinsuredidno= topvue.formdata.lcinsured.lcinsuredidno;////被保人证件号码
				if(idno!=""&&lcinsuredidno!=""){
					if(idno.trim()==lcinsuredidno.trim()){
						alert("投保人和被保险人证件号码相同，请检查投被保险人关系是否填写正确！");
						flag=false;
					}
				}
		}
		
		
		return flag;
	}