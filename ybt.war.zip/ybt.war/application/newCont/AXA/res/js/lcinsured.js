
function DatePicker(investment){
		
		  // 仅选择日期
		  $("#insubeginyearAXA").datetimepicker(
		  {
		    language: "zh-CN",
		    startView: 1, 
		    format: "yyyy-MM-dd",
		    clearBtn:true,
		    initialDate:moment(new Date()).subtract(-1,'days').format('YYYY-MM-DD')
		  }).on('click', function(ev){
			   $("#insubeginyearAXA").datetimepicker('setInitialDate', moment(new Date()).subtract(-1,'days').format('YYYY-MM-DD'));  	
		       $("#insubeginyearAXA").datetimepicker('setStartDate', moment(new Date()).subtract(-1,'days').format('YYYY-MM-DD'));
				if(investment=='L'){
					$("#insubeginyearAXA").datetimepicker('setEndDate', moment(new Date()).subtract(-60,'days').format('YYYY-MM-DD'));
				}else if(investment=='D'){
					$("#insubeginyearAXA").datetimepicker('setEndDate', moment(new Date()).subtract(-30,'days').format('YYYY-MM-DD'));
				}else{
					$("#insubeginyearAXA").datetimepicker('setEndDate', moment(new Date()).subtract(-1,'days').format('YYYY-MM-DD'));
				}
		       
		  }); 
   };

//争议解决方式 
commonCombobox_option.commonCombobox_disputeResolution_axa = {
			"data" : [ {
				"value" : "1",
				"text" : "中国经济贸易仲裁委员会上海分会仲裁"
			}, {
				"value" : "0",
				"text" : "有管辖权的人民法院裁决"
			}]
};
//PA职业大类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxapa = {
	url : path + '/newCont/codeselect/newoccupationaxa/axanewcode1.do',
	valueField : "code",
	delayLoadDataFlag : true,
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//PA职业中类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxapa2 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axanewcode2/#lcinsuredoccupationaxapa.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
 
//PA职业小类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxapa3 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axanewcode3/#lcinsuredoccupationaxapa2.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//PA职位
commonCombobox_option.commonCombobox_lcinsuredoccupationaxapa4 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axanewcode4/#lcinsuredoccupationaxapa3.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};

//PA多被保人职业大类
commonCombobox_option.commonCombobox_lcinsuredoccupationnewaxamulti = {
	url : path + '/newCont/codeselect/newoccupationaxa/axanewcode1.do',
	valueField : "code",
	delayLoadDataFlag : true,
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//PA多被保人职业中类
commonCombobox_option.commonCombobox_lcinsuredoccupationnewaxamulti1 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axanewcode2/#lcinsuredoccupationnewaxamulti.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
 
//PA多被保人职业小类
commonCombobox_option.commonCombobox_lcinsuredoccupationnewaxamulti2 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axanewcode3/#lcinsuredoccupationnewaxamulti1.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//PA多被保人职位
commonCombobox_option.commonCombobox_lcinsuredoccupationnewaxamulti3 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axanewcode4/#lcinsuredoccupationnewaxamulti2.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};


//IC职业大类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxaic = {
	url : path + '/newCont/codeselect/newoccupationaxa/axaiccode1.do',
	valueField : "code",
	delayLoadDataFlag : true,
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//IC职业中类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxaic2 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axaiccode2/#lcinsuredoccupationaxaic.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
 
//IC职业小类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxaic3 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axaiccode3/#lcinsuredoccupationaxaic2.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//IC职位
commonCombobox_option.commonCombobox_lcinsuredoccupationaxaic4 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axaiccode4/#lcinsuredoccupationaxaic3.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};

//IC多被保人职业大类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxaicmulti = {
	url : path + '/newCont/codeselect/newoccupationaxa/axaiccode1.do',
	valueField : "code",
	delayLoadDataFlag : true,
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//IC多被保人职业中类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxaicmulti1 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axaiccode2/#lcinsuredoccupationaxaicmulti.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
 
//IC多被保人职业小类
commonCombobox_option.commonCombobox_lcinsuredoccupationaxaicmulti2 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axaiccode3/#lcinsuredoccupationaxaicmulti1.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//IC多被保人职位
commonCombobox_option.commonCombobox_lcinsuredoccupationaxaicmulti3 = {
	url : path + '/newCont/codeselect/newoccupationaxa/axaiccode4/#lcinsuredoccupationaxaicmulti2.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};

/*//保险计划@IC 
commonCombobox_option.commonCombobox_plan_axa={
		"data":[{
			"value" : "CMI002",
			"text" : "全球计划（含美国，无自费）"
		},{
			"value" : "CMI001",
			"text" : "全球计划（含美国，20%自费）"	
		},{
			"value" : "CMI004",
			"text" : "国际计划（除美国，无自费）"
		},{
			"value" : "CMI003",
			"text" : "国际计划（除美国，20%自费）"
		}]
};*/
//保险计划@IC 
commonCombobox_option.commonCombobox_plan_axa={
		"data":[{
			"value" : "CMI006",
			"text" : "全球计划（含美国，无自付）"
		},{
			"value" : "CMI005",
			"text" : "全球计划（含美国，20%自付）"	
		},{
			"value" : "CMI008",
			"text" : "国际计划（除美国，无自付）"
		},{
			"value" : "CMI007",
			"text" : "国际计划（除美国，20%自付）"
		}]
};
//保险计划@PA
commonCombobox_option.commonCombobox_plan_axapa={
		"data":[{
			"value" : "703001",
			"text" : "计划A"
		},{
			"value" : "703002",
			"text" : "计划B"
		},{
			"value" : "703003",
			"text" : "计划C"
		}]
}
//职业类别@PA
commonCombobox_option.commonCombobox_lcinsuredoccupationclassaxa={
		"data":[{
			"value" : "1",
			"text" : "职业类别一"
		},{
			"value" : "2",
			"text" : "职业类别二"
		}]
//		,{
//			"value" : "3",
//			"text" : "未成年人"
//		}
}
//多被保人职业类别@PA
commonCombobox_option.commonCombobox_lcinsuredoccupationclassmultiaxa={
		"data":[{
			"value" : "1",
			"text" : "职业类别一"
		},{
			"value" : "2",
			"text" : "职业类别二"
		},{
			"value" : "3",
			"text" : "未成年人"
		}]
}
//被保人有无社保
commonCombobox_option.commonCombobox_ishavesocial_axa={
		"data" : [ {
			"value" : "0",
			"text" : "无"
		}, {
			"value" : "1",
			"text" : "有"
		} ]
};
//证件类型@IC
commonCombobox_option.commonCombobox_lcinsuredidtypeaxa = {
		url : path + '/newCont/codeselect/common/axaidtype1',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText : "codename",
		textShow : [ "codename" ]
};
//多被保人证件类型@IC
commonCombobox_option.commonCombobox_lcinsuredidtypemultiaxa = {
		url : path + '/newCont/codeselect/common/axaidtype1',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText : "codename",
		textShow : [ "codename" ]
};

//多被保人有无社保
commonCombobox_option.commonCombobox_ishavesocialmulti_axa={
		"data" : [ {
			"value" : "0",
			"text" : "无"
		}, {
			"value" : "1",
			"text" : "有"
		} ]
};
//被保人居住地址(省)
commonCombobox_option.commonCombobox_insuredpostprovince = {

	url :  path + '/newCont/codeselect/common/areacodeaxa/0.do',
	valueField : "id",
	// 显示在输入框的
	inputText : "idname",
	textShow : [ "idname" ]
};
//被保人居住地址(市)
commonCombobox_option.commonCombobox_insuredpostcity = {
	url :  path + '/newCont/codeselect/common/areacodeaxa/#lcinsuredpostprovinceaxa.do',
	valueField : "id",
	// 显示在输入框的
	inputText : "idname",
	textShow : [ "idname" ] 
};
//被保人居住地址(区)
commonCombobox_option.commonCombobox_insuredpostdistrict = {
	url :  path + '/newCont/codeselect/common/areacodeaxa/#lcinsuredpostcityaxa.do',
	valueField : "id",
	// 显示在输入框的
	inputText : "idname",
	textShow : [ "idname" ]
};
//附加被保人居住地址(省)
commonCombobox_option.commonCombobox_insuredpostprovincemulti ={
		url :  path + '/newCont/codeselect/common/areacodeaxa/0',
		valueField : "id",
		delayLoadDataFlag : true,
		relateType: "vue",
		// 显示在输入框的
		inputText : "idname",
		textShow : [ "idname" ]
};
//附加居住地址(市)
commonCombobox_option.commonCombobox_insuredpostcitymulti ={

	url :  path + '/newCont/codeselect/common/areacodeaxa/#lcinsuredmulti.lcaddress.postprovince',
	valueField : "id",
	delayLoadDataFlag : true,
	relateType: "vue",
	// 显示在输入框的
	inputText : "idname",
	textShow : [ "idname" ]
};	
//附加居住地址(区)
commonCombobox_option.commonCombobox_insuredpostdistrictmulti = {

	url :  path + '/newCont/codeselect/common/areacodeaxa/#lcinsuredmulti.lcaddress.postcity',
	valueField : "id",
	delayLoadDataFlag : true,
	relateType: "vue",
	// 显示在输入框的
	inputText : "idname",
	textShow : [ "idname" ]
};

commonCombobox_option.commonCombobox_lcinsuredplan={
		url : path + '/newCont/codeselect/planaxa/#newContApply.riskcode',
		valueField : "id",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "idname" ,
		textShow : [ "idname" ]			
};
commonCombobox_option.commonCombobox_lcinsuredprofit ={
		url : path + '/newCont/codeselect/profitaxa/#lcinsured.lcinsuredplan',
		valueField : "id",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "idname" ,
		textShow : [ "idname" ]		
};
//根据保险计划将免赔额置灰
afterVueSelect.lcinsuredplan =function(form_element){
	var lcinsuredplan = vueobj["testdivchange"].formdata.lcinsured.lcinsuredplan;
	var riskcode = vueobj["testdivchange"].formdata.newContApply.riskcode;
	$.ajax({
			url : path + '/newCont/codeselect/axa/lcinsuredplan/riskcode.do',
			type : "POST",
			data : {
				"lcinsuredplan" : lcinsuredplan,
				 "riskcode"     :   riskcode
			},
	success : function(data) {
		 if(data.deductible=='Y'){
			 $('#lcinsureddeductibleaxa').combobox("enable");
		 }else{
			 $('#lcinsureddeductibleaxa').combobox("clear");
			$('#lcinsureddeductibleaxa').combobox("disable");
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsureddeductibleaxa", ""); 
		 }	
	  },
	});
};
commonCombobox_option.commonCombobox_lcinsuredplanmulti={
		url : path + '/newCont/codeselect/planaxa/#lcinsured.lcinsuredplan/#newContApply.riskcode',
		valueField : "id",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "idname" ,
		textShow : [ "idname" ]	
};


commonCombobox_option.commonCombobox_lcinsuredprofitmulti ={
		url : path + '/newCont/codeselect/profitaxa/#lcinsuredmulti.lcinsuredplan',
		valueField : "id",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "idname" ,
		textShow : [ "idname" ]		
};
//根据保险计划将免赔额置灰
afterVueSelect.lcinsuredplanAXA =function(form_element){
	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	var index = getElementIntex(this); 
	var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;	
	var lcinsuredplan =$("input[name='lcinsuredmulti"+this.elementindex+".lcinsuredplan']").val();
	var riskcode = vueobj["testdivchange"].formdata.newContApply.riskcode;
	$.ajax({
			url : path + '/newCont/codeselect/axa/lcinsuredplan/riskcode.do',
			type : "POST",
			data : {
				"lcinsuredplan" : lcinsuredplan,
				 "riskcode"     :   riskcode
			},
	success : function(data) {
		 if(data.deductible=='Y'){
			 $("input[name='lcinsuredmulti["+index+"].deductible']").combobox("enable");

		 }else{
			 $("input[name='lcinsuredmulti["+index+"].deductible']").combobox("disable");	
			 $("input[name='lcinsuredmulti["+index+"].deductible']").combobox("clear");
			vueobj.testdivchange.formdata.lcinsuredmulti[index].deductible="";
		 }	
	  },
	});
};
//与投保人关系
commonCombobox_option.commonCombobox_relation_axa = {

		url : path + '/newCont/codeselect/common/relation_insh',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "codename" ,
		textShow : [ "codename" ]
		
	};
//与投保人关系@IC
commonCombobox_option.commonCombobox_relation_axaic={
		"data":[{
			"value" : "00",
			"text" : "本人"
		},{
			"value" : "31",
			"text" : "父母"
		},{
			"value" : "32",
			"text" : "子女"
		},{
			"value" : "33",
			"text" : "配偶"
		}]
}

//
afterVueSelect.lcinsuredrelationtoappntAXA = function(form_element) {
	
	if($('#lcinsuredrelationtoappntAXA').val() == '30'){
	$('#lcinsuredrelationAXA').removeAttr("disabled");
	
    }else{
	$('#lcinsuredrelationAXA').attr("disabled",true);
	$('#lcinsuredrelationAXA').val("");
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", "");
    }
};

//与主被保险人关系
commonCombobox_option.commonCombobox_relation__axamulti = {

		"data" : [ {
			"value" : "32",
			"text" : "子女"
		}, {
			"value" : "33",
			"text" : "配偶"
		}]
		
	};
//与主被保险人关系@PA
commonCombobox_option.commonCombobox_relationmultiaxa = {
		"data" : [ {
			"value" : "31",
			"text" : "父母"
		}, {
			"value" : "32",
			"text" : "子女"
		},{
			"value" : "33",
			"text" : "配偶"
		},{
			"value" : "30",
			"text" : "其他"
		}]
		
	};
afterVueSelect.relationtomaininsuredaxa = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;

	var relationtomaininsured=$("input[name='lcinsuredmulti"+this.elementindex+".relatoinsu']").val();
	var index = this.elementindex.replace(/[^0-9]/ig,"");
	if(relationtomaininsured == '30'){
	$("input[name='lcinsuredmulti"+this.elementindex+".otherrelatoinsu']").attr("disabled",false);
  }else{
	$("input[name='lcinsuredmulti"+this.elementindex+".otherrelatoinsu']").attr("disabled",true);
	
	vueobj.testdivchange.formdata.lcinsuredmulti[index].otherrelatoinsu="";
}	
};
//行业代码
commonCombobox_option.commonCombobox_lcinsuredoccupationaxa = {
	url : path + '/newCont/codeselect/occupationaxa/axacode1.do',
	valueField : "code",
	delayLoadDataFlag : true,
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//职业代码
commonCombobox_option.commonCombobox_lcinsuredoccupationaxa2 = {
	url : path + '/newCont/codeselect/occupationaxa/axacode2/#lcinsured.industrytype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
 
//职位代码
commonCombobox_option.commonCombobox_lcinsuredoccupationaxa3 = {
	url : path + '/newCont/codeselect/occupationaxa/axacode3/#lcinsured.occupationtype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};

//多被保人行业
commonCombobox_option.commonCombobox_lcinsuredoccupationaxamulti = {
	url : path + '/newCont/codeselect/occupationaxa/axacode1',
	valueField : "code",
	delayLoadDataFlag : true,
	relateType: "vue",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//多被保人职业
commonCombobox_option.commonCombobox_lcinsuredoccupationaxamulti2 = {
	url : path + '/newCont/codeselect/occupationaxa/axacode2/#lcinsuredmulti.industrytype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
 
//多被保人职位
commonCombobox_option.commonCombobox_lcinsuredoccupationaxamulti3 = {
	url : path + '/newCont/codeselect/occupationaxa/axacode3/#lcinsuredmulti.occupationtype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};

//是否抽烟
commonCombobox_option.commonCombobox_lcinsuredsmoke ={
		"data" : [ {
			"value" : "Y",
			"text" : "是"
		}, {
			"value" : "N",
			"text" : "否"
		}]
};                    
commonCombobox_option.commonCombobox_lcinsuredsex ={
		"data" : [ {
			"value" : "1",
			"text" : "男"
		}, {
			"value" : "2",
			"text" : "女"
		}]
};
afterVueSelect.lcinsuredsmoke = function(form_element) {
	  if($('#lcinsuredsmoke').val() == 'Y'){
		$('#lcinsuredsmokeyear').removeAttr("disabled");
		
	    }else{
		$('#lcinsuredsmokeyear').attr("disabled",true);
		$('#lcinsuredsmokeyear').val("");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredsmokeyear", "");
	    }	
};

afterVueSelect.lcinsuredsmokeAXA = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
	
/*	var relationtoappnt=$("input[name='lcinsuredmulti"+this.elementindex+".relatoinsu']").val();
	if(relationtoappnt=='00'){
		return;
	}
	*/
	var lcinsuredsmoke=$("input[name='lcinsuredmulti"+this.elementindex+".lcinsuredsmoke']").val();
	var index = this.elementindex.replace(/[^0-9]/ig,"");
	if(lcinsuredsmoke == 'Y'){
	$("input[name='lcinsuredmulti"+this.elementindex+".lcinsuredsmokeyear']").attr("disabled",false);
  }else{
	$("input[name='lcinsuredmulti"+this.elementindex+".lcinsuredsmokeyear']").attr("disabled",true);
	
	vueobj.testdivchange.formdata.lcinsuredmulti[index].lcinsuredsmokeyear="";
}	
};

commonCombobox_option.commonCombobox_lcinsuredishsbcclerk = {
		"data" : [ {
			"value" : "0",
			"text" : "否"
		}, {
			"value" : "1",
			"text" : "是"
		} ]
};
//您目前在中国是
commonCombobox_option.commonCombobox_lcinsuredinchinaforaxa = {
		"data" : [ {
			"value" : "1",
			"text" : "工作"
		}, {
			"value" : "2",
			"text" : "生活"
		},{
			"value" : "3",
			"text" : "学习"
		}] 
};

commonCombobox_option.commonCombobox_deductible = {
		"data" : [ {
			"value" : "0",
			"text" : "无"
		}, {
			"value" : "15000",
			"text" : "15000"
		}]
};
commonCombobox_option.commonCombobox_deductible_GP = {
	"data" : [ {
		"value" : "0",
		"text" : "无"
	},{
		"value" : "10000",
		"text" : "10000"
	}, {
		"value" : "30000",
		"text" : "30000"
	}, {
		"value" : "80000",
		"text" : "80000"
	}]
};
commonCombobox_option.commonCombobox_disputeResolution = {
		"data" : [ {
			"value" : "2",
			"text" : "提交中国国际经济贸易仲裁委员会"
		}, {
			"value" : "3",
			"text" : "有权限的人民法院"
		}]
};


//同本人
var sameFieldLcinusred={
		"lcinsuredname"	:"appntname",
		"lcinsurednativeplace"	:"nativeplace",//国籍
		"industrytype"	:"industrytype",// 行业
		"occupationtype" :"occupationcode", //职业
		"lcinsuredsex"	:"appntsex",//性别
		"lcinsuredroccupationcode": "responsibility", //职位
		"lcinsuredidtype"	:"idtype",//证件类型
		"lcinsuredidno"	:"idno",//证件号码
		"lcinsuredbirthday"	:"appntbirthday",//出生日期
		"insureidenddate"	:"appntenddate",//证件有效止期
		"lcinsuredbirthcounty":"birthcounty",					
		"appntenddate":"insureidenddate",
		"mobile"	:"mobile",//移动电话 
		"email"	:"email",
	};
var sameFieldLcinusred1={
		"lcinsuredname"	:"appntname",
		"lcinsurednativeplace"	:"nativeplace",//国籍
		"lcinsuredsex"	:"appntsex",//性别
		"lcinsuredidtype"	:"idtype",//证件类型
		"lcinsuredidno"	:"idno",//证件号码
		"lcinsuredbirthday"	:"appntbirthday",//出生日期
		"insureidenddate"	:"appntenddate",//证件有效止期
		"lcinsuredbirthcounty":"birthcounty",					
		"appntenddate":"insureidenddate",
		"mobile"	:"mobile",//移动电话 
		"email"	:"email",
	};
var sameFieldLcinsuredtoaxalcappnt={
		"inchinafor" :"inchinafor",
		"ishsbcclerk":"ishsbcclerk",	
		"familename":"surname",
		"givenname":"name",
		"phonetype":"phonetype",
};

	var sameFieldLcinusredAddress={
			"zipcode"	:"zipcode",//联系地址邮政编码
			"postprovince"	:"postprovince",//通讯地址省
			"postdistrict"	:"postdistrict",//通讯地址区
			"postcity"	:"postcity",//通讯地址市
			"postaladdress"	:"postaladdress",//通讯地址
			"mobile"	:"mobile",//移动电话 
			"email"	:"email",
			
		};
	var sameAddressToLcappnt ={
			"zipcode"	:"zipcode",//联系地址邮政编码
			"postprovince"	:"postprovince",//通讯地址省
			"postdistrict"	:"postdistrict",//通讯地址区
			"postcity"	:"postcity",//通讯地址市
			"postaladdress"	:"postaladdress",//通讯地址	
			
	};

	/**
	 * 投保人 同被保人 AM AS PA
	 */
	afterVueSelect.lcinsuredrelationtoappntaxa = function(form_element) {
		
		if($('#lcinsuredrelationtoappntaxa').val() == '30'){
		$('#lcinsuredrelationaxa').removeAttr("disabled");
		
	}else{
		$('#lcinsuredrelationaxa').attr("disabled",true);
		$('#lcinsuredrelationaxa').val("");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", "");
	}

		var topvue = getTopvueObj(this);
		var riskcode = vueobj["testdivchange"].formdata.lccont.riskcode;	 
		var form =$(this.$el)
		.parentsUntil("form").parent("form");
		if (this.formdata.relationtoappnt=="00") {

			for ( var key in topvue.form_elements.lcinsured) {
				
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if(riskcode=="@PA"){
					if (sameFieldLcinusred1[topvue.form_elements.lcinsured[key].name]!=undefined) {
						
						bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusred1[targetName],
								topvue.formdata.lcinsured,targetName,targetElement);
					}
				}else{
					if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {
						
						bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusred[targetName],
								topvue.formdata.lcinsured,targetName,targetElement);
					}
				}
				
				if (sameFieldLcinsuredtoaxalcappnt[topvue.form_elements.lcinsured[key].name]!=undefined) {
					
					bindSameElement.call(topvue, topvue.formdata.axalcappnt, sameFieldLcinsuredtoaxalcappnt[targetName],
							topvue.formdata.lcinsured,targetName,targetElement);
				}
				
				if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredaddress,targetName,targetElement);
				}

			}
			
			
			topvue.$nextTick(function () { 
				try {
					form.data('bootstrapValidator').resetForm();
				} catch (e) {
				}
			});
			$("#lcinsuredpostalflagaxa").hide();
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "");
		} else {
			
			
			
			for ( var key in topvue.form_elements.lcinsured) {
				
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if(riskcode=="@PA"){
					if (sameFieldLcinusred1[topvue.form_elements.lcinsured[key].name]!=undefined) {					
						unbindSameElement.call(topvue, sameFieldLcinusred1[targetName],
								targetElement);
					}
				}else{
					if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {					
						unbindSameElement.call(topvue, sameFieldLcinusred[targetName],
								targetElement);
					}
				}
				if (sameFieldLcinsuredtoaxalcappnt[topvue.form_elements.lcinsured[key].name]!=undefined) {					
					unbindSameElement.call(topvue, sameFieldLcinsuredtoaxalcappnt[targetName],
							targetElement);
				}
				if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					try {
						if(targetName=='postprovince'||targetName=='postdistrict'||targetName=='postcity'||
								targetName=='postaladdress'||targetName=='zipcode'){
							var postalflags=$("input[name='lcinsuredaddress.postalflags']");
							if(postalflags.is("[type='checkbox']:checked")){
								continue; 
							}
						}					
					} catch (e) {
						
					}
					unbindSameElement.call(topvue, sameFieldLcinusredAddress[targetName],
							targetElement);
				}

			}
			$("#lcinsuredpostalflagaxa").show();
			
						
			//2.投被保险人为本人，修改为非本人选项，则系统会清空被保险人信息，需要重新填写  （ 00为本人）
			if($('#lcinsuredrelationtoappntaxa').val() != "00" && $('#lcinsuredrelationtoappntaxa').val() != "" ){				
			
				//清空主被保人信息	输入框处理			            
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredname", null);//姓名
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredidno", null);//证件号码
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredbirthday", null);//出生日期
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"insureidenddate", new Array());//证件有效止期
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", null);//与投保人其它关系
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"schoolname", null);//大学/学院
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"schoollocated", null);//大学/学院所在州
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"stature", null);//身高（cm）
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"avoirdupois", null);//体重（KG）
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredsmokeyear", null);//抽烟年数
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"givenname", null);//名
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"stature", null);//身高（cm）
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"avoirdupois", null);//体重（KG）
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"familename", null);//姓				
				//清空被保人地址信息
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"mobile", null);//电话号码
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"email", null);//电子邮件
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"zipcode", null);//邮政编码
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postaladdress", null);//详细地址
				
				topvue.$nextTick(function () { 
				try {
									//下拉框处理
				//清空被保人信息			
				$('#lcinsuredoccupationclassaxa').combobox("clear");//职业类别
				$('#lcinsuredotherexpensesaxa').combobox("clear");//是否拥有其他补偿型医疗保险
				$('#lcinsuredphonetypeaxa').combobox("clear");//电话类型
				$('#lcinsuredoccupationaxapa4').combobox("clear");//职业
				$('#lcinsuredoccupationaxapa').combobox("clear");//行业大类
				$('#lcinsuredoccupationaxapa2').combobox("clear");//行业中类
				$('#lcinsuredoccupationaxapa3').combobox("clear");//行业小类
				$('#lcinsuredsexaxa').combobox("clear");//性别
				$('#lcinsuredsmoke').combobox("clear");//是否抽烟
				$('#lcinsuredplan').combobox("clear");//保险计划选择
				$('#lcinsuredplanaxa').combobox("clear");//保险计划
				$('#lcinsuredprofit').combobox("clear");//保险利益选择
				$('#lcinsuredoccupationaxaic4').combobox("clear");//职业
				$('#lcinsuredinchinaforaxa').combobox("clear");//目前在中国是
				$('#lcinsuredishavesocialaxa').combobox("clear");//有无社保
				$('#lcinsuredishsbcclerkaxa').combobox("clear");//是否是汇丰工作人员
				$('#lcinsuredidtypeaxa').combobox("clear");//证件类型
				$('#lcinsureddeductibleaxa').combobox("clear");//免赔额
				$('#lcinsuredfreemedicalaxa').combobox("clear");//是否拥有公费医疗或者基本医疗保险
				$('#lcinsuredidtype').combobox("clear");//证件类型
				$('#lcinsuredoccupationaxaic').combobox("clear");//行业大类				
				$('#lcinsuredoccupationaxa2').combobox("clear");//职业
				$('#lcinsuredoccupationaxa3').combobox("clear");//职位
				$('#lcinsuredoccupationaxaic2').combobox("clear");//行业中类
				$('#lcinsurednativeplace').combobox("clear");//国籍/地区
				$('#lcinsuredoccupationaxa').combobox("clear");//行业
				$('#lcinsuredoccupationaxaic3').combobox("clear");//行业小类
				 //清空被保人地址信息			
				$('#lcinsuredpostalflagaxa').combobox("clear");// 同投保人地址
				$('#lcinsuredpostprovinceaxa').combobox("clear");// 省/直辖市	
				$('#lcinsuredpostcityaxa').combobox("clear");// 地址市			
				$('#lcinsuredpostdistrictaxa').combobox("clear");// 地址区		
				} catch (e) {
				}
			});
		   }
			
		}

};
/**
 * IC  投保人 同被保人
 */
afterVueSelect.lcinsuredrelationtoappntaxaic = function(form_element) {
	
	if($('#lcinsuredrelationtoappntaxa').val() == '30'){
	$('#lcinsuredrelationaxa').removeAttr("disabled");
	
}else{
	$('#lcinsuredrelationaxa').attr("disabled",true);
	$('#lcinsuredrelationaxa').val("");
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", "");
}

	var topvue = getTopvueObj(this);
	var riskcode = vueobj["testdivchange"].formdata.lccont.riskcode;	 
	var form =$(this.$el)
	.parentsUntil("form").parent("form");
	if (this.formdata.relationtoappnt=="00") {

		for ( var key in topvue.form_elements.lcinsured) {
			
			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred1[topvue.form_elements.lcinsured[key].name]!=undefined) {
				bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusred1[targetName],
						topvue.formdata.lcinsured,targetName,targetElement);
			}
			
			if (sameFieldLcinsuredtoaxalcappnt[topvue.form_elements.lcinsured[key].name]!=undefined) {
				
				bindSameElement.call(topvue, topvue.formdata.axalcappnt, sameFieldLcinsuredtoaxalcappnt[targetName],
						topvue.formdata.lcinsured,targetName,targetElement);
			}
			
			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
				
				bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredAddress[targetName],
						topvue.formdata.lcinsuredaddress,targetName,targetElement);
			}

		}
		topvue.$nextTick(function () { 
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});
		$("#lcinsuredpostalflagaxa").hide();
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "");
	} else {
		for ( var key in topvue.form_elements.lcinsured) {
			
			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred1[topvue.form_elements.lcinsured[key].name]!=undefined) {					
				unbindSameElement.call(topvue, sameFieldLcinusred1[targetName],
						targetElement);
			}
			if (sameFieldLcinsuredtoaxalcappnt[topvue.form_elements.lcinsured[key].name]!=undefined) {					
				unbindSameElement.call(topvue, sameFieldLcinsuredtoaxalcappnt[targetName],
						targetElement);
			}
			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
				try {
					if(targetName=='postprovince'||targetName=='postdistrict'||targetName=='postcity'||
							targetName=='postaladdress'||targetName=='zipcode'){
						var postalflags=$("input[name='lcinsuredaddress.postalflags']");
						if(postalflags.is("[type='checkbox']:checked")){
							continue; 
						}
					}					
				} catch (e) {
					
				}
				unbindSameElement.call(topvue, sameFieldLcinusredAddress[targetName],
						targetElement);
			}

		}
		$("#lcinsuredpostalflagaxa").show();

		//2.投被保险人为本人，修改为非本人选项，则系统会清空被保险人信息，需要重新填写  （ 00为本人）
		if($('#lcinsuredrelationtoappntaxaic').val() != "00" && $('#lcinsuredrelationtoappntaxaic').val() != "" ){	
			//清空主被保人信息	输入框处理			            
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredname", null);//姓名
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredidno", null);//证件号码
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredbirthday", null);//出生日期
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"insureidenddate", new Array());//证件有效止期
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"otherrelationtoappnt", null);//与投保人其它关系
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"schoolname", null);//大学/学院
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"schoollocated", null);//大学/学院所在州
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"stature", null);//身高（cm）
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"avoirdupois", null);//体重（KG）
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredsmokeyear", null);//抽烟年数
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"givenname", null);//名
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"stature", null);//身高（cm）
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"avoirdupois", null);//体重（KG）
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"familename", null);//姓				
			//清空被保人地址信息
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"mobile", null);//电话号码
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"email", null);//电子邮件
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"zipcode", null);//邮政编码
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postaladdress", null);//详细地址
			
			topvue.$nextTick(function () { 
				try {
			//下拉框处理
			//清空被保人信息			
			$('#lcinsuredoccupationclassaxa').combobox("clear");//职业类别
			$('#lcinsuredotherexpensesaxa').combobox("clear");//是否拥有其他补偿型医疗保险
			$('#lcinsuredphonetypeaxa').combobox("clear");//电话类型
			$('#lcinsuredoccupationaxapa4').combobox("clear");//职业
			$('#lcinsuredoccupationaxapa').combobox("clear");//行业大类
			$('#lcinsuredoccupationaxapa2').combobox("clear");//行业中类
			$('#lcinsuredoccupationaxapa3').combobox("clear");//行业小类
			$('#lcinsuredsexaxa').combobox("clear");//性别
			$('#lcinsuredsmoke').combobox("clear");//是否抽烟
			$('#lcinsuredplan').combobox("clear");//保险计划选择
			$('#lcinsuredplanaxa').combobox("clear");//保险计划
			$('#lcinsuredprofit').combobox("clear");//保险利益选择
			$('#lcinsuredoccupationaxaic4').combobox("clear");//职业
			$('#lcinsuredinchinaforaxa').combobox("clear");//目前在中国是
			$('#lcinsuredishavesocialaxa').combobox("clear");//有无社保
			$('#lcinsuredishsbcclerkaxa').combobox("clear");//是否是汇丰工作人员
			$('#lcinsuredidtypeaxa').combobox("clear");//证件类型
			$('#lcinsureddeductibleaxa').combobox("clear");//免赔额
			$('#lcinsuredfreemedicalaxa').combobox("clear");//是否拥有公费医疗或者基本医疗保险
			$('#lcinsuredidtype').combobox("clear");//证件类型
			$('#lcinsuredoccupationaxaic').combobox("clear");//行业大类				
			$('#lcinsuredoccupationaxa2').combobox("clear");//职业
			$('#lcinsuredoccupationaxa3').combobox("clear");//职位
			$('#lcinsuredoccupationaxaic2').combobox("clear");//行业中类
			$('#lcinsurednativeplace').combobox("clear");//国籍/地区
			$('#lcinsuredoccupationaxa').combobox("clear");//行业
			$('#lcinsuredoccupationaxaic3').combobox("clear");//行业小类
			 //清空被保人地址信息			
			$('#lcinsuredpostalflagaxa').combobox("clear");// 同投保人地址
			$('#lcinsuredpostprovinceaxa').combobox("clear");// 省/直辖市	
			$('#lcinsuredpostcityaxa').combobox("clear");// 地址市			
			$('#lcinsuredpostdistrictaxa').combobox("clear");// 地址区								
				} catch (e) {
				}
			});
	   }
		
		
	}

};
/**
 * 投保人地址同被保人地址
 */
afterVueSelect.lcinsuredpostalflagaxa = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (topvue.formdata.lcinsured.relationtoappnt!="00") {
		
		
		if (obj.is("[type='checkbox']:checked")) {
			
			for ( var key in topvue.form_elements.lcinsured) {
				
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (sameAddressToLcappnt[topvue.form_elements.lcinsured[key].name]!=undefined) {
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameAddressToLcappnt[targetName],
							topvue.formdata.lcinsuredaddress,targetName,targetElement);
				}
			}
		
		} else {
			for ( var key in topvue.form_elements.lcinsured) {
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (sameAddressToLcappnt[topvue.form_elements.lcinsured[key].name]!=undefined) {
					unbindSameElement.call(topvue, sameAddressToLcappnt[targetName],
							targetElement);
				}
			}
		}
		
		
	}
	

};



//附属被保人同本人
var sameFieldLcinusredtwo={
		"lcinsuredname"	:"appntname",
		"lcinsurednativeplace"	:"nativeplace",//国籍
		"industrytype"	:"industrytype",// 行业
		"occupationtype" :"occupationcode", //职业
		"lcinsuredroccupationcode": "responsibility", //职位
		"lcinsuredidtype"	:"idtype",//证件类型
		"lcinsuredsex"	:"appntsex",//性别
		"lcinsuredidno"	:"idno",//证件号码
		"lcinsuredbirthday"	:"appntbirthday",//出生日期
		"insureidenddate"	:"appntenddate",//证件有效止期
		"lcinsuredbirthcounty":"birthcounty",	
		"appntenddate":"insureidenddate",
		
		
	};
var sameFieldLcinusredtwo1={
		"lcinsuredname"	:"appntname",
		"lcinsurednativeplace"	:"nativeplace",//国籍
		"lcinsuredidtype"	:"idtype",//证件类型
		"lcinsuredsex"	:"appntsex",//性别
		"lcinsuredidno"	:"idno",//证件号码
		"lcinsuredbirthday"	:"appntbirthday",//出生日期
		"insureidenddate"	:"appntenddate",//证件有效止期
		"lcinsuredbirthcounty":"birthcounty",	
		"appntenddate":"insureidenddate",
	};
var sameFieldLcinsuredtwotoaxalcappnt={
		"inchinafor" :"inchinafor",
		"ishsbcclerk":"ishsbcclerk",	
		"familename":"surname",
		"givenname":"name",
		"phonetype":"phonetype",
		
};
	var sameFieldLcinusredtwoAddress={
			"zipcode"	:"zipcode",//联系地址邮政编码
			"postprovince"	:"postprovince",//通讯地址省
			"postdistrict"	:"postdistrict",//通讯地址区
			"postcity"	:"postcity",//通讯地址市
			"postaladdress"	:"postaladdress",//通讯地址			
			"mobile"	:"mobile",//移动电话 
			"email"	:"email",
		};
	
 
/**
 *  多被保人 投保人 同被保人 AM AS PA
 */
afterVueSelect.lcinsuredrelationtoappntaxamulti = function(form_element) {
	var topvue = getTopvueObj(this);
	var riskcode = vueobj["testdivchange"].formdata.lccont.riskcode;
	var obj = $("#"+form_element.id);
	var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
	var relationtoappnt=$("input[name='lcinsuredmulti"+this.elementindex+".relationtoappnt']").val();
	var index = this.elementindex.replace(/[^0-9]/ig,"");
	if(relationtoappnt == '30'){
	$("input[name='lcinsuredmulti"+this.elementindex+".otherrelationtoappnt']").attr("disabled",false);
}else{
	$("input[name='lcinsuredmulti"+this.elementindex+".otherrelationtoappnt']").attr("disabled",true);
	vueobj.testdivchange.formdata.lcinsuredmulti[index].otherrelationtoappnt="";
}	 
	var form =$(this.$el).parentsUntil("form").parent("form");
	if (relationtoappnt=="00") {
	
		for ( var key in topvue.form_elements.AXAlcinsured) {
			
			var targetName= topvue.form_elements.AXAlcinsured[key].name;
			var targetElement= topvue.form_elements.AXAlcinsured[key];
			if(riskcode=="@PA"){
				if (sameFieldLcinusredtwo1[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
					bindSameElementByJqobj.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusredtwo1[targetName],
							topvue.formdata.lcinsuredmulti[index],targetName,targetElement,targetObj);
				}
			}else{
				if (sameFieldLcinusredtwo[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
					bindSameElementByJqobj.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusredtwo[targetName],
							topvue.formdata.lcinsuredmulti[index],targetName,targetElement,targetObj);
				}
			}
		
			if (sameFieldLcinsuredtwotoaxalcappnt[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.axalcappnt, sameFieldLcinsuredtwotoaxalcappnt[targetName],
						topvue.formdata.lcinsuredmulti[index],targetName,targetElement,targetObj);
			}
			
			
			if (sameFieldLcinusredtwoAddress[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,"lcaddress."+targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredtwoAddress[targetName],
						topvue.formdata.lcinsuredmulti[index].lcaddress,targetName,targetElement,targetObj);
			}

		}
					
		topvue.$nextTick(function () { 
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});		
		$("input[name='lcinsuredmulti"+this.elementindex+".lcaddress.postalflags']").hide();
		vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.postalflags=""
	} else {																				
		for ( var key in topvue.form_elements.AXAlcinsured) {			
			var targetName= topvue.form_elements.AXAlcinsured[key].name;
			var targetElement= topvue.form_elements.AXAlcinsured[key];
			var index = getIndex(eleName);
			if(riskcode=="@PA"){
				if (sameFieldLcinusredtwo1[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");		
					unbindSameElementByJqobj.call(topvue, sameFieldLcinusredtwo1[targetName],
							targetElement,targetObj);
				}
			}else{
				if (sameFieldLcinusredtwo[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");		
					unbindSameElementByJqobj.call(topvue, sameFieldLcinusredtwo[targetName],
							targetElement,targetObj);
				}
			}
			if (sameFieldLcinsuredtwotoaxalcappnt[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");									
				unbindSameElementByJqobj.call(topvue, sameFieldLcinsuredtwotoaxalcappnt[targetName],
						targetElement,targetObj);
			}
			if (sameFieldLcinusredtwoAddress[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,"lcaddress."+targetName)+"']");	
				try {
					if(targetName=='postprovince'||targetName=='postdistrict'||targetName=='postcity'||
							targetName=='postaladdress'||targetName=='zipcode'){
						var postalflags=$("input[name='lcinsuredmulti["+index+"].lcaddress.postalflags']");
						if(postalflags.is("[type='checkbox']:checked")){
							continue;
						}
					}					
				} catch (e) {
					
				}
				unbindSameElementByJqobj.call(topvue, sameFieldLcinusredtwoAddress[targetName],
						targetElement,targetObj);
			}

		}
		$("input[name='lcinsuredmulti"+this.elementindex+".lcaddress.postalflags']").show();
	}
};

 
/**
 * IC  多被保人投保人 同被保人
 */
afterVueSelect.lcinsuredrelationtoappntaxaicmulti = function(form_element) {
	var topvue = getTopvueObj(this);
	var riskcode = vueobj["testdivchange"].formdata.lccont.riskcode;
	var obj = $("#"+form_element.id);
	var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
	var relationtoappnt=$("input[name='lcinsuredmulti"+this.elementindex+".relationtoappnt']").val();
	var index = this.elementindex.replace(/[^0-9]/ig,"");
	if(relationtoappnt == '30'){
	$("input[name='lcinsuredmulti"+this.elementindex+".otherrelationtoappnt']").attr("disabled",false);
}else{
	$("input[name='lcinsuredmulti"+this.elementindex+".otherrelationtoappnt']").attr("disabled",true);
	vueobj.testdivchange.formdata.lcinsuredmulti[index].otherrelationtoappnt="";
}	 
	var form =$(this.$el).parentsUntil("form").parent("form");
	if (relationtoappnt=="00") {
	
		for ( var key in topvue.form_elements.AXAlcinsured) {
			
			var targetName= topvue.form_elements.AXAlcinsured[key].name;
			var targetElement= topvue.form_elements.AXAlcinsured[key];
			if (sameFieldLcinusredtwo1[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusredtwo1[targetName],
						topvue.formdata.lcinsuredmulti[index],targetName,targetElement,targetObj);
			}
		
			if (sameFieldLcinsuredtwotoaxalcappnt[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.axalcappnt, sameFieldLcinsuredtwotoaxalcappnt[targetName],
						topvue.formdata.lcinsuredmulti[index],targetName,targetElement,targetObj);
			}
			
			
			if (sameFieldLcinusredtwoAddress[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,"lcaddress."+targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredtwoAddress[targetName],
						topvue.formdata.lcinsuredmulti[index].lcaddress,targetName,targetElement,targetObj);
			}

		}
					
		topvue.$nextTick(function () { 
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});		
		$("input[name='lcinsuredmulti"+this.elementindex+".lcaddress.postalflags']").hide();
		vueobj.testdivchange.formdata.lcinsuredmulti[index].lcaddress.postalflags=""
	} else {																				
		for ( var key in topvue.form_elements.AXAlcinsured) {			
			var targetName= topvue.form_elements.AXAlcinsured[key].name;
			var targetElement= topvue.form_elements.AXAlcinsured[key];
			var index = getIndex(eleName);
			if (sameFieldLcinusredtwo1[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");		
				unbindSameElementByJqobj.call(topvue, sameFieldLcinusredtwo1[targetName],
						targetElement,targetObj);
			}
			if (sameFieldLcinsuredtwotoaxalcappnt[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");									
				unbindSameElementByJqobj.call(topvue, sameFieldLcinsuredtwotoaxalcappnt[targetName],
						targetElement,targetObj);
			}
			if (sameFieldLcinusredtwoAddress[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,"lcaddress."+targetName)+"']");	
				try {
					if(targetName=='postprovince'||targetName=='postdistrict'||targetName=='postcity'||
							targetName=='postaladdress'||targetName=='zipcode'){
						var postalflags=$("input[name='lcinsuredmulti["+index+"].lcaddress.postalflags']");
						if(postalflags.is("[type='checkbox']:checked")){
							continue;
						}
					}					
				} catch (e) {
					
				}
				unbindSameElementByJqobj.call(topvue, sameFieldLcinusredtwoAddress[targetName],
						targetElement,targetObj);
			}

		}
		$("input[name='lcinsuredmulti"+this.elementindex+".lcaddress.postalflags']").show();
	}
};
//多被保人同投保人通讯地址
afterVueSelect.lcinsuredpostalflagaxamulti = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	
	
	if(topvue.formdata['lcinsuredmulti']){
		var index = getElementIntex(this); 
		var relationtoappnt = topvue.formdata.lcinsuredmulti[index].relationtoappnt;
		if (relationtoappnt=="00") {
			return;
		}
		var eleName = this.namepref 
			+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
		
		obj=$("input[name='"+eleName+"']");
	
		if (obj.is("[type='checkbox']:checked")) {
			
			for ( var key in topvue.form_elements.AXAlcinsured) {
				
				var targetName= topvue.form_elements.AXAlcinsured[key].name;
				var targetElement= topvue.form_elements.AXAlcinsured[key];
				var index = getIndex(eleName);
				
				if (sameAddressToLcappnt[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");	
					bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, sameAddressToLcappnt[targetName],
							topvue.formdata.lcinsuredmulti[index].lcaddress,targetName,targetElement,targetObj);
				}
			}
		
		} else {
			for ( var key in topvue.form_elements.AXAlcinsured) {
 
				var targetName= topvue.form_elements.AXAlcinsured[key].name;
				var targetElement= topvue.form_elements.AXAlcinsured[key];
				var index = getIndex(eleName);
				
				if (sameAddressToLcappnt[topvue.form_elements.AXAlcinsured[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");	
					unbindSameElementByJqobj.call(topvue, sameAddressToLcappnt[targetName],
							targetElement,targetObj);
				}
			}
		}
		
	}	
};
var afterInitTab={
		   
};
// 
afterInitTab.lcinsured_tabinfo= function() {
 try{
	 var investment = vueobj["testdivchange"].formdata.newContApply.investment;
	 DatePicker(investment);
 }catch(e){
  
 }
}	

afterloadNewElements.lcinsured_tabinfo=function(){
	
	setTimeout(function(){
		
		if(($("#lcinsuredidtypeaxa").is(":visible")||$("#lcinsuredidtypeaxa").length>0)){
	   		 $("#lcinsuredidtypeaxaTitle").remove();
	   		$("#lcinsuredidtypeaxa").parent().append("<small id='lcinsuredidtypeaxaTitle' class='help-block' style='color: red;'>请注意，" +
	   				"此处选择的被保险证件类型，需和其之后通过手机银行上传的证件文件（e.g.,图片）的类型保持一致。若被保险人选择了“身份证”，则需上传其身份证的图片，不能上传户口本上有证件号码的图片。</small>");
			 }

		
		if(($("#lcinsuredidtype").is(":visible")||$("#lcinsuredidtype").length>0)){
   		 $("#lcinsuredidtypeTitle").remove();
   		$("#lcinsuredidtype").parent().append("<small id='lcinsuredidtypeTitle' class='help-block' style='color: red;'>请注意，" +
   				"此处选择的被保险证件类型，需和其之后通过手机银行上传的证件文件（e.g.,图片）的类型保持一致。若被保险人选择了“身份证”，则需上传其身份证的图片，不能上传户口本上有证件号码的图片。</small>");
		 }
	},50);
	
	var topvue = getTopvueObj(this);
	if(topvue.formdata.lccont.currencytype!=undefined){
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"bak", topvue.formdata.lccont.currencytype);
	}else{
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"bak", " ");
	}
}

//根据身份证号，同步出生日期
afterVueSelect.inshlcinsuredidno = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");
	if($("#inshlcinsuredidtype").val() != "I" && $("#inshlcinsuredidtype").val() != "J"){
		return;
	}
	if($("#inshlcinsuredidtype").val() == "I"||$("#inshlcinsuredidtype").val() == "J"){
		if (obj.is("[id='inshlcinsuredidno']")){
			var idno = $("#inshlcinsuredidno").val();
			var birthday = idno.substring(6,14);
			var year = birthday.substring(0,4);
			var mon = birthday.substring(4,6);
			var day = birthday.substring(6);
			var formatBirth = year + "-" + mon + "-" + day;
			topvue.$set(topvue.formdata.lcinsuredtwo,"lcinsuredbirthday",formatBirth);
			
		}
	
		
		
	}
	
}
beforesubmitvueform.lcinsured_tabinfoform = function() {
	var topvue = getTopvueObj(this);
	var riskcode = vueobj["testdivchange"].formdata.lccont.riskcode;
	var insuredsize=vueobj["testdivchange"].formdata['lcinsuredmulti'].length;
	if(riskcode=="@PA"){
		var idno = vueobj["testdivchange"].formdata.lcinsured.lcinsuredidno;
		if($('#lcinsuredidtypeaxa').val() == '01'){
			if(!validateId(idno)){
				return false;
			}
		}else{
		}
		for(var i=0;i<insuredsize;i++){
			var multino = vueobj["testdivchange"].formdata.lcinsuredmulti[i].lcinsuredidno;
			var lcinsuredidtype= vueobj["testdivchange"].formdata.lcinsuredmulti[i].lcinsuredidtype;
			if(lcinsuredidtype == '01'){
				if(!validateId(multino)){
					return false;
				}
			}else{
			}
		}
	}
	// if(!(new Date(topvue.formdata.lcinsured.insureidenddate)>new Date())){
	// 	alert("证件有效期必须大于今天");
	// 	return false;
	// }
	// for(var i=0;i<insuredsize;i++){
	// 	var insureidenddate= vueobj["testdivchange"].formdata.lcinsuredmulti[i].insureidenddate;
	// 	if(!(new Date(insureidenddate)>new Date())){
	// 		alert("证件有效期必须大于今天");
	// 		return false;
	// 	}
	// }

	//3.保存被保险人信息时， 若投被保险人信息非同一人时，请检查投保人和被保险人的证件号码是否相同，
	//若相同，则报错“投保人和被保险人证件号码相同，请检查投被保险人关系是否填写正确！”		  00为本人		
	if (topvue.formdata.lcinsured.relationtoappnt!="00"&&topvue.formdata.lcinsured.relationtoappnt!= "") {
			var idno= topvue.formdata.lcappnt.idno;//投保人证件号码
			var lcinsuredidno= topvue.formdata.lcinsured.lcinsuredidno;////被保人证件号码
			if(idno!=""&&lcinsuredidno!=""){
				if(idno.trim()==lcinsuredidno.trim()){
					alert("投保人和被保险人证件号码相同，请检查投被保险人关系是否填写正确！");
					return false;
				}
			}
	}
	
	return true;
}
function validateId(id){
    var city={11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江 ",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北 ",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏 ",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外 "};
    var tip = "";
    var pass= true;
    var code = id;
    if(!code || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(code)){
        tip = "身份证号格式错误";
        pass = false;
    }

   else if(!city[code.substr(0,2)]){
        tip = "身份证号格式错误";
        pass = false;
    }
    else{
        //18位身份证需要验证最后一位校验位
        if(code.length == 18){
            code = code.split('');
            //∑(ai×Wi)(mod 11)
            //加权因子
            var factor = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 ];
            //校验位
            var parity = [ 1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2 ];
            var sum = 0;
            var ai = 0;
            var wi = 0;
            for (var i = 0; i < 17; i++)
            {
                ai = code[i];
                wi = factor[i];
                sum += ai * wi;
            }
            var last = parity[sum % 11];
            if(parity[sum % 11] != code[17]){
                tip = "身份证号格式错误";
                pass =false;
            }
        }
    }
    if(!pass){
    	alert(tip);
    	return false;
    }else{
    	return true;
    }
}