var tab_d = $('#cusTable');
var select2 = '请选择';
//页面初始化
$(document).ready(function() {
	
	$("#downLoad").attr("disabled", true);
	
	var init_url = "";
	
	/**加载页面表格*/
	       var col = [{field: 'metentid',title: '序号',formatter: function (value, row, index) {  
                       return index+1;  
                     }},
	   				{field: 'branchNo',title: 'Branch Code',align: 'center',valign : 'middle',visible: true},
	   				{field: 'transactionDate',title: 'Transaction Date',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'cifId',title: 'CIF ID',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'applicationNo',title: 'Application No',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'contno',title: 'Contno',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'currency',title: 'Currency',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'premiun',title: 'Premium',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'cny_premium',title: 'CNY_Premium',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'status',title: 'Status',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'statusDetails',title: 'Status_Details',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'delayedPayment',title: '是否延迟扣款',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'txnId',title: 'Txn ID',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'staffId',title: 'StaffId',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'payendyear',title: 'Payment Term',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'firsttrialtime',title: 'Deduction Date',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'debittime',title: 'Deduction Time',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'riskcode',title: 'Prod Code',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'commonchannel',title: 'Channel',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'lcRiskCode',title: 'RiskCode',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'esignFlag',title: 'EsignFlag',align: 'center',sortable: true,valign : 'middle'},
					{field: 'shoppingCartTransaction',title: 'ShoppingCartTransaction',align: 'center',sortable: true,valign : 'middle'},//购物车交易
	   				{field: 'agentName1',title: 'Staff Name',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'agentJob',title: 'Staff registration No',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'riskLevel',title: 'Customer Risk level',align: 'center',sortable: true,valign : 'middle',visible: false},
	   				{field: 'recording',title: '是否手工单补录',align: 'center',sortable: true,valign : 'middle',visible: false},
	   				{field: 'referra',title: '介绍人工号',align: 'center',sortable: true,valign : 'middle',visible: false},
	   				{field: 'enterWay',title: '保单录入方式',align: 'center',sortable: true,valign : 'middle'}
	  			   ];	
	       
	var uniqueId = "metentid";
	var sortOrder = "metentid asc";
	
	$("#datetype").change(function() {
		var insuranceCompany = ($(this).children('option:selected').val().trim());
		select2 = insuranceCompany;
	});
    
	 $("#search").click(function() {
		    if(select2=='请选择'||select2==0){
				alert("请选择查询类型");
				return;
			}
		
		    
		    
		    var start = $("#StartDate").val();
			var end = $("#endDate").val();
		 	if(start!=null&&start!=""&&end!=null&&end!=""&&DateDiff(start,  end)<=60&&CompareDate(end,start)){
		 		    $("#cusTable").bootstrapTable('destroy');
				    $("#downLoad").attr("disabled", false);
				    $("#downLoad").attr("class", "btn btn-primary");    
					var url_d = "/ExcelReportController/selectRouterByDate.do";
					tableInit3(url_d, tab_d, col,uniqueId, queryParams);					
		 	}else{
		 		if(start==null||start==""){
		 			alert("请输入开始时间");
		 			return false;
		 		}
		 		if(end==null||end==""){
		 			alert("请输入结束时间");
		 			return false;
		 		}		 		
		 		if(DateDiff(start,  end)>60){
		 			alert("最大查询范围为60天，请核实您的日期");
		 			return false;
		 		}		 		
		 		if(!CompareDate(end,start)){
		 			alert("开始时间大于结束时间，请正确的选择您的查询时间");
		 			return false;
		 		}
		 	}		     		  		
   });
	
	$("#downLoad").click(function(){
		var start = $("#StartDate").val();
		var end = $("#endDate").val();
		var branchno = $("#branchno").val();
		var datetype =$("#datetype").val();
		download(start,end,branchno,datetype);
	});
});
		
/**
 * 设置表格查询参数
 * @param params
 */
function queryParams(params){	
//	var start = $("#StartDate").val();
//	var end = $("#endDate").val();
//	if(DateDiff(start,  end)>30){
//		alert("最大查询范围为30天，请核实您的日期");
//		return false;
//	}
//	if(start==null||start==""){
//		alert("请输入开始时间");
//		return false;
//	}
//	if(end==null||end==""){
//		alert("请输入结束时间");
//		return false;
//	}
//	if(!CompareDate(end,start)){
//		alert("开始时间大于结束时间，请正确的选择您的查询时间");
//		return false;
//	}
	//设置查询参数 
	 param = {
	    		limit : params.limit,
		        offset: params.offset,		        
		        sortName:params.sortName,//排序列名
		        sortOrder:params.sortOrder,//排位命令（desc，asc）		        
		        pageSize: params.pageSize,
		        pageNumber:params.pageNumber,		        
				StartDate: $("#StartDate").val(),				
				endDate: $("#endDate").val(),
				branchno:$("#branchno").val(),
				datetype:$("#datetype").val(),
		}; 	     
	    return param; 
}


/**
 * 翻页带查询参数及列排序
 * @param url
 * @param obj
 * @param col
 * @param uniqueId 行主键
 * @param sortOrder 排序方式
 * @param queryParams
 * @author TKW
 */
function tableInit3(url, obj, col, uniqueId,queryParams) {
	obj.bootstrapTable('destroy');
	obj.bootstrapTable({
		url : path + url, // 请求后台的URL（*）
		dataType : "json",
		method : 'post', // 请求方式（*）
		contentType : "application/x-www-form-urlencoded",
		toolbar : '#toolbar',
		columns : col,
		striped : true, // 是否显示行间隔色
		cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		pagination : true, // 是否显示分页（*）
		queryParamsType : "limit",// undefined/limit
		queryParams : queryParams,// 传递参数（*）
		sidePagination : "server", //
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		strictSearch : true,// 设置为 true启用 全匹配搜索，否则为模糊搜索
		showColumns : true, // 是否显示所有的列
		showRefresh : true, // 是否显示刷新按钮
		minimumCountColumns : 2, // 最少允许的列数
		clickToSelect : true, // 是否启用点击选中行
		// height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		// uniqueId: "ID", // 每一行的唯一标识，一般为主键列
		uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
		showToggle : true, // 是否显示详细视图和列表视图的切换按钮
		cardView : false, // 是否显示详细视图
		detailView : false
	});
};

function  DateDiff(sDate1,  sDate2){  
    var  aDate,  oDate1,  oDate2,  iDays  
    aDate  =  sDate1.split("-")  
    oDate1  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0])    
    aDate  =  sDate2.split("-")  
    oDate2  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0])  
    iDays  =  parseInt(Math.abs(oDate1  -  oDate2)  /  1000  /  60  /  60  /24)    //把相差的毫秒数转换为天数  
    return  iDays  
}    

function CompareDate(d1,d2)
{
  return ((new Date(d1.replace(/-/g,"\/"))) >= (new Date(d2.replace(/-/g,"\/"))));
}

function download(start,end,branchno,datetype){
//var obj=new Object();
//obj.name="1";
//obj.startrouter=start;
//obj.endrouter=end;
//window.showModalDialog("showdialog.jsp",obj,"dialogWidth=650px;dialogHeight=200px;scroll:no;"); 	
show();
$.ajax({	
	
	type : "POST",
	data : "start="+start+"&end="+end+"&branchno="+branchno+"&datetype="+datetype,		
	url:path+"/ExcelReportController/downloadRouter.do",// 后台请求URL地址	
	success : function(data) {	
	   closed();
	   var json=eval(data);
	   if(json.success){
		var url ="download.jsp?path="+json.parm+"&a="+"sdf";
		toback(url);
	   }else{
		   alert("未匹配到数据！"); 
	   }						
	},
	 error : function() {
	 closed();
	 alert("plus failed");
	}
});		
}