$(function(){
	
	//CustimerId
	if(grpcontno!=null && grpcontno !="" && grpcontno !="null"){
		$("#b").val(grpcontno);
	}
	//查询保险公司
	$.ajax({
		 url:path + '/newContEnter/selectFromLacomByAgentcom.do',  
        type: "POST",
        data:{"agentcom":insuranceCom},
		 success: function(data){ 
			 if(data!=null){
				 $("#BX").val(data.name);
				 //如果存在这个保险公司，查询出该保险公司对对应的产品
				 selectLmriskByInsuranceCom();
			 }else{
				 $("#BX").val(insuranceCom);
				 alert("未查询到该保险公司："+insuranceCom);
			 }
		 }
	});
	
	
	
	
});
//根据保险公司查产品  匹配！！
function selectLmriskByInsuranceCom(){
	
	$.ajax({
	   url:path + '/newContEnter/mateLmrisk.do',  
       type: "POST",
       data:{"insurancecom":insuranceCom,"riskcode":riskcode},
	   success: function(data){
			 //如果匹配上
			 if(data.success==true){
				 $("#riskcode").val(data.msg);
				 $("#displayBtn").click();
			 }else{
				 if(riskcode!=null && riskcode !="" && riskcode !="null"){
					 $("#riskcode").val(riskcode);
				 }
				 alert(data.msg);
			 }
		 }
	});
}

$("#displayBtn").click(function(){
	$("#add").removeAttr("disabled"); 
	$("#add").removeClass("btn btn-primaryis");
	$("#add").addClass("btn btn-primary");
});

$("#add").click(function() {
	$("#choice_Modal").modal('show');
});
//代录入入口工作时间校验
function rEnter(){	
	if(grpcontno==""||grpcontno==null){
		alert("投保人客户号不能为空");
		return false;
	}
	//添加工作时间的校验	
	if(insuranceCom=="INSH"){
		show();
		$.ajax({
			type : "POST",
			async: false,
			url:path+"/QueryCifController/workingTime.do",// 后台请求URL地址
			dataType : "json",
			success : function(data) {
				if(data.success==false){
					if(data.parm&&data.parm=="warn"){
						layer.confirm( data.msg, {
				  			  btn: ['确认','取消'], //按钮
				  			  title:"系统提示",
				  			  closeBtn:false
				  			}, function(confirmIndex){
				  				layer.close(confirmIndex);
				  				closed();
				  				rEnterPayment();
				  				}, function(){
				  					closed();
				  				});														
					}else if(data.parm&&data.parm=="refuse"){							
						layer.alert(data.msg, {closeBtn: false});
						closed();
						return;	  
					}
				}else{
					closed();
					rEnterPayment();
				}
			},
			error:function(data){
				closed();
			}
			});
	}else{
		closed();
		rEnterPayment();
	}	
};

//电子录入时间校验
function eEnter(){				
	if(grpcontno==""||grpcontno==null){
		alert("投保人客户号不能为空");
		return false;
	}

		if(insuranceCom=="INSH"){
			show();
			$.ajax({
				type : "POST",
				async: false,
				url:path+"/QueryCifController/workingTime.do",// 后台请求URL地址
				dataType : "json",
				success : function(data) {
					if(data.success==false){
						if(data.parm&&data.parm=="warn"){
							layer.confirm( data.msg, {
					  			  btn: ['确认','取消'], //按钮
					  			  title:"系统提示",
					  			  closeBtn:false
					  			}, function(confirmIndex){
					  				layer.close(confirmIndex);
					  				closed();
					  				eEnterpayment();
					  				}, function(){
					  					closed();
					  				});														
						}else if(data.parm&&data.parm=="refuse"){							
							layer.alert(data.msg, {closeBtn: false});
							closed();
							return;	  
						}
					}else{
						closed();
						eEnterpayment();
					}
				},
				error:function(data){
					closed();
				}
				});
		}else{
			closed();
			eEnterpayment();
		}	
};

/**
 * 纸质录入时间校验
 */
function pEnter(){	
	if(grpcontno==""||grpcontno==null){
		alert("投保人客户号不能为空");
		return false;
	}

	//添加工作时间的校验	
	if(insuranceCom=="INSH"){
		show();
		$.ajax({
			type : "POST",
			async: false,
			url:path+"/QueryCifController/workingTime.do",// 后台请求URL地址
			dataType : "json",
			success : function(data) {
				if(data.success==false){
					if(data.parm&&data.parm=="warn"){
						layer.confirm( data.msg, {
				  			  btn: ['确认','取消'], //按钮
				  			  title:"系统提示",
				  			  closeBtn:false
				  			}, function(confirmIndex){
				  				layer.close(confirmIndex);
				  				closed();
				  				pEnterPayment();
				  				}, function(){
				  					closed();
				  				});														
					}else if(data.parm&&data.parm=="refuse"){							
						layer.alert(data.msg, {closeBtn: false});
						closed();
						return;	  
					}
				}else{
					closed();
					pEnterPayment();
				}
			},
			error:function(data){
				closed();
			}
			});
	}else{
		closed();
		pEnterPayment();
	}	
};

/**
 * 代录入录单入口
 * @param tContNo
 * @returns {Boolean}
 */
function rEnterPayment (){
	$(function(){
		$.ajax({
		type : "POST",
		url:path+"/QueryCifController/queryCif.do",// 后台请求URL地址
		data : {"bankName":grpcontno,"YH":riskcode,"BX":insuranceCom,"GoalSequenceNumber":GoalSequenceNumber,"GoalId":GoalId},
		dataType : "json",
		success : function(data) {
			closed();
			if(data.success==false){
				alert(data.msg);
				return;
			}else{
				var parm="";
				$.ajax({
				type : "POST",
				async: false,
				url:path+"/newContEnter/selectpower.do",// 后台请求URL地址
				data : {"grpcontno":grpcontno,"insurancecom":insuranceCom,"riskcode":riskcode},
				dataType : "json",
				success : function(data) {
					closed();
					if(data.success==false){
						alert(data.msg);
						return;
					}else{						
						var url= ""; 
						var enterFlag = "rEnter";
						url = path+"/newCont/enter/newWay/"+ insuranceCom+"/"+ riskcode +"/"+ grpcontno+"/"+enterFlag+".do"
				        + "?recording=N" + "&orderID="+ orderID + "&reportID=" + reportID 
	      			    + "&recordID=" + recordID + "&FPRID=" + FPRID
	      			    + "&prdTypeCode=" + prdTypeCode + "&prdSubTypeCode=" + prdSubTypeCode
						+ "&prdAlternativeNumber=" + prdAlternativeNumber
						+ "&prdClassificationCode=" + prdClassificationCode
						+ "&countryTradableCode=" + countryTradableCode
						+ "&customerIndicator=" + customerIndicator
						+ "&applicationId=" + applicationId
						+ "&quotationId=" + quotationId
						+ "&shoppingCartIndicator=" + shoppingCartIndicator
						+ "&remoteSalesIndicator=" + remoteSalesIndicator; 					        						 
						window.location.href=url; 
					}
				},
				error:function(data){
					closed();
				}
				});
			}
		}
	});
 });
} 

/**
 * 电子录入入口
 * @param tContNo
 * @returns {Boolean}
 */
function eEnterpayment(){	
	$(function(){
		$.ajax({
		type : "POST",
		url:path+"/QueryCifController/queryCif.do",// 后台请求URL地址
		data : {"bankName":grpcontno,"YH":riskcode,"BX":insuranceCom,"GoalSequenceNumber":GoalSequenceNumber,"GoalId":GoalId},
		dataType : "json",
		success : function(data) {
			closed();
			if(data.success==false){
				alert(data.msg);
				return;
			}else{
				var parm="";
				$.ajax({
				type : "POST",
				async: false,
				url:path+"/newContEnter/selectpower.do",// 后台请求URL地址
				data : {"grpcontno":grpcontno,"insurancecom":insuranceCom,"riskcode":riskcode},
				dataType : "json",
				success : function(data) {
					closed();
					if(data.success==false){
						alert(data.msg);
						return;
					}else{						
						var url= ""; 
						enterFlag ="eEnter";
						url = path+"/newCont/enter/"+ insuranceCom+"/"+ riskcode +"/"+ grpcontno+".do"
				        + "?recording=N" + "&orderID="+ orderID + "&reportID=" + reportID 
	      			    + "&recordID=" + recordID + "&FPRID=" + FPRID
	      			    + "&prdTypeCode=" + prdTypeCode + "&prdSubTypeCode=" + prdSubTypeCode
						+ "&prdAlternativeNumber=" + prdAlternativeNumber
						+ "&prdClassificationCode=" + prdClassificationCode
						+ "&countryTradableCode=" + countryTradableCode
						+ "&customerIndicator=" + customerIndicator
						+ "&applicationId=" + applicationId
						+ "&quotationId=" + quotationId
						+ "&shoppingCartIndicator=" + shoppingCartIndicator
						+ "&remoteSalesIndicator=" + remoteSalesIndicator
						+ "&enterWay=eEnter";					        						 
						window.location.href=url; 
					}
				},
				error:function(data){
					closed();
				}
				});
			}
		}
	});
 });
}

/**
 * 纸质录入入口
 * @param tContNo
 * @returns {Boolean}
 */
function pEnterPayment (){
	$(function(){
		$.ajax({
		type : "POST",
		url:path+"/QueryCifController/queryCif.do",// 后台请求URL地址
		data : {"bankName":grpcontno,"YH":riskcode,"BX":insuranceCom,"GoalSequenceNumber":GoalSequenceNumber,"GoalId":GoalId},
		dataType : "json",
		success : function(data) {
			closed();
			if(data.success==false){
				alert(data.msg);
				return;
			}else{
				var parm="";
				$.ajax({
				type : "POST",
				async: false,
				url:path+"/newContEnter/selectpower.do",// 后台请求URL地址
				data : {"grpcontno":grpcontno,"insurancecom":insuranceCom,"riskcode":riskcode},
				dataType : "json",
				success : function(data) {
					closed();
					if(data.success==false){
						alert(data.msg);
						return;
					}else{						
						var url= ""; 
						enterFlag ="pEnter";
						url = path+"/newCont/enter/newWay/"+ insuranceCom+"/"+ riskcode +"/"+ grpcontno+"/"+enterFlag+".do"
				        + "?recording=N" + "&orderID="+ orderID + "&reportID=" + reportID 
	      			    + "&recordID=" + recordID + "&FPRID=" + FPRID
	      			    + "&prdTypeCode=" + prdTypeCode + "&prdSubTypeCode=" + prdSubTypeCode
						+ "&prdAlternativeNumber=" + prdAlternativeNumber
						+ "&prdClassificationCode=" + prdClassificationCode
						+ "&countryTradableCode=" + countryTradableCode
						+ "&customerIndicator=" + customerIndicator
						+ "&applicationId=" + applicationId
						+ "&quotationId=" + quotationId
						+ "&shoppingCartIndicator=" + shoppingCartIndicator
						+ "&remoteSalesIndicator=" + remoteSalesIndicator; 					        						 
						window.location.href=url; 
					}
				},
				error:function(data){
					closed();
				}
				});
			}
		}
	});
 });
} 






























/*$("#add").click(function() {
	if(grpcontno==""||grpcontno==null){
		alert("投保人客户号不能为空");
		return false;
	}
	if(insuranceCom=="INSH"){
		show();
		$.ajax({
			type : "POST",
			async: false,
			url:path+"/QueryCifController/workingTime.do",// 后台请求URL地址
			dataType : "json",
			success : function(data) {
				if(data.success==false){
					if(data.parm&&data.parm=="warn"){
						layer.confirm( data.msg, {
				  			  btn: ['确认','取消'], //按钮
				  			  title:"系统提示",
				  			  closeBtn:false
				  			}, function(confirmIndex){
				  				layer.close(confirmIndex);
				  				closed();
				  				payment();
				  				}, function(){
				  					closed();
				  				});					
					}else if(data.parm&&data.parm=="refuse"){
						layer.alert(data.msg, {closeBtn: false});
						closed();
						return;	
					 }
				}else{
					closed();
	  				payment();
				}
			},
			error:function(data){
				closed();
			}
			});
	}else{
		closed();
		payment();
	}			
})

function payment(){
	show();
	$(function(){
		$.ajax({
		type : "POST",
		url:path+"/QueryCifController/queryCif.do",// 后台请求URL地址
		data : {"bankName":grpcontno,"YH":riskcode,"BX":insuranceCom,"GoalSequenceNumber":GoalSequenceNumber,"GoalId":GoalId},
		dataType : "json",
		success : function(data) {
			closed();
			if(data.success==false){
				alert(data.msg);
				return;
			}else{
				var parm="";
				$.ajax({
				type : "POST",
				async: false,
				url:path+"/newContEnter/selectpower.do",// 后台请求URL地址
				data : {"grpcontno":grpcontno,"insurancecom":insuranceCom,"riskcode":riskcode},
				dataType : "json",
				success : function(data) {
					closed();
					if(data.success==false){
						alert(data.msg);
						return;
					}else{
						
						var url= "";
                        url = path+"/newCont/enter/"+ insuranceCom +"/"+ riskcode +"/"+ grpcontno+".do" +
	        			"?recording=N" + "&orderID="+ orderID + "&reportID=" + reportID 
	        			+ "&recordID=" + recordID + "&FPRID=" + FPRID
	        			+ "&prdTypeCode=" + prdTypeCode + "&prdSubTypeCode=" + prdSubTypeCode
						+ "&prdAlternativeNumber=" + prdAlternativeNumber
						+ "&prdClassificationCode=" + prdClassificationCode
						+ "&countryTradableCode=" + countryTradableCode
						+ "&customerIndicator=" + customerIndicator
						+ "&applicationId=" + applicationId
						+ "&quotationId=" + quotationId
						+ "&shoppingCartIndicator=" + shoppingCartIndicator
						+ "&remoteSalesIndicator=" + remoteSalesIndicator; 				        						 
						window.location.href=url; 
					}
				},
				error:function(data){
					closed();
				}
				});
			}
		}
	});
 });
}*/
