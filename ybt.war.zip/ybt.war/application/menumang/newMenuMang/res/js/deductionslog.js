function queryParams(params) { 
	
	// 设置查询参数
	var param = {
		limit : params.limit,
		offset : params.offset,
		sortName : params.sort,// 排序列名
		sortOrder : params.order,// 排位命令（desc，asc）
		pageSize : params.pageSize,
		pageNumber : params.pageNumber,
		contno:$("#proposalprtno").val().trim(),
		insurancecom:$("#insurancecom").val().trim(),
		debitstatus:$("#debitstatus").val().trim(),
		authstatus:$("#authstatus").val().trim(),
	};
	return param;
};


var limitedFileType=".pdf";
var uploadParamInsuranceCom = "";
var uploadParamProposalCotno = "";
var paramsDebitAccountNo = "";
var paramsAuthorizationFlag = "";
var showdilog = "";
var uploadData = "";
var paramsTopUpFlag = "";

$(function(){
	//保险公司 
	$.ajax({
		 url:path + '/newContEnter/selectFromLacom.do',  
         type: "POST",
		 success: function(data){
			 for(var i=0;i<data.length;i++){
				var select=document.getElementById("insurancecom");
			    var option=document.createElement("option");
				option.value=data[i].agentcom.replace(/^\s+|\s+$/g, '');;
				option.innerHTML=data[i].agentcom+"-"+data[i].name;
				select.appendChild(option);	
		 	 }
		 }
	});
	
	//点击查询加载bootstrap数据表格
	$("#search").click(function(){
		init();
	});
	
	Dropzone.autoDiscover = false;
	$("#upfilezone").dropzone({
		url:path+"/thirdPartyAuthorizationController/authorizationFileUpload.do",
	    addRemoveLinks: true,
	    method: 'post',
	    timeout:600000,
	    enctype:"multipart/form-data",
	    filesizeBase: 1000,
	    dictRemoveFile: "移除文件",
	    dictCancelUpload: "取消上传",
	    autoProcessQueue:false,
	    acceptedFiles: limitedFileType,
	    dictInvalidFileType: "仅支持.pdf类型文件上传.",
	    thumbnailWidth:100,
	    thumbnailHeight:100,
	    maxThumbnailFilesize:5,
	    maxFiles:2,
	    maxFilesize:40,
	    uploadMultiple:true,
	    parallelUploads:30,
	    previewTemplate: document.querySelector('#preview-template').innerHTML,
	    sendingmultiple: function(file, xhr, formData) {
	    	console.log(formData);
	    	formData.append("filesize", file.size);
	        formData.append("proposalContno", uploadParamProposalCotno);
	        formData.append("insuranceCom", uploadParamInsuranceCom);
	        formData.append("debitAccountNo", paramsDebitAccountNo);
	        formData.append("authorizationFlag", paramsAuthorizationFlag);
	        formData.append("topUpFlag", paramsTopUpFlag);
	    },
	    init: function() {
	        var submitButton = document.querySelector("#upFiles");
	        var closeButt = document.querySelector("#closeButt"); // 关闭按钮 
	        var xClsBtn = document.querySelector("#xClsBtn"); // x 关闭模态框
	        var upstatus = true;
	        dropzoneObj = this;
	        
	        closeButt.addEventListener("click", function() {
	        	console.log("modal关闭按钮");

	        	var files = dropzoneObj.files;
	        	var _ref;
	        	for(var i=0; i<files.length; i++){
	        		(_ref = files[i].previewElement) != null ? _ref.parentNode.removeChild(files[i].previewElement) : void 0;
	        	}
	        	files.length=0;
	        	$("#upFiles").removeAttr("disabled");
	        	$("#dataTable").bootstrapTable('refresh'); 
	        });
	        
	        xClsBtn.addEventListener("click", function() {
	        	console.log("modal x 符号");

	        	var files = dropzoneObj.files;
	        	var _ref;
	        	for(var i=0; i<files.length; i++){
	        		(_ref = files[i].previewElement) != null ? _ref.parentNode.removeChild(files[i].previewElement) : void 0;
	        	}
	        	files.length=0;
	        	$("#upFiles").removeAttr("disabled");
	        	$("#dataTable").bootstrapTable('refresh'); 
	        });
	        
	        
	    	submitButton.addEventListener("click", function() {
	    		
		    	if(!dropzoneObj.files.length > 0){
		    		alert("请选择文件");
		    		return;
		    	}
				var list = new Array();
				for(var i=0; i<dropzoneObj.files.length; i++){
					list.push(dropzoneObj.files[i].name);
					console.log(dropzoneObj.files[i].name);
				}
				
				if(dropzoneObj.files !=null && dropzoneObj.files != ""){
	        			showdilog= layer.load(0, {
	        				shade: [0.1,'#fff'] //0.1透明度的白色背景
	        		   });
	        	}
				dropzoneObj.processQueue(); 
				
			});
	    	
	    	this.on("canceled", function(file) {
	    		var _ref;
	    		layer.close(showdilog);
	    		dropzoneObj.reset();
	    		this.files.length=0;
	    	    return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
			});
	    	
	    	this.on("addedfile",function(file){
	    		console.info("file.type : "  + file.type );
	    		if(file.type != "application/pdf" || dropzoneObj.files.length > 1){
	    			upstatus = false;
	    		}else{
	    			upstatus = true;
	    		};
	    		
		    	!upstatus?$("#upFiles").attr("disabled",true):$("#upFiles").removeAttr("disabled");
		    	
	    	});
	    	
	    	this.on("removedfile", function(file) {
	    			var _ref;
	    			//仅移除单个文件
	    			(_ref = file.previewElement) != null ? _ref.parentNode!=null?_ref.parentNode.removeChild(file.previewElement):void 0 : void 0;
	        		
	    			var upfiles = this.files;
	    	    	var len = 0;
	    	    	var check = 0;
	    	    	for(var j = 0,len=upfiles.length; j < len; j++) {
	    	    		if(upfiles[j].accepted)check++;
	    	    	}
	    	    	
	    	    	if(len==check){
	    	    		upstatus = true;
	    	    	}else{
	    	    		upstatus = false;
	    	    	};
	    	    	
	    	    	!upstatus?$("#upFiles").attr("disabled",true):$("#upFiles").removeAttr("disabled");

			}); 
	    	
	    	this.on("successmultiple", function(file, response, e){
	    		console.log("File upload return type ===" + typeof(response));
	    		if(typeof(response) == "string"){
	    			response = JSON.parse(response);
	    		}
	    		layer.close(showdilog);
				
	    		var reg=/ /g;
				var _ref;
				var dropzoneObj =this;
				//上传成功，移除dropZone内所有文件
				for(var i=0; i<this.files.length; i++){
	        		(_ref = this.files[i].previewElement) != null ? _ref.parentNode.removeChild(this.files[i].previewElement) : void 0;
	        	}
				
				uploadData=response.success?response:"";
				this.files.length=0;
				
	            var resultMsg = response.msg;
	            console.log("++++"+response.msg+"******");
	            
	            if(response.success){
	            	
	            	 layer.close(showdilog);
	            	 $("#closeButt").click();
	            	
	            	if(paramsTopUpFlag != '' && "TP" != paramsTopUpFlag 
	            			&& (uploadParamInsuranceCom == 'MELI' || uploadParamInsuranceCom == 'ANZL')){
	            		$.ajax({
		   	   	             type: "post",
		   	   	             url: path + "/thirdPartyAuthorizationController/sendAuthNotice.do", 
		   	   	             data:{"proposalContno":uploadParamProposalCotno, "insuranceCom":uploadParamInsuranceCom},
		   	   	             dataType: 'JSON',
		   	   	             success: function (data) {
		   	   	                console.log(data.msg);
		   	   	             },
		   	   	             error: function () {
		   	   	                 console.log("三方授权变更通知发送异常");
		   	   	             }          
	   	   	         	});
	            	}
	            	
	            	alert(resultMsg);
	                $("#dataTable").bootstrapTable('refresh'); 
	            	
	            }else{
	            	layer.close(showdilog);
	            	$("#closeButt").click();
	            	if(resultMsg == 'undefined' || resultMsg == undefined){
		                alert("Time out,please login again!");
		            }else{
		                alert(resultMsg);
		            }
	            	$("#dataTable").bootstrapTable('refresh');
	            	
	            }
	            
			});
	    	this.on("completemultiple",function(){
	    		try {
	    			console.log("completemultiple");
	    			layer.close(showdilog);
				} catch (e) {
					console.log("上传三方授权文件异常");
				}
	   		 
	   	    }); 
	    	this.on("maxfilesreached",function(){
	    		alert("文件达到最大数量,请确认上传的文件.");
	    	});    	  	
	  }
	    
	});
	
	
});


function init(){
	
	var staffidType="";
	//先查询一下是不是sale_manager
	 $.ajax({
         type: "post",
         url: path+"/tracertController/getstaffidtype.do", 
         data:{},
         dataType: 'JSON',
         success: function (data) {
             if (data == true) {
            	 staffidType='Y'; 
             }else{
            	 staffidType='N'; 
             }
         },
         error: function () {
             alert('查询员工是否是sale_manager失败！'); 
         },          
     });
	
	
	$("#dataTable").bootstrapTable('destroy');
    $("#dataTable").bootstrapTable({
   	 url: path+"/tracertController/selectLcnotconclusion.do",  //请求后台的URL（*）  
   	 dataType : "json",
   	 striped: true,
   	 pagination: true,
   	 paginationLoop:false,
   	 queryParams: queryParams,
   	columns : [{
		field : "contno",
		title : "投保单号/保全号",
		align : "center",
		sortable: true
	},{
		field : "insurancecom",
		title : "保险公司",
		align : "center"
		
	},
	{
		field : "lccontno",
		title : "保单号",
		align : "center"
		
	},
		
	{
		field : "debitstatus",
		title : "扣款状态",
		align : "center",
		formatter:function(value,row,index){
			  if(value=="Y"){
				  return "扣款成功";
			  }else if(value=="N"){
				  return "待扣款";
			  }else if(value=="C"){
				  return "取消投保";
			  }else if(value=="S"){
				  return "扣款成功";
			  }
		}
	},{
		field : "uploadflag",
		title : "上传状态",
		align : "center",
		editable: {type: 'text',
			validate: function (value) {	
				var data = $("#dataTable").bootstrapTable('getData');
                index = $(this).parents('tr').data('index');
                var rowval = data[index];
                console.log(rowval); 
                if(staffidType=='Y'){
                	return '无权限修改上传状态！';
                }               
                if(rowval.debitstatus=='Y'||rowval.debitstatus=='S'){
                	return '此单已扣款，不能修改！';
                }
        		if ($.trim(value) == '') {
        			return '上传状态不能为空!';  
        		} 
        		if ($.trim(value) != 'Y'&&$.trim(value) != 'U'&&$.trim(value) != 'F') {
        			return "请填写正确的上传标记，上传标记只能为U,F,Y 注：U为未成功上传到YBT系统，F为未成功上传到保险公司，Y为上传成功"; 
        		}         		
        }},
		formatter:function(value,row,index){
			  if(value=="U"){
				  return "未成功上传到YBT系统";  
			  }else if(value=="F"){
				  return "未成功上传到保险公司";
			  }else if(value=="Y"){
				  return "上传成功";
			  }
		}   
	},{
		field : "conclusion",
		title : "核保状态",
		align : "center",
		formatter:function(value,row,index){					
				if(row.insurancecom=="AXA"){
					if(value == "0"){
						return "退保";
					} else if(value == "1"){
						return "待核保";
					}else if(value == "2"){
						return "待报价确认";
					}else if(value == "3"){
						return "待出单";
					}else if(value == "4"){
						return "拒保";
					}else if(value == "5"){
						return "失败";
					}else if(value == "6"){
						return "核保中";
					}else if(value == "7"){
						return "核保通过";
					}else if(value == "8"){
						return "询价录入";
					}else if(value == "9"){
						return "寻单中";
					}else if(value == "10"){
						return "已出单";
					}else if(value == "11"){
						return "待支付";
					}else if(value == "12"){
						return "已支付";
					}else if(value == "13"){
						return "出单待报价确认";
					}else if(value == "14"){
						return "二次核保中";
					}else if(value == "15"){
						return "批改录入";
					}
				}else if((row.appflag =="12"||row.appflag =="02")&&row.topupFlag!="TP"){
					return "核保通过";
				}else if(value=="00"){
					return "待核保";
				}else if(value=="01"||value=="10"){
					return "核保通过";
				}else if(value=="02"){
					return "取消投保";
				}else if(value=="03"){
					return "拒保";
				}else if(value=="04"){
					return "投保计划/核保结论更新中";
				}else if(value=="L1"){
					return "复核通过";
				}else if(value=="L2"){
					return "终止";
				}else if(value=="L3"){
					return "追加已生效";
				}else if(value=="L4"){
					return "追加已生效";
				}else if(value=="L5"){
					return "追加已生效";
				}else if(value=="L6"){
					return "扣费失败逾期终止";
				}else if(value=="L6"){
					return "撤销"; 
				}						
		}
	},{
		field : "prem",
		title : "总保费",
		align : "center"
	},{
		field : "conclusiondate",
		title : "扣款起期",
		align : "center",
		editable : {
			type: 'date',
			clear: false,
			title: '请选择日期:',
			validate: function (value) {	
				var data = $("#dataTable").bootstrapTable('getData');
                index = $(this).parents('tr').data('index');
                var rowval = data[index];                
                if(rowval.debitstatus=='Y'||rowval.debitstatus=='S'){
                	return '此单已扣款，不能修改！';       		
        }},
			
		},
		
	},{
		field : "makedate",
		align : "center",
		title : "创建日期"
	},{
		field : "managecom",
		title : "网点代码",
		align : "center"
	},{
		field : "riskcode",
		title : "险种代码",
		align : "center"
	},{
		field : "debitdate",
		title : "扣款成功日期",
		align : "center"
	},{
		field : "description",
		title : "扣款失败原因",
		align : "center"
	},{
		field : "operator",
		title : "StaffID",
		align : "center"
	},
	{
		field : "confirmflag",
		title : "客户扣款授权标记",
		align : "center",
		visible: false
	},
	{
		field : "appflag",
		title : "保单状态",
		align : "center",
		visible: false
	},
	{
		field : "topupFlag",
		title : "交易类型",
		align : "center",
		formatter:function(value,row,index){
			  if(value=="TP"){
				  return "投连追加";
			  }else if(value=="NOTP"){
				  return "新单";
			  }
		}
	},
	{
		field : "commonchannel",
		title : "渠道",
		align : "center",
		formatter:function(value,row,index){
			  if(value=="BH"||row.topupFlag=="TP"){
				  return "分行下单模式";
			  }else if(value=="SC"){
				  return "购物车模式";
			  }else if(value=="RS"){
				  return "远程购物车模式";
			  }else if(value=="DG"){
				  return "手机银行下单模式";
			  }
		}
		
	},
	{
		field : "enterWay",
		title : "保单录入方式",
		align : "center",
		visible: true
	},
	{
		field : "esignFlag",
		title : "签名",
		align : "center",
		formatter:function(value,row,index){
			  if(value=="E"){
				  return "电子签名";
			  }else if(value=="P"){
				  return "纸质签名";
			  }else if(value=="S"){
				  return "电子签名";
			  }
		}
		
	},	
	{
		field : "custType",
		title : "客户类型",
		align : "center"		
	},
	{
		field : "debitAuthFlag",
		title : "扣款授权",
		align : "center",
		editable: {type: 'text',
			validate: function (value) {	
				var data = $("#dataTable").bootstrapTable('getData');
                index = $(this).parents('tr').data('index');
                var rowval = data[index];
                console.log(rowval); 
                if(rowval.insurancecom=="AXA"){
                	return '此客户购买的产品为非人寿产品，不需进行扣款授权';
                }
                if(rowval.debitAuthFlag=='NA'){
                	return 'RCC客户，无需授权';
                }               
                if(rowval.debitstatus=='Y'||rowval.debitstatus=='S'){
                	return '此单已扣款，不能修改！';
                }
        		if ($.trim(value) == '') {
        			return '扣款授权状态不能为空!'; 
        		} 
        		if(rowval.topupFlag=="TP"){
        			if(rowval.conclusion!="L1"){
        				return '此投保交易还在核保中，不可进行扣款授权';
        			}
        			
        		}else{
    			if(rowval.appflag!='12'&&rowval.appflag!='02'){
        			if(rowval.conclusion=="00"&&rowval.debitstatus=='N'){
            			return '此投保交易还在核保中，不可进行扣款授权';
            		}
        		} 	
        		}
        		      		
        		if(rowval.confirmflag=="N"&&(rowval.commonchannel=="RS"||rowval.commonchannel=="SC")){
        			return '此投保交易为购物车模式，客户尚未确认扣款，不可进行扣款授权';
        		}
        		if(!compareDate(rowval.conclusiondate,rowval.appflag)){
        			return ('此投保交易的扣款起始日为'+rowval.conclusiondate+'， 请在扣款起始日进行确认并授权');
        		}
        		if ($.trim(value) != 'Y'&&$.trim(value) != 'N') {
        			return "请填写正确的扣款授权标记，授权标记只能为Y/N 注：Y为NORCC客户扣款已授权，N为NORCC客户扣款未授权";  
        		}         		
        }},
	},
	{
		field : "staffAuth",
		title : "授权人员",
		align : "center"		
	},
	{
		field : "dateAuth",
		title : "授权时间",
		align : "center"		
	},{
		field : "authorizationFlag",
		title : "三方授权",
		align : "center",
		editable: {type: 'text',
					validate: function (value) {	
						var data = $("#dataTable").bootstrapTable('getData');
		                index = $(this).parents('tr').data('index');
		                var rowval = data[index];
		                if(rowval.insurancecom=="AXA"){
		                	return '此客户购买的产品非人寿产品，无需进行三方授权操作';
		                }
		                if(rowval.topupFlag=="TP"){
		                	return '此单为投连追加，无需进行三方授权操作';
		                }
		        		if ($.trim(value) != 'Y'&&$.trim(value) != 'N') {
		        			return "请填写正确的三方授权标记，授权标记只能为Y/N 注：Y为同意授权，N为取消授权";  
		        		}
		        		if(rowval.debitstatus=='Y'||rowval.debitstatus=='S'){
		                	return '此单已扣款，不能修改！';
		                }
					}
				}
	
	},{
		field : "authorizationNo",
		title : "三方授权号",
		align : "center",
		visible: true
	},{
		field : "authorizationTime",
		title : "三方授权日期",
		align : "center",
		visible: true
	}],
	 showExport: true,
	 exportDataType:'all',
	 exportTypes : [ 'excel'],
		//表格导出数据设置
		exportOptions : {
			//忽略列ignoreColumn : [ 0, 0 ],
			fileName : "扣款日志"+new Date().toLocaleString(),
			worksheetName : "扣款日志",
			tableName : "扣款日志"
		},
	 sidePagination : "server", //表示服务端请求
	 sortName:"contno",
	 sortOrder:"desc",
   	 pageNumber:1,  //初始化加载第一页，默认第一页  
     pageSize: 10,  //每页的记录行数（*）  
     sidePagination : "server",
     pageList: [5,10,20,50], //可供选择的每页的行数（*）
     showColumns : false, // 是否显示所有的列
	 showRefresh : false, // 是否显示刷新按钮
	 uniqueId :"contno",// 每一行的唯一标识，一般为主键列，
	/* onLoadSuccess: function(data){
		 console.log(data);
		 for(var i=0; i<data.rows.length; i++){
			 if(data.rows[i].topupFlag == 'TP'){
				 $('#dataTable tr[data-index='+i +'] a[data-name="authorizationFlag"]').editable('toggleDisabled', false);
			 }
		 }
	 },*/
	 onEditableSave: function (field, row,oldValue, $el) {
		 if(field == 'authorizationFlag'){
//			 console.log(row.contno + ' ' + row.debitAccountNo + ' ' + row.authorizationFlag);
			 
			 if(!confirm("请确认是否进行授权变更操作?")){
				 $("#dataTable").bootstrapTable('refresh');
				  return false;
			 }
			 
			 if(row.insurancecom == 'AXA'){
				 console.log('AXA无需进行三方授权');
				 $("#dataTable").bootstrapTable('refresh');
				 return false;
			 }
			 
			 if(row.debitAccountNo == null || row.debitAccountNo == '' || row.debitAccountNo == undefined){
				 alert('变更授权失败，数据有误');
				 $("#dataTable").bootstrapTable('refresh');
				 return false;
			 }
			 
			 
			 uploadParamInsuranceCom = row.insurancecom;
			 uploadParamProposalCotno = row.contno;
			 paramsDebitAccountNo = row.debitAccountNo;
			 paramsAuthorizationFlag = row.authorizationFlag;
			 paramsTopUpFlag = row.topupFlag;
			 
			 
			 
			 
			 $.ajax({
   	             type: "post",
   	             url: path + "/thirdPartyAuthorizationController/getThirdFileByFlag.do", 
   	             data:{"authorizationFlag":row.authorizationFlag},
   	             dataType: 'JSON',
   	             success: function (data) {
   	            	 if(data.success){
   	            		 var pdfName =  row.authorizationFlag == 'Y' ? '代收保费服务协议':'代收保费服务协议内容终止变更申请书' ;
   	            		 var downloadUrl = path + "/application/pipline/insurance/piplineinfo/jsp/download.jsp?path="+data.parm+"&a="+"sdf";
   	            		 var downloadUrlStr = '<a href='+ downloadUrl +'>文件下载</a>';
   	            		 //弹出下载链接
   	            		 parent.layer.open({  
   	     				    type: 1,  
//   	     				    shade: 0.3, 
//   	     				    anim: 2,
   	     				    btn: ['上传','取消'],
   	     				    yes:function(pindex,layero){
   	     				    	parent.layer.close(pindex);
   	     				    	//确认文件已下载，开始上传并变更授权
   	     				    	$("#myModal1").modal('show');
   	     				    	
   	     				    },
   	     				    btn2: function(pindex, layero){
//   	     				    	layer.close(index);
   	     				    	$("#dataTable").bootstrapTable('refresh');
   	     				        return false;
   	     				    },
   	     				    offset: '200px',//['150px','500px'],
   	     				    resize : true,
   	     				    scrollbar: false,
   	     				    title: "请点击<b style='color:red'>文件下载</b>下载文件，填写完成后点击<b style='color:red'>上传</b>按钮进行上传",
   	     				    area:  ['600px','170px'], //445px
   	     				    content: "<div  align='center' style='background-color:#fff;font-size:14px'><table border='1' width='98%' bgcolor='#e9faff' cellpadding='2'>"+
   	     					    "<tbody align='center' id='tpAuthNotice' style='font-size:14px'>"+
   	     					    "<tr height='35px'>"+
   	     					    "<td width='20%' ><b>文件名：</b></td>"+
   	     					    "<td width='80%' ><b>"+pdfName+"</b></td>"+
   	     					    "</tr>"+
   	     					    "<tr height='30px'>"+
   	     					    "<td width='20%'>下载链接：</td>"+
   	     					    "<td width='80%'>"+downloadUrlStr+"</td>"+
   	     					    "</tr>"+
   	     					    "</tbody>"+
   	     					    "</table></div>",  
   	     				    success: function(pindex, layero) {
//   	     				        layer.iframeAuto(index);

   	     				    },
   	     				    cancel: function(pindex, layero){
   	     				    	$("#dataTable").bootstrapTable('refresh');
   	     				    }
   	     				}); 
   	            		 
   	            	 }else{
   	            		alert(data.msg);
   	            		$("#dataTable").bootstrapTable('refresh');
   	            	 }
   	             },
   	             error: function(){
   	            	 console.log("三方授权变更操作已取消");
   	            	 alert("系统异常");
   	            	 $("#dataTable").bootstrapTable('refresh');
   	             }
			 });
			
		 }else{
			 var des = "";
			 var filedflag="";
			 if(field=="uploadflag"){
				 des ="上传状态"; 
				 filedflag="1";
			 }else if(field=="conclusiondate"){
				 des ="扣款起期";
				 filedflag="2";
			 }else if(field=="debitenddate"){
				 des ="扣款止期";
				 filedflag="3";
			 }else if(field=="debitAuthFlag"){
				 des ="扣款授权";
				 filedflag="4";
			 }
			 if(field=="conclusiondate"){
				 if(row.debitAuthFlag=="Y"){
					 if(!confirm("请注意, 投保人为境外个人, 扣款起始日修改后, 请在扣款日当日再次确认其保费资金来源后进行扣款授权,系统方可进行扣款操作")){
						 $("#dataTable").bootstrapTable('refresh');
						  return false	
					 }
				 }
	if(!confirm("请确定是否将【"+des+"】:"+oldValue+",修改为:"+row[field]+" ?请注意，请留存客户修改扣款起期得指令(e.g.录音电话或文件)后再进行确认！")==true){
					 $("#dataTable").bootstrapTable('refresh');
					  return false		  
				    }
			 }else{
				 
			 if(!confirm("请确定是否将【"+des+"】:"+oldValue+",修改为:"+row[field])==true){
				 $("#dataTable").bootstrapTable('refresh');
				  return false		  
			    }
			 }
			 if(field=="debitAuthFlag"){
				 if(row[field]==oldValue){
					 alter("授权的值没有发生改变，无需操作"); 
					 $("#dataTable").bootstrapTable('refresh');
					 return false;	
				 }
				 if(row[field]=="Y"){
					 var context ="请注意，投保人为境外个人，请先检查并确认1）投保人人民币账户已有足够的资金支付保费 ；2）此保费资金来源非结汇资金且投保人人民币账户近一年交易记录已上传“文件中心”，再授权进行保费扣缴。";
					 if(!confirm(context)){ 
						 $("#dataTable").bootstrapTable('refresh');
						  return false;
					 }
				 }else{
					 if(oldValue=="Y"){
						 var context ="请注意，取消扣款授权后，此保单的扣款将停止，请确认是否修改？";
						 if(!confirm(context)){
							 $("#dataTable").bootstrapTable('refresh');
							  return false;
						 } 
					 }
				 }
						 
			 }
			 $.ajax({
	             type: "post",
	             url: path+"/tracertController/updateLcnotconclusion.do", 
	             data:{"uploadflag":row.uploadflag,"conclusiondate":row.conclusiondate,"debitenddate":row.debitenddate,"contno":row.contno,"filedflag":filedflag,"debitAuthFlag":row.debitAuthFlag,"topupFlag":row.topupFlag},
	             dataType: 'JSON',
	             success: function (data, status) {
	                 if (data.success) {
	                     alert('修改成功'); 
	                     $("#dataTable").bootstrapTable('refresh');
	                 }else{
	                	 alert('修改失败'); 
	                     $("#dataTable").bootstrapTable('refresh'); 
	                 }
	             },
	             error: function () {
	                 alert('修改失败'); 
	             }          
	         });   
		 }
			   
	   }	 
    });
}

function compareDate(conclusiondate,appflag){
	     const format = 'YYYY-MM-DD';
		const moment1 = moment(new Date(),format);
		//当appflag为12线上单时，扣款起期conclusiondate默认T+1日，所以在此处需减一天
//		if(appflag=="12"){
//			conclusiondate= moment(conclusiondate).subtract(1,"days");
//		}
		const moment2 = moment(conclusiondate,format);
		console.log("当天日期大于或等于扣款起期"+ moment1.isSameOrAfter(moment2)); 
		return moment1.isSameOrAfter(moment2) ;// true

	/*var currDate =moment(myDate).format("YYYY-MM-DD");
	var condate = new Date(conclusiondate);
	if(currDate>=condate){
		console.log("当天日期大于或等于扣款起期"); 
		return true;
	}else{
		console.log("当天小于扣款起期"); 
		return false;
	}*/
	
}
	

function checkEditColumn(value,row,index){
	
	if(row.topupFlag == 'TP'){
		$('#dataTable tr[data-index='+ index +'] a[data-name="authorizationFlag"]').editable('toggleDisabled', false);
	}
	
	  return value;
}