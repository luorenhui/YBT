var vueobj=[];

        var vue_config = [
            //{id : "testdivchange", url : path + "/vue/common/test.do",initFunction:pageinit},
            //{id : "notice", url : path + "/vue/common/testnotice.do"}
        ];
        
//        var computeds={ 
//        		testgrpcontno:function (){
//        			if(this.formdata.newContApply ){
//        				if(this.formdata.newContApply.grpcontno ==null){
//        						this.$set(this.formdata.newContApply,"grpcontno", "CNHSBC");	
//        				}else{
//        					var reg = new RegExp("[a-zA-Z]*");
//        					this.$set(this.formdata.newContApply,"grpcontno","CNHSBC"+ this.formdata.newContApply.grpcontno.replace(reg,""));
//        				}
//        				
//        			}
//        			
//        		}
//        	};
        
        /**
         *   值变化钩子
         */
        var afterVueSelect={
        		
        		/**
        		 * 同被保人
        		 */
        		grpcontno:function(form_element){
        			 
        			var topvue = getTopvueObj(this);
        			if(topvue.formdata.newContApply ){
        				if(topvue.formdata.newContApply.grpcontno ==null){
        					topvue.$set(topvue.formdata.newContApply,"grpcontno", "CNHSBC");
        				  
        				}else{
        					var reg = new RegExp("[a-zA-Z]*");
        					
        					topvue.$set(topvue.formdata.newContApply,"grpcontno", "CNHSBC"+ topvue.formdata.newContApply.grpcontno.replace(reg,""));
        				}
        				
        			}
        			
        		}
        };
        var commonCombobox_option={
        		 commonCombobox_insurancecom : {
        		    url : path + '/newContEnter/selectFromLacom.do',
        		    valueField : "agentcom",
        		    // 显示在输入框的
        		    inputText : "name",
        		    // 显示在下拉列表的项，默认空，空则全部显示
        		    textShow : ["name" ],
        		    textShowFormat: function(textShow,linedata){
        	        	return  "测试" +   textShow;
        	        }
        		}
        	,   commonCombobox_riskcode : {

        		    url : path + '/newCont/codeselect/searchrisk/#insurancecom.do',
        		    valueField : "riskcode"
        		    // 显示在输入框的
        		    ,inputText : "riskname"
        		    ,textShow : [ "riskname" ]
        		}

        };

window.actionEvents = {
    //投保单复制
    'click .select': function (e, value, row, index) {

        $.ajax({
            url:path + '/newContApply/anzlCopyCont.do',
            type: "POST",
            async: false,
            data:{"oldproposalcontno":row.proposalcontno},
            success: function(data){
                if(data.success==true){
                    alert("复制成功");
                    
                    if(row.insurancecom!="MELI"){
                    	window.location.href=path+"/newCont/enter/"+ row.insurancecom +"/"+ row.riskcode +"/"+ row.grpcontno+"/"+ row.transno+".do?flag=3";
                    }else{
                    	 window.location.href="partNewContEnter.jsp?flag=4&transno="+data.msg;
                    }
                   
                }else{
                    alert(data.msg);
                }

            }
        });
    }
};


var bootstrapvalid={

    	grpcontno: {
            message: '用户名不能为空',//默认提示信息
            validators: {
                notEmpty: {
                    message: '用户名必填不能为空'
                },
                stringLength: {
                    min: 6,
                    max: 30,
                    message: '用户名长度不能小于6位或超过30位'
                },
                regexp: {
                    regexp: /^[a-zA-Z0-9_\.]+$/,
                    message: '用户名只能由字母、数字、点和下划线组成。'
                },

            }
        },
        insurancecom_combobox: {
        		message: 'insurancecom不能为空',//默认提示信息
        		validators: {
        			notEmpty: {
        				message: 'insurancecom必填不能为空'
        			}

        		}
        }

    	
};

var lanmuid=null;





function pageinit(  ) {
//    initData($("#testdivchange"));

    /****/
//    $("#testdivchange").find('input[checkboxoption]').each(function(i){
//        var obj = $(this);
//        console.log(obj);
//        var checkboxoption = obj.attr("checkboxoption");
//        var index = checkboxoption.indexOf("commonCombobox_");
//
//        try {
//            if(index>=0){
//                ;
//                obj.combobox(commonCombobox_option[checkboxoption]);
//            }else{
//                obj.combobox($.parseJSON(checkboxoption));
//            }
//        } catch (e) {
//            console.log('error init combobox  id:', obj, ', checkboxoption:', checkboxoption);
//        }
//
//
//    });

//    $('.i-checks').iCheck({
//        checkboxClass : 'icheckbox_square-green',
//        radioClass : 'iradio_square-green',
//    });

//    $('#insurancecom').combobox(insurancecom);
//    $('#riskcode').combobox(riskcode);
//    $("#grpcontno").val("CNHSBC706009446");
    
  
}
function afterRowEdit(element, row, index) {
    if (element.attr("id") == "table_keyword") {

        var data = element.bootstrapTable("getData");
        var rows = $('#tablebatch').bootstrapTable("getSelections");

        for (var i = 0; i < rows.length; i++) {
            rows[i].monitorLevel[0].keywords = data;
            $('#tablebatch').bootstrapTable("updateRow", {
                index : rows[i]._row_index,
                row : rows[i]
            });
        }
    }

}

function initTest() {
    initData($("#testdivchange"));
    
    
    
}
vue_config.push({id : "testdivchange", url : "/newCont/common/init/newContApply/PALIPAPER/no_transno",initFunction:pageinit});

var uniqueId = "metentid";
var col = [
           {
               field : 'metentid',
               title : '序号',
               formatter : function(value, row, index) {
                   return index + 1;
               }
           }, {
               field : 'proposalcontno',
               title : '投保单号',
               align : 'center',
               valign : 'middle',
               visible : true,
           }, {
               field : 'forceuwreason',
               title : '投保日期',
               align : 'center',
               valign : 'middle'
           }, {
               field : 'grpcontno',
               title : '投保人客户号',
               align : 'center',
               valign : 'middle'
           },
           {
               field : 'riskcode',
               title : '产品代码',
               align : 'center',
               valign : 'middle',
               visible : true
           },
           {
               field : 'appflag',
               title : '投保单状态',
               align : 'center',
               valign : 'middle'
           },{
               field : 'premiumBudget',
               title : '保费',
               align : 'center',
               valign : 'middle'
           },  {
               title: '操作',
               align: 'center',
               formatter: actionFormatter,
               events: actionEvents
           } ];

$(function() {
    $("#add").click(function(){

        var grpcontno=$("#grpcontno").val();
        var insurancecom=$("#insurancecom").val();
        var riskcode=$("#riskcode").val();
        if(grpcontno==""||grpcontno==null){
            alert("投保人客户号不能为空");
            return false;
        }
        if(insurancecom==""||insurancecom==null){
            alert("保险公司不能为空");
            return false;
        }

        if($("#riskcode").val()==""||$("#riskcode").val()==null){
            alert("保险产品不能为空");
            return false;
        }

        var applydata={
            grpcontno:grpcontno,
            insurancecom:insurancecom,
            riskcode:riskcode,
            parm:"",
            flag:"1",
            transno:""
        };


        var url;
			$.ajax({
			type : "POST",
			url:path+"/customerIDController/selectcustomerID.do",// 后台请求URL地址
			data : {"bankName":grpcontno.trim(),"YH":riskcode,"BX":insurancecom},
			dataType : "json",
			success : function(data) {
				closed();
				if(data.success==false){
					alert(data.msg);
					return;
				}else{
 
					
					
					var parm="";
					$.ajax({
					type : "POST",
					async: false,
					url:path+"/newContEnter/selectpower.do",// 后台请求URL地址
					data : {"grpcontno":grpcontno,"insurancecom":insurancecom,"riskcode":riskcode},
					dataType : "json",
					success : function(data) {
						closed();
						if(data.success==false){
							alert(data.msg);
							return;
						}else{
							
//							alert("成功");
						/*	var url = "partNewContEnter.jsp?grpcontno="+grpcontno+"&tContNo="+tContNo+"&riskCode="+riskcode+"&parm="+parm+"&flag=1";
							//toadd(url);
					       window.location.href=url;*/
							
							if("MELI"==insurancecom){
								 url=path+"/url_toview/to_newCont.do?grpcontno="+grpcontno+"&tContNo="
								 +tContNo+"&riskCode="+riskcode+"&parm="+parm+"&flag=1";
		                           
					        }else{
					        	url = path+"/newCont/enter/"+ insurancecom +"/"+ riskcode +"/"+ grpcontno+".do";
					        	
					        }
							
                            //toadd(url);
                            window.location.href=url;
						}
					},
					error:function(data){
						closed();
					}
					});
				}
			}
			,
			error:function(data){
				closed();
			}
		});

			
       
    });
    
   

    $("#search").click(function () {
    	;  
    	
//    	$("#form123").data('bootstrapValidator').validate()
//    	alert($("#testdivchange").data('bootstrapValidator').validate());
//    	alert($("#testdivchange").data('bootstrapValidator').validateField($("#insurancecom_combobox")));
        $("#cusTable").bootstrapTable('destroy');
        var url_d = "/newContApply/selectPro.do";
        tableInit(url_d, $('#cusTable'), col, uniqueId, queryParams);
    });
   
});

/**
 * 设置表格查询参数
 *
 * @param params
 */
function queryParams(params) {
    // 设置查询参数
    var param = {
        limit: params.limit,
        offset: params.offset,
        grpcontNo :"",
        contNo :"",
        tBRBirth : ""

    };
    return param;
}

function tableInit(url, obj, col, uniqueId, queryParams) {
    obj.bootstrapTable({
        url : path + url, // 请求后台的URL（*）
        dataType : "json",
        method : 'post', // 请求方式（*）
        contentType : "application/x-www-form-urlencoded",
        toolbar : '#toolbar',
        columns : col,
        striped : true, // 是否显示行间隔色
        cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination : true, // 是否显示分页（*）
        queryParamsType : "limit",// undefined/limit
        queryParams : queryParams,// 传递参数（*）
        sidePagination : "server", //
        pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
        search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
        strictSearch : true,// 设置为 true启用 全匹配搜索，否则为模糊搜索
        showColumns : true, // 是否显示所有的列
        showRefresh : true, // 是否显示刷新按钮
        minimumCountColumns : 2, // 最少允许的列数
        clickToSelect : true, // 是否启用点击选中行
        // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
        // uniqueId: "ID", // 每一行的唯一标识，一般为主键列
        uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
        showToggle : true, // 是否显示详细视图和列表视图的切换按钮
        cardView : false, // 是否显示详细视图
        detailView : false
    });
};

function actionFormatter(value, row, index) {
    return [
        '<button class="btn btn-red select">复制</button>'
    ].join('');
}




