var lanmuid=null;
 
var statement={
    valueField : "code",
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ],
    data:[{
        code:'',
        codename:'请选择投保人声明'
    },{
        code:'1',
        codename:'1-仅为中国税收居民'
    },{
        code:'2',
        codename:'2-仅为非居民'
    },{
        code:'3',
        codename:'3-既是中国税收居民又是其他国家（地区）税收居民'
    }]
}

function pageinit(  ) {
    initData($("#tracertdivchange"));

    /****/
    $("#tracertdivchange").find('input[checkboxoption]').each(function(i){
        var obj = $(this);
        console.log(obj);
        var checkboxoption = obj.attr("checkboxoption");
        var index = checkboxoption.indexOf("commonCombobox_");

        try {
            if(index>=0){
                ;
                obj.combobox(commonCombobox_option[checkboxoption]);
            }else{
                obj.combobox($.parseJSON(checkboxoption));
            }
        } catch (e) {
            console.log('error init combobox  id:', obj, ', checkboxoption:', checkboxoption);
        }


    });

    $('.i-checks').iCheck({
        checkboxClass : 'icheckbox_square-green',
        radioClass : 'iradio_square-green',
    });

    $("#statement").combobox(statement);


}
function afterRowEdit(element, row, index) {
    if (element.attr("id") == "table_keyword") {

        var data = element.bootstrapTable("getData");
        var rows = $('#tablebatch').bootstrapTable("getSelections");

        for (var i = 0; i < rows.length; i++) {
            rows[i].monitorLevel[0].keywords = data;
            $('#tablebatch').bootstrapTable("updateRow", {
                index : rows[i]._row_index,
                row : rows[i]
            });
        }
    }

}

function initTest() {
    initData($("#tracertdivchange"));
}
vue_config.push({id : "tracertdivchange", url : path + "/trancertController/selNewCont/"+data.insurancecom+"/trancert.do?lccontParm="+encodeURI(JSON.stringify(data)),initFunction:pageinit});

function addTrancert(){
    $.ajax({
        type : "POST",
        url  :  path + "/trancertController/saveTrancertData/"+data.insurancecom+".do",
        data : {
            "lccontFormdata" :  JSON.stringify(vueobj["lccontdivchange"].formdata),
            "trancertFormdata" :  JSON.stringify(vueobj["tracertdivchange"].formdata),
        },
        error : function(request) {
            alert("Connection error");
        },
        success : function(data) {
            alert(data.msg);
            if($("#proposalcontno").val()==null||$("#proposalcontno").val()==""){
                vueobj["lccontdivchange"].$set(vueobj["lccontdivchange"].formdata.lccont, "proposalcontno",data.parm);
            }

        }
    });
}