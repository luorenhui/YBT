/**
 * 
 * @param noticeid
 * @param type
 *            1主被保險人 2附屬
 */
function hiddenNoticeELements(topvue, noticeid, type,noticeinfoType) {

	if(!noticeinfoType){
		noticeinfoType="i";
	}
	
	var insuquestion ="insuquestion";
	if(noticeinfoType=="q"){
		
		insuquestion="noticeInfo";
	}
	
	if(noticeinfoType=="a"){
		
		insuquestion="appntquestion";
	}
	
	var questionID = noticeid + noticeinfoType + type;
	try {
		// topvue.form_elementsBYID.commonFormNotice[noticeid].insuquestion[questionID].elementstatus="02";
		if (topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID].elementstatus == "02") {
			console.info(noticeid + " 该条告知配置不显示不作处理");

		} else {
				
				topvue.$set( topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID],
						"elementstatus", "04");
				
			
		}

	} catch (e) {
		console.info(" error : 告知：" + noticeid + " 所属子元素节点ID配置未找到被保人问题，"
				+ " 请检查告知formelement 的告知配置项 请按照约定进行ID设置 " + noticeid + noticeinfoType
				+ type + " exception:" + e);
	}

	// topvue

}

function showNoticeELements(topvue, noticeid, type ,noticeinfoType) {
	if(!noticeinfoType){
		noticeinfoType="i";
	}
	var questionID = noticeid + noticeinfoType + type;
	var insuquestion ="insuquestion";
	if(noticeinfoType=="q"){
		
		insuquestion="noticeInfo";
	}
	try {
		if (topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID].elementstatus == "02") {
			console.info(noticeid + " 该条告知配置不显示不作处理");

		} else {
			
				topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID],
						"elementstatus", "01");
			
		}
		// topvue.form_elementsBYID.commonFormNotice[noticeid].insuquestion[questionID].elementstatus="02";
	
	} catch (e) {
		console.info(" error : 告知：" + noticeid + " 所属子元素节点ID配置未找到被保人问题，"
				+ " 请检查告知formelement 的告知配置项 请按照约定进行ID设置 " + noticeid + noticeinfoType
				+ type + " exception:" + e);
	}

	// topvue

}


function showFather(topvue,noticeid){
	if (topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
//		topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus  = "04";
		topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid],
				"elementstatus", "01");
	}
	
}

function hiddenFather(topvue,noticeid){
	
	if ( topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
		topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid],
				"elementstatus", "04");
	}
}
//隐藏小于18岁告知
function hiddenAllinfant(topvue,noticeid){
    hiddenFather(topvue, "notice13");
    hiddenNoticeELements(topvue, "notice13", "1", "i");

}

//显示小于18岁告知
function showAllinfant(topvue){	
    showFather(topvue,"notice13");
	showNoticeELements(topvue, "notice13", "1", "i");
}
/**
 * 控制小于18岁问题 是否显示
 * @param topvue
 */
function checkinfantNotice(topvue) {
	var formdata = topvue.formdata;
	if (formdata['lcinsured'] 
			&& formdata['lcinsured'].lcinsuredage
			&& formdata['lcinsured'].lcinsuredage <= 18) {
		showAllinfant(topvue);
	}else{
		hiddenAllinfant(topvue);
		
	}
}


/***
 * 女性被保人告知显示
 * @param topvue
 * @returns {Boolean}
 */
function showELementSByInsu(topvue) {
    try{

        var formdata = topvue.formdata;
        // var lcappntsex = formdata['lcappnt'].appntsex;
        var lcinsuredsex = formdata['lcinsured'].lcinsuredsex;
        if(lcinsuredsex=='1'){
            showFather(topvue,"notice12");
            showNoticeELements(topvue, "notice12", "1", "q");
        }
        else{
        	hiddenFather(topvue,"notice12");
            hiddenNoticeELements(topvue, "notice12", "1", "q");
        }

    } catch (e) {
        // TODO: handle exception
    }

    return true;
}


afterloadNewElements.lcbnf_tabinfo = function(url, form_element) {
	
	try {
		var topvue = getTopvueObj(this);
		showBelongInsu(topvue);
	} catch (e) {
		
		console.info("afterloadNewElements.lcbnf_tabinfo : " + e);
	}
	
};

afterloadNewElements.subriskcode_tabinfo = function(url, form_element) {
	
	try {
		var topvue = getTopvueObj(this);
		showBelongInsu(topvue);
	} catch (e) {
		console.info("afterloadNewElements.subriskcode_tabinfo : " + e);
	}
	
};


// 告知加载后的处理
afterloadNewElements.notice_tabinfo = function(url, form_element) {
	console.info( " 告知加载后的处理");
	var topvue = getTopvueObj(this);
	// checksimpleNotice(topvue);//之前处理未成年人的
	checkinfantNotice(topvue);//对于小于18岁的处理
	showELementSByInsu(topvue);//这边处理女性告知
	
	var showElement= 0 ;
	for ( var index in topvue.form_elements.commonFormNotice) {
		if(topvue.form_elements.commonFormNotice[index].elementstatus=='01'){
			showElement++;
		}	
	}
	var formdata = topvue.formdata;
//	alert(formdata['noticeDetaileInsu'].noticeinfo2);
	var lcinsuredsex = formdata['lcinsured'].lcinsuredsex;
	if(lcinsuredsex!='1')
		this.$set(this.formdata.noticeinfos[11],"insuredyesorno", "");
	if(showElement==0){
		
		$("#notice_submit").trigger("click");
	}else{
		$("#tab_notice_tabinfo").removeClass("disabled");
		$("#notice_tabinfo").removeClass("disabled");
		
	}

};

var afterInitTab={
		 
};
// 告知加载后的处理
afterInitTab.notice_tabinfo= function() {
    	if($("#notice_tabinfoform  .col-sm-12:eq(0)").is(":visible")){
    		//更改告知样式
    		$("textarea").css({"height":"200px","width":"500px"});
    		document.getElementById("notice6q25_combobox").style.width = "210px";
    		document.getElementById("notice7q26_combobox").style.width = "210px";
//    		$("#notice6q25_combobox").attr("value","工薪");
    		var elements=$("span:contains(</br>)");
    		var length=elements.length;
    		for(var i=0;i<length;i++){
    			$(elements[i]).html($(elements[i]).text());
    		}
    	}	
}


//告知提交前 清空所有不显示的数据
beforesubmitvueform.notice_tabinfoform = function() {
//	v-bind:elementstatus ="form_element.elementstatus"
	$("#notice_tabinfoform").find("[elementstatus][elementstatus!='01']").val('').trigger("click");
//	if($("#notice_tabinfoform").find("[elementstatus][elementstatus!='01']").length==0){
//		
//		
////		this.$set(this.formdata.newContApply,"currentSIDIndex",7);
//		
//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit_tabinfo");
////		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
////		$("#tab_notice_tabinfo").removeClass("active");
////		$("#tab_notice_tabinfo").addClass("disabled");
////		$("#notice_tabinfo").removeClass("active");
////		$("#notice_tabinfo").addClass("disabled");
////		$("#tab_contsubmit_tabinfo").addClass("active");
////		$("#contsubmit_tabinfo").addClass("active");
//	}else{
		 
		
//	}
//if($("#notice_tabinfoform").find("[elementstatus][elementstatus='01']").length==0){
//		
//		
//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit");
//		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
// con
//	}else{
//		 
//		
//	}
	return true; 
};

aftersubmitvueform.notice_tabinfoform = function() {
	 
	if($("#notice_tabinfoform").find("[name^='noticeinfo'][elementstatus][elementstatus='01']").length==0){
		
		this.$set(this.formdata.newContApply,"currentSID", "contsubmit");
		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
		this.$set(this.formdata.newContApply,"contsubmit", false);
		$('#tab_contsubmit_tabinfo').trigger("click");
		this.$set(this.form_elementsBYID.PALIinsuranceContInput['notice_tabinfo'],
				"elementstatus", "04");
		
		
	}else{
		 
		
	}
	try {
		var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
		buttonControl(proposalcontno);
	} catch (e) {

	}
	return true; 
};

/*  	$("#notice_tabinfoform").click(function(){
		alert("b");
	});  */	
/* 	alert($("#notice_tabinfoform  .col-sm-12:eq(18)").length); */
    
	var mouse=0;
    //方便测试用
    $(document).keydown(function (event) {
    	//F9
        if (event.keyCode == 120) {  
        	console.info(mouse.target);
        }
	});
    $(document).mousemove(function (e) {
    	mouse=e;
	});
    commonCombobox_option.commonCombobox_incomesource ={
    		url :  path + '/newCont/codeselect/common/incomeway.do',
    		valueField : "code",
    		// 显示在输入框的
    		inputText : "codename",
    		textShow : [ "codename" ]
    }