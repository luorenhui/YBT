
/*
afterVueSelect.idtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcappnt.idtype;
	if (idtype != "X"){ 
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"renewCount", null);
		$("#appntrenewCount").attr("disabled",true);
	}else {
		$("#appntrenewCount").attr("disabled",false);
	}
	if (idtype != "I"){
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"startingDate", null);
		$("#appntstartingDate").attr("disabled",true);
	}else {
		$("#appntstartingDate").attr("disabled",false);
	}
};*/
/**
 * 投保人 通讯地址同 居住地址
 */
afterVueSelect.postaddressflaginsh = function(form_element) {
	
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (obj.is("[type='checkbox']:checked")) {

		for ( var key in topvue.form_elements.lcappnt) {
			
			if (topvue.form_elements.lcappnt[key].name == 'zactladdrcountry') {
				bindSameElement.call(this, this.formdata, "addresscountry",
						this.formdata, "zactladdrcountry",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postprovince') {
				bindSameElement.call(this, this.formdata, "homeprovince",
						this.formdata, "postprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postcity') {
				bindSameElement.call(this, this.formdata, "homecity",
						this.formdata, "postcity",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'postdistrict') {
				bindSameElement.call(this, this.formdata, "homedistrict",
						this.formdata, "postdistrict",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'postaladdress') {
				bindSameElement.call(this, this.formdata, "homeaddress",
						this.formdata, "postaladdress",
						topvue.form_elements.lcappnt[key]);

			}
			

		}
	} else {
		for ( var key in topvue.form_elements.lcappnt) {
			
			if (topvue.form_elements.lcappnt[key].name == 'zactladdrcountry') {
				unbindSameElement.call(this, "addresscountry",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postprovince') {
				unbindSameElement.call(this, "homeprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postcity') {
				unbindSameElement.call(this, "homecity",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postdistrict') {
				unbindSameElement.call(this, "homedistrict",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postaladdress') {
				unbindSameElement.call(this, "homeaddress",
						topvue.form_elements.lcappnt[key]);
			}
			

		}
		

	}

};

commonCombobox_option.commonCombobox_banksccflag = {
		"data" : [ {
			"value" : "N",
			"text" : "否"					
		}, {
			"value" : "Y",
			"text" : "是"
		} ]
	};

commonCombobox_option.commonCombobox_bankcustomertype = {

		url : path + '/newCont/codeselect/common/bankcustomertype',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "codename" ,
		textShow : [ "codename" ]
		
	};


/*//证件长期有效
afterVueSelect.appntislongitemmeli = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
		+ form_element.name + "']");
	if (obj.is("[type='checkbox']:checked")){
		topvue.$set(topvue.formdata.lcappnt,"appntenddate","9999-12-31");
		$("#lcappnt_tabinfoform").data('bootstrapValidator').resetField($("#appntenddate"));
		$("#appntenddate").attr("disabled",true);
	}else {
		$("#appntenddate").attr("disabled",false);
	}
}*/
/**
 * 投保人 永久地址同 居住地址
 */
afterVueSelect.permanentflag = function(form_element) {
	
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (obj.is("[type='checkbox']:checked")) {

		for ( var key in topvue.form_elements.lcappnt) {
			
			if (topvue.form_elements.lcappnt[key].name == 'permanentcountry') {
				bindSameElement.call(this, this.formdata, "addresscountry",
						this.formdata, "permanentcountry",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'permanentprovince') {
				bindSameElement.call(this, this.formdata, "homeprovince",
						this.formdata, "permanentprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'permanentcity') {
				bindSameElement.call(this, this.formdata, "homecity",
						this.formdata, "permanentcity",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'permanentarea') {
				bindSameElement.call(this, this.formdata, "homedistrict",
						this.formdata, "permanentarea",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'permanentdetails') {
				bindSameElement.call(this, this.formdata, "homeaddress",
						this.formdata, "permanentdetails",
						topvue.form_elements.lcappnt[key]);

			}
			

		}
	} else {

		for ( var key in topvue.form_elements.lcappnt) {
			
			if (topvue.form_elements.lcappnt[key].name == 'permanentcountry') {
				unbindSameElement.call(this, "addresscountry",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'permanentprovince') {
				unbindSameElement.call(this, "homeprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'permanentcity') {
				unbindSameElement.call(this, "homecity",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'permanentarea') {
				unbindSameElement.call(this, "homedistrict",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'permanentdetails') {
				unbindSameElement.call(this, "homeaddress",
						topvue.form_elements.lcappnt[key]);
			}
			

		}

	}

};




//行业类别
commonCombobox_option.commonCombobox_appntindustry = {
	url : path + '/newCont/codeselect/occupation/AL.do',
	valueField : "occupationcode1",
	// 显示在输入框的
	inputText : "occupationname1",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname1" ]
};
//行业代码
commonCombobox_option.commonCombobox_appntindustrycode = {
	url : path + '/newCont/codeselect/occupation/#appntindustrytype/AL.do',
	valueField : "occupationcode2",
	// 显示在输入框的
	inputText : "occupationname2",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname2" ]
};
 
//职业代码
commonCombobox_option.commonCombobox_appntoccupationcode = {
	url : path + '/newCont/codeselect/occupationocc/#appntoccupationtype/AL.do',
	valueField : "occupationcode",
	// 显示在输入框的
	inputText : "occupationname",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname" ]
};

afterVueSelect.occupationcodeinsh = function() { 
	var occupat = $('#occualias').val();
	var occupationcode = $('#occupationcodeinsh').val();
	try {
		if(occupat!=null&&occupationcode!=''&&occupat.indexOf("K")!=-1 
				&& occupationcode!=null&&occupationcode!=''&& occupationcode.indexOf("K04")==-1){
			addressHidden();
		}else{
			addressShow();
		}
	} catch (e) {
		
	}	
}


function addressShow(){
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"showflag", "Y");	
	/*$("#companyinsh").removeAttr("disabled");*/
}

function addressHidden(){
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"showflag", "N");
	$("#companyinsh").attr("disabled","disabled");
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employphonecountry", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"countrycode_loy", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employareacodetel", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employphone", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employcountry", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employprovince", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employcity", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employarea", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"company", "");
}

/**
* 同被保人
*/
/*afterVueSelect.relationtoappnt=function(form_element){
	 
	var topvue = getTopvueObj(this);
	if(topvue.formdata.lcinsured["relationtoappnt"]=="01"){
		
		topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",topvue.formdata.lcappnt.appntname); 
		
//		topvue.formdata.lcinsured["lcinsuredname"]=topvue.formdata.lcappnt.appntname;
	}else{
//		topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",""); 
		
	}
	
}*/

//

//
////单位/学校国家变化时改变单位/学校地址省市区下拉状态
//afterVueSelect.employcountry = function() {
//	if($('#employcountry').val() != 'CN'){
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employprovince", null);
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employcity", null);
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employarea", null);
//		$('#employprovince').combobox("clear");
//		$('#employprovince').combobox("disable");
//		$('#employcity').combobox("clear");
//		$('#employcity').combobox("disable");
//		$('#employarea').combobox("clear");
//		$('#employarea').combobox("disable");
//		
//	}else{
//		$('#employprovince').combobox("enable");
//		$('#employcity').combobox("enable");
//		$('#employarea').combobox("enable");
//	}
//}
//
////通讯地址国家变化时改变通讯地址省市区下拉状态
afterVueSelect.zactladdrcountry = function() {
	
	if($("#postaddressflaginsh").is("[type='checkbox']:checked")){
		return;
	}
	if($('#zactladdrcountry').val() != 'CN'){	
		if($('#zactladdrcountry').val()!=null&&$('#zactladdrcountry').val()!=""&&$('#zactladdrcountry').val()!=undefined){
			$('#appntpostprovinceinsh').combobox("clear");
			$('#appntpostcityinsh').combobox("clear");
			$('#appntpostdistrictinsh').combobox("clear");	
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"postprovince", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"postcity", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"postdistrict", null);
		}
//		$('#appntpostprovinceinsh').combobox("clear");
		$('#appntpostprovinceinsh').combobox("disable");
//		$('#appntpostcityinsh').combobox("clear");
		$('#appntpostcityinsh').combobox("disable");
//		$('#appntpostdistrictinsh').combobox("clear");
		$('#appntpostdistrictinsh').combobox("disable");
	}/*else if($('#appntpostprovinceinsh_combobox').val() != '' && $('#appntpostprovinceinsh_combobox').val() !=undefined){
		return;
	}*/else{
		/*$('#appntpostprovinceinsh').combobox("enable");
		$('#appntpostcityinsh').combobox("enable");
		$('#appntpostdistrictinsh').combobox("enable");*/
	}
	
}

//居住地址国家变化时改变居住地址省市区下拉状态
//afterVueSelect.addresscountry = function(form_element) {
//	if($('#addresscountry').val() != 'CN'){
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"homeprovince", null);
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"homecity", null);
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"homedistrict", null);
//		$('#homeprovince').combobox("clear");
//		$('#homeprovince').combobox("disable");
//		$('#homecity').combobox("clear");
//		$('#homecity').combobox("disable");
//		$('#homedistrict').combobox("clear");
//		$('#homedistrict').combobox("disable");
//	}else{
//		$('#homeprovince').combobox("enable");
//		$('#homecity').combobox("enable");
//		$('#homedistrict').combobox("enable");
//	}
//}

////永久居住地址国家变化时改变永久居住地址省市区下拉状态
afterVueSelect.permanentcountry = function() {
	
	if($("#permanentflag").is("[type='checkbox']:checked")){
		return;
	}
	if($('#permanentcountry').val() != 'CN'){
		if($('#permanentcountry').val()!=null&&$('#permanentcountry').val()!=""&&$('#permanentcountry').val()!=undefined){
			$('#permanentprovince').combobox("clear");
			$('#permanentcity').combobox("clear");
			$('#permanentarea').combobox("clear");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"permanentprovince", null);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"permanentcity", null);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"permanentarea", null);
			
		}
//		$('#permanentprovince').combobox("clear");
		$('#permanentprovince').combobox("disable");
//		$('#permanentcity').combobox("clear");
		$('#permanentcity').combobox("disable");
//		$('#permanentarea').combobox("clear");
		$('#permanentarea').combobox("disable");
	}/*else if($('#permanentprovince_combobox').val() != '' && $('#permanentprovince_combobox').val() !=undefined){
		return;
	}*/else{
	/*	$('#permanentprovince').combobox("enable");
		$('#permanentcity').combobox("enable");
		$('#permanentarea').combobox("enable");*/
	}
}



//曾居住地址国家变化时改变曾居住地址省市区下拉状态
//afterVueSelect.previouscountry = function(form_element) {
//	if($('#previouscountry').val() != 'CN'){
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previousprovince", null);
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previouscity", null);
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previousarea", null);
//		$('#previousprovince').combobox("clear");
//		$('#previousprovince').combobox("disable");
//		$('#previouscity').combobox("clear");
//		$('#previouscity').combobox("disable");
//		$('#previousarea').combobox("clear");
//		$('#previousarea').combobox("disable");
//	}else{
//		$('#previousprovince').combobox("enable");
//		$('#previouscity').combobox("enable");
//		$('#previousarea').combobox("enable");
//	}
//}

//出生地国家变化时改变其省市下拉框状态
//afterVueSelect.birthcountyinsh = function() {
//	if($('#birthcountyinsh').val() != 'CN'){
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"appntbirthprovince", null);
////		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"appntcity", null);
//		$('#appntbirthprovince').combobox("clear");
//		$('#appntbirthprovince').combobox("disable");
//		$('#appntcity').combobox("clear");
//		$('#appntcity').combobox("disable");
//	}else{
//		$('#appntbirthprovince').combobox("enable");
//		$('#appntcity').combobox("enable");
//	}
//}

//主要收入来源为其他时，显示其他收入来源描述
afterVueSelect.appntincomesource = function(form_element) {
	if($('#appntincomesource').val() != '4'){
//		console.log(vueobj["testdivchange"].formdata.lcappnt);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"appntincomeother", null); //清空前端值
		$('#appntincomeother').attr("disabled",true);
//		$('#appntincomeother').val("");
	}else{
		$('#appntincomeother').removeAttr("disabled");
	}
}
//投保目的为其他时，显示其他投保目的
afterVueSelect.goaltypeinsh = function(form_element) {
	if($('#goaltypeinsh').val() != 'O'){
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.ldcustomer,"othergoaltype", null);
		$('#othergoaltypeinsh').attr("disabled",true);
//		$('#othergoaltypeinsh').val("");
	}else{
		$('#othergoaltypeinsh').removeAttr("disabled");
	}
}
//多国籍下拉状态
afterVueSelect.multiplenativeplaceflag = function(form_element) {
	
	if($('#multiplenativeplaceflag').val() != 'Y'){
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"nativeplace2", null);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"nativeplace3", null);
		$('#nativeplace2').combobox("clear");
		$('#nativeplace2').combobox("disable");	
		$('#nativeplace3').combobox("clear");
		$('#nativeplace3').combobox("disable");	
	}else{
		/*$('#nativeplace2').combobox("enable");
		$('#nativeplace3').combobox("enable");	*/
	}
}
/*beforesubmitvueform.lcappnt_tabinfoform=function(){
	var topvue = getTopvueObj(this);
	if(topvue.formdata.lccont&&topvue.formdata.lccont.commonchannel=="SC"||
			topvue.formdata.lccont&&topvue.formdata.lccont.commonchannel=="RS"){
		if(topvue.formdata.lccont.anotherholder=="Y"){
			alert("购物车流程不支持此联名账户的签署确认方式")
			return false;
		}
	}
	if(topvue.formdata.lcappnt.idtype== "I"){
		  var date = new Date();
	       var seperator1 = "-";
	       var year = date.getFullYear();
	       var month = date.getMonth() + 1;
	       var strDate = date.getDate();
	       if (month >= 1 && month <= 9) {
	           month = "0" + month;
	       }
	       if (strDate >= 0 && strDate <= 9) {
	           strDate = "0" + strDate;
	       }
	       var currentdate = year + seperator1 + month + seperator1 + strDate;
		
		if(topvue.formdata.lcappnt.startingDate==null 
				|| topvue.formdata.lcappnt.startingDate=="" ){
			alert("证件有效起期不可为空");
			return false;
		}
		
		if((new Date(topvue.formdata.lcappnt.startingDate)>new Date(currentdate))){
			alert("证件有效起期必须小于等于当前日期");
			return false;
		}
		if((new Date(topvue.formdata.lcappnt.startingDate))>=
			(new Date(topvue.formdata.lcappnt.appntenddate))){
			alert("证件有效起期必须小于证件有效止期");
			return false;
		}
	}
	if(topvue.formdata.lcappnt.idtype== "X"){
		if(topvue.formdata.lcappnt.renewCount==null 
				|| topvue.formdata.lcappnt.renewCount=="" ){
			alert("证件为港澳台通行证，换证次数不可为空");
			return false;
		}
		var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.lcappnt.renewCount)).slice(-2);//01
		topvue.$set(topvue.formdata.lcappnt,"renewCount",newrenewcount);
	}
	return true;
}*/

//投保人信息成功保存后， 校验投保单号
aftersubmitvueform.lcappnt_tabinfoform = function(){
	var recording = initFormdata.newContApply.recording;	
	console.log("***checking Recording flag***=======" + recording);
	if(recording == "Y"){
		console.log("***current Recording changing operation***");
		var topvue = getTopvueObj(this);
		topvue.form_elementsBYID.lccont.proposalcontno.cssClass = "disabled";
		$("#proposalcontno").attr("disabled",true);
		console.log("***diabled proposalcontno***");
	}
	/*var proposalcontno =vueobj["testdivchange"].formdata.lccont.proposalcontno;
	if(proposalcontno !=null && proposalcontno !=""){
		$('#newcompanyCode').combobox("disable");
		$('#newcitycode').combobox("disable");		
	}*/
	console.log("***aftersubmitvueform.lcappnt_tabinfoform***");
	return true;
}
//IPS的warningInfo提示框
afterloadNewElements.lccont_tabinfo=function(){
	var topvue = getTopvueObj(this);
/*	if(topvue.formdata.quotation.warningInfo.length>0){
		var warningInfo=topvue.formdata.quotation.warningInfo[0].code;
		if(warningInfo=="FPS0026"||warningInfo=="FPS0127"||warningInfo=="FPS0128"){
			alert("未获取到有效的建议书信息，请手动录入投保相关内容");
		}
	}*/
}

/*afterloadNewElements.lcappnt_tabinfo=function(){
	
	setTimeout(function(){
		if(($("#appntrenewCount").is(":visible")||$("#appntrenewCount").length>0)){
   		 $("#appntrenewCountTitle").remove();
   		$("#appntrenewCount").parent().append("<small id='appntrenewCountTitle' class='help-block' style='color: red;'>请注意，" +
   				"请按证件上的换证次数填写，例如：01。</small>");
		 }
	},50);
} */
