$(document).ready(function () {


    var tab_d = $('#cusTable');


    $.ajax({
        url: path + "/Notice/Edit/show/mainriskModify.do",
        type: "POST",
        data :{"insurancecom":"ANZL"},
        error: function (request) {
            alert("Connection error");
        },
        success: function (data) {
            $("#mainrisk").append("<option >" + "</option>");
            for (var i = 0; i < data.length; i++) {
                $("#mainrisk").append(
                    "<option value=" + data[i].riskcode + ">"
                    + data[i].riskname + "</option>");
            }
        }
    });




    /** 加载页面表格 */
    var col = [ {
        checkbox: true
    },{
        field : 'id',
        title : '序号',
        formatter : function(value, row, index) {
            return index + 1;
        }
    }, {
        field : 'insurancecom',//占用这个字段
        title : '主险名称',
        align : 'center',
        valign : 'middle',
        visible : true
    }, {
        field : 'mainriskcode',
        title : '主险代码',
        align : 'center',
        valign : 'middle'
    }, {
        field : 'additionriskcode',
        title : '附加险代码',
        align : 'center',
        valign : 'middle'
    }, {
        field : 'checkflag',
        title : '审核状态',
        align : 'center',
        valign : 'middle'
    },{
        title : '明细修改',
        align : 'center',
        formatter : actionFormatter,
        events : actionEvents
    },{
        title : '提交',
        align : 'center',
        formatter : actionFormatter1,
        events : actionEvents1
    }, {
        title : '删除',
        align : 'center',
        formatter : actionFormatter2,
        events : actionEvents2
    }];

    var uniqueId = "metentid";
    $("#search").click(function() {

        var mainRisk = $("#mainrisk").val();
        if(mainRisk == null || mainRisk == ''){
            alert("请先选择需要查询的主险");
            return;
        }

        $("#cusTable").bootstrapTable('destroy');
        url_d = "/vue/common/impartConfigModifyQuery.do";
        tableInit3(url_d, tab_d, col, uniqueId, queryParams);

    });


    function queryParams(params) {

        var param = {
            limit : params.limit,
            offset : params.offset,
            insurancecom : "ANZL",
            mainriskcode : $("#mainrisk").val(),
        };
        return param;
    };

    function tableInit3(url, obj, col, uniqueId, queryParams) {
        obj.bootstrapTable({
            url : path + url, // 请求后台的URL（*）
            dataType : "json",
            method : 'post', // 请求方式（*）
            contentType : "application/x-www-form-urlencoded",
            toolbar : '#toolbar',
            columns : col,
            striped : true, // 是否显示行间隔色
            cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
            pagination : true, // 是否显示分页（*）
            queryParamsType : "limit",// undefined/limit
            queryParams : queryParams,// 传递参数（*）
            sidePagination : "server", // 分页方式：client客户端分页，server服务端分页（*）
            pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
            search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
            strictSearch : false,// 设置为 true启用 全匹配搜索，否则为模糊搜索
            showColumns : true, // 是否显示所有的列
            showRefresh : false, // 是否显示刷新按钮
            minimumCountColumns : 2, // 最少允许的列数
            clickToSelect : true, // 是否启用点击选中行
            uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
            showToggle : true, // 是否显示详细视图和列表视图的切换按钮
            cardView : false, // 是否显示详细视图
            detailView : false
        });
    };

    $("#tableVisable").hide();

});

function actionFormatter(value, row, index) {
    return [ '<button type="button" class="btn btn-primary detailInfo">明细修改</button>' ].join('');
};


window.actionEvents = {
    'click .detailInfo' : function(e, value, row, index) {

        $.ajax({
            url: path + "/vue/common/testnotice.do",
            type: "POST",
            data: {"combinecode": row.combinecode},
            error: function (request) {
                alert("Connection error");
            },
            success: function (additionRisk) {

//              vueobj["testdivchange"].form_elements = additionRisk.form_elements;
                vueobj["testdivchange"].$set(vueobj["testdivchange"].form_elements,"tbody",additionRisk.form_elements.tbody);
                $("#tableVisable").show();
            }
        });

    }

};

function actionFormatter1(value, row, index) {
    return [ '<button type="button" class="btn btn-primary modifySunbmt">提交</button>' ].join('');
};

function actionFormatter2(value, row, index) {
    if(row.checkflag == '审核通过'){

        return [ '<button type="button" class="btn btn-primary del">删除</button>' ].join('');
    }
};


window.actionEvents2 = {
    'click .del' : function(e, value, row, index) {
        var con= confirm ("你确定要删除该告知配置吗？");
        if(con==false){
            return;
        }
        $.ajax({
            url: path + "/vue/common/delete.do",
            type: "POST",
            data: {"combinecode": row.combinecode},
            error: function (request) {
                alert("Connection error");
            },
            success: function (additionRisk) {

                 $('#cusTable').bootstrapTable('refresh');

            }
        });

    }

};
