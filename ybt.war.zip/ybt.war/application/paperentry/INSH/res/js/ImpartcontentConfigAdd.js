$(document).ready(function () {
    $.ajax({
        url: path + "/Notice/Edit/show/Allmainrisk.do",
        type: "POST",
        data :{"insurancecom":"ANZL"},
        error: function (request) {
            alert("Connection error");
        },
        success: function (data) {
            $("#mainrisk").append("<option >" + "</option>");
            for (var i = 0; i < data.length; i++) {
                $("#mainrisk").append(
                    "<option value=" + data[i].riskcode + ">"
                    + data[i].riskname + "</option>");
            }
        }
    });


    $("#mainrisk").change(function () {
        var mainRiskVal = $("#mainrisk").val();
        $("#headId").empty();
        if (mainRiskVal == "") {
            return;
        }
        $.ajax({
            url: path + "/Notice/Edit/show/additionRisk.do",
            type: "POST",
            data: {"mainRiskVal": mainRiskVal},
            error: function (request) {
                alert("Connection error");
            },
            success: function (additionRisk) {
                for (var i = 0; i < additionRisk.length; i++) {
                    $("#headId").append("<th><input type='checkbox' value=" + additionRisk[i].riskcode + " name='additionRiskCode'/>" + additionRisk[i].riskname)
                    + "</th>";
                }
            }
        });

    });
































});