

/*//附加险   逻辑增加 //预录单没有被保人
$.fn.bootstrapValidator.validators.subriskAgeValid = {
		
	validate : function(validator, $field, options) {

		var topvueobj = getTopvueObj(options.vueobj);
		var riskbelong =options.vueobj.formdata.riskbelong;
		 
		var form =$(options.vueobj.$el)
			.parentsUntil("form").parent("form");
		for ( var index in riskbelong) {
			//主被保险人
			if(riskbelong[index]=="01"){
				topvueobj.formdata.lcinsured.lcinsuredbirthday;
			}
			
			//第二 被保险人
			if(riskbelong[index]=="02"){
				
			}
		}
		
		
		return true; 
	}
}; */

 
 
 bootstrap_valid.subriskAgeValid = function(validitem   ){
 
	
	 
		var vueobj = this;
		var validobj= {
				message:"该险种对应被保险人的年龄必须",
				vueobj:vueobj
		};
	 
		return validobj;
      
};


			//附加险代码获取
			commonCombobox_option.commonCombobox_subriskcode = {

				url : path + '/newCont/codeselect/searchsubrisk/INSH/#newContApply.riskcode',
				valueField : "riskCode",
				oneResultAuto:false,
				mutually_exclusive:true,
				// 显示在输入框的
				relateType: "vue",
				inputText : "salesChl",
				textShow : [ "salesChl" ]
			};
			
			
			//额外年金领取年龄
			commonCombobox_option.commonCombobox_subrisk_extragetyear = {
				url :  path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/extragetyear',
				valueField: "paramscode",
				relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};
			
			
			//保险期间
			commonCombobox_option.commonCombobox_subrisk_insuyears = {
				url :  path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/insuyear',
				valueField: "paramscode",
				relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};
			//缴费期间
			commonCombobox_option.commonCombobox_subrisk_payendyears = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/payendyear',
			    valueField: "paramscode",
			    relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};

			//缴费方式
			commonCombobox_option.commonCombobox_subrisk_payintvs = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/payintv',
			    valueField: "paramscode",
			    relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};

			//红利给付方式
			commonCombobox_option.commonCombobox_subrisk_bonuspayment = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/bonuspayment',
			    valueField: "paramscode",
			    relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};

/* //预录单没有被保人
			//附加险险种所属 commonCombobox_subriskbelong
			commonCombobox_option.commonCombobox_subriskbelong = {
				url :  path + '/newCont/codeselect/common/subriskbelong',
				valueField : "code",
				relateType: "vue",
				oneResultAuto:false,
				// 显示在输入框的
				inputText : "codename",
				textShow : ["codename"]
			};*///产品类型
			commonCombobox_option.commonCombobox_subrisk_producttype = {
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/producttype',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
			};

			//产品计划
			commonCombobox_option.commonCombobox_subrisk_productplanning = {
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/productplanning',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]

			};
			
			
			//备用查询
			


			//续期保费逾期
			commonCombobox_option.commonCombobox_subrisk_AutoPayFlag = {
				    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/AutoPayFlag',
				    valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
				    // 显示在输入框的
				    inputText: "paramsname",
				    // 显示在下拉列表的项，默认空，空则全部显示
				    textShow: ["paramsname"]
			};

			//自动申请续保
			commonCombobox_option.commonCombobox_subrisk_AutoRenewal = {
					
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/AutoRenewal',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
					
			};

			//申请使用优选体费用
			commonCombobox_option.commonCombobox_subrisk_PremiumRate = {
					
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/PremiumRate',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
					
			};
////预录单没有被保人
/*			commonCombobox_option.commonCombobox_subrisk_belonginsured = {
					url: path + '/newCont/codeselect/searchParamslcinsured/#newContApply.transno',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
				};*/

			/**
			 * 加载险种对应的参数 加载判断
			 */
			afterVueSelect.subriskcode=function(form_element){
				var url ="/newCont/common/init/subriskcode/INSHPAPER/#newContApply.transno"; 
				
				if(this.formdata.riskcode){
					loadNewElements(this, url ,form_element);				
				}
				if(this.formdata.riskcode=="@F1"){
					if($("div:contains('该附加险提供单被保险人和联合人寿两种选择')").is(':visible')){}else{

						$('#subriskcode_tabinfoform').after(
					      		"<div><p style='color:red'>1. 该附加险提供单被保险人和联合人寿两种选择。选定单被保险人（联合人寿）并经保险公司核保通过后，后期不再接受变更为联合人寿（单被保险人）;</p>" +
							    "<p style='color:red'>2. 自投保人首次投保本附加合同的生效日起，至主合同最后一期保险费约定交纳日止，为保证续保期间。在保证续保期间，若每一保险期间届满前未收到投保人不再续保的书面通知，则视为投保人同意续保 </p></div>");
					
					}
				}else{
					$("p:contains('该附加险提供单被保险人和联合人寿两种选择')").remove();
					$("p:contains('自投保人首次投保本附加合同的生效日起')").remove();
				}
					
			};
			
/*			function belonglcinsuredClear(){
				if(vueobj["testdivchange"].formdata.newContApply.riskcode=="@Z0"){
					try {
							$("input\[id^='belonginsuredtwos\['\]").combobox("clear");
							$("input\[id^='belonginsuredtwos\['\]").combobox("clearData");
						
						if($("#subriskcode_tabinfoform").data('bootstrapValidator')!=null&&
								$("#subriskcode_tabinfoform").data('bootstrapValidator')!=undefined){
								$("#subriskcode_tabinfoform").data('bootstrapValidator').destroy();
						        $('#subriskcode_tabinfoform').data('bootstrapValidator', null);
							}
					} catch (e) {
						// TODO: handle exception
					}		
				}
				}*/
			
//			beforesubmitvueform.subriskcode_tabinfoform=function(){
//				var topvue = getTopvueObj(this);
//				var confirmInfo="1. 该附加险提供单被保险人和联合人寿两种选择。选定单被保险人（联合人寿）并经保险公司核保通过后，后期不再接受变更为联合人寿（单被保险人）;\u000d";    
//				confirmInfo +="2. 自投保人首次投保本附加合同的生效日起，至主合同最后一期保险费约定交纳日止，为保证续保期间。在保证续保期间，若每一保险期间届满前未收到投保人不再续保的书面通知，则视为投保人同意续保 ";
//				//校验主附险主被保人个数										
//				if(topvue.formdata['sublcpols']){
//					var sublcpols = topvue.formdata.sublcpols;
//					var flag ='false';
//					for (var i = 0; i < sublcpols.length; i++) {
//						var sublcpol = sublcpols[i].riskcode;
//						if(sublcpol=='@F1'){
//							flag ='true';
//							break;
//						}						
//					}					
//				}
//				if(flag=='true'){
//					if(!confirm(confirmInfo)){
//						return false;
//					}else{
//						return true;
//					}
//				}else{
//					return true;
//				}
//				
//			}
			
//			//附加险保存后
//			aftersubmitvueform.subriskcode_tabinfoform = function() {
//			 
//				 if(this.formdata.newContApply.noticeCombineID==this.formdata.newContApply.lastnoticeCombineID){
//					 
//					 
//				 }else{
//					 topvue.$set(topvue.form_elements, commonFormNotice, []);
//				 }
//				
//				
//				return true; 
//			};
			
			
			aftersubmitvueform.subriskcode_tabinfoform = function() {
				if(!checkCRSShow.call(this)){
 
					this.$set(this.formdata.newContApply,"FATACACRS",false);
					if(this.formdata.newContApply.currentSIDIndex>4){
						this.$set(this.formdata.newContApply,"currentSIDIndex",4);
						this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
						$('#tab_FATACACRS_tabinfo').trigger("click");
					}
					
					
				}
				return true;
			};

			 