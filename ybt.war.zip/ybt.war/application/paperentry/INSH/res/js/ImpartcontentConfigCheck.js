
$(document).ready(function () {


    var tab_d = $('#cusTable');


    $.ajax({
        url: path + "/Notice/Edit/show/AllCheckMainrisk.do",
        type: "POST",
        data:{"insurancecom":"ANZL"},
        error: function (request) {
            alert("Connection error");
        },
        success: function (data) {
            $("#mainrisk").append("<option >" + "</option>");
            for (var i = 0; i < data.length; i++) {
                $("#mainrisk").append(
                    "<option value=" + data[i].riskcode + ">"
                    + data[i].riskname + "</option>");
            }
        }

    });




    /** 加载页面表格 */
    var col = [ {
        checkbox: true
    },{
        field : 'id',
        title : '序号',
        formatter : function(value, row, index) {
            return index + 1;
        }
    }, {
        field : 'insurancecom',//占用这个字段
        title : '主险名称',
        align : 'center',
        valign : 'middle',
        visible : true
    }, {
        field : 'mainriskcode',
        title : '主险代码',
        align : 'center',
        valign : 'middle'
    }, {
        field : 'additionriskcode',
        title : '附加险代码',
        align : 'center',
        valign : 'middle'
    }, {
        title : '明细查看',
        align : 'center',
        formatter : actionFormatter,
        events : actionEvents
    } , {
        title : '审核',
        align : 'center',
        formatter : actionFormatter1,
        events : actionEvents1
    }];

    var uniqueId = "metentid";
    $("#search").click(function() {
    	var mainValue = $("#mainrisk").val().trim();
    	if(mainValue == null || mainValue == ''){
    		alert("请选择要审核的主险!");
    		return;
    	}
        $("#cusTable").bootstrapTable('destroy');
        url_d = "/vue/common/impartConfigCheckQuery.do";
        tableInit3(url_d, tab_d, col, uniqueId, queryParams);

    });




    /**
     * 设置表格查询参数
     *
     * @param params
     */
    function queryParams(params) {
        // 设置查询参数
        var headers = "";
        $('input[name="additionRiskCode"]:checked').each(function(i){
            if(0==i){
                headers = $(this).val();
            }else{
                headers += (","+$(this).val());
            }
        });

        var param = {
            limit : params.limit,
            offset : params.offset,
            insurancecom : "ANZL",
            mainriskcode : $("#mainrisk").val()

        };
        return param;
    };

    /**
     * 翻页带查询参数及列排序
     *
     */
    function tableInit3(url, obj, col, uniqueId, queryParams) {
        obj.bootstrapTable({
            url : path + url, // 请求后台的URL（*）
            dataType : "json",
            method : 'post', // 请求方式（*）
            contentType : "application/x-www-form-urlencoded",
            toolbar : '#toolbar',
            columns : col,
            striped : true, // 是否显示行间隔色
            cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
            pagination : true, // 是否显示分页（*）
            queryParamsType : "limit",// undefined/limit
            queryParams : queryParams,// 传递参数（*）
            sidePagination : "server", // 分页方式：client客户端分页，server服务端分页（*）
            pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
            search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
            strictSearch : false,// 设置为 true启用 全匹配搜索，否则为模糊搜索
            showColumns : true, // 是否显示所有的列
            showRefresh : false, // 是否显示刷新按钮
            minimumCountColumns : 2, // 最少允许的列数
            clickToSelect : true, // 是否启用点击选中行
            uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
            showToggle : true, // 是否显示详细视图和列表视图的切换按钮
            cardView : false, // 是否显示详细视图
            detailView : false
        });
    };




});


function actionFormatter(value, row, index) {
    return [ '<button type="button" class="btn btn-primary detailInfo">明细查看</button>' ].join('');
};


window.actionEvents = {
    'click .detailInfo' : function(e, value, row, index) {

        $.ajax({
            url: path + "/vue/common/testnotice.do",
            type: "POST",
            data: {
                "combinecode": row.combinecode
            },
            error: function (request) {
                alert("Connection error");
            },
            success: function (additionRisk) {

//                     vueobj["testdivchange"].form_elements = additionRisk.form_elements;

                vueobj["testdivchange"].$set(vueobj["testdivchange"].form_elements,"tbody",additionRisk.form_elements.tbody);
                $("#tableVisable").show();
            }
        });

    }

};




function actionFormatter1(value, row, index) {
    return [ '<button type="button" class="btn btn-primary check">审核</button>' ].join('');
};


window.actionEvents1 = {
    'click .check' : function(e, value, row, index) {
        var status = $("#checkStatus").val();
        if(status == "请选择"){
            alert("请选择审核状态！");
            return;
        }
        $.ajax({
            url: path + "/Notice/Edit/show/checksubmit.do",
            type: "POST",
            data: {
                "combinecode": row.combinecode,
                "checkStatus" : status,
                "oldcombinecode":row.bak1
            },
            error: function (request) {
                alert("Connection error");
            },
            success: function (data) {
                alert(data.desc);
                window.location.href = "ImpartcontentConfigCheck.jsp";
            }
        });

    }

};