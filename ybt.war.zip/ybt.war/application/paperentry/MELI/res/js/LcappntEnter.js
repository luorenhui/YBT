var occupationcode = {
    url: path + '/newContEnter/selectByLdoccupationVo.do',
    valueField: "occupationcode",
    // 显示在输入框的
    inputText: "occupationname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["occupationname"]
}
var creditgrade = {
    valueField: "code",
    inputText: "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["codename"],
    data: [{
        code: '1',
        codename: '农村'
    }, {
        code: '2',
        codename: '城镇'
    }]
}
var goaltype = {
    url: path + '/LdcodeController/selectIdTypeByCodetype.do?codetype=goaltype',
    valueField: "code",
    // 显示在输入框的
    inputText: "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["codename"]
}

function lcappntinit() {
    initData($("#lcappntdivchange"));

    /****/
    $("#lcappntdivchange").find('input[checkboxoption]').each(function (i) {
        var obj = $(this);
        console.log(obj);
        var checkboxoption = obj.attr("checkboxoption");
        var index = checkboxoption.indexOf("commonCombobox_");

        try {
            if (index >= 0) {
                ;
                obj.combobox(commonCombobox_option[checkboxoption]);
            } else {
                obj.combobox($.parseJSON(checkboxoption));
            }
        } catch (e) {
            console.log('error init combobox  id:', obj, ', checkboxoption:', checkboxoption);
        }
    });

    $('.i-checks').iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-green',
    });
    $("#idtype").combobox(idtype);
    $("#appntsex").combobox(appntsex);
    $("#nativeplace").combobox(nativeplace);
    $("#occupationcode").combobox(occupationcode);
    $("#creditgrade").combobox(creditgrade);
    $("#goaltype").combobox(goaltype);
    vueobj["lcappntdivchange"].$set(vueobj["lcappntdivchange"].formdata.lcappnt, "appntenddate", dateToString(Number($("#appntenddate").val())));
    vueobj["lcappntdivchange"].$set(vueobj["lcappntdivchange"].formdata.lcappnt, "appntbirthday", dateToString(Number($("#appntbirthday").val())));


}

vue_config.push({
    id: "lcappntdivchange",
    url: path + "/lcappntController/selNewCont/" + data.insurancecom + "/lcappnt.do?lccontParm=" + encodeURI(JSON.stringify(data)),
    initFunction: lcappntinit
});
