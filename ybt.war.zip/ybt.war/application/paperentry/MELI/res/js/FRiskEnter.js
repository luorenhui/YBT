combineCheckID["lccont_tabinfo"]="sublcpols_tabinfo"; 
