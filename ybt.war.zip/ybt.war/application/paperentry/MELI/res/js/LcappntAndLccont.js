
/*//选择了身份证类型时
afterVueSelect.idtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcappnt.idtype;
	if (idtype== "I"){
		$("#appntstartingDate").attr("disabled",false);
	}else {
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"startingDate", null);
		$("#appntstartingDate").attr("disabled",true);
	}
	if (idtype== "X"){
		$("#appntrenewCount").attr("disabled",false);
	}else {
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"renewCount", null);
		$("#appntrenewCount").attr("disabled",true);
	}
};*/
/** 
 * 投保人 通讯地址同 居住地址
 */
afterVueSelect.postalflagmeli = function(form_element) {
	
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (obj.is("[type='checkbox']:checked")) {

		for ( var key in topvue.form_elements.lcappnt) {
			
			if (topvue.form_elements.lcappnt[key].name == 'homeprovince') {
				bindSameElement.call(this, this.formdata, "postprovince",
						this.formdata, "homeprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homecity') {
				bindSameElement.call(this, this.formdata, "postcity",
						this.formdata, "homecity",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homedistrict') {
				bindSameElement.call(this, this.formdata, "postdistrict",
						this.formdata, "homedistrict",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homedetails') {
				bindSameElement.call(this, this.formdata, "postdetails",
						this.formdata, "homedetails",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homezipcode') {
				bindSameElement.call(this, this.formdata, "zipcode",
						this.formdata, "homezipcode",
						topvue.form_elements.lcappnt[key]);
			}
			

		}
	} else {
		for ( var key in topvue.form_elements.lcappnt) {
			
			
			if (topvue.form_elements.lcappnt[key].name == 'homeprovince') {
				unbindSameElement.call(this, "postprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homecity') {
				unbindSameElement.call(this, "postcity",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homedistrict') {
				unbindSameElement.call(this, "postdistrict",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homedetails') {
				unbindSameElement.call(this, "postdetails",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homezipcode') {
				unbindSameElement.call(this, "zipcode",
						topvue.form_elements.lcappnt[key]);
			}

		}
		

	}

};
/*//证件长期有效
afterVueSelect.appntislongitemmeli = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");
	if (obj.is("[type='checkbox']:checked")){
		topvue.$set(topvue.formdata.lcappnt,"appntenddate","9999-01-01");
		$("#lcappnt_tabinfoform").data('bootstrapValidator').resetField($("#appntenddate"));
		$("#appntenddate").attr("disabled",true);
	}else {
		$("#appntenddate").attr("disabled",false);
	}
}
*/


//MELI居民类型
commonCombobox_option.commonCombobox_creditgrademeli = {
	valueField : "code",
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ],
	data : [ {
		code : '1',
		codename : '农村居民'
	}, {
		code : '2',
		codename : '城镇居民'
	} ]
};
//是否外国政要或组织高级管理人员
commonCombobox_option.commonCombobox_ispolitical = {
	valueField : "code",
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ],
	data : [ {
		code : 'Y',
		codename : '是'
	}, {
		code : 'N',
		codename : '否'
	} ]
};
//MELI 证件递交
commonCombobox_option.commonCombobox_idsubmit = {
	valueField : "code",
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ],
	data : [ {
		code : 'Y',
		codename : '是'
	}, {
		code : 'N',
		codename : '否'
	} ]
};


/*//行业类别
commonCombobox_option.commonCombobox_appntindustry = {
	url : path + '/newCont/codeselect/occupation/AL.do',
	valueField : "occupationcode1",
	// 显示在输入框的
	inputText : "occupationname1",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname1" ]
};
//行业代码
commonCombobox_option.commonCombobox_appntindustrycode = {
	url : path + '/newCont/codeselect/occupation/#appntindustrytype/AL.do',
	valueField : "occupationcode2",
	// 显示在输入框的
	inputText : "occupationname2",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname2" ]
};
 
//职业代码
commonCombobox_option.commonCombobox_appntoccupationcode = {
	url : path + '/newCont/codeselect/occupationocc/#appntoccupationtype/AL.do',
	valueField : "occupationcode",
	// 显示在输入框的
	inputText : "occupationname",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname" ]
};*/

 

/*afterVueSelect.relationtoappnt=function(form_element){
	 
	var topvue = getTopvueObj(this);
	if(topvue.formdata.lcinsured["relationtoappnt"]=="01"){
		
		topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",topvue.formdata.lcappnt.appntname); 
		
//		topvue.formdata.lcinsured["lcinsuredname"]=topvue.formdata.lcappnt.appntname;
	}else{
//		topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",""); 
		
	}
	
}*/
//根据身份证号，同步出生日期
/**
 
afterVueSelect.idno = function(form_element) {
	var topvue = getTopvueObj(this);
	if($("#idtype").val() != "I"&&$("#idtype").val() != "J"){
		return;
	}
	if($("#idtype").val() == "I"||$("#idtype").val() == "J"){
			var idno = $("#idno").val();
			var birthday = idno.substring(6,14);
			var year = birthday.substring(0,4);
			var mon = birthday.substring(4,6);
			var day = birthday.substring(6);
			var formatBirth = year + "-" + mon + "-" + day;
			topvue.$set(topvue.formdata.lcappnt,"appntbirthday",formatBirth);		
	}
	
};
$.fn.bootstrapValidator.validators.appnt_idno = {
		validate : function(validator, $field, options) {
			var topvueobj = getTopvueObj(options.vueobj);
			var lcappnt = topvueobj.formdata.lcappnt;
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			if(lcappnt.idno.length==18||(lcappnt.idtype!="I"&&lcappnt.idtype!="J")){
				form.data('bootstrapValidator').updateStatus($field, "VALID");
				form.find("input[id*='idno']").each(function() {
					if (!form.data('bootstrapValidator').isValidField($(this))) {
						form.data('bootstrapValidator').revalidateField($(this));
					}

				});
				return true;
			}
			return false;
		}
	};
	bootstrap_valid.appnt_idno = function(validitem) {

		var vueobj = this;
		var validobj = {
			message : "您选择的证件长度必须为18位，您的输入有误!",
			vueobj : vueobj
		};

		return validobj;

	}; */


//投保人信息成功保存后， 校验投保单号
aftersubmitvueform.lcappnt_tabinfoform = function(){
	var topvue = getTopvueObj(this);
	var recording = initFormdata.newContApply.recording;	
	console.log("***checking Recording flag***=======" + recording);
	if(recording == "Y"){
		console.log("***current Recording changing operation***");
		
		topvue.form_elementsBYID.lccont.proposalcontno.cssClass = "disabled";
		$("#proposalcontno").attr("disabled",true);
		console.log("***diabled proposalcontno***");
	}
	var proposalcontno =vueobj["testdivchange"].formdata.lccont.proposalcontno;
	if(proposalcontno !=null && proposalcontno !=""){
		$('#newcompanyCode').combobox("disable");
		$('#newcitycode').combobox("disable");		
	}
	var postFlag = vueobj["testdivchange"].formdata.lcappntaddress.postalflags;
	if(postFlag != null && postFlag.length > 0){
		topvue.$set(topvue.formdata.lcappntaddress,"homeprovince",vueobj["testdivchange"].formdata.lcappntaddress.postprovince); 
		topvue.$set(topvue.formdata.lcappntaddress,"homecity",vueobj["testdivchange"].formdata.lcappntaddress.postcity); 
		topvue.$set(topvue.formdata.lcappntaddress,"homedistrict",vueobj["testdivchange"].formdata.lcappntaddress.postdistrict); 
		topvue.$set(topvue.formdata.lcappntaddress,"homedetails",vueobj["testdivchange"].formdata.lcappntaddress.postdetails); 
		topvue.$set(topvue.formdata.lcappntaddress,"homezipcode",vueobj["testdivchange"].formdata.lcappntaddress.zipcode); 
	}
	console.log("***aftersubmitvueform.lcappnt_tabinfoform***");

	return true;
}
/*//IPS的warningInfo提示框
afterloadNewElements.lccont_tabinfo=function(){
	
	var topvue = getTopvueObj(this);
	if(topvue.formdata.quotation.warningInfo.length>0){
		var warningInfo=topvue.formdata.quotation.warningInfo[0].code;
		if(warningInfo=="FPS0026"||warningInfo=="FPS0127"||warningInfo=="FPS0128"){
			alert("未获取到有效的建议书信息，请手动录入投保相关内容");
		}
	}
}
afterloadNewElements.lcappnt_tabinfo=function(){	
	setTimeout(function(){
		if(($("#appntrenewCount").is(":visible")||$("#appntrenewCount").length>0)){
   		 $("#appntrenewCountTitle").remove();
   		$("#appntrenewCount").parent().append("<small id='appntrenewCountTitle' class='help-block' style='color: red;'>请注意，" +
   				"请按证件上的换证次数填写，例如：01。</small>");
		 }
	},50);
}*/
/*
beforesubmitvueform.lcappnt_tabinfoform = function(){
	var topvue = getTopvueObj(this);
	if(topvue.formdata.lccont&&topvue.formdata.lccont.commonchannel=="SC"||
			topvue.formdata.lccont&&topvue.formdata.lccont.commonchannel=="RS"){
		if(topvue.formdata.lccont.anotherholder=="Y"){
			alert("购物车流程不支持此联名账户的签署确认方式")
			return false;
		}
	}
	   var date = new Date();
       var seperator1 = "-";
       var year = date.getFullYear();
       var month = date.getMonth() + 1;
       var strDate = date.getDate();
       if (month >= 1 && month <= 9) {
           month = "0" + month;
       }
       if (strDate >= 0 && strDate <= 9) {
           strDate = "0" + strDate;
       }
       var currentdate = year + seperator1 + month + seperator1 + strDate;
	if(!(new Date(topvue.formdata.lcappnt.appntenddate)>=new Date(currentdate))){
		alert("证件有效止期必须大于等于今天");
		return false;
	}
	if(topvue.formdata.lcappnt.idtype== "I" &&(
			topvue.formdata.lcappnt.startingDate!=null 
			&& topvue.formdata.lcappnt.startingDate!="")){
		
//		if(topvue.formdata.lcappnt.startingDate==null 
//				|| topvue.formdata.lcappnt.startingDate=="" ){
//			alert("证件有效起期不可为空");
//			return false;
//		}
		
		if((new Date(topvue.formdata.lcappnt.startingDate)>new Date(currentdate))){
			alert("证件有效起期必须小于等于当前日期");
			return false;
		}
		if((new Date(topvue.formdata.lcappnt.startingDate))>=
			(new Date(topvue.formdata.lcappnt.appntenddate))){
			alert("证件有效起期必须小于证件有效止期");
			return false;
		}	
	}
	if(topvue.formdata.lcappnt.idtype== "X"){
		// 个位数时，前置补一个0
		if(topvue.formdata.lcappnt.renewCount==null 
				|| topvue.formdata.lcappnt.renewCount=="" ){
			alert("证件为港澳台通行证，换证次数不可为空");
			return false;
		}
		var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.lcappnt.renewCount)).slice(-2);//01
		topvue.$set(topvue.formdata.lcappnt,"renewCount",newrenewcount);
	}
	return true;
}*/

