//证件类型
var idtype = {
    url:path + '/LdcodeController/selectIdTypeByCodetype.do?codetype=idtype',
    valueField : "code",
    // 显示在输入框的
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ]
 
};
//国籍
var nativeplace={
    url:path + '/LdcodeController/selectIdTypeByCodetype.do',

    param :{
        codetype:'iss_country'
    },
    valueField : "code",
    // 显示在输入框的
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ]
}
//职业代码
var occupationcode={
    url:path + '/newContEnter/selectByLdoccupationVo.do',
    valueField : "occupationcode",
    // 显示在输入框的
    inputText : "occupationname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["occupationname" ]
}
//性别
var appntsex={
    valueField : "code",
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ],
    data:[{
        code:'0',
        codename:'男'
    },{
        code:'1',
        codename:'女'
    }]
}
//被保人与投保人的关系
var relationtoappnt = {
    url:path + '/LdcodeController/selectLcodeByCodetype.do?codetype=relationformanu',
    valueField : "code",
    // 显示在输入框的
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ]

};
//保险期间
var insuyears = {
    url: path + '/LmriskparamsdefaController/selectByLmriskparamsdefaVo.do?riskcode='+data.riskcode+"&paramstype=insuyear",
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
}
//缴费期间
var payendyears={
    url: path + '/LmriskparamsdefaController/selectByLmriskparamsdefaVo.do?riskcode='+data.riskcode+"&paramstype=payendyear",
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
}
//时间控件
function initDateTimePicker(id){
    $("#"+id).datetimepicker({
        format: 'yyyy-mm-dd',
        autoclose:true,
        todayHighlight:true,
        minView:2,
        weekStart:0,
        language: 'zh-CN',//显示中文,
        showMeridian:true,
        showMeridian:true
    });
}