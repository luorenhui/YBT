/*//附加险   逻辑增加  //预录单没有被保人
$.fn.bootstrapValidator.validators.subriskAgeValid = {
		
	validate : function(validator, $field, options) {

		var topvueobj = getTopvueObj(options.vueobj);
		var riskbelong =options.vueobj.formdata.riskbelong;
		 
		var form =$(options.vueobj.$el)
			.parentsUntil("form").parent("form");
		for ( var index in riskbelong) {
			//主被保险人
			if(riskbelong[index]=="01"){
				topvueobj.formdata.lcinsured.lcinsuredbirthday;
			}
			
			//第二 被保险人
			if(riskbelong[index]=="02"){
				
			}
		}
		
		
		return true; 
	}
}; */

 
 
 bootstrap_valid.subriskAgeValid = function(validitem   ){
 
	
	 
		var vueobj = this;
		var validobj= {
				message:"该险种对应被保险人的年龄必须",
				vueobj:vueobj
		};
	 
		return validobj;
      
};


			//附加险代码获取
			commonCombobox_option.commonCombobox_subriskcode = {

				url : path + '/newCont/codeselect/searchsubrisk/MELI/#newContApply.riskcode',
				valueField : "riskCode",
				oneResultAuto:false,
				mutually_exclusive:true,
				// 显示在输入框的
				relateType: "vue",
				inputText : "riskName",
				textShow : [ "riskName" ]
			};
			//保险期间
			commonCombobox_option.commonCombobox_subrisk_insuyears = {
				url :  path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/insuyear',
				valueField: "paramscode",
				relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};
			//缴费期间
			commonCombobox_option.commonCombobox_subrisk_payendyears = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/payendyear',
			    valueField: "paramscode",
			    relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};

			//缴费方式
			commonCombobox_option.commonCombobox_subrisk_payintvs = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/payintv',
			    valueField: "paramscode",
			    relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};

			//红利给付方式
			commonCombobox_option.commonCombobox_subrisk_bonuspayment = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/bonuspayment',
			    valueField: "paramscode",
			    relateType: "vue",
				oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};

//预录单没有被保人
/*			//附加险险种所属 commonCombobox_subriskbelong
			commonCombobox_option.commonCombobox_subriskbelong = {
				url :  path + '/newCont/codeselect/common/subriskbelong',
				valueField : "code",
				relateType: "vue",
				oneResultAuto:false,
				// 显示在输入框的
				inputText : "codename",
				textShow : ["codename"]
			};*/
			
			//产品类型
			commonCombobox_option.commonCombobox_subrisk_producttype = {
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/producttype',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
			};

			//产品计划
			commonCombobox_option.commonCombobox_subrisk_productplanning = {
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/productplanning',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]

			};
			
			
			//备用查询
			


			//续期保费逾期
			commonCombobox_option.commonCombobox_subrisk_AutoPayFlag = {
				    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/AutoPayFlag',
				    valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
				    // 显示在输入框的
				    inputText: "paramsname",
				    // 显示在下拉列表的项，默认空，空则全部显示
				    textShow: ["paramsname"]
			};

			//自动申请续保
			commonCombobox_option.commonCombobox_subrisk_AutoRenewal = {
					
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/AutoRenewal',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
					
			};

			//申请使用优选体费用
			commonCombobox_option.commonCombobox_subrisk_PremiumRate = {
					
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/PremiumRate',
					valueField: "paramscode",
					relateType: "vue",
					oneResultAuto:false,
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
					
			};

			/**
			 * 加载险种对应的参数 加载判断
			 */
			afterVueSelect.subriskcode=function(form_element){
				var url ="/newCont/common/init/subriskcode/MELIPAPER/#newContApply.transno"; 
				
				if(this.formdata.riskcode){
					loadNewElements(this, url ,form_element);
				}
				
//				this.
					
			};
			
//			//附加险保存后
//			aftersubmitvueform.subriskcode_tabinfoform = function() {
//			 
//				 if(this.formdata.newContApply.noticeCombineID==this.formdata.newContApply.lastnoticeCombineID){
//					 
//					 
//				 }else{
//					 topvue.$set(topvue.form_elements, commonFormNotice, []);
//				 }
//				
//				
//				return true; 
//			};
			
			/**
			 * 附加险保存后
			 */
			aftersubmitvueform.subriskcode_tabinfoform = function() {
				if(!checkCRSShow.call(this)){
 
					this.$set(this.formdata.newContApply,"FATACACRS",false);
					if(this.formdata.newContApply.currentSIDIndex>4){
						this.$set(this.formdata.newContApply,"currentSIDIndex",4);
						this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
						$('#tab_FATACACRS_tabinfo').trigger("click");
					}
					
					
				}
				return true;
			};

			 