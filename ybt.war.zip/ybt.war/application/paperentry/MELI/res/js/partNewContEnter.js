var loadflag = {};

/**
 * 页面加载配置 
 */

var loadTab = [{
    "flag": true,
    "id": "basicinfo",
    "url": "/application/paperentry/MELI/jsp/LccontEnter.jsp"
}, {
    "flag": true,
    "id": "appntinfo",
    "url": "/application/paperentry/MELI/jsp/LcappntEnter.jsp"
}/*, {
    "flag": true,
    "id": "tracerinfo",
    "url": "/application/paperentry/MELI/jsp/TrancertEnter.jsp"
}, {
    "flag": true,
    "id": "Lcinsuredinfo",
    "url": "/application/paperentry/MELI/jsp/LcinsuredEnter.jsp"
}, {
    "flag": true,
    "id": "lcbnginfo",
    "url": "/application/paperentry/MELI/jsp/LcbnfEnter.jsp"
}*/, {
    "flag": true,
    "id": "kriskcode",
    "url": "/application/paperentry/MELI/jsp/KRiskEnter.jsp"
}, {
    "flag": true,
    "id": "friskcode",
    "url": "/application/paperentry/MELI/jsp/FRiskEnter.jsp"
}/*, {
    "flag": true,
    "id": "Impartcontentinfo",
    "url": "/application/paperentry/MELI/jsp/ImpartcontentEnter.jsp"
}, {
    "flag": true,
    "id": "submit",
    "url": "/application/paperentry/MELI/jsp/SubmitEnter.jsp"
}*/];
$(function () {
            $(loadTab).each(function () {
                // console.info(this.id + "--->" + this.url);
                $("a[href='#" + this.id + "']").bind('click', {
                    id: this.id,
                    url: this.url,
                    flag: this.flag
                }, tabsHandler);
                $("a[href='#" + this.id + "']").on();
            });
            $("a[href='#appntinfo']").tab('show');
            $("#tab_basicinfo").trigger("click");



});

/**
 *
 * @param event
 * @returns {Boolean}
 */
function tabsHandler(event) {
    var data = event.data;
    urlflag = data.flag;
    if (urlflag) {
        showTabs(data.id, data.url);
    } else {
        $("a[href='#" + data.id + "']").blur();
    }
    return urlflag; // 阻止默认a标签响应
}

//显示并加载
//显示并加载
function showTabs(tabsId, url) {
    $("a[href='#" + tabsId + "']").tab('show');
    var $tabContent = $('#' + tabsId);
    if (!loadflag[tabsId] || typeof(loadflag[tabsId]) == undefined) {
        $tabContent.load(path + url, function (responseTxt, statusTxt, xhr) {
        });
        loadflag[tabsId] = true;
        // console.info(tabsId + ' load done!');
    }
}

function initDate() {
    var year = new Date().getFullYear();
    var month = new Date().getMonth() + 1;
    if (month < 10) {
        month = "0" + month;
    }
    var date = new Date().getDate();
    if (date < 10) {
        date = "0" + date;
    }
    return year + "-" + month + "-" + date;
}