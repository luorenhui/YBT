var tab_d = $('#cusTable');

// 页面初始化 
$(document).ready(function() {

					var col = [
					 {
						field : 'metentid',
						title : '序号',
						formatter : function(value, row, index) {
							return index + 1;
						}
					}, {
						field : 'proposalcontno',
						title : '投保单号',
						align : 'center',
						valign : 'middle',
						visible : true,
						formatter : click,
						events : actionEvents2
					}, {
						field : 'forceuwreason',
						title : '投保日期',
						align : 'center',
						valign : 'middle'
					}, {
						field : 'grpcontno',
						title : '投保人客户号',
						align : 'center',
						valign : 'middle'
					},
					{
						field : 'riskcode',
						title : '产品代码',
						align : 'center',
						valign : 'middle',
						visible : true
					}, 
					{
						field : 'appflag',
						title : '投保单状态',
						align : 'center',
						valign : 'middle'
					},{
						field : 'premiumBudget',
						title : '保费',
						align : 'center',
						valign : 'middle'
					},{
						field : 'chargecode',
						title : '扣款状态',
						align : 'center',
						valign : 'middle'
					}, {
						field : 'cndescription',
						title : '扣款失败原因',
						align : 'center',
						valign : 'middle'
					}, {
						field : 'firsttrialtime',
						title : '扣款日期',
						align : 'center',
						valign : 'middle'
					}, {
						field : 'bankaccno',
						title : '生效日期',
						align : 'center',
						valign : 'middle'
					},{
						title : '操作',
						align : 'center',
						formatter : actionFormatter,
						events : actionEvents
					 }];

					var uniqueId = "metentid";

			$("#search").click(function() {
				$("#cusTable").bootstrapTable('destroy');
				var url_d = "/newContApply/selectCont.do";
				tableInit3(url_d, tab_d, col,uniqueId, queryParams);
			});
			

});

/**
 * 设置表格查询参数
 * 
 * @param params
 */
function queryParams(params) {
	// 设置查询参数
	var param = {
		limit : params.limit,
		offset : params.offset,
//		transactionNo : $("#transactionNo").val().trim(),
		grpcontNo : $("#grpcontNo").val().trim(),
		contNo : $("#contNo").val().trim(),
		tBRBirth : $("#tBRBirth").val(),
		appflag : $("#appStatus").val()
	};
	return param;
}

/**
 * 翻页带查询参数及列排序
 */
function tableInit3(url, obj, col, uniqueId,queryParams) {
	obj.bootstrapTable({
		url : path + url, // 请求后台的URL（*）
		dataType : "json",
		method : 'post', // 请求方式（*）
		contentType : "application/x-www-form-urlencoded",
		toolbar : '#toolbar',
		columns : col,
		striped : true, // 是否显示行间隔色
		cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		pagination : true, // 是否显示分页（*）
		queryParamsType : "limit",// undefined/limit
		queryParams : queryParams,// 传递参数（*）
		sidePagination : "server", //
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		strictSearch : true,// 设置为 true启用 全匹配搜索，否则为模糊搜索
		showColumns : true, // 是否显示所有的列
		showRefresh : true, // 是否显示刷新按钮
		minimumCountColumns : 2, // 最少允许的列数
		clickToSelect : false, // 是否启用点击选中行
		// height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		// uniqueId: "ID", // 每一行的唯一标识，一般为主键列
		uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
		showToggle : true, // 是否显示详细视图和列表视图的切换按钮
		cardView : false, // 是否显示详细视图
		detailView : false
	});
};

function actionFormatter(value, row, index) {
	return ["<select style='width: 120px;' class='ss form-control' id='selectOpt"+index+ "' >"+
				"<option>请选择</option>"+
				"<option>操作</option>"+
				"<option>取消</option>"+
				"<option>扣款查询</option>"+
			"</select>"].join('');
};


function click(value, row, index){
	return '<a class="blue" style="text-decoration:underline;"><span style="cursor:pointer">'+row.proposalcontno+'</span></a>';
};

window.actionEvents2 = {
		
		'click .blue' : function(e, value, row, index) {
//			console.log(row);
			//window.location.href="partNewContEnter.jsp?flag=3&transno="+row.transno;
            var lccontParm={
                grpcontno:row.grpcontno,
                insurancecom:row.insurancecom,
                riskcode:row.riskcode,
                parm:"",
                flag:"3",
                transno:row.transno
            }
            //window.location.href="partNewContEnter.jsp?flag=2&transno="+row.transno;
            window.location.href=path+"/newContenter/toLccont.do?lccontParm="+encodeURI(JSON.stringify(lccontParm));
		}
		
		
};

window.actionEvents = {
		'change  .ss' : function(e, value, row, index) {
//			console.log(index);
			 var selectedVal = $("#selectOpt"+index).val();
//			 alert(selectedVal);
			 if(selectedVal == "请选择"){
//				 alert("请选择要操作的选项!");
				 return;
			 }else if(selectedVal == "取消"){
				 var r=confirm("您将进行保单取消操作");
					if (r==true)
					{
						$.ajax({
							url  : path + "/newContApply/cancel.do",
							type : "POST",
							data : {"transno":row.transno},
							dataType : "json",
							success : function(data) {
								alert(data.msg);
								if(data.success==true){
									  $('#cusTable').bootstrapTable('refresh');
									
								}
							},
							error : function() {
								alert("投保单取消失败!");
							}
						});
					}else{
//						$("#selectOpt"+index).val("请选择");
						$("#selectOpt"+index)[0].selectedIndex = 0;
						return;
					}
			 }else if(selectedVal == "操作"){
                 $.ajax({
                     url: path + '/newContEnter/selectBylccont.do',
                     type: "POST",
                     async: false,
                     data: {"transno": row.transno},
                     success: function (data) {
						if(data.appflag=="01"){
                            var newDate=initDate();
                            if(dateToString(row.polapplydate)==newDate){
                                if(confirm("您确定要进行继续操作吗?")){
                                    $.ajax({  //试算查询页面状态
                                        type : "POST",
                                        url:path + '/newContEnter/selectStateOfPage.do', // 后台请求URL地址
                                        data : {"proposalcontno":row.proposalcontno},
                                        dataType : "json",
                                        success:function(data) {
                                            if(data!=null){
                                                if(data.success==true){ //数据正确，返回按钮状态
                                                    if(data.parm=="P0"){
                                                        alert("此单状态为"+row.appflag+"已经不能再继续录入!");
                                                    }else{

                                                    	var lccontParm={
                                                                grpcontno:row.grpcontno,
                                                                insurancecom:row.insurancecom,
                                                                riskcode:row.riskcode,
                                                                parm:"",
                                                                flag:"2",
                                                                transno:row.transno
														}
                                                        //window.location.href="partNewContEnter.jsp?flag=2&transno="+row.transno;
														window.location.href=path+"/newContenter/toLccont.do?lccontParm="+encodeURI(JSON.stringify(lccontParm));
                                                    }
                                                }else{ //数据不正确，不能进行操作
                                                    alert("页面跳转出错，"+data.msg);
                                                }
                                            }
                                        }
                                    });
                                }else{
                                    $("#selectOpt"+index)[0].selectedIndex = 0;
                                    return;
                                }
                            }else{
                                if(confirm("此保单非当日录入，继续操作则会更新投保日期为当日日期，是否继续操作？")){
                                    $.ajax({  //试算查询页面状态
                                        type : "POST",
                                        url:path + '/newContEnter/selectStateOfPage.do', // 后台请求URL地址
                                        data : {"proposalcontno":row.proposalcontno},
                                        dataType : "json",
                                        success:function(data) {
                                            if(data!=null){
                                                if(data.success==true){ //数据正确，返回按钮状态
                                                    if(data.parm=="P0"){
                                                        alert("此单状态为"+row.appflag+"已经不能再继续录入!");
                                                    }else{
                                                        $.ajax({  //试算查询页面状态
                                                            type : "POST",
                                                            url:path + '/newContEnter/updatePolDate.do', // 后台请求URL地址
                                                            data : {"transno":row.transno},
                                                            dataType : "json",
                                                            success:function(data) {
                                                                if(data.success==true){
                                                                    var lccontParm={
                                                                        grpcontno:row.grpcontno,
                                                                        insurancecom:row.insurancecom,
                                                                        riskcode:row.riskcode,
                                                                        parm:"",
                                                                        flag:"2",
                                                                        transno:row.transno
                                                                    }
                                                                    //window.location.href="partNewContEnter.jsp?flag=2&transno="+row.transno;
                                                                    window.location.href=path+"/newContenter/toLccont.do?lccontParm="+encodeURI(JSON.stringify(lccontParm));
                                                                   // window.location.href="partNewContEnter.jsp?flag=2&transno="+row.transno;
                                                                }else{
                                                                    alert("出现异常");
                                                                }
                                                            }
                                                        });

                                                    }
                                                }else{ //数据不正确，不能进行操作
                                                    alert("页面跳转出错，"+data.msg);
                                                }
                                            }
                                        }
                                    });

                                }else{
                                    $("#selectOpt"+index)[0].selectedIndex = 0;
                                    return;
                                }
                            }
						}else{
                            if(confirm("您确定要进行继续操作吗?")){
                                $.ajax({  //试算查询页面状态
                                    type : "POST",
                                    url:path + '/newContEnter/selectStateOfPage.do', // 后台请求URL地址
                                    data : {"proposalcontno":row.proposalcontno},
                                    dataType : "json",
                                    success:function(data) {
                                        if(data!=null){
                                            if(data.success==true){ //数据正确，返回按钮状态
                                                if(data.parm=="P0"){
                                                    alert("此单状态为"+row.appflag+"已经不能再继续录入!");
                                                }else{
                                                    window.location.href="partNewContEnter.jsp?flag=2&transno="+row.transno;
                                                }
                                            }else{ //数据不正确，不能进行操作
                                                alert("页面跳转出错，"+data.msg);
                                            }
                                        }
                                    }
                                });
                            }else{
                                $("#selectOpt"+index)[0].selectedIndex = 0;
                                return;
                            }
						}
                     }
                 });


			 }else if(selectedVal == "扣款查询"){
				 if(confirm("您确定要扣款查询吗?")){
					 var chargeCode = row.acctType;
					 if(chargeCode=='E'){
						 show();
						 $.ajax({  //试算查询页面状态
								type : "POST",
								url:path + '/debitQueryController/debitQuery.do', // 后台请求URL地址  
								data : {"proposalContno":row.proposalcontno,
										"familyID":row.familyid,
										"chargeCode":row.acctType,
										"manageCom":row.managecom},
								dataType : "json",
								success:function(data) {
									closed();
									alert(data.msg);
									 $('#cusTable').bootstrapTable('refresh');
								},
								error:function(){
									closed();
									alert("查询扣款失败!");
								}
						});
						 
						 
						 
					 }else{
						 alert("此单状态为:"+row.chargecode+" 不能执行扣款查询!");
					 }
				 }else{
					 $("#selectOpt"+index)[0].selectedIndex = 0; 
					 return;
				 }
			 }
			 
			
		}
		
		
//		'selected .operator' : function(e, value, row, index) {
//			
//			/*if(row.tempfeeno == '01' || row.tempfeeno == null || 
//					row.tempfeeno == '02' || row.tempfeeno == '10' ||
//					row.tempfeeno == '03'){
//				window.location.href="partNewContEnter.jsp?flag=2&transno="+row.transno;
//			}else{
//				alert("此单状态为"+row.appflag+"已经不能再继续录入!");
//				return;
//			}*/
//			
//			
//		},
//		//您将进行保单取消操作
//		'click .cancel' : function(e, value, row, index) {
//				
//		
//			
//		}
		
};



function initDate() {
    var year = new Date().getFullYear();
    var month = new Date().getMonth() + 1;
    if (month < 10) {
        month = "0" + month;
    }
    var date = new Date().getDate();
    if (date < 10) {
        date = "0" + date;
    }
    return year + "-" + month + "-" + date;
}















//$(function() {
//	$("#add").click(
//			function() {
//
//				var bankName = $("#bankName").val();
//				var salesChl = $("#salesChl").val();
//				var tContNo = $("#contNo").val();
//				var riskCode = $("#riskCode").val();
//
//				// alert(bankName+"="+salesChl+"="+tContNo+"="+riskCode);
//
//				var url = "partNewContEnter.jsp?bankName=" + bankName
//						+ "&salesChl=" + salesChl + "&tContNo=" + tContNo
//						+ "&riskCode=" + riskCode;
//				toadd(url);
//			});
//});
