//被保人与投保人的关系
var relationtoappnt1 = {
    url: path + '/LdcodeController/selectLcodeByCodetype.do?codetype=relationformanu',
    valueField: "code",
    // 显示在输入框的
    inputText: "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["codename"],
    afterselect: function () {
        if ($("#relationtoappnt").val() == "00") {
            $.ajax({
                url: path + '/lcinsuredController/selectBylcinsured.do',
                type: "POST",
                data: {"transno": vueobj["lccontdivchange"].formdata.lccont.transno},
                success: function (data) {
                    vueobj["Lcinsureddivchange"].$set(vueobj["Lcinsureddivchange"].formdata, "lcinsured", data.formdata.lcinsured);
                    vueobj["Lcinsureddivchange"].$set(vueobj["Lcinsureddivchange"].formdata, "lcaddress", data.formdata.lcaddress);

                }
            });
        } else {
            vueobj["Lcinsureddivchange"].$set(vueobj["Lcinsureddivchange"].formdata, "lcinsured", "");
            vueobj["Lcinsureddivchange"].$set(vueobj["Lcinsureddivchange"].formdata, "lcaddress", "");
        }
    }

};

function lcinsuredinit() {
    initData($("#Lcinsureddivchange"));

    $("#Lcinsureddivchange").find('input[checkboxoption]').each(function (i) {
        var obj = $(this);
        console.log(obj);
        var checkboxoption = obj.attr("checkboxoption");
        var index = checkboxoption.indexOf("commonCombobox_");

        try {
            if (index >= 0) {
                obj.combobox(commonCombobox_option[checkboxoption]);
            } else {
                obj.combobox($.parseJSON(checkboxoption));
            }
        } catch (e) {
            console.log('error init combobox  id:', obj, ', checkboxoption:', checkboxoption);
        }
    });
    $('.i-checks').iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-green',
    });
    $("#relationtoappnt").combobox(relationtoappnt1);
    $("#lcinsuredidtype").combobox(idtype);
    $("#lcinsuredsex").combobox(appntsex);
    $("#lcinsurednativeplace").combobox(nativeplace);
    $("#lcinsuredroccupationcode").combobox(occupationcode);

}

vue_config.push({
    id: "Lcinsureddivchange",
    url: path + "/lcinsuredController/selNewCont/" + data.insurancecom + "/lcinsured.do?lccontParm=" + encodeURI(JSON.stringify(data)),
    initFunction: lcinsuredinit
});


function addLcinsured() {
    data.transno = vueobj["lccontdivchange"].formdata.lccont.transno;
    $.ajax({
        type: "POST",
        url: path + "/lcinsuredController/saveLcinsuredData/" + data.insurancecom + ".do",
        data: {
            "lccontParm": JSON.stringify(data),
            "lcinsuredFormdata": JSON.stringify(vueobj["Lcinsureddivchange"].formdata)
        },
        error: function (request) {
            alert("Connection error");
        },
        success: function (data) {
            alert(data.msg);
        }
    });
}