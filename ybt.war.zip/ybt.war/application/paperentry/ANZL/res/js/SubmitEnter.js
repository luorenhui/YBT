var lanmuid=null;



function pageinit(  ) {
    initData($("#subEnterdivchange"));

    /****/
    $("#subEnterdivchange").find('input[checkboxoption]').each(function(i){
        var obj = $(this);
        console.log(obj);
        var checkboxoption = obj.attr("checkboxoption");
        var index = checkboxoption.indexOf("commonCombobox_");

        try {
            if(index>=0){
                ;
                obj.combobox(commonCombobox_option[checkboxoption]);
            }else{
                obj.combobox($.parseJSON(checkboxoption));
            }
        } catch (e) {
            console.log('error init combobox  id:', obj, ', checkboxoption:', checkboxoption);
        }


    });

    $('.i-checks').iCheck({
        checkboxClass : 'icheckbox_square-green',
        radioClass : 'iradio_square-green',
    });
}


function initTest() {
    initData($("#subEnterdivchange"));
}
vue_config.push({id : "subEnterdivchange", url : path + "/submitController/selNewCont/"+data.insurancecom+"/submit.do?lccontParm="+encodeURI(JSON.stringify(data)),initFunction:pageinit});

