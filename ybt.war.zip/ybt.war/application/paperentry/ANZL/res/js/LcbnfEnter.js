var getform={
    valueField : "code",
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ],
    data:[{
        code:'N',
        codename:'指定'
    },{
        code:'Y',
        codename:'法定'
    }]
}
var bnfno={
    valueField : "code",
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ],
    data:[{
        code:'1',
        codename:'1'
    },{
        code:'2',
        codename:'2'
    },{
        code:'3',
        codename:'3'
    }]
}


function pageinit() {
    initData($("#Lcbnfdivchange"));
    $("#Lcbnfdivchange").find('input[checkboxoption]').each(function(i){
        var obj = $(this);
        console.log(obj);
        var checkboxoption = obj.attr("checkboxoption");
        var index = checkboxoption.indexOf("commonCombobox_");

        try {
            if(index>=0){
                ;
                obj.combobox(commonCombobox_option[checkboxoption]);
            }else{
                obj.combobox($.parseJSON(checkboxoption));
            }
        } catch (e) {
            console.log('error init combobox  id:', obj, ', checkboxoption:', checkboxoption);
        }


    });

    $('.i-checks').iCheck({
        checkboxClass : 'icheckbox_square-green',
        radioClass : 'iradio_square-green',
    });
    $("#getform").combobox(getform);
    $("#bnfno").combobox(bnfno);
    $("#sex").combobox(appntsex);
    $("#idtype").combobox(idtype);
    $("#relationtoinsured").combobox(relationtoappnt);
}
vue_config.push({id : "Lcbnfdivchange", url : path + "/lcbnfController/selNewCont/"+data.insurancecom+"/lcbnf.do?lccontParm="+encodeURI(JSON.stringify(data)),initFunction:pageinit});

