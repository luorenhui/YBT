////代理人
//commonCombobox_option.commonCombobox_agentcodeaxa = {
//		url: path + '/axa/quotation/getagent/#departmentcodeaxa.do',
//		valueField : "agentid",
//		inputText : "agentname",
//		textShow :["agentname"]
//};
commonCombobox_option.commonCombobox_banksccflag = {
	"data" : [ {
		"value" : "N",
		"text" : "否"
	}, {
		"value" : "Y",
		"text" : "是"
	} ]
};
commonCombobox_option.commonCombobox_bankcustomertype = {

	url : path + '/newCont/codeselect/common/bankcustomertype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText :  "codename" ,
	textShow : [ "codename" ]

};
//是否是汇丰工作人员  
commonCombobox_option.commonCombobox_ishsbcclerklccont = {
		"data" : [ {
			"value" : "0",
			"text" : "否"
		}, {
			"value" : "1",
			"text" : "是"
		} ]
};
//保单递送方式
commonCombobox_option.commonCombobox_getpolmode = {
		"data" : [ {
			"value" : "1",
			"text" : "行内领取"
		} ]
};
//保单递送方式
commonCombobox_option.commonCombobox_getpolmodepa = {
		"data" : [ {
			"value" : "2",
			"text" : "电子保单"
		} ]
};
//保单递送方式
commonCombobox_option.commonCombobox_getpolmodeic = {
		"data" : [ {
			"value" : "2",
			"text" : "电子保单"
		} ,{
			"value" : "1",
			"text" : "行内领取"
		}]
};
//业务员
commonCombobox_option.commonCombobox_salenameaxa = {
		url: path + '/axa/quotation/getagent/#departmentcodeaxa.do',
		valueField : "salecode",
		inputText : "salename",
		textShow :["salename"]
};
//证件类型
commonCombobox_option.commonCombobox_IDtype = {
		url : path + '/newCont/codeselect/common/axaidtype',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText : "codename",
		textShow : [ "codename" ]
};
//证件类型@IC
commonCombobox_option.commonCombobox_IDtypeaxa = {
		url : path + '/newCont/codeselect/common/axaidtype1',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText : "codename",
		textShow : [ "codename" ]
};
//性别
commonCombobox_option.commonCombobox_sex = {
		"data" : [ {
			"value" : "1",
			"text" : "男性"
		},{
			"value" : "2",
			"text" : "女性"
		},{
			"value" : "0",
			"text" : "未知的性别"
		},{
			"value" : "9",
			"text" : "未说明的性别"
		}]
};
//性别@IC
commonCombobox_option.commonCombobox_sexaxa = {
		url : path + '/newCont/codeselect/common/sexaxa',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText : "codename",
		textShow : [ "codename" ]
};
//婚姻状况
commonCombobox_option.commonCombobox_marry = {
		"data" : [ {
			"value" : "1",
			"text" : "单身"
		}, {
			"value" : "2",
			"text" : "已婚"
		} ]
};
//电话类型
commonCombobox_option.commonCombobox_phonetype = {
		"data" : [ {
			"value" : "1",
			"text" : "家庭座机"
		}, {
			"value" : "2",
			"text" : "单位座机"
		}, {
			"value" : "3",
			"text" : "手机号码"
		} ]/*,
		afterselect : function(){
			if($('#phonetypeaxa').val() == ""){
				$('#phonenumber').attr("disabled",true);
				$('#phonenumber').val("");
			}else{
				$('#phonenumber').removeAttr("disabled");
			}
		}*/
};
//行业代码
commonCombobox_option.commonCombobox_appntoccupationaxa = {
	url : path + '/newCont/codeselect/occupationaxa/axacode1.do',
	valueField : "code",
	delayLoadDataFlag : true,
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//职业代码
commonCombobox_option.commonCombobox_appntoccupationaxa2 = {
	url : path + '/newCont/codeselect/occupationaxa/axacode2/#appntoccupationaxa.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
 
//职位代码
commonCombobox_option.commonCombobox_appntoccupationaxa3 = {
	url : path + '/newCont/codeselect/occupationaxa/axacode3/#appntoccupationaxa2.do',
	valueField : "code",
	// 显示在输入框的
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ]
};
//您目前在中国是
commonCombobox_option.commonCombobox_inchinaforaxa = {
		"data" : [ {
			"value" : "1",
			"text" : "工作"
		}, {
			"value" : "2",
			"text" : "生活"
		},{
			"value" : "3",
			"text" : "学习"
		}]
};
////保单币种
//commonCombobox_option.commonCombobox_currencytype = {
//		"data" : [ {
//			"value" : "01",
//			"text" : "人民币" 
//		}, {
//			"value" : "04",
//			"text" : "美元"
//		} ]
//};
//是否是汇丰工作人员
commonCombobox_option.commonCombobox_ishsbcclerk = {
		"data" : [ {
			"value" : "0",
			"text" : "否"
		}, {
			"value" : "1",
			"text" : "是"
		} ]
};
//通讯地址
//省/直辖市
commonCombobox_option.commonCombobox_appntpostprovince = {
		url :  path + '/newCont/codeselect/common/areacodeaxa/0.do',
		valueField : "id",
		// 显示在输入框的
		inputText : "idname",
		textShow : [ "idname" ]
};
//市
commonCombobox_option.commonCombobox_appntpostcity = {
		url :  path + '/newCont/codeselect/common/areacodeaxa/#appntpostprovinceaxa.do',
		valueField : "id",
		// 显示在输入框的
		inputText : "idname",
		textShow : [ "idname" ] 
};
//区/县
commonCombobox_option.commonCombobox_appntpostdistrict = {
		url :  path + '/newCont/codeselect/common/areacodeaxa/#appntpostcityaxa.do',
		valueField : "id",
		// 显示在输入框的
		inputText : "idname",
		textShow : [ "idname" ]
};

//中国居住地址
//省/直辖市
commonCombobox_option.commonCombobox_appnthomeprovince = {
		url :  path + '/newCont/codeselect/common/areacodeaxa/0.do',
		valueField : "id",
		// 显示在输入框的
		inputText : "idname",
		textShow : [ "idname" ]
};
//市
commonCombobox_option.commonCombobox_appnthomecity = {
		url :  path + '/newCont/codeselect/common/areacodeaxa/#homeprovince.do',
		valueField : "id",
		// 显示在输入框的
		inputText : "idname",
		textShow : [ "idname" ] 
};
//区/县
commonCombobox_option.commonCombobox_appnthomedistrict = {
		url :  path + '/newCont/codeselect/common/areacodeaxa/#homecity.do',
		valueField : "id",
		// 显示在输入框的
		inputText : "idname",
		textShow : [ "idname" ]
};

//投保人信息成功保存后， 校验投保单号
afterloadNewElements.lccont_tabinfoform = function(){
	var recording = initFormdata.newContApply.recording;	
	console.log("***checking Recording flag***=======" + recording);
	if(recording == "Y"){
		console.log("***current Recording changing operation***");
		var topvue = getTopvueObj(this);
		topvue.form_elementsBYID.lccont.proposalcontno.cssClass = "disabled";
		$("#proposalcontno").attr("disabled",true);
		console.log("***diabled proposalcontno***");
	}
	console.log("***aftersubmitvueform.lcappnt_tabinfoform***");
	return true;
}

/**
 * 投保人 通讯地址同 居住地址
 */
afterVueSelect.postaddressflagaxa = function(form_element) {
	
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (obj.is("[type='checkbox']:checked")) {

		for ( var key in topvue.form_elements.lcappnt) {
			if (topvue.form_elements.lcappnt[key].name == 'postprovince') {
				bindSameElement.call(this, this.formdata, "homeprovince",
						this.formdata, "postprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postcity') {
				bindSameElement.call(this, this.formdata, "homecity",
						this.formdata, "postcity",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'postdistrict') {
				bindSameElement.call(this, this.formdata, "homedistrict",
						this.formdata, "postdistrict",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'postaladdress') {
				bindSameElement.call(this, this.formdata, "homeaddress",
						this.formdata, "postaladdress",
						topvue.form_elements.lcappnt[key]);

			}
			if (topvue.form_elements.lcappnt[key].name == 'zipcode') {
				bindSameElement.call(this, this.formdata, "homezipcode",
						this.formdata, "zipcode",
						topvue.form_elements.lcappnt[key]);

			}

		}
	} else {
		for ( var key in topvue.form_elements.lcappnt) {
			
			if (topvue.form_elements.lcappnt[key].name == 'postprovince') {
				unbindSameElement.call(this, "homeprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postcity') {
				unbindSameElement.call(this, "homecity",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postdistrict') {
				unbindSameElement.call(this, "homedistrict",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'postaladdress') {
				unbindSameElement.call(this, "homeaddress",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'zipcode') {
				unbindSameElement.call(this, "homezipcode",
						topvue.form_elements.lcappnt[key]);

			}

		}
		

	}

};
beforesubmitvueform.lccont_tabinfoform = function() {
	var topvue = getTopvueObj(this);
	var riskcode = vueobj["testdivchange"].formdata.lccont.riskcode;
	if(riskcode=="@PA"){
		var idno = vueobj["testdivchange"].formdata.lcappnt.idno;
		if($('#idtypeaxa').val() == '01'){
			if(!validateId(idno)){
				return false;
			}
		}else{
		}
		
	}
	// if(!(new Date(topvue.formdata.lcappnt.appntenddate)>new Date())){
	// 	alert("证件有效期必须大于今天");
	// 	return false;
	// }
//	var formdata=vueobj["testdivchange"].formdata;
//	var agentid = vueobj["testdivchange"].formdata.axalcappnt.agentcodeaxa;
//	var salename = vueobj["testdivchange"].formdata.axalcappnt.salenameaxa;
//	if(salename == null){
//		$.ajax({
//			url : path+'/axa/quotation/getsalename/branch.do',
//			type : "POST",
//			data : {"branch" : formdata.lccont.companyCode},
//			async: false,
//			success : function(data){
//				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.axalcappnt,"salenameaxa", data.salecode);
//			},
//			
//		});
//	}
	return true;
}
function validateId(id){
    var city={11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江 ",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北 ",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏 ",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外 "};
    var tip = "";
    var pass= true;
    var code = id;
    if(!code || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(code)){
        tip = "身份证号格式错误";
        pass = false;
    }

   else if(!city[code.substr(0,2)]){
        tip = "身份证号格式错误";
        pass = false;
    }
    else{
        //18位身份证需要验证最后一位校验位
        if(code.length == 18){
            code = code.split('');
            //∑(ai×Wi)(mod 11)
            //加权因子
            var factor = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 ];
            //校验位
            var parity = [ 1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2 ];
            var sum = 0;
            var ai = 0;
            var wi = 0;
            for (var i = 0; i < 17; i++)
            {
                ai = code[i];
                wi = factor[i];
                sum += ai * wi;
            }
            var last = parity[sum % 11];
            if(parity[sum % 11] != code[17]){
                tip = "身份证号格式错误";
                pass =false;
            }
        }
    }
    if(!pass){
    	alert(tip);
    	return false;
    }else{
    	return true;
    }
}
var paperShowdilog= "";
function printAXAPaper() {
	var insurancecom=vueobj["testdivchange"].formdata.lccont.insurancecom;
	var riskcode=vueobj["testdivchange"].formdata.lccont.riskcode;
	var appntname=vueobj["testdivchange"].formdata.lcappnt.appntname;
	var appntsex=vueobj["testdivchange"].formdata.lcappnt.appntsex;
	var appntbirthday=vueobj["testdivchange"].formdata.lcappnt.appntbirthday;
	var nativeplace=vueobj["testdivchange"].formdata.lcappnt.nativeplace;
	var idtype=vueobj["testdivchange"].formdata.lcappnt.idtype;
	var idno=vueobj["testdivchange"].formdata.lcappnt.idno;
	console.log("riskcode:" + riskcode);
	console.log("appntname:" + appntname);
	console.log("appntsex:" + appntsex);
	console.log("appntbirthday:" + appntbirthday);
	console.log("nativeplace:" + nativeplace);
	console.log("idtype:" + idtype);
	console.log("idno:" + idno);
	var getAxaPdfNameUrl= path+"/PaperPrintController/getAxaPdfName.do";
	var printUrl= path+"/PaperPrintController/printAXA.do";
	var axaPdfName = "";
	$.ajax({
		type : "POST",
		url: getAxaPdfNameUrl,
		data: {
		},
		success:function(data) {
			if(data.success){
				axaPdfName = data.msg;
				if(confirm("您确定要打印投保单号："+axaPdfName+"?")){
					//打开遮罩层
					paperShowdilog= layer.load(0, {
						shade: [0.1,'#fff'] //0.1透明度的白色背景
					});
					$.ajax({
						type : "POST",
						url: printUrl,
						data: {
							"insurancecom":insurancecom,
							"riskcode":riskcode,
							"appntname":appntname,
							"appntsex":appntsex,
							"appntbirthday":appntbirthday,
							"nativeplace":nativeplace,
							"idtype":idtype,
							"idno":idno,
							"axaPdfName":axaPdfName
						},
						success:function(data) {
							if(data.success){
								vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"printPolicyFlag", "Y");
								vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"printPolicyFlag","Y");
								vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"axaPdfName",axaPdfName);
								vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"axaPdfName",axaPdfName);
								//新开网页打开pdf
								var readUrl= path+"/PaperPrintController/readAXAPDF.do?axaPdfName=" + axaPdfName;

								if (!!window.ActiveXObject || "ActiveXObject" in window){
									//ie
									window.open('javascript:window.name;', '<script>window.location.replace("'+readUrl+'")<\/script>');
								}else{
									//google
									window.open(readUrl,"_blank");
								}
								layer.close(paperShowdilog);
							}else{
								layer.close(paperShowdilog);
								layer.alert("投保单生成失败!");
							}

						},
						error: function(){
							layer.close(paperShowdilog);
							layer.alert("系统异常");
						}
					});
				}
			}

		},
		error: function(){
			alert("系统异常");
		}
	});
}