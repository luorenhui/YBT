var lanmuid=null;

var insurancecom = {
    url : path + '/newContEnter/selectFromLacom.do',
    valueField : "agentcom",
    // 显示在输入框的
    inputText : "name",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["name" ],
    textShowFormat : function(showText, data)
    {
        return data.agentcom + "-" + data.name;
    }
};
var anotherHolderIdType={
    url:path + '/LdcodeController/selectIdTypeByCodetype.do?codetype=idtype',
    valueField : "code",
    // 显示在输入框的
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ]
}

var getpolmode={
    valueField : "code",
    inputText : "codename",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["codename" ],
    data:[/*{
        code:'1',
        codename:'快递递送'
    },*/{
        code:'2',
        codename:'电子保单'
    }]
}
var newbankaccno = {
    url : path + '/newContApp/selectAccNo/#grpcontno.do',
    valueField : "accountnumber",
    // 显示在输入框的
    inputText : "accountnumber",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow : ["accountnumber" ],
    rebuildflag : true,
    afterselect :function(){
        var newbankaccno=$("#newbankaccno").val();
        $.ajax({
            url:path + '/newContEnter/selectaccountbalance.do',
            type: "POST",
            data:{"newbankaccno":newbankaccno},
            success: function(data){
                vueobj["lccontdivchange"].$set(vueobj["lccontdivchange"].formdata.lccont, "accountbalance",data.accountbalance);
            }
        })
    }
};

var tempflag = true;
function pageinit(  ) {
    if(tempflag){
    initData($("#lccontdivchange"));
    /****/
    $("#lccontdivchange").find('input[checkboxoption]').each(function(i){

        var obj = $(this);
        console.log(obj);
        var checkboxoption = obj.attr("checkboxoption");
        var index = checkboxoption.indexOf("commonCombobox_");

        try {
            if(index>=0){
                ;
                obj.combobox(commonCombobox_option[checkboxoption]);
            }else{
                obj.combobox($.parseJSON(checkboxoption));
            }
        } catch (e) {
            console.log('error init combobox  id:', obj, ', checkboxoption:', checkboxoption);
        }
    });

    $('.i-checks').iCheck({
        checkboxClass : 'icheckbox_square-green',
        radioClass : 'iradio_square-green',
    });

    $('#insurancecom').combobox(insurancecom);
    $("#getpolmode").combobox(getpolmode);
    $("#newbankaccno").combobox(newbankaccno);
        vueobj["lccontdivchange"].$set(vueobj["lccontdivchange"].formdata.lccont, "polapplydate",dateToString(Number($("#polapplydate").val())));
        tempflag = false;
    $("#anotherHolderIdType").combobox(anotherHolderIdType);
    }
}


function afterRowEdit(element, row, index) {
    if (element.attr("id") == "table_keyword") {

        var data = element.bootstrapTable("getData");
        var rows = $('#tablebatch').bootstrapTable("getSelections");

        for (var i = 0; i < rows.length; i++) {
            rows[i].monitorLevel[0].keywords = data;
            $('#tablebatch').bootstrapTable("updateRow", {
                index : rows[i]._row_index,
                row : rows[i]
            });
        }
    }

}

alert(data.insurancecom);
vue_config.push({id : "lccontdivchange", url : path + "/lccontController/selNewCont/"+data.insurancecom+"/lccont.do?lccontParm="+encodeURI(JSON.stringify(data)),initFunction:pageinit});


