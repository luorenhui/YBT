var tab_d = $('#cusTable');

// 页面初始化
$(document).ready(function() { 

	$("#grpcontno").val(grpcontno);
	
	//查询保险公司
	$.ajax({
		 url:path + '/newContEnter/selectFromLacomByAgentcom.do',  
        type: "POST",
        data:{"agentcom":insuranceCom},
		 success: function(data){ 
			 if(data!=null){
				 $("#insuCom").val(data.agentcom + '-' +data.name);
				 //如果存在这个保险公司，查询出该保险公司对对应的产品
				 selectLmriskByInsuranceCom();
			 }else{
				 $("#insuCom").val(insuranceCom);
				 alert("未查询到该保险公司："+insuranceCom);
			 }
		 }
	});
		
	function selectLmriskByInsuranceCom(){
		$.ajax({
		   url:path + '/newContEnter/mateLmrisk.do',  
	       type: "POST",
	       data:{"insurancecom":insuranceCom,"riskcode":riskcode},
		   success: function(data){
				 //如果匹配上
				 if(data.success){
					 $("#riskcode").val(riskcode + '-' +data.msg);
				 }else{
					 if(riskcode!=null && riskcode !="" && riskcode !="null"){
						 $("#riskcode").val(riskcode);
					 }
					 alert(data.msg);
				 }
			 }
		});
	}
	
	
//信息预览，跳转预录单页面
$("#preview").click(function(){
	
	shows1();
	if(insuranceCom=="INSH"){
		$.ajax({
			type : "POST",
			async: false,
			url:path+"/QueryCifController/workingTime.do",// 后台请求URL地址
			dataType : "json",
			success : function(data) {
				if(!data.success){
					if(data.parm && data.parm=="warn"){
						layer.confirm( data.msg, {
				  			  btn: ['确认','取消'], //按钮
				  			  title:"系统提示",
				  			  closeBtn:false
				  			}, function(confirmIndex){
				  					layer.close(confirmIndex);
				  					closeds1();
				  					payment();
				  				}, function(){
				  					closeds1();
				  				});					
					}else if(data.parm&&data.parm=="refuse"){
						layer.alert(data.msg, {closeBtn: false});
						closeds1();
						return;	
					 }
				}else{
					closeds1();
	  				payment();
				}
			},
			error:function(data){
				alert("系统异常");
				closeds1();
			}
			});
	}else{
		closeds1();
		payment();
	}
});
	
    var col = [
        {
            field : 'metentid',
            title : '序号',
            formatter : function(value, row, index) {
                return index + 1;
            }
        }, 
        {
            title : '操作',
            align : 'center',
            formatter : actionFormatter,
            events : actionEvents
        },
        {
            field : 'proposalcontno',
            title : '投保单号',
            align : 'center',
            valign : 'middle',
            visible : true
        },{
            field : 'transno',
            title : '流水号',
            align : 'center',
            valign : 'middle',
            visible : false
        }, {
            field : 'polapplydate',
            title : '投保日期',
            align : 'center',
            valign : 'middle',
            visible : false
        },{
            field : 'grpcontno',
            title : '投保人客户号',
            align : 'center',
            valign : 'middle'
        },
        {
            field : 'insurancecom',
            title : '保险公司代码',
            align : 'center',
            valign : 'middle'
        },{
            field : 'riskcode',
            title : '产品代码',
            align : 'center',
            valign : 'middle',
            visible : true
        },{
            field : 'makedate',
            title : '创建日期',
            align : 'center',
            valign : 'middle',
            visible : true
        }];

    var uniqueId = "metentid";

    $("#search").click(function() {
        $("#cusTable").bootstrapTable('destroy');
        var url_d = "/newContApply/getContPapper.do";
        tableInit(url_d, tab_d, col, uniqueId, queryParams);
    });


});

function payment(){
	
	var url = path+"/newCont/enter/"+ insuranceCom +"/"+ riskcode +"/"+ grpcontno+".do" +
			"?recording=N" + "&orderID="+ orderID + "&reportID=" + reportID 
			+ "&recordID=" + recordID + "&FPRID=" + FPRID
			+ "&prdTypeCode=" + prdTypeCode + "&prdSubTypeCode=" + prdSubTypeCode
			+ "&prdAlternativeNumber=" + prdAlternativeNumber
			+ "&prdClassificationCode=" + prdClassificationCode
			+ "&countryTradableCode=" + countryTradableCode
			+ "&customerIndicator=" + customerIndicator
			+ "&applicationId=" + applicationId
			+ "&quotationId=" + quotationId
			+ "&shoppingCartIndicator=" + shoppingCartIndicator
			+ "&remoteSalesIndicator=" + remoteSalesIndicator
			+ "&paper=PAPER" + "&enterWay=" + enterWay; 
	window.location.href = url;
	
	/*shows1();
	$(function(){
		$.ajax({
		type : "POST",
		url:path+"/QueryCifController/queryCif.do",// 后台请求URL地址
		data : {"bankName":grpcontno,"YH":riskcode,"BX":insuranceCom,"GoalSequenceNumber":GoalSequenceNumber,"GoalId":GoalId},
		dataType : "json",
		success : function(data) {
			closeds1();
			if(data.success==false){
				alert(data.msg);
				return;
			}else{
				var parm="";
				$.ajax({
				type : "POST",
				async: false,
				url:path+"/newContEnter/selectpower.do",// 后台请求URL地址
				data : {"grpcontno":grpcontno,"insurancecom":insuranceCom,"riskcode":riskcode},
				dataType : "json",
				success : function(data) {
					closeds1();
					if(data.success==false){
						alert(data.msg);
						return;
					}else{
						var url = path+"/newCont/enter/"+ insuranceCom +"/"+ riskcode +"/"+ grpcontno+".do" +
				        			"?recording=N" + "&orderID="+ orderID + "&reportID=" + reportID 
				        			+ "&recordID=" + recordID + "&FPRID=" + FPRID
				        			+ "&prdTypeCode=" + prdTypeCode + "&prdSubTypeCode=" + prdSubTypeCode
									+ "&prdAlternativeNumber=" + prdAlternativeNumber
									+ "&prdClassificationCode=" + prdClassificationCode
									+ "&countryTradableCode=" + countryTradableCode
									+ "&customerIndicator=" + customerIndicator
									+ "&applicationId=" + applicationId
									+ "&quotationId=" + quotationId
									+ "&shoppingCartIndicator=" + shoppingCartIndicator
									+ "&remoteSalesIndicator=" + remoteSalesIndicator
									+ "&paper=PAPER" + "&enterWay=" + enterWay; 
						window.location.href = url; 
					}
				},
				error:function(data){
					alert("系统异常")
					closeds1();
				}
				});
			}
		}
	});
 });*/
}

/**
 * 表格查询参数
 */
function queryParams(params) {
    // 设置查询参数
    var param = {
        limit : params.limit,
        offset : params.offset,
        grpcontno : grpcontno,
        insurancecom : insuranceCom,
        riskcode : riskcode
    };
    return param;
}

/**
 * 翻页带查询参数及列排序
 */
function tableInit(url, obj, col, uniqueId,queryParams) {
    obj.bootstrapTable({
        url : path + url, // 请求后台的URL（*）
        dataType : "json",
        method : 'post', // 请求方式（*）
        contentType : "application/x-www-form-urlencoded",
        toolbar : '#toolbar',
        columns : col,
        striped : true, // 是否显示行间隔色
        cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination : true, // 是否显示分页（*）
        queryParamsType : "limit",// undefined/limit
        queryParams : queryParams,// 传递参数（*）
        sidePagination : "server", //
        pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
        search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
        strictSearch : true,// 设置为 true启用 全匹配搜索，否则为模糊搜索
        showColumns : true, // 是否显示所有的列
        showRefresh : true, // 是否显示刷新按钮
        minimumCountColumns : 2, // 最少允许的列数
        clickToSelect : false, // 是否启用点击选中行
        // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
        // uniqueId: "ID", // 每一行的唯一标识，一般为主键列
        uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
        showToggle : true, // 是否显示详细视图和列表视图的切换按钮
        cardView : false, // 是否显示详细视图
        detailView : false
    });
};

function actionFormatter(value, row, index) {
    return ["<select style='width: 120px;' class='ss form-control' id='selectOpt"+index+ "' >"+
    "<option >请选择</option>"+
    "<option >操作</option>"+
    "</select>"].join('');
};


window.actionEvents = {
    'change .ss' : function(e, value, row, index) {
        var selectedVal = $("#selectOpt"+index).val();
        if(selectedVal == "请选择"){
            return;
        }else if(selectedVal == "操作"){
        	shows1();
        	if(row.insurancecom=="INSH"){
        		$.ajax({
        			type : "POST",
        			async: false,
        			url:path+"/QueryCifController/workingTime.do",// 后台请求URL地址
        			dataType : "json",
        			success : function(data) {
        				if(!data.success){
        					if(data.parm && data.parm=="warn"){
        						layer.confirm(data.msg, {btn: ['确认','取消'], title:"系统提示",closeBtn:false}, 
        								function(confirmIndex){
        				  					layer.close(confirmIndex);
        				  					closeds1();
        				  					jumpToPrePolicy(row.proposalcontno, row.insurancecom, row.riskcode, row.grpcontno, row.transno, row.polapplydate,index);
        				  				}, function(){
        				  					closeds1();
        				  				});					
        					}else if(data.parm && data.parm=="refuse"){
        						layer.alert(data.msg, {closeBtn: false});
        						closeds1();
        						return;	
        					 }
        				}else{
        					closeds1();
        					jumpToPrePolicy(row.proposalcontno, row.insurancecom, row.riskcode, row.grpcontno, row.transno, row.polapplydate,index);
        				}
        			},
        			error:function(data){
        				closeds1();
        				alert("系统异常");
        			}
        			});
        	}else{
        		closeds1();
        		jumpToPrePolicy(row.proposalcontno, row.insurancecom, row.riskcode, row.grpcontno, row.transno, row.polapplydate, index);
        	}
        }
    }
};

//操作预录单确认跳转flag
function jumpToPrePolicy(proposalcontno, insurancecom, riskcode, grpcontno, transno, polapplydate, index){
	
	if(dateToString(polapplydate) == getCurrentDate()){
		
		$.ajax({
	        url: path + '/newContApply/selectNormalByProposalcontno.do',
	        type: "POST",
	        async: false,
	        dataType:"json",
	        data: {"proposalcontno": proposalcontno},
	        success: function (data) {
	        	if(data.success){
	        		window.location.href=path+"/newCont/enter/"+ insurancecom +"/"+ riskcode +"/"+ grpcontno+"/"+ transno+".do?flag=5&paper=PAPER";
	        	}else{
	        		console.log("未查询到正式单信息");
	        		window.location.href=path+"/newCont/enter/"+ insurancecom +"/"+ riskcode +"/"+ grpcontno+"/"+ transno+".do?flag=2&paper=PAPER";
	        	}
	        },
	        error:function(){
	        	alert("系统异常");
	        }
	    })
		
	}else{
		alert("非当日投保单，无法继续操作");
		$("#selectOpt"+index).val('请选择');
	}
	
}

//获取当前日期
function getCurrentDate() {
    var year = new Date().getFullYear();
    var month = new Date().getMonth() + 1;
    if (month < 10) {
        month = "0" + month;
    }
    var date = new Date().getDate();
    if (date < 10) {
        date = "0" + date;
    }
    return year + "-" + month + "-" + date;
}

function dateToString(d){
	var date=new Date(d);
	var a=date.getFullYear();
	var b=0;
	
	if(date.getMonth() + 1<10){
		b="0"+(date.getMonth()+1);
	}else{
		b=date.getMonth()+1;
	}
	
	var c=0;
	if(date.getDate()<10){
		c="0"+date.getDate();
	}else{
		c=date.getDate();
	}
	
	var d=a + '-' + b + '-' + c;
	return d;
}
