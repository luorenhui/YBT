
function payment(){	
	
	var trustField1 = $("#wi").val().trim();
	var trustField2 = $("#wo").val().trim();
	var trustField3 ="";
	if(trustField1==""||trustField2==""){
		alert("授权委托书必须填写完整");
		return ;
	}
	
	var url ="";
	if(insuranceCom=="AXA"){
		if(ipsNo!=null&&ipsNo!=""&&ipsNo!=undefined){
			url=path+"/newCont/enter/"+ ipsNo +"/AXAips.do"
			+ "?enterWay="+enterWay
			+ "&trustField1= "+trustField1
			+ "&trustField2= "+trustField2
			+ "&trustField3= "+trustField3;
		}else{
			url = path+"/newCont/enter/"+ insuranceCom +"/"+ riskcode +"/"+ grpcontno+".do" +
			"?recording=N" + "&orderID="+ orderID + "&reportID=" + reportID 
			+ "&recordID=" + recordID + "&FPRID=" + FPRID
			+ "&prdTypeCode=" + prdTypeCode + "&prdSubTypeCode=" + prdSubTypeCode
			+ "&prdAlternativeNumber=" + prdAlternativeNumber
			+ "&prdClassificationCode=" + prdClassificationCode
			+ "&countryTradableCode=" + countryTradableCode
			+ "&customerIndicator=" + customerIndicator
			+ "&applicationId=" + applicationId
			+ "&quotationId=" + quotationId
			+ "&shoppingCartIndicator=" + shoppingCartIndicator
			+ "&remoteSalesIndicator=" + remoteSalesIndicator
			+ "&enterWay="+enterWay
			+ "&trustField1= "+trustField1
			+ "&trustField2= "+trustField2
			+ "&trustField3= "+trustField3;
		}
		
		
	}else{
		url = path+"/newCont/enter/"+ insuranceCom +"/"+ riskcode +"/"+ grpcontno+".do" +
		"?recording=N" + "&orderID="+ orderID + "&reportID=" + reportID 
		+ "&recordID=" + recordID + "&FPRID=" + FPRID
		+ "&prdTypeCode=" + prdTypeCode + "&prdSubTypeCode=" + prdSubTypeCode
		+ "&prdAlternativeNumber=" + prdAlternativeNumber
		+ "&prdClassificationCode=" + prdClassificationCode
		+ "&countryTradableCode=" + countryTradableCode
		+ "&customerIndicator=" + customerIndicator
		+ "&applicationId=" + applicationId
		+ "&quotationId=" + quotationId
		+ "&shoppingCartIndicator=" + shoppingCartIndicator
		+ "&remoteSalesIndicator=" + remoteSalesIndicator
		+ "&enterWay="+enterWay
		+ "&trustField1= "+trustField1
		+ "&trustField2= "+trustField2
		+ "&trustField3= "+trustField3;
	}
	
	
    window.location.href = url;
}