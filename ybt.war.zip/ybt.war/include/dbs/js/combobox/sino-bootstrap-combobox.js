 
/***
 * CDK
 * 根据  bootstrap-combobox.js v1.1.6  改造的
 * 中科软下拉框组件,配合  bootstrap3.3 使用
 *
 */

var alertmsg=	 "选择一个选项";
var loadmsg = 	 "数据加载中.或有前置选项未选取.";
var preNeedmsg = "需要先选择前置输入框.";
var allCommonInit = {};
var allOptions = {};
var data_cash={};

!function($) {

    "use strict";

    /*
     * COMBOBOX PUBLIC CLASS DEFINITION ================================
     */

    var Combobox = function(element, options) {
        this.$source = $(element);
        var allOption = {};
        if(element.id=="mainriskcode"){
            console.log(element.id); 
        }

//        if(allCommonInit[element.id]!=undefined){
//
//            if(allCommonInit[element.id].$container!=undefined){
//            	
//            	
////				allCommonInit[element.id].$container.parent().empty();
////				allCommonInit[element.id].$container.append(this.$source);
////				allCommonInit[element.id].options = allOptions[element.id];
////				this.options =  allOptions[element.id];
//
////                if(allCommonInit[element.id].$container.attr("inputid")==element.id
////                    &&allCommonInit[element.id].$container.find('input:hidden[comboboxshowtext!="true"]').attr("id")==element.id
////                    &&this.$source.parent().is("div.combobox-container")
////                ){
////                    console.log(element.id,allCommonInit[element.id].$container.find('input:hidden[comboboxshowtext!="true"]').attr("id"),"not rebuild combobox");
////                    return ;
////
////                }
//                console.log(element.id,allCommonInit[element.id].$container.find('input:hidden[comboboxshowtext!="true"]').attr("id"),"rebuild combobox");
//
//                if(this.$source.parent().is("div.combobox-container")){
//                    allCommonInit[element.id].$container.parent().find("select,ul").remove();
//                    allCommonInit[element.id].$menu.empty();
//                    var  top = this.$source.parent().parent();
//                    this.$source.parent().remove();
//                    top.append(this.$source);
//                }
//
////				allCommonInit[element.id].initdata(allOptions[element.id].data);
////				allCommonInit[element.id].rebuild();
//            }
////			this.$container
////			this.showtext();
////			return ;
//        }else{


//        }



        allOption = jQuery.extend(allOption, $.fn.combobox.defaults, options);
        this.options = allOption;
        if(this.options.id){
            this.options.select_sino_id=this.options.id +"_"+Math.floor( Math.random()*1000000000);
        }else{
            this.options.select_sino_id="_"+Math.floor( Math.random()*1000000000);
        }



        if (this.$source.is("input")) {
            this.$container =this.setupInput();
//			 this.loadData();

        } else {
            this.$container = this.setup();


        }




        this.$element = this.$container.find('input[type=text][comboboxshowtext="true"]');
        this.$target = this.$container.find('input:hidden[comboboxshowtext!="true"]');
        this.$button = this.$container.find('.dropdown-toggle');
        this.$menu = $(this.options.menu).appendTo('body');
        this.template = this.options.template || this.template
        this.matcher = this.options.matcher || this.matcher;
        this.sorter = this.options.sorter || this.sorter;
        this.highlighter = this.options.highlighter || this.highlighter;
        this.shown = false;
        this.selected = false;
        this.transferAttributes();

        if (this.$source.is("input")) {
        	
        	
        	this.loadData();
            if((this.options.needParam)&&(!this.options.param)){
                this.refresh();

            }
            this.listen();
        } else {
            this.refresh();
            this.listen();
        }

        allCommonInit[element.id]=this;
        allOptions[element.id]=this.options;
        
        
//        if(this.disabled){
//        	this.disable();
//        }

    };

    Combobox.prototype = {

        constructor : Combobox
        ,
        setData : function(data) {
            this.options.data=data;
        }
        ,
        clearData : function() {
            this.options.data=null;
            this.options.dataflag=false;
            this.options.menuloadflag=false;
//that .options.menuloadflag=false;

            this.$menu.empty();
            this.$container.find("ul").empty();
            this.source=null;
            //data_cash[this.options.result.url+"_stauts"]=undefined;
            //data_cash[this.options.result.url+"_data"]=undefined;
            //data_cash[this.options.result.url+"_id_map"]=undefined;
            //data_cash[this.options.result.url+"_html"]=undefined;
            //data_cash[this.options.result.url+"_select_sino_id"]=undefined;
           
//				this.listen();
//				this.transferAttributes();
//				this.listen();
        }
        ,
        setup : function() {
            var combobox = $(this.template());
            this.$source.before(combobox);
            this.$source.hide();
            return combobox;
        }

        ,
        setupInput : function() {

            if(this.$source.parent().find("div.input-group").length>0){

                return this.$source.parent();
            }else{
                var combobox = $(this.templateInput());

                this.$source.after(combobox);
                combobox.prepend(this.$source);
                this.$source.hide();

                return combobox;
            }


        }

        ,
        loadData : function() {

            var data =this.options.data;
            if(!data||(this.options.url==null||this.options.url==undefined)||(this.options.data instanceof Array&&this.options.data.length==0)){
            	
            	
            	if(this.options.delayLoadDataFlag
            			&&(this.$source.val()==undefined||this.$source.val()=='')
            			&&(this.options.url!=null&&this.options.url!=undefined)){
            		this.afterInit();//
        			return ;
            	}
                this.loader();

            }else{
//				if(this.options.rebuildflag){
//					this.initdata(data);
//				}
            }

        },

        reLoadData : function() {

            this.options.data=null;
            this.options.dataflag=false;
            this.loadData();
            this.refresh();
            this.transferAttributes();
            this.listen();
        }
        ,
        loading : function() {

        }

        ,
        initEmpty : function() {
            var optionHTML="<option value='' selected='selected'>"+preNeedmsg+"</option>";
            var selectHTML="<select class='combobox form-control' id='"+this.options.select_sino_id+"'  style='display: none;width:auto'>" ;
            selectHTML=selectHTML+optionHTML +"</select>";
//			this.$container.parent().find("select,ul").remove();
            this.$container.after(selectHTML);
            this.refresh();
        }
        ,
        loader : function() {

        	
        	
            var that =this;
            if((this.options.needParam)&&(!this.options.param)){
//				that.refresh();
//				that.listen();
                return ;
            }

            var result = initURL(this.options.url,this.options, that ) ;
            this.options.result=result;
            if(result==undefined || result.url ==undefined||(!result.sendflag)){
                this.initdata(this.options.data);
            }else{

                //this.options.url= result.url;
                if(this.options.checkRelateInput){

                    if(!result.checkFlag){
                        this.initEmpty();
                        //alert();
                        return;
                    }else{
                    	
                    }

                }
                
                this.options.begintoloaddataflag=true;//表示即将开始数据加载
                if(!this.options.Loadingflag){
                	this.options.Loadingflag=true;
                }else{
                	return ;
                }
                
                if(data_cash[result.url+"_stauts"]&&result!=undefined && result.url !=undefined&&(result.sendflag)){
                	
                	if(data_cash[result.url+"_stauts"]=="REQUEST_ERR"){
                		
                	}else{
                		that.options.Loadingflag=false;
                		
                		setTimeout( function(){

                			that.initdataByCash( result);

                    	}, 50 );
                	 
                		return ;
                	}
                	
                }

            	data_cash[result.url+"_stauts"]="REQUEST";
            	 var xhr_combobox = $.ajax( {
                     type : "post",
                     url :  result.url,
                     timeout: 60000,//超時一分鐘
                     data : this.options.param,
                     
                     // dataType : "json",
                     success : function(data) {
                     	that.options.Loadingflag=false;
                     	data_cash[result.url+"_stauts"]="REQUEST_SUCC";
                     	
                         that.initdata(data,result);
                         
                     },
                     complete: function (XMLHttpRequest,status) {
                         if(status == 'timeout') {
                         	xhr_combobox.abort();    // 超时后中断请求
                         	alert("请求超时，页面即将关闭，请从YBT系统登录后继续录入");

                         	if (navigator.userAgent.indexOf("Firefox") != -1 || navigator.userAgent.indexOf("Chrome") !=-1) {  
                                 window.location.href="about:blank";  
                                 window.close();  
                             } else {  
                                 window.opener = null;  
                                 window.open("", "_self");  
                                 window.close();  
                             }  
                         	
                         }
                         if(status =='error'){
                        	 data_cash[result.url+"_stauts"]="REQUEST_ERR";
                         	alert("数据查询出现错误，如果操作收到影响。请联系IT");
                         }
                     }
                 });
            
                
                
               
            }

        }
        ,
        initdataByCash : function(result) {
        	var that = this ; 
        	if(data_cash[result.url+"_stauts"]=="INITDATA_SUCC"){
        		
     
                
    					
//    			that.clearData();
               
        		if(result){
        			var data = data_cash[result.url+"_data"];
        			that.$source.removeData("comboboxData");
                    that.$source.data("comboboxData",data);
                    that.options.data = data;
        			that.options.dataflag=true;
        			that.options.loaddataflag=false;
                    that.$container.parent().find("select").remove();
//                    if(!data){
//		                return ;
//		            }
        			that.init_2(data_cash[result.url+"_id_map"],data_cash[result.url+"_html"],data);
                }
        		
        	}else{
        		setTimeout( function(){

        			that.initdataByCash( result);

            	}, 50 );//延迟100毫秒
        	}
        	
        	
        }
        ,
        initdata : function(data,result) {


            var that = this ;
            that.$source.removeData("comboboxData");
            that.$source.data("comboboxData",data);
           
           
           
				 try {
		            	try {
							if(data.indexOf(TIMEOUT_MESSAGE)>=0){
//								alert(TIMEOUT_MESSAGE_ALERT);
								location.reload();
							}
						} catch (e) {
							// TODO: handle exception
//							try {
//								if(!data.success){
//									alert(data.msg);
//								}
//							} catch (e) {
//								// TODO: handle exception
//							}
							
						}
					} catch (e) {
						// TODO: handle exception
					}
            
					 if(!data){
			                return ;
			            }
//			that.clearData();
            that.options.data = data;
//			that.options.dataflag=true;
//			that.options.loaddataflag=false;
            that.$container.parent().find("select").remove();

            var optionHTML="<option value='' selected='selected'>"+alertmsg+"</option>";
            var selectHTML="<select class='combobox form-control' id='"+that.options.select_sino_id+"'  style='display: none;width:auto'>" ;
            var id_map={};
            for ( var i = 0; i  < data.length; i ++) {
                try {
                    optionHTML = optionHTML + "<option value='"+geJsonValue(data[i],that.options.valueField)+"' textField='"+geJsonValue(data[i],that.options.inputText)+"'>";
                    id_map[geJsonValue(data[i],that.options.valueField)]=data[i];
                    if(that.options.textShow.length==0){
                        for ( var key in data[i]) {
                            if ("undefined" == typeof (data[i][key])
                                || data[i][key]==null
                                || data[i][key].length == 0) {
                                //optionHTML = optionHTML + "-";

                            } else {
                                optionHTML = optionHTML + data[i][key] + "-";
                            }
                        }

                    }else{
                        for ( var key in that.options.textShow) {
                            if ("undefined" == typeof (data[i][that.options.textShow[key]])
                                || data[i][that.options.textShow[key]]==null
                                || data[i][that.options.textShow[key]].length == 0) {
                                //optionHTML = optionHTML + "-";

                            } else {
                                optionHTML = optionHTML + data[i][that.options.textShow[key]] + "-";
                            }
                        }
                    }

                    if (optionHTML.length > 0) {
                        optionHTML = optionHTML.substring(0, optionHTML.length - 1);
                    }
                    optionHTML = optionHTML + "</option>";
                } catch (e) {
                    // TODO: handle exception
                    alert("数据格式有误");
                }

            }
            
            
            
            
//			this.options.optionHTML=optionHTML;
            selectHTML=selectHTML+optionHTML +"</select>";

 	if(result!=undefined && result.url !=undefined&&(result.sendflag)){


            	data_cash[result.url+"_html"]=selectHTML;
            	data_cash[result.url+"_id_map"]=id_map;
                data_cash[result.url+"_stauts"]="INITDATA_SUCC";
                data_cash[result.url+"_select_sino_id"]=that.options.select_sino_id;
                data_cash[result.url+"_data"]=data;
            }
            
            
           that.init_2(id_map,selectHTML,data);

        },
        init_2:function(id_map,selectHTML,data){
        	
        	var that= this;
        	that.id_map=id_map;
//			that.$container.find("select,ul").remove();
            that.$container.after(selectHTML);
            that.refresh();
//			that.listen();
            that.transferAttributes();
            
            try {
            	if(data.length == 1 &&that.options.oneResultAuto &&(!that.shown)){
            		
            		if(that.$source.val()==null||that.$source.val()==""){
            			if(!that.options.autoSelect){
//            					this.$target.removeAttr("disabled"); 
            					
            					var disableflag=false;
            	        		 if(this.$target.attr("disabled")){
            	        			 this.$target.removeAttr("disabled"); 
            	        			 disableflag=true;
            	        		 }
                        	
                        		that.setValue(geJsonValue(data[0],that.options.valueField));
                            	that.showtext();
                            	this.$source.trigger("click");

//                            	that.triggerChange();
                            	that.options.autoSelect=true;
                            	 if(disableflag){
                            		 this.$target.attr("disabled",true); 
                                 }
                            	
            			}
            			
            		}
                	
                }
			} catch (e) {
				 console.log(e);
			}
//            if(that.options.autoSelect){
//            	that.showtext();
//            }
            if(that.shown){
                
                //单选项处理
                if(that.options.autoSelect){
                	
                }else{
                	that.clearElement();
                }
                that.lookup();
            }
            
            if(that.options.autoSelect){
            	that.$element.trigger('input').trigger('change');
            	that.triggerChange();
            }else{
            }
            
            that.afterInit();
        },
        afterInit: function(){
        	var that = this;
        	 var obj = that.$source.data('comboboxBeforeMethod');
         	//执行之前未完成的函数
         	for(var key in obj){
         		that[key].apply(that, obj[key]);
         	}
         	 that.$source.data('comboboxBeforeMethod' ,{});
         	 
             try {
                 if(that.options.afterselect!=undefined){

                 	that.options.afterselect(that.$element,that.$target  ,that.$target.val(),that.$source.val(),that);
                 }
             } catch (e) {
                 console.log(e);
             }
             if(that.disabled){
             	that.disable();
             }
             try { 
            	 delete update_element[that.$source.attr("name")];
             } catch (e) {
	 
			}
            
        }
        ,
        disable : function() {
        	try {
        		
        		var form =this.$element
				.parentsUntil("form").parent("form");
        		form.data('bootstrapValidator').resetField(this.$element);
			} catch (e) {
				// TODO: handle exception
			}
        	 
			this.$source.attr('disabled', true);
            this.$element.prop('disabled', true);
            this.$button.attr('disabled', true);
            this.disabled = true;
            this.$container.addClass('combobox-disabled');
            
            var obj = this.$source.data('comboboxBeforeMethod');
            if(obj){
            	delete  obj["enable"];
            }
        }

        ,
        enable : function() {
            this.$element.prop('disabled', false);
            this.$button.attr('disabled', false);
            this.$source.attr('disabled', false);
            this.disabled = false;
            this.$container.removeClass('combobox-disabled');
            
//        R   .disabled = false;
//            this.tempFlagCheck ="1";
            var obj = this.$source.data('comboboxBeforeMethod');
            if(obj){
            	delete  obj["disable"];
            }
        },
        parse : function() {
            var that = this, map = {},mapValue = {}, mapText = {}, source = [], selected = false, selectedValue = '';

            var tmpSource ;
            if (this.$source.is("input")) {
            	if(this.options.result&&data_cash[this.options.result.url+"_select_sino_id"]){
            		tmpSource=$("#"+data_cash[this.options.result.url+"_select_sino_id"]);
            	}else{
            		tmpSource=$("#"+this.options.select_sino_id);
            	}
                
            } else {
                tmpSource=this.$source;
            }


            tmpSource.find('option').each(function() {
                var option = $(this);
                if (option.val() === '') {
                    that.options.placeholder = option.text();
                    return;
                }
                if(that.$source.is("input")){
                    map[option.attr("textField")] = option.val();
                    mapText[option.text()]=option.attr("textField");


                    //设置回显
                    if(that.$target!= undefined){
                        if( option.val() ==that.$target.val()){
                            option.prop('selected',true);
                             selected = option.text();
 			selectedValue = option.val();

                        }

                    }
		mapValue[option.val()] =option.text();
               		 source.push(option.text());
                }else{

                    map[option.text()] = option.val();

                }

                

                //if (option.prop('selected')) {
                 //   selected = option.text();
                //    selectedValue = option.val();
               // }
            })

            this.mapText = mapText;
            this.map = map;
            this.mapValue = mapValue;
            if (selected) {
                this.$element.val(selected);
//                .trigger('input').trigger('change') ;
                this.$target.val(selectedValue);
//                .trigger('input').trigger('change');
                this.$container.addClass('combobox-selected');
                try{
            		if(clearTextFlag){
            			if(cleanComboboxName.indexOf(this.$source.attr("name"))>=0){
            				this.$container.removeClass('combobox-selected');       				
            			}else{
            				
            			}
            			
            		}
            	}catch(e){
            		
            	}
            //    this.$element.trigger('input').trigger('change');
                this.selected = true;
                
                
            }
           
            return source;
        }

        ,
        transferAttributes : function() {
            this.options.placeholder = this.$source.attr('data-placeholder')
                || this.options.placeholder
            this.$element.attr('placeholder', this.options.placeholder)
            this.$target.prop('name', this.$source.prop('name'))
            this.$target.val(this.$source.val())
            if (this.$source.is("input")) {
            } else {
                this.$source.removeAttr('name') // Remove from source otherwise form
                // will pass parameter twice.
            }

            this.$element.attr('required', this.$source.attr('required'))
            this.$element.attr('rel', this.$source.attr('rel'))
            this.$element.attr('title', this.$source.attr('title'))
            this.$element.attr('class', this.$source.attr('class'))
            this.$element.attr('tabindex', this.$source.attr('tabindex'))
            this.$source.removeAttr('tabindex')
            if (this.$source.attr('disabled') !== undefined)
                this.disable();
        }

        ,
        select : function() {
            var val = this.$menu.find('.active').attr('data-value');
            this.$element.val(this.updater(val))
//            .trigger('input')
            .trigger('change') ;
            this.$target.val(this.map[val]);
            this.$source.val(this.map[val])		
//            .trigger('input').trigger('onchange')
            	.trigger('change').trigger("click");
            
            this.$container.addClass('combobox-selected');
            
            try{
        		if(clearTextFlag){
        			if(cleanComboboxName.indexOf(this.$source.attr("name"))>=0){
        				this.$container.removeClass('combobox-selected');       				
        			}else{
        				
        			}
        			
        		}
        	}catch(e){
        		
        	}
//			this.options.select_sino_id
//			$()
//			this.showtext();
            this.selected = true;

            try {
//				relValueAry:[],
                //对应的input的 ID
//				relInputAry:[]
                var select_Data = this.id_map[this.map[val]];
                this.select_Data =select_Data;
                var relValueAry =this.options.relValueAry;
                var relInputAry =this.options.relInputAry;
                for ( var i = 0; i < relValueAry.length; i++) {
                    $("#"+ relInputAry[i]).val(select_Data[relValueAry[i]]).click();
                }
            } catch (e) {
            }
            //选择后的 操作

            try {
                if(this.options.afterselect!=undefined){

                    this.options.afterselect(this.$element,this.$target  ,this.map[val],val,this);
                }
            } catch (e) {
                console.log(e);
            }
            
            try {
                if(this.options.afterClick!=undefined){

                    this.options.afterClick(this.$element,this.$target  ,this.map[val],val,this);
                }
            } catch (e) {
                console.log(e);
            }
            
            try {
                //
                //this.$element为显示在页面上的框体，
                //this.$target为隐藏的框体，选中的select选项，
                //this：整个combobox标签
                afterComboboxSelect(this.$element,this.$target  ,val,this);
            } catch (e) {
            }
            return this.hide();
        }
        ,
        isRemoved : function(item) {
        	var tempFlag= true;
        	
        	var that =this; 
        	if(this.options.relateType&&(this.options.relateType=="vue"||this.options.relateType=="commmon")){
        		if (this.options.mutually_exclusive) {
        			var index = this.$source.attr("id").indexOf("[");
        			var tempid ;
        			if(index >= 0 ){
        				tempid = this.$source.attr("id").substring(0,index+1);
        			}else{
        				tempid = this.$source.attr("id");
        			}
        			$("[id*='"+tempid+"']").each(function() {
        				var tempindex = $(this).attr("id").indexOf("[");
        				var targetID;
        				if(tempindex >= 0 ){
        					targetID = $(this).attr("id").substring(0,tempindex+1);
            			}else{
            				targetID = $(this).attr("id");
            			}
        				if(targetID!=tempid){
        					return true; 
        				}
        				tempFlag=tempFlag&&!(that.mapValue[$(this).val()]==item);
        			});
        			 
				}
        	}
            return tempFlag;
        }
        ,
        updater : function(item) {
            return item;
        }

        ,
        show : function() {
        	
        	if(this.options.delayLoadDataFlag
        			&&(this.$source.val()==undefined||this.$source.val()=='')){
        		this.options.delayLoadDataFlag=false;
        		this.loadData();
        	}
        	
            var pos = $.extend( {}, this.$element.position(), {
                height : this.$element[0].offsetHeight
            });


            this.$menu.insertAfter(this.$element).css( {
                top : pos.top + pos.height,
                left : pos.left
            }).show();
            var that = this ;
//            $(this.$menu).hover(
//            		  function () {
//            		    that.blur();
//            		  },
//            		  function () {
//            			  
//            			  that.focus();
//            		  }
//            		);
            
//            that.blur();
          
            
            this.shown = true;
            return this;
        }

        ,
        hide : function() {
            this.$menu.hide();
            this.shown = false;
            return this;
        }

        ,
        lookup : function(event) {
            this.query = this.$element.val();
            return this.process(this.source);
        }

        ,
        process : function(items) {

            if((items==null ||typeof(items) == "undefined")||items.length==0){
                items = new Array();

                this.$menu.prepend()
                this.$menu.html("<li ><a href='#'>"+loadmsg+"</a></li>");
//				this.loadData();
                return this.show();
            }else{
                var that = this;

                items = $.grep(items, function(item) {
                	
                	var tmpf=	that.matcher(item);
                	 
                    return tmpf&&that.isRemoved(item);
                })

                items = this.sorter(items);

                if (!items.length) {
                    return this.shown ? this.hide() : this;
                }

                return this.render(items.slice(0, this.options.items)).show();
            }





        }

        ,
        template : function() {
            if (this.options.bsVersion == '2') {
                return '<div class="combobox-container"><input type="hidden" /> <div class="input-append"> <input type="text" autocomplete="off" /> <span class="add-on dropdown-toggle" data-dropdown="dropdown"> <span class="caret"/> <i class="icon-remove"/> </span> </div> </div>'
            } else {
                return '<div class="combobox-container"> <input type="hidden" /> <div class="input-group"> <input type="text" autocomplete="off" /> <span class="input-group-addon dropdown-toggle" data-dropdown="dropdown"> <span class="caret" /> <span class="glyphicon glyphicon-remove" /> </span> </div> </div>'
            }
        }

        ,
        templateInput : function() {
            if (this.options.bsVersion == '2') {
                return '<div class="combobox-container" inputid="'+this.$source.attr("id")+'"> <div class="input-append"> <input id="'+this.$source.attr("id")+'_combobox" name="'+this.$source.attr("name")+'_combobox" type="text" comboboxshowtext="true" autocomplete="off" /> <span class="add-on dropdown-toggle" data-dropdown="dropdown"> <span class="caret"/> <i class="icon-remove"/> </span> </div> </div>'
            } else {
                return '<div class="combobox-container" inputid="'+this.$source.attr("id")+'"> <div class="input-group"> <input id="'+this.$source.attr("id")+'_combobox" name="'+this.$source.attr("name")+'_combobox" type="text" comboboxshowtext="true" autocomplete="off" /> <span class="input-group-addon dropdown-toggle" data-dropdown="dropdown"> <span class="caret" /> <span class="glyphicon glyphicon-remove" /> </span> </div> </div>'
            }
        }

        ,
        matcher : function(item) {
            return ~item.toLowerCase().indexOf(this.query.toLowerCase());
        }

        ,
        sorter : function(items) {
            var beginswith = [], caseSensitive = [], caseInsensitive = [], item;

            while (item = items.shift()) {
                if (!item.toLowerCase().indexOf(this.query.toLowerCase())) {
                    beginswith.push(item);
                } else if (~item.indexOf(this.query)) {
                    caseSensitive.push(item);
                } else {
                    caseInsensitive.push(item);
                }
            }

            return beginswith.concat(caseSensitive, caseInsensitive);
        }

        ,
        highlighter : function(item) {
            var query = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,
                '\\$&');
            return item.replace(new RegExp('(' + query + ')', 'ig'), function(
                $1, match) {
                return '<strong>' + match + '</strong>';
            })
        }

        ,
        render : function(items) {
            var that = this;
		/*if(data_cash[that .options.result.url+"_items"]){
			
if(!that .options.menuloadflag){
			this.$menu.html(data_cash[that .options.result.url+"_items"]);
			that .options.menuloadflag=true;
}
			return this;
		}*/
            items = $(items).map(function(i, item) {
                if (that.$source.is("input")) {

                    i = $(that.options.item).attr('data-value', that.mapText[item]);

                    i.find('a').html(that.highlighter( that.options.textShowFormat(item,that.id_map[that.map[that.mapText[item]]])));
                } else {
                    i = $(that.options.item).attr('data-value', item);
                    i.find('a').html(that.highlighter(item));
                }


                return i[0];
            })

		
/*if(that .options.result!=undefined && that .options.result.url !=undefined&&(that .options.result.sendflag)){
 data_cash[that .options.result.url+"_items"]=items;
 data_cash[that .options.result.url+"_menu"]=this.$menu;
}*/


            items.first().addClass('active');
	    

            this.$menu.html(items);
            return this;
        }

        ,
        next : function(event) {
            var active = this.$menu.find('.active').removeClass('active'), next = active
                .next();

            if (!next.length) {
                next = $(this.$menu.find('li')[0]);
            }

            next.addClass('active');
        }

        ,
        prev : function(event) {
            var active = this.$menu.find('.active').removeClass('active'), prev = active
                .prev();

            if (!prev.length) {
                prev = this.$menu.find('li').last();
            }

            prev.addClass('active');
        }

        ,
        toggle : function() {
            if(!this.options.data||(this.options.data instanceof Array&&this.options.data.length==0)){
                this.loadData();
            }

            if (!this.disabled) {
                if (this.$container.hasClass('combobox-selected')) {
                    this.clearTarget();
                    this.triggerChange();
                    this.clearElement();
                    
                    try {
                        if(this.options.afterClickClear!=undefined){

                            this.options.afterClickClear(this.$element,this.$target);
                        }
                    } catch (e) {
                        console.log(e);
                    }
                } else {
                    if (this.shown) {
                        this.hide();
                    } else {
                    	
                        this.clearElement();
                        this.lookup();
                    }
                }
            }else{
            	//如果是运行不修改清理值的情况
            	try{
            		if(clearTextFlag){
            			if(cleanComboboxName.indexOf(this.$source.attr("name"))>=0){
            				          				
            			}else{
            				if (this.$container.hasClass('combobox-selected')) {
            					this.$target.removeAttr("disabled"); 
                                this.clearTarget();
                                this.triggerChange();
                                this.clearElement();
                                this.$target.attr("disabled",true); 
                                try {
                                    if(this.options.afterClickClear!=undefined){

                                        this.options.afterClickClear(this.$element,this.$target);
                                    }
                                } catch (e) {
                                    console.log(e);
                                }
                            } 
            				
            			}
            			
               	}
            	}catch(e){
            		
            	}
            	
            }
        }
        ,
        
        clear : function() {
        	var disableflag=false;
        	 if(this.$target.attr("disabled")){
    			 this.$target.removeAttr("disabled"); 
    			 disableflag=true;
    		 }
        	this.clearElement();
        	this.clearTarget();
        	 this.$source
             .trigger('input')
             .trigger("click");
        	
        	 if(disableflag){
        		 this.$target.attr("disabled",true); 
             }
        }
        ,
        clearElement : function() {
            this.$element.val('')//.focus()
            	.trigger('input').trigger('change');
            this.select_Data={
            		
            };
            try {
                var relInputAry =this.options.relInputAry;
                for ( var i = 0; i < relInputAry.length; i++) {
                    $("#"+ relInputAry[i]).val("").click();
                }
            } catch (e) {
                // TODO: handle exception
            }
            
            try {
            	data_cash[this.options.result.url+"_items"]=undefined;
                data_cash[this.options.result.url+"_menu"]=undefined;
                data_cash[this.options.result.url+"_stauts"]=undefined;
            } catch (e) {
                // TODO: handle exception
            }
            
        }

        ,
        clearTarget : function() {
            this.$source.val('').trigger("fatherchange");//级联下拉;
            this.$target.val('').trigger('change');
            this.$container.removeClass('combobox-selected');
            try {
                if(this.options.afterselect!=undefined){

                    this.options.afterselect(this.$element,this.$target  ,'','',this);
                }
            } catch (e) {
                console.log(e);
            }
            this.selected = false;
        }

        ,
        triggerChange : function() {
//            this.$source.trigger('change').trigger("click");
            this.$source
            .trigger('input')
            .trigger('change')
            .trigger("click")//vue
            .trigger("fatherchange");//级联下拉
        }

        ,
        refresh : function() {
            this.source = this.parse();
            this.options.items = this.source.length;
        }

        ,
        listen : function() {
            this.$element.on('focus', $.proxy(this.focus, this)).on('blur',
                $.proxy(this.blur, this)).on('keypress',
                $.proxy(this.keypress, this)).on('keyup',
                $.proxy(this.keyup, this));

            if (this.eventSupported('keydown')) {
                this.$element.on('keydown', $.proxy(this.keydown, this));
            }

            this.$menu.on('click', $.proxy(this.click, this)).on('mouseenter',
                'li', $.proxy(this.mouseenter, this)).on('mouseleave',
                'li', $.proxy(this.mouseleave, this))
                .on('mouseleave','ul', $.proxy(this.menu_mouseleave, this))
                .on('mouseenter','ul', $.proxy(this.menu_mouseenter, this))
                .on('mouseleave', $.proxy(this.menu_mouseleave, this))
                .on('mouseenter', $.proxy(this.menu_mouseenter, this));

            this.$button.on('click', $.proxy(this.toggle, this));
        }

        ,
        eventSupported : function(eventName) {
            var isSupported = eventName in this.$element;
            if (!isSupported) {
                this.$element.setAttribute(eventName, 'return;');
                isSupported = typeof this.$element[eventName] === 'function';
            }
            return isSupported;
        }

        ,
        move : function(e) {
            if (!this.shown) {
                return;
            }

            switch (e.keyCode) {
                case 9: // tab
                case 13: // enter
                case 27: // escape
                    e.preventDefault();
                    break;

                case 38: // up arrow
                    e.preventDefault();
                    this.prev();
                    break;

                case 40: // down arrow
                    e.preventDefault();
                    this.next();
                    break;
            }

            e.stopPropagation();
        }

        ,
        keydown : function(e) {
            this.suppressKeyPressRepeat = ~$.inArray(e.keyCode, [ 40, 38, 9,
                13, 27 ]);
            this.move(e);
        }

        ,
        keypress : function(e) {
            if (this.suppressKeyPressRepeat) {
                return;
            }
            this.move(e);
        }

        ,
        keyup : function(e) {
            switch (e.keyCode) {
                case 40: // down arrow
                case 39: // right arrow
                case 38: // up arrow
                case 37: // left arrow
                case 36: // home
                case 35: // end
                case 16: // shift
                case 17: // ctrl
                case 18: // alt
                    break;

                case 9: // tab
                case 13: // enter
                    if (!this.shown) {
                        return;
                    }
                    this.select();
                    break;

                case 27: // escape
                    if (!this.shown) {
                        return;
                    }
                    this.hide();
                    break;

                default:
                    this.clearTarget();
                    this.lookup();
            }

            e.stopPropagation();
            e.preventDefault();
        }

        ,
        focus : function(e) {
            this.focused = true;
        }

        ,
        blur : function(e) {
            var that = this;
            this.focused = false;
            var val = this.$element.val();
            if (!this.selected && val !== '') {
                this.$element.val('')
                .trigger('input').trigger('change')
                .trigger("click");
                this.triggerChange();
//                .trigger('input').trigger('change').trigger("click");
                this.$target.val('').trigger('input').trigger('change').trigger("click");
            }
            if (!this.mousedover && this.shown) {
                setTimeout(function() {
                    that.hide();
                }, 200);
            }
        }

        ,
        click : function(e) {
            e.stopPropagation();
            e.preventDefault();
            this.select();
//            this.$element.focus();
        }

        ,
        mouseenter : function(e) {
            this.mousedover = true;
            this.$menu.find('.active').removeClass('active');
            $(e.currentTarget).addClass('active');
        }
        ,
        menu_mouseenter : function(e) {
            this.mousedover = true;
            this.blur(e);
            this.$element.blur();
//            this.$menu.find('ul').focus();
//            this.$menu.focus();

//            this.$menu.find('.active').removeClass('active');
//            $(e.currentTarget).addClass('active');
        }
        ,
        mouseleave : function(e) {
            this.mousedover = false;
        }
        ,
        menu_mouseleave : function(e) {
            this.mousedover = false;
            this.focus(e);
            this.$element.focus();
        }
        ,
        showtext : function() {
            var val = this.$source.val();
            if(this.mapValue&&this.mapValue[val]){
            	this.$element.val(this.mapValue[val]);
//            	.trigger('change').trigger("input");
            }else{
            	if(val==""||val==null||val==undefined){
            		this.$element.val("");//.trigger('change').trigger("input");
            	}else{
            		this.$element.val("");
//            		.trigger('change').trigger("input");
                	this.options.data=undefined;
                	this.loadData();
            	}
            	
            }
        }
        
        ,
        getShowTextInput : function() {
            var $tetxelement=  this.$source.parent().find("input:visible");
            return $tetxelement;
        },
        setValue:function( newValue){
            this.$source.val(newValue);
            if(newValue){
            	this.$container.addClass('combobox-selected');
            	try{
            		if(clearTextFlag){
            			if(cleanComboboxName.indexOf(this.$source.attr("name"))>=0){
            				this.$container.removeClass('combobox-selected');       				
            			}else{
            				
            			}
            			
            		}
            	}catch(e){
            		
            	}
            	
            }
            //this.$source.trigger("click");
            var tmpdata = this.options.data;

            if(tmpdata ==undefined ||
                tmpdata ==null||
                tmpdata.length==0){

                this.loadData();
            }
        }
    };

    Combobox.prototype.getOptions = function () {
        return this.options;
    };

    /*
     * COMBOBOX PLUGIN DEFINITION ===========================
     */
    $.fn.combobox = function(option) {
    	var flag= true;
        var value,
            args = Array.prototype.slice.call(arguments, 1);
        this.each(function() {
            var $this = $(this), data = $this.data('combobox'), options = typeof option == 'object'
                && option;
//					if(allCommonInit[this.id]!=undefined){
//							if(allCommonInit[this.id].$container!=undefined){
//								if(allCommonInit[this.id].$container.attr("inputid")==this.id
//										&&allCommonInit[this.id].$container.find('input:hidden[comboboxshowtext!="true"]').attr("id")==this.id
//										&&data
//										&&$this.parent().is("div.combobox-container")){
//									return ;
//							}
//						}
//					}
            if(this.id=="nativeplace2"){
                console.log(this.id + " **** " + option);
            }

            
            
            //
            if (!data||data.options==undefined||data.options.rebuildflag||(!data.initFlag)) {
                
                //当未初始化调用部分函数时处理 此时
                if (typeof option == 'string'&&$.inArray(option, allowedMethods) >= 0) {
//    				data[option]();
//                	data.initFlag =false;
                	var obj = $this.data('comboboxBeforeMethod');
                	if(obj==undefined){
                		obj ={};
                		$this.data('comboboxBeforeMethod',obj);
                	}
                	//缓存下来
                	obj[option]=args;
                	return ;
                }else{
                	//取得之前缓存的函数
                	
                	$this.data('combobox', (data = new Combobox(this,
                            options)));
                	data.initFlag =true;
                	
                }
            }else{
            	data.setValue( $this.val());
            	data.showtext();
            	
            	if(option!= 'enable'&&option!= 'disable'){
            		
            		if (data.$source.attr('disabled') !== undefined){
                		
                		data.disable();
                	}else{
                		data.enable();
                	}
            	}
            
            }
//					$this.data('combobox', (data = new Combobox(this,
//							options)));

            if (typeof option == 'string') {
//						data[option]();
                if ($.inArray(option, allowedMethods) < 0) {
                    throw new Error("Unknown method: " + option);
                }

                if (!data) {
                    return ; 
                }

                value = data[option].apply(data, args);
            }

            return typeof value === 'undefined' ? this : value;
        });
        return typeof value === 'undefined' ? this : value;
    };

    $.fn.combobox.defaults = {
        bsVersion : '3',
        menu : '<ul class="typeahead typeahead-long dropdown-menu"></ul>',
        item : '<li><a href="#"></a></li>',

        oneResultAuto: true,
        // 是否可编辑
        editable : false,
        //是否需要参数
        needParam : false,
        // 页面是否首次加载flag
        loadFlag : false,
        // url: '../CodeSelectEasyUI',
        // 默认new ,new采用新式codequery old 为老式
        QueryType : 'new',
        // 采用 old方式查询时有效，为valueField的查询结果列号，默认是0
        id_index : 0,
        valueField : 'value',
        // 是否加载页面后自动加载数据
        firstLoad : true,
        // 默认最后一次输入事件与执行搜索之间的延迟间隔
        delay : 200,
        // 显示在输入框的
        inputText : "text",
        // 是否显示blank行
        blankneed : false,
        panelHeight : 'auto',
        // 当value为一部分值时，text框变为可输入，搭配relatedText一起使用
        nochangeValue : [],
        // 是否显示代码
        showCode : false,
        cache : true,
        // 与Text框一样的值的文本框ID
        relatedText : "",
        // 对于CODE相似的查询是否使用已经加载的的数据源
        useSameCode : false,
        //是否检查依赖的元素值是否为空
        checkRelateInput:true,
        //随机数ID
        select_sino_id: "",
        //对应的json key
        relValueAry:[],
        /**
         * 相同类型选择互斥
         */
        mutually_exclusive:false,
        //元素ID
        elementid:"",
        // 显示在下拉列表的项，默认空，空则全部显示
        textShow : ["text"],
        //是否重建
        rebuildflag:false,
        //对应的input的 ID
        relInputAry:[],
        //选中 事件后  触发
        afterSelect:undefined,
        afterClick:undefined,
        afterClickClear:undefined,
        beforeExcuteFlag : true,
        //是否延迟加载 数据
        delayLoadDataFlag:false,
        
        routerName : undefined,
        //vue绑定的对象ID， 
//        relateType:,
//        relateVueID:{}
        //格式下拉框显示内容
        textShowFormat: function(textShow,linedata){return  textShow;}
    };

    //可支持的方法
    var allowedMethods = [
        'getOptions',
        'refresh',
        'loadData',
        'setValue',
        "showtext",
        "clearTarget",
        "disable",
        "enable",
        "clear",
        "setData",
        "clearData"
    ];

    $.fn.combobox.Constructor = Combobox;
    $.fn.combobox.methods = allowedMethods;

}(window.jQuery);


function getURL() {
    var ary = window.location.pathname.split("/");
    var url = "";
    if (ary.length >= 2) {
        url = "/" + ary[1];
    } else {
        url = "";
    }
    return url;
}

function geJsonValue(object , key){
	
	 var ary= key.split(".");
	 
	 for (var i = 0; i < ary.length; i++) {
		 object =object[ary[i]];
	 }
	
	 return object;
}



var urlelementAry="urlelementAry";

/**
 * 检查URL对应的值是否完成
 * @param url
 */
function checkURL(result,option){
    result["checkFlag"]=true;
    for (var i = 0; i < result[urlelementAry].length; i++) {

    	if(option.relateType&&option.relateType=="vue"){
    		
    		
    	        
    	}else{
    		 var jqexp =result[urlelementAry][i];

 	        if($(jqexp).length==0){
 	        	
// 				alert("jquery no match for :" + jqexp);
 	            result["checkFlag"]=false;
 	            break;
 	        }

 	        if($(jqexp).val()==""||$(jqexp).val()==null||$(jqexp).val()== undefined){

 	            //	alert(" no value for " + jqexp +" please select ");
// 				alert(" please select pre input !");
 	            result["checkFlag"]=false;
 	            break;
 	        }
    	}
       
    }


}


/**
 * 初始化
 * @param url
 */
function initURL(url,option, ele ){


    var result =formatURL(url,option,ele);
    if(result!=null
        && typeof(result)=="object"
        &&typeof(result[urlelementAry])!="undefined"){
        bindElementURL(result,ele);
    }
    return result;
}


/**
 * 绑定
 * @param url
 */
function bindElementURL(result , ele){

    for (var i = 0; i < result[urlelementAry].length; i++) {

        var jqexp =result[urlelementAry][i];
        
//        $(jqexp).unbind( "fatherchange" );
        if(!ele.options.bindELement){
			ele.options.bindELement={
					
			};
			
		}
        if(ele.options.bindELement[jqexp]){
        	
        }else{
        		
        	ele.options.bindELement[jqexp] ="true";
        	 $(jqexp).bind("fatherchange",function(){
//     			$(ele.$source).val("");
        		 
        		 var disableflag=false;
        		 if(ele.$target.attr("disabled")){
        			 ele.$target.removeAttr("disabled"); 
        			 disableflag=true;
        		 }
        		
                 ele.clearElement();
                 ele.clearTarget();
     //
                 ele.clearData();
                 ele.triggerChange();
                 if(disableflag){
                	 ele.$target.attr("disabled",true); 
                 }
                
                 if(ele.options.data){
                	 
                 }else{
                	 if(!ele.options.begintoloaddataflag){
//                		 if($(ele.$target).attr("id")=="citydivision"){
//                			 ele.$target;
//                		 }
                		 ele.loadData();
                	 }
                		
                 }
                 //ele.loadData();
//     			ele.$source.combobox();
//     			if($(jqexp).val()==""||$(jqexp).val()== undefined){
//     				ele.initEmpty();
//     			}

//     			ele.$source.combobox("loaddata",{});
                 //ele.reLoadData();

             });
        }
        
       
    }
}

var reg_combobox_url= new RegExp("#([\\s\\S]*?[.\\/\\\\\])|#([\\s\\S]*)?", "g");


 
/**
 * 从 vue 对象中哪指
 *//*
function getVueFormDataValue(exp,ele){
	

   	var expAry= exp.split(".");
   	var lastKey = "";
	var vueobjtemp ; 
   	if(vue_config.length==1){
   		vueobjtemp =vue_config[vue_config.length-1].vueobj;
   	}else{
   		vueobjtemp =vueobj[vue_config[option.vueid]];
   	}
	var value = vueobjtemp.formdata;
       for ( var index in expAry) {
       	lastKey= expAry[index];
       	var tempkey =expAry[index].replace("#","");
       	var aryIndex ;  //循环元素下标
       	//循环元素处理
       	if(ele.$source.attr("name")&&ele.$source.attr("name").indexOf("[")>=0&&	value[tempkey]  instanceof Array){
       		
       		aryIndex = getIndex(ele.$source.attr("name"));
       		value =  value [tempkey][aryIndex];
       	}else{
       		value =  value [tempkey];
       	}
       
	}
       return  value;
}*/
/**
 * 格式化参数URL 成为正式的URL 
 * @param url
 * @param option
 * @param ele
 * @returns
 */
function formatURL(url ,option,ele) {
    var result={};
    result.sendflag = true;
    var newurl ;
    var elementAry = new Array();
    if(url){
    	
        try {

        	 if(option.relateType&&option.relateType=="vue"){
        		 
        		 
        		  newurl = url.replace(reg_vueform_url, function() { 
        			  var args = arguments;
        			  var exp = args[0].replace("/","").replace("\\","");
                   	

        				

        			   	var expAry= exp.split(".");
        			   	//跟对象传入设置
        			   	if(option.routerName){
        			   		expAry = option.routerName.split(".").concat(expAry);
        			   	}
        			   	var lastKey = "";
        				var vueobjtemp ; 
        			   	if(vue_config.length==1){
        			   		vueobjtemp =vue_config[vue_config.length-1].vueobj;
        			   	}else{
        			   		vueobjtemp =vueobj[vue_config[option.vueid]];
        			   	}
        				var value = vueobjtemp.formdata;
        				var  realJqexp=""; 
        				
        			       for ( var index in expAry) {
        			       	lastKey= expAry[index];
        			       	var tempkey =expAry[index].replace("#","");
        			       	var aryIndex ;  //循环元素下标
        			       	//循环元素处理
        			       	if(ele.$source.attr("name")&&ele.$source.attr("name").indexOf("[")>=0&&	value[tempkey]  instanceof Array){
        			       		
        			       		aryIndex = getIndex(ele.$source.attr("name"),tempkey );
        			       		value =  value [tempkey][aryIndex];
        			       		
        			       		if(realJqexp==""){
            			       			realJqexp = realJqexp + tempkey + "["+aryIndex+"]";
            			       	}else{
            			       		
            			       			realJqexp = realJqexp+ "." + tempkey + "["+aryIndex+"]";
            			       	}
        			       	}else{
        			       		value =  value [tempkey];
        			       		if(realJqexp==""){
            			       			realJqexp = realJqexp + tempkey;
            			       	}else{
            			       		
            			       			realJqexp = realJqexp+ "." + tempkey;
            			       	}
        			       	}
        			       	
        			       
        				}
//        			       return  value;

//                   	value=	getVueFormDataValue( exp,ele);
                       elementAry.push("[name='"+realJqexp+"']");
                       if(value ==null||value==""||value==undefined){
                    	   
                    	   result.sendflag =result.sendflag&&false;
                       }
                   	return 	args[0].replace(exp,value);
                  	
                  });
             	
             }else{
            	 
            	  newurl = url.replace(reg_combobox_url, function() { 
            		  var args = arguments;
            		  var jqexp = args[0].replace(".","").replace("/","").replace("\\","");
            		  
            		  var jqexptemp =jqexp;
            		  	if(ele.$source.attr("id")&&ele.$source.attr("id").indexOf("[")>=0){
  			       		
            		  		aryIndex = getIndex(ele.$source.attr("id"));
  			       		
            		  		jqexptemp = jqexp + "\\["+aryIndex+"\\]";
  			       		 
  			       		}else{ }
            		  
                      elementAry.push(jqexptemp);
                      
                      if($(jqexptemp).val() ==null||$(jqexptemp).val()==""||$(jqexptemp).val()==undefined){
                   	   
                   	   	result.sendflag =result.sendflag&&false;
                      }
                      return 	args[0].replace(jqexp,$(jqexptemp).val());
                  	
                  });
            	 
            }
        	 
          
//    		var urltt = "{a}a{b}b{c}c";
    //
//    		// 方式三，采用非固定参数的回调函数
//    		var rep3 = urltt.replace(reg, function() {
//    			var args = arguments;
//    			return args;
//    		});
//    		alert(rep3);
        } catch (e) {
        	console.log(e);
            result["url"]=url
            return result;
        }
        if(option.relateType&&option.relateType=="vue"){
        	result["url"]=newurl +vueoOption.url_suffix;
        }else{
        	result["url"]=newurl;
        }
    	
    }else{
    	result["url"]=url
        return result;
    }
    
    
    result[urlelementAry] =elementAry;

    checkURL(result,option);
    return result;

}

/**
 * 获取下标
 * @param name
 */
function getIndex(name){
	
	var startaryIndex	= name.indexOf("[");
	var endaryIndex 	= name.indexOf("]");
	return name.substring(startaryIndex+1,endaryIndex);
}

/**
 * 获取当前对象name的下标
 * @param name
 */
function getIndex(name , currentName){
 
	name = name.substring(name.indexOf(currentName));
	var startaryIndex	= name.indexOf("[");
	var endaryIndex 	= name.indexOf("]");
	return name.substring(startaryIndex+1,endaryIndex);
}
/**
 * 
 * @param ele 源
 * @param id 目标路径
 * @param option
 */
function getActualEle(ele,id, option) {

	if (option.relateType && option.relateType == "vue") {
		if (index) {

			
		}else{
			
		}

	}

}
