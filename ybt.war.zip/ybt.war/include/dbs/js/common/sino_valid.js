//上一个被选中 的tab
var last_tab_sys = null;
/**
 * 需要忽略自动检查数据变更校验的的
 */
var ignoreChangeCheckTargetID=[];
var ignoreCheck={};
var _sinovalid_needValidFlag =true ;//是否需要校验
/**
 * 合并校验‘ key 合并到 value 进行 ID
 */
var combineCheckID={
		
		
};
/*******************************************************************************
 * notnull的提示
 */
// $.fn.validatebox.defaults.missingMessage = "不可为空";
/**
 * 校验 的逻辑处理规则
 */
// $.extend($.fn.validatebox.defaults.rules,
// {
// num : {
// validator : function(value, param) {
//
// var reg = new RegExp("^[0-9]*$");
// return reg.test(value);
// },
// message : '输入内容必须为数字.'
// },
// equals : {
// validator : function(value, param) {
// return value == $(param[0]).val();
// },
// message : 'Field do not match.'
// },
// notnull : {
// validator : function(value, param) {
// if (value != null && $.trim(value).length > 0) {
// return true;
// }
// // alert(this.name);
// return false;
// },
// message : '{0} 不可为空'
// },
// scope : {
// validator : function(value, param) {
//
// return eval(value.replace(/[^\x00-\xff]/g, "**").length
// + param[1]);
// },
// message : '{0} 的长度需要 {1} .'
// },
// codetext : {
// /**
// *
// * 为了codeselect 校验用
// */
// validator : function(value, param) {
//
// // allInputSelectInit
// var tData = $("#" + allInputSelectInit[param[1]].id).data(
// "lastData");
// var option = $("#" + allInputSelectInit[param[1]].id).combobox(
// "options");
// var valueAry = option.nochangeValue;
// var nowValue = $("#" + allInputSelectInit[param[1]].id)
// .combobox("getValue");
//
// for ( var i = 0; i < valueAry.length; i++) {
// if (nowValue == valueAry[i]) {
// return true;
// }
// }
//
// if (tData != undefined) {
// for ( var i = 0; i < tData.length; i++) {
// for ( var key in tData[i]) {
//
// if (option.inputText == key) {
// if (tData[i][key] == value) {
// return true;
// }
// }
// }
// }
// }
//
// },
// message : '是不符合要求的数据 .'
// }
// });
// /**
// * 加載所有的需要校驗的項
// */
// $(function() {
// /**
// * */
//
// });
/*******************************************************************************
 * 初始化 verify
 * 
 * @param target
 *            某个tar
 * @return
 */
function initVerifyTarget(target) {

	try {
		if (allInputSelectInit[target.attr("id")] == null
				&& (target.combo("options") == undefined || target
						.combo("options") == null)) {

		}

	} catch (e) {
		var verfiyText = target.attr('verify');
		var param = {};
		initValid(param, verfiyText, target);
		// target.validatebox(param);
	}

}
/**
 * 初始化 所有 有 verify 属性的
 * 
 * @return
 */
function initVerify() {

	$("*[verify]").each(
			function(index) {

				var target = $(this);
				try {
					if (allInputSelectInit[target.attr("id")] == null
							&& (target.combo("options") == undefined || target
									.combo("options") == null)) {

					}

				} catch (e) {

					try {
						target.combo("");
					} catch (e) {
						var verfiyText = target.attr('verify');
						var param = {};
						initValid(param, verfiyText, target);
					}

				}

			});
}
/**
 * 用来在表单提交时校验form的数据
 * 
 * @param targetForm
 *            某个form 的jq对象
 * @return
 */
function validForm(targetForm) {

	targetForm
			.find("*[verify]")
			.each(
					function(index) {

						var target = $(this);
						try {
							try {
								if (target != null
										&& target.combo("options") != null
										&& target.combo("options").notNullFlag != null) {

									target.combo("options").required = target
											.combo("options").notNullFlag;
									target.combo("validate");
								}
							} catch (e) {
								// TODO: handle exception
							}

						} catch (e) {
						}

					});

	// for ( var key in allInputSelectInit) {
	//
	// var target = $("#" + allInputSelectInit[key].id);
	// try {
	// if (target != null && target.combo("options") != null
	// && target.combo("options").notNullFlag != null) {
	//
	// target.combo("options").required = target.combo("options").notNullFlag;
	// target.combo("validate");
	// }
	// } catch (e) {
	// // TODO: handle exception
	// }
	//
	// }
	return targetForm.form('validate');

}
/**
 * 初始化校验参数 供校验逻辑使用
 * 
 * @param option
 * @param verfiyText
 * @param comboFlag
 * @return
 */
function initValid(option, verfiyText, target, comboFlag) {

	var verifyText = verfiyText.split("|");
	if (verifyText.length > 1) {

	} else {
		target.validatebox({});
		return;
	}
	var alertMsg = verifyText[0];
	var verifyAry = verifyText[1].split("&");
	var validType = new Array();
	for (var i = 0; i < verifyAry.length; i++) {
		if (verifyAry[i].length == 0) {
			continue;
		}
		if ("notnull".toLowerCase() == verifyAry[i].toLowerCase()) {
			if (comboFlag == true) {
				option.notNullFlag = true;
			} else {
				option.required = true;
			}
			//

			option.missingMessage = alertMsg
					+ $.fn.validatebox.defaults.missingMessage;
			initNotNullFlag(target);

			// var tempAry = new Array();
			// tempAry[0] = alertMsg;
			// validType[validType.length] = "notnull['" + tempAry[0] +"']";
		}
		if (verifyAry[i].toLowerCase().indexOf("len") >= 0) {

			var tempAry = new Array();
			tempAry[0] = alertMsg;
			tempAry[1] = verifyAry[i].replace("len", "");
			validType[validType.length] = "scope['" + tempAry[0] + "','"
					+ tempAry[1] + "']";
		}

		if ("email".toLowerCase() == verifyAry[i].toLowerCase()) {

			var tempAry = new Array();
			tempAry[0] = alertMsg;

			validType[validType.length] = "email";
		}

		if (verifyAry[i].toLowerCase().indexOf("codetext") >= 0
				|| verifyAry[i].substring(0, verifyAry[i].indexOf(":"))
						.toLowerCase() == "code") {

			var tempAry = new Array();
			tempAry[0] = alertMsg;
			tempAry[1] = verifyAry[i].substring(verifyAry[i].indexOf(":") + 1);
			validType[validType.length] = "codetext['" + tempAry[0] + "','"
					+ tempAry[1] + "']";
		}

		if ("num".toLowerCase() == verifyAry[i].toLowerCase()) {

			var tempAry = new Array();
			tempAry[0] = alertMsg;

			validType[validType.length] = "num['" + tempAry[0] + "']";
		}

	}
	option.validType = validType;

	// $(this).validType = validType;
	if (comboFlag) {

	} else {
		target.validatebox(option);
	}

	return option; // /返回的 option 供 combobox使用

}

/**
 * 
 * @param target
 *            初始化存储对象的组件
 * @return
 */
function initData(target ,combineinitFlag) {
	console.log("initData target id :"+ target.attr("id"));
	if(target==undefined||target.length==0){
		return ;
	}
	
	if(combineCheckID[target.attr("id")]){
		
	}else{
		if(combineinitFlag){
			for ( var key in combineCheckID) {
				if(combineCheckID[key]==target.attr("id")){
					this.initData($("#"+key),false);
				}
			}
		}
	}
	target.find(".changevaluealert").removeClass(
	"changevaluealert");
	var initData = {};
	target.find("input,select").each(
			function(i) {
				
//				console.log();
				if("proposalcontno"==$(this).attr("name")){
					console.log($(this).attr("name"));
				}
				if ($(this).attr("name") == ""
						|| $(this).attr("name") == undefined) {

				} else {
					try {
						initData[$(this).attr("name")] = $(this).combo(
								"getValue");
					} catch (e) {
						if ($(this).is("[type!='radio'][type!='checkbox']")) {
							initData[$(this).attr("name")] = $(this).val();
						} else {
							if ($(this).is("[type='radio']:checked")) {
								initData[$(this).attr("name")] = $(this).val();
							}
							if ($(this).is("[type='checkbox']:checked")) {
								
								if(initData[$(this).attr("name")]){
									
								}else{
									initData[$(this).attr("name")]=[];
								}
								initData[$(this).attr("name")].push($(this).val());
							}
						}

					}

					$(this).parent().find(".changevaluealert").removeClass(
							"changevaluealert");
//					changeDataField[indexC].parent().addClass("changevaluealert");
				}
			});

	target.find("table").each(function(i) {

		try {
			initData[this.id] = $(this).datagrid("getSelected");
		} catch (e) {
		}

	});
	try {
		target.removeData("initData_for_change"); // 移除blah

	} catch (e) {
		// TODO: handle exception
	}
	target.data("initData_for_change", initData);

}


function checkAryHasObj(ary , obj ){
	
	var flag = false; 
	for ( var index in ary) {
		if(ary[index]==obj){
			flag = true;
			break;
		}
	}
	return flag; 
}
/**
 * 
 * @param target
 *            监测数据是否修改，但是未保存
 * @return
 */
function checkChange(target,nextTarget,type) {
//	return true;
	var checkFlag = true;
	var combincheck = true;
	if(!_sinovalid_needValidFlag){
		return checkFlag; 
	}
	
	console.log("checkChange target id :"+ target.attr("id"));
	if(nextTarget!=undefined&&target.attr("id")==nextTarget.attr("id")){
		return checkFlag; 
	}
	
	
	if(combineCheckID[target.attr("id")]&&combineCheckID[target.attr("id")]==nextTarget.attr("id")){
		
		return checkFlag; 
		
	}else if(combineCheckID[target.attr("id")]&&(!type)){
		 
		combincheck =combincheck&&checkChange($("#"+combineCheckID[target.attr("id")]),nextTarget,"combine");
	}else{
		for ( var key in combineCheckID) {
			if(combineCheckID[key]==target.attr("id")&&(!type)){
				
				if(key ==nextTarget.attr("id") ){
					return checkFlag;
				}
				combincheck =combincheck&&checkChange($("#"+key),nextTarget,"combine");
			}
		}
	}
	target.find(".changevaluealert").removeClass(
	"changevaluealert");
	var initData = {};
	
	try {
		initData = target.data("initData_for_change");
	} catch (e) {
		return true;
	}

	var changeDataField = new Array();

	target
			.find("input,select")
			.each(
					function(i) {
						// if(checkFlag){
						//					
						// }else{
						// return ;
						// }
						
						if(ignoreCheck[$(this).attr("name")]==undefined){
							if ($(this).attr("name") == ""
								|| $(this).attr("name") == undefined
								|| ($(this).attr("name").indexOf("_combobox")+"_combobox".length)==$(this).attr("name").length) {

						} else {

							if ($(this).is("[type!='radio'][type!='checkbox']")) {
								if (initData[$(this).attr("name")] != $(this)
										.val()) {
									if (initData[$(this).attr("name")] == null
											&& $(this).val() == "") {
									} else {
										if($(this).attr("elementstatus")!='02'){
											checkFlag = checkFlag && false;
											changeDataField[changeDataField.length] = $(this);
										}
										
									}
								}
							} else {
								if ($(this).is("[type='radio']:checked")) {
									if (initData[$(this).attr("name")] != $(
											this).val()) {
										if (initData[$(this).attr("name")] == null
												&& $(this).val() == "") {
										} else {
											checkFlag = checkFlag && false;
											changeDataField[changeDataField.length] = $(this);
										}
									}
								}
								
								
										
								if ($(this).is("[type='checkbox']:checked")) {
									
									if (!checkAryHasObj(initData[$(this).attr("name")],$(this).val()) ) {
										if (initData[$(this).attr("name")] == null
												&& $(this).val() == "") {
											//判断长度是否
											
										} else {
											checkFlag = checkFlag && false;
											changeDataField[changeDataField.length] = $(this);
										}
									}
									
									
								}
								
								if ($(this).is("[type='checkbox']:not(:checked)")) {
									
									if (checkAryHasObj(initData[$(this).attr("name")],$(this).val()) ) {
										checkFlag = checkFlag && false;
										changeDataField[changeDataField.length] = $(this);
									}
									
									
								}
								
							}

						}
						}
						
					});

	target.find("table").each(function(i) {

		try {
			if (initData[this.id] == $(this).datagrid("getSelected")) {

			} else {
				checkFlag = checkFlag && false;
				changeDataField[changeDataField.length] = $(this);
			}

		} catch (e) {
			// TODO: handle exception
		}

	});
	if (checkFlag&&changeDataField.length==0) {

	} else {
		
		for ( var indexC in changeDataField) {
			changeDataField[indexC].parent().find("select:visible").addClass("changevaluealert");
			changeDataField[indexC].parent().find("input:visible").addClass("changevaluealert");
			changeDataField[indexC].parent().addClass("changevaluealert");
//			changeDataField[indexC].parent().parent().addClass("changevaluealert");
		}

		if(!checkFlag){
			
			if (target.attr("title") == "") {
				alert(target.panel("options").title + "的信息被修改，请保存！");
			} else {
				if(!target.attr("title")){
					alert($("#"+"tab_"+ target.attr("id")).attr("title") + "的信息被修改，请保存！");
				}else{
					alert(target.attr("title") + "的信息被修改，请保存！");
				}
				
				if(changeDataField.length>0){
					changeDataField[changeDataField.length-1].focus();
				}
 
			}
			
		}
		

	}
	return checkFlag&&combincheck;
}




/**
 * 
 * @param target
 *            监测数据是否修改，但是未保存 纸质单数据修改检查用
 * @return
 */
function checkChangefull(target,nextTarget,type,msg) {
//	return true;
	var checkFlag = true;
	var combincheck = true;
	if(!_sinovalid_needValidFlag){
		return checkFlag; 
	}
	
	console.log("checkChange target id :"+ target.attr("id"));
	if(nextTarget!=undefined&&target.attr("id")==nextTarget.attr("id")){
		return checkFlag; 
	}
	
	
	if(combineCheckID[target.attr("id")]&&combineCheckID[target.attr("id")]==nextTarget.attr("id")){
		
		return checkFlag; 
		
	}else if(combineCheckID[target.attr("id")]&&(!type)){
		 
		combincheck =combincheck&&checkChange($("#"+combineCheckID[target.attr("id")]),nextTarget,"combine");
	}else{
		for ( var key in combineCheckID) {
			if(combineCheckID[key]==target.attr("id")&&(!type)){
				
				if(key ==nextTarget.attr("id") ){
					return checkFlag;
				}
				combincheck =combincheck&&checkChange($("#"+key),nextTarget,"combine");
			}
		}
	}
	target.find(".changevaluealert").removeClass(
	"changevaluealert");
	var initData = {};
	
	try {
		initData = target.data("initData_for_change");
	} catch (e) {
		return true;
	}

	var changeDataField = new Array();

	target
			.find("input,select")
			.each(
					function(i) {
						// if(checkFlag){
						//					
						// }else{
						// return ;
						// }
						
						if(ignoreCheck[$(this).attr("name")]==undefined){
							if ($(this).attr("name") == ""
								|| $(this).attr("name") == undefined
								|| ($(this).attr("name").indexOf("_combobox")+"_combobox".length)==$(this).attr("name").length) {

						} else {

							if ($(this).is("[type!='radio'][type!='checkbox']")) {
								if (initData[$(this).attr("name")] != $(this)
										.val()) {
									if (initData[$(this).attr("name")] == null
											&& $(this).val() == "") {
									} else {
										if($(this).attr("elementstatus")!='02'){
											checkFlag = checkFlag && false;
											changeDataField[changeDataField.length] = $(this);
										}
										
									}
								}
							} else {
								if ($(this).is("[type='radio']:checked")) {
									if (initData[$(this).attr("name")] != $(
											this).val()) {
										if (initData[$(this).attr("name")] == null
												&& $(this).val() == "") {
										} else {
											checkFlag = checkFlag && false;
											changeDataField[changeDataField.length] = $(this);
										}
									}
								}
								
								
										
								if ($(this).is("[type='checkbox']:checked")) {
									
									if (!checkAryHasObj(initData[$(this).attr("name")],$(this).val()) ) {
										if (initData[$(this).attr("name")] == null
												&& $(this).val() == "") {
											//判断长度是否
											
										} else {
											checkFlag = checkFlag && false;
											changeDataField[changeDataField.length] = $(this);
										}
									}
									
									
								}
								
								if ($(this).is("[type='checkbox']:not(:checked)")) {
									
									if (checkAryHasObj(initData[$(this).attr("name")],$(this).val()) ) {
										checkFlag = checkFlag && false;
										changeDataField[changeDataField.length] = $(this);
									}
									
									
								}
								
							}

						}
						}
						
					});

	target.find("table").each(function(i) {

		try {
			if (initData[this.id] == $(this).datagrid("getSelected")) {

			} else {
				checkFlag = checkFlag && false;
				changeDataField[changeDataField.length] = $(this);
			}

		} catch (e) {
			// TODO: handle exception
		}

	});
	if (checkFlag&&changeDataField.length==0) {

	} else {
		
		for ( var indexC in changeDataField) {
			changeDataField[indexC].parent().find("select:visible").addClass("changevaluealert");
			changeDataField[indexC].parent().find("input:visible").addClass("changevaluealert");
			changeDataField[indexC].parent().addClass("changevaluealert");
//			changeDataField[indexC].parent().parent().addClass("changevaluealert");
		}

		var msgType="confirm";
		if(!checkFlag){
			
			if (target.attr("title") == "") {
				if(msgType=="confirm"){
					
					return confirm(target.panel("options").title +msg);
					
				}else{
					alert(target.panel("options").title +msg);
				}
				
			} else {
				if(!target.attr("title")){
					
					if(msgType=="confirm"){
						
						return confirm($("#"+"tab_"+ target.attr("id")).attr("title") +msg);
						
					}else{
						alert($("#"+"tab_"+ target.attr("id")).attr("title") +msg);
					}
					
				}else{
					
					if(msgType=="confirm"){
						
						return confirm(target.attr("title") +msg);
						
					}else{
						alert(target.attr("title") + msg);
					}
					
				}
				
				if(changeDataField.length>0){
					changeDataField[changeDataField.length-1].focus();
				}
 
			}
			
		}
		

	}
	return checkFlag&&combincheck;
}

function initNotNullFlag(target) {

	if (target.parent().find("span[necessary='necessary']").length == 0) {
		target
				.after("<span style='color: red;margin-left: 5px' necessary='necessary'>*</span>");
	}
}