/** 
 *平安 投保人 邮寄地址同 家庭地址
 */
afterVueSelect.postalflagPingAn = function(form_element) {
	
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (obj.is("[type='checkbox']:checked")) {

		for ( var key in topvue.form_elements.lcappnt) {
			
			if (topvue.form_elements.lcappnt[key].name == 'homeprovince') {
				bindSameElement.call(this, this.formdata, "postprovince",
						this.formdata, "homeprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homecity') {
				bindSameElement.call(this, this.formdata, "postcity",
						this.formdata, "homecity",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homedistrict') {
				bindSameElement.call(this, this.formdata, "postdistrict",
						this.formdata, "homedistrict",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homedetails') {
				bindSameElement.call(this, this.formdata, "postdetails",
						this.formdata, "homedetails",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homezipcode') {
				bindSameElement.call(this, this.formdata, "zipcode",
						this.formdata, "homezipcode",
						topvue.form_elements.lcappnt[key]);
			}
			

		}
	} else {
		for ( var key in topvue.form_elements.lcappnt) {
			
			
			if (topvue.form_elements.lcappnt[key].name == 'homeprovince') {
				unbindSameElement.call(this, "postprovince",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homecity') {
				unbindSameElement.call(this, "postcity",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homedistrict') {
				unbindSameElement.call(this, "postdistrict",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homedetails') {
				unbindSameElement.call(this, "postdetails",
						topvue.form_elements.lcappnt[key]);
			}
			if (topvue.form_elements.lcappnt[key].name == 'homezipcode') {
				unbindSameElement.call(this, "zipcode",
						topvue.form_elements.lcappnt[key]);
			}

		}
		

	}

};
//证件长期有效
/*afterVueSelect.appntislongitemmeli = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");
	if (obj.is("[type='checkbox']:checked")){
		topvue.$set(topvue.formdata.lcappnt,"appntenddate","9999-12-31");
		$("#lcappnt_tabinfoform").data('bootstrapValidator').resetField($("#appntenddate"));
		$("#appntenddate").attr("disabled",true);
	}else {
//		$("#appntenddate").attr("disabled",false);
	}
}*/



//MELI居民类型
commonCombobox_option.commonCombobox_creditgrademeli = {
	valueField : "code",
	inputText : "codename",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "codename" ],
	data : [ {
		code : '1',
		codename : '农村居民'
	}, {
		code : '2',
		codename : '城镇居民'
	} ]
};


/*//行业类别
commonCombobox_option.commonCombobox_appntindustry = {
	url : path + '/newCont/codeselect/occupation/AL.do',
	valueField : "occupationcode1",
	// 显示在输入框的
	inputText : "occupationname1",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname1" ]
};
//行业代码
commonCombobox_option.commonCombobox_appntindustrycode = {
	url : path + '/newCont/codeselect/occupation/#appntindustrytype/AL.do',
	valueField : "occupationcode2",
	// 显示在输入框的
	inputText : "occupationname2",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname2" ]
};
 
//职业代码
commonCombobox_option.commonCombobox_appntoccupationcode = {
	url : path + '/newCont/codeselect/occupationocc/#appntoccupationtype/AL.do',
	valueField : "occupationcode",
	// 显示在输入框的
	inputText : "occupationname",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : [ "occupationname" ]
};*/

 

/*afterVueSelect.relationtoappnt=function(form_element){
	 
	var topvue = getTopvueObj(this);
	if(topvue.formdata.lcinsured["relationtoappnt"]=="01"){
		
		topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",topvue.formdata.lcappnt.appntname); 
		
//		topvue.formdata.lcinsured["lcinsuredname"]=topvue.formdata.lcappnt.appntname;
	}else{
//		topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",""); 
		
	}
	
}*/

//投保人信息成功保存后， 校验投保单号
aftersubmitvueform.lcappnt_tabinfoform = function(){
	var recording = initFormdata.newContApply.recording;	
	console.log("***checking Recording flag***=======" + recording);
	if(recording == "Y"){
		console.log("***current Recording changing operation***");
		var topvue = getTopvueObj(this);
		topvue.form_elementsBYID.lccont.proposalcontno.cssClass = "disabled";
		$("#proposalcontno").attr("disabled",true);
		console.log("***diabled proposalcontno***");
	}
	var proposalcontno =vueobj["testdivchange"].formdata.lccont.proposalcontno;
	if(proposalcontno !=null && proposalcontno !=""){
		$('#newcompanyCode').combobox("disable");
		$('#newcitycode').combobox("disable");		
	}
	console.log("***aftersubmitvueform.lcappnt_tabinfoform***");
	return true;
}
//投保人与被保人关系
commonCombobox_option.commonCombobox_relationforpingan = {
//	url:path + '/LdcodeController/selectLcodeByCodetype.do?codetype=relationformanu',
	url : path + '/newCont/codeselect/common/relationforpingan',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText :  "codename" ,
	textShow : [ "codename" ]

};

commonCombobox_option.commonCombobox_bankcustomertype = {

	url : path + '/newCont/codeselect/common/bankcustomertype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText :  "codename" ,
	textShow : [ "codename" ]

};