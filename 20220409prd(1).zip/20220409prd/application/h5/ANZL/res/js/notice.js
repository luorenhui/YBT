/**
 * 
 * @param noticeid
 * @param type
 *            1主被保險人 2附屬
 */
function hiddenNoticeELements(topvue, noticeid, type,noticeinfoType) {

	if(!noticeinfoType){
		noticeinfoType="i";
	}
	
	
	var insuquestion ="insuquestion";
	if(noticeinfoType=="q"){
		
		insuquestion="noticeInfo";
	}
	
	if(noticeinfoType=="a"){
		
		insuquestion="appntquestion";
	}
	
	var questionID = noticeid + noticeinfoType + type;
	try {
		// topvue.form_elementsBYID.commonFormNotice[noticeid].insuquestion[questionID].elementstatus="02";
		
		//对象不为空再操作里面的属性
		if(null!=topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID]
		&&topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID]!=undefined){
			
		
		if (topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID].elementstatus == "02") {
			console.info(noticeid + " 该条告知配置不显示不作处理");

		} else {
				
				topvue.$set( topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID],
						"elementstatus", "04");
			
		}
		
	  }

	} catch (e) {
		console.info(" error : 告知：" + noticeid + " 所属子元素节点ID配置未找到被保人问题，"
				+ " 请检查告知formelement 的告知配置项 请按照约定进行ID设置 " + noticeid + noticeinfoType
				+ type + " exception:" + e);
	}

	// topvue

}


function showNoticeELements(topvue, noticeid, type ,noticeinfoType) {

	if(!noticeinfoType){
		noticeinfoType="i";
	}
	var questionID = noticeid + noticeinfoType + type;
	var insuquestion ="insuquestion";
	if(noticeinfoType=="q"){
		
		insuquestion="noticeInfo";
	}
	try {
		//对象不为空再操作里面的属性
		if(null!=topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID]
		&&topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID]!=undefined){
			
		
		if (topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID].elementstatus == "02") {
			console.info(noticeid + " 该条告知配置不显示不作处理");

		} else {
			
				topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID],
						"elementstatus", "01");
			
		}
		// topvue.form_elementsBYID.commonFormNotice[noticeid].insuquestion[questionID].elementstatus="02";
	
	 }
		
	} catch (e) {
		console.info(" error : 告知：" + noticeid + " 所属子元素节点ID配置未找到被保人问题，"
				+ " 请检查告知formelement 的告知配置项 请按照约定进行ID设置 " + noticeid + noticeinfoType
				+ type + " exception:" + e);
	}

	// topvue

}


function showFather(topvue,noticeid){
	console.info("执行showFather……");
	if (topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
//		topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus  = "04";
		topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid],
				"elementstatus", "01");
	}
	
}

function hiddenFather(topvue,noticeid){
	console.info("执行hiddenFather……");
	if ( topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
		topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid],
				"elementstatus", "04");
	}
}
//隐藏所有的 第二被保人 问题
function hiddenAllInsuTwo(topvue){
	
	for ( var key in topvue.form_elementsBYID.commonFormNotice) {
 
		hiddenNoticeELements(topvue, topvue.form_elementsBYID.commonFormNotice[key].id, "2");
	}
	
//	--简单告知
//	notice1q5 -- 被保险人2身高
//	notice1q6 -- 被保险人2体重
//	--复杂告知
//	notice10q5 -- 被保险人2身高
//	notice10q6 -- 被保险人2体重
	
	hiddenNoticeELements(topvue, "notice1", "5", "q");
	hiddenNoticeELements(topvue, "notice1", "6", "q");
	hiddenNoticeELements(topvue, "notice10", "5", "q");
	hiddenNoticeELements(topvue, "notice10", "6", "q");
	
 
	
	
}

//显示所有的 第二被保人 问题
function showAllInsuTwo(topvue){
	
	for ( var key in topvue.form_elementsBYID.commonFormNotice) {
		
		showNoticeELements(topvue, topvue.form_elementsBYID.commonFormNotice[key].id, "2");
	}
	showNoticeELements(topvue, "notice1", "5", "q");
	showNoticeELements(topvue, "notice1", "6", "q");
	showNoticeELements(topvue, "notice10", "5", "q");
	showNoticeELements(topvue, "notice10", "6", "q");
	
	
}
/**
 * 控制第二被保人问题 是否显示
 * @param topvue
 */
function checkInsuTwoNotice(topvue) {
	var formdata = topvue.formdata;
	if (formdata['lcinsured'] 
			&& formdata['lcinsured'].lcinsuredtwoflag
			&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
			&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
		showAllInsuTwo(topvue);
	}else{
		hiddenAllInsuTwo(topvue);
		
	}
}
////被保人保存前  影响告知显示
//beforesubmitvueform.lcinsured_tabinfoform = function() {
//	
//	
////	try {
////		//被保人 女性 和 小孩显示控制
////		checkInsuTwoNotice(this);
////	} catch (e) {
////		console.info("checkInsuTwoNotice exception: " + e);
////	}
////	try {
////		//是否显示第二被保人问题
////		showELementSByInsu(this);
////	} catch (e) {
////		console.info("lcinsured_tabinfoform exception: " + e);
////	}
////	try {
////		//显示 所属被保人的  （受益人，附加险）
////		showBelongInsu(this);
////	} catch (e) {
////		console.info("lcinsured_tabinfoform exception: " + e);
////	}
//	return true;
//};


afterloadNewElements.lcbnf_tabinfo = function(url, form_element) {
	
	try {
/*		 this.$nextTick(function(){		
		     setTimeout(function(){
		    	 for (var i=0;i<$("input[id^='bnfrenewCount']").length;i++){
		    		 if(($("#bnfrenewCount\\["+i+"\\]").is(":visible") && $("#bnfrenewCountTitle"+i+"").length <= 0)){
//	    		   		 $("#bnfrenewCountTitle").remove();
	    		   		$("#bnfrenewCount\\["+i+"\\]").parent().append("<small id='bnfrenewCountTitle"+i+"' class='help-block zhq' style='color: red;'>请注意，" +
	    		   				"请按证件上的换证次数填写，例如：01。</small>");
	    				 }
	    	 }
		     },200);
			});
			$("input[value='增加新受益人']").click(function(){
				 setTimeout(function(){
					 if(($("#bnfrenewCount\\["+(vueobj["testdivchange"].formdata['bnf'].length-1)+"\\]").is(":visible") 
							 && $("#bnfrenewCountTitle"+(vueobj["testdivchange"].formdata['bnf'].length-1)+"").length <= 0)){
					 $("#bnfrenewCount\\["+(vueobj["testdivchange"].formdata['bnf'].length-1)+"\\]").parent().append("<small id='bnfrenewCountTitle"+(vueobj["testdivchange"].formdata['bnf'].length-1)+"' class='help-block zhq' style='color: red;'>请注意，" +
	   				"请按证件上的换证次数填写，例如：01。</small>");
					 }
				 },200);
})		*/
		var topvue = getTopvueObj(this);
		showBelongInsu(topvue);
	} catch (e) {
		
		console.info("afterloadNewElements.lcbnf_tabinfo : " + e);
	}
	
};

afterloadNewElements.subriskcode_tabinfo = function(url, form_element) {
	
	//判断是否是多被保人
	if(initFormdata.newContApply.investment=='M'){
		
		var mu=vueobj["testdivchange"].formdata.lcinsuredmulti.length;
		
		var mysize=parseInt(mu+1);
		var ar=[{
			code : '0',
			codename : '主被保险人',
		}];
		for(var a=1;a<mysize;a++){
			ar.push({
				code : a,
				codename : '其他被保险人'+a,
			});
		}
		
		commonCombobox_option.commonCombobox_maininsured.data=ar;
		$("input[id^='maininsured[']").combobox("setData" ,ar);
		$("input[id^='maininsured[']").combobox("loadData");
//		setTimeout(function(){
//			//页面加载以后加载所属被保人的值
//			incuredall();
//		},200);
	
		//点击增加附加险按钮加载所属被保人的值
//		$("input[name='addnew']").click(function() {
//			setTimeout(function(){
//				incuredall();
//		},200);
//			
//		});
	}
//	 this.$nextTick(function(){		
//	     setTimeout(function(){
//	    	 for (var i=0;i<$("input[id^='otherinsuredrenewCount1']").length;i++){
//	if(($("#otherinsuredrenewCount1\\["+i+"\\]").is(":visible")&&$("#otherinsuredrenewCount1Title\\["+i+"\\]").length<=0)){
////   		 $("#otherinsuredrenewCount1Title").remove();
//   		$("#otherinsuredrenewCount1\\["+i+"\\]").parent().append("<small id='otherinsuredrenewCount1Title\\["+i+"\\]' class='help-block zhq' style='color: red;'>请注意，" +
//   				"请按证件上的换证次数填写，例如：01。</small>");
//		 }
//	    	 }
//	     },200);
//		});
//		$("input[name='addnew']").click(function(){
//			 setTimeout(function(){
//				 $("#otherinsuredrenewCount1\\["+(vueobj["testdivchange"].formdata['otherinsured'].length-1)+"\\]").parent().append("<small class='help-block zhq' style='color: red;'>请注意，" +
//   				"请按证件上的换证次数填写，例如：01。</small>");
//			 },200);
//})						
	try {
		var topvue = getTopvueObj(this);
		showBelongInsu(topvue);
	} catch (e) {
		console.info("afterloadNewElements.subriskcode_tabinfo : " + e);
	}
	
};
/**
 * 显示 所属被保人的  （受益人，附加险）
 * @param vueobj
 */
function showBelongInsu(topvue){
	
	var formdata = topvue.formdata;
	
	if (formdata['lcinsured'] 
			&& formdata['lcinsured'].lcinsuredtwoflag
			&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
			&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
		//附加险
		topvue.$set(topvue.form_elementsBYID.bnf.lcbnfofinsu , "elementstatus", "01");
		topvue.$set(topvue.form_elementsBYID.subriskcode.subriskbelong , "elementstatus", "01");
		
		
	}else{
		//附加险
		topvue.$set(topvue.form_elementsBYID.bnf.lcbnfofinsu , "elementstatus", "04");
		topvue.$set(topvue.form_elementsBYID.subriskcode.subriskbelong , "elementstatus", "04");
	}
	
	
}
/***
 * 控制特殊告知显示
 * @param topvue
 * @returns {Boolean}
 */
function showELementSByInsu(topvue) {

	try {
		if (!topvue.form_elements.commonFormNotice) {
			return true;
		}

		// lcinsured_tabinfoform
		var maininsuAge = getAgeFromBrithday(topvue.formdata.lcinsured.lcinsuredbirthday); // 年龄
		var appntAge = getAgeFromBrithday(topvue.formdata.lcappnt.appntbirthday); // 年龄
		var appntSex = topvue.formdata.lcappnt.appntsex;
		var appntWoemnFlag =false;
		//投保人女性告知
		if (appntSex == '1' && appntAge >= 15) {
			
			showNoticeELements(topvue, "notice7" , "1" ,"a");
			showNoticeELements(topvue, "notice37", "1" ,"a");
			showNoticeELements(topvue, "notice38", "1" ,"a");
			showNoticeELements(topvue, "notice39", "1" ,"a");
		} else {
			appntWoemnFlag = true;
			hiddenNoticeELements(topvue, "notice7" , "1","a");
			hiddenNoticeELements(topvue, "notice37", "1","a");
			hiddenNoticeELements(topvue, "notice38", "1","a");
			hiddenNoticeELements(topvue, "notice39", "1","a");
		}
		
		var hasInsuTwoFlag = false;
		var formdata = topvue.formdata;
		var twoinsuAge = "";
		try {

			if (formdata['lcinsured']
					&& formdata['lcinsured'].lcinsuredtwoflag
					&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
					&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
				twoinsuAge = getAgeFromBrithday(topvue.formdata.lcinsuredtwo.lcinsuredbirthday); // 年龄
				hasInsuTwoFlag = true;
			}
		} catch (e) {
			console.info("error : 附属被保险人 年龄 获取 失败 " + e);
		}

		// 女性 》=15 notice7 notice37 notice38 notice39

//		if (topvue.form_elementsBYID.commonFormNotice["notice7"].elementstatus == "02"
//				&& topvue.form_elementsBYID.commonFormNotice["notice37"].elementstatus == "02"
//				&& topvue.form_elementsBYID.commonFormNotice["notice38"].elementstatus == "02"
//				&& topvue.form_elementsBYID.commonFormNotice["notice39"].elementstatus == "02") {
//			// 均已配置不显示 不做处理
//		} else {
			var mainWomenFlag = false;
			var twoWomenFlag = false;

			// 主被保人 女性 判断

			var maininsuSex = topvue.formdata.lcinsured.lcinsuredsex; // 0 男
																		// 1女

			if (maininsuSex == '1' && maininsuAge >= 15) {
				
				showNoticeELements(topvue, "notice7", "1");
				showNoticeELements(topvue, "notice37", "1");
				showNoticeELements(topvue, "notice38", "1");
				showNoticeELements(topvue, "notice39", "1");
			} else {
				mainWomenFlag = true;
				hiddenNoticeELements(topvue, "notice7", "1");
				hiddenNoticeELements(topvue, "notice37", "1");
				hiddenNoticeELements(topvue, "notice38", "1");
				hiddenNoticeELements(topvue, "notice39", "1");
			}

			// 第二被保人 女性 判断

			if (hasInsuTwoFlag) {
				var twoinsuSex = topvue.formdata.lcinsuredtwo.lcinsuredsex; // 0 男
																			// 1女

				if (twoinsuSex == '1' && twoinsuAge >= 15) {
					
					showNoticeELements(topvue, "notice7", "2");
					showNoticeELements(topvue, "notice37", "2");
					showNoticeELements(topvue, "notice38", "2");
					showNoticeELements(topvue, "notice39", "2");
				} else {
					twoWomenFlag = true;
					hiddenNoticeELements(topvue, "notice7", "2");
					hiddenNoticeELements(topvue, "notice37", "2");
					hiddenNoticeELements(topvue, "notice38", "2");
					hiddenNoticeELements(topvue, "notice39", "2");
				}

			} else {
				twoWomenFlag = true;
			}

			if (twoWomenFlag && mainWomenFlag && appntWoemnFlag) {
				hiddenFather(topvue,"notice7");
				hiddenFather(topvue,"notice37");
				hiddenFather(topvue,"notice38");
				hiddenFather(topvue,"notice39");
			}else{
				showFather(topvue,"notice7");
				showFather(topvue,"notice37");
				showFather(topvue,"notice38");
				showFather(topvue,"notice39");
			}
//		}

		// 小孩子notice8 notice9 notice28 notice29
//		if (topvue.form_elementsBYID.commonFormNotice["notice8"].elementstatus == "02"
//				&& topvue.form_elementsBYID.commonFormNotice["notice9"].elementstatus == "02"
//				&& topvue.form_elementsBYID.commonFormNotice["notice28"].elementstatus == "02"
//				&& topvue.form_elementsBYID.commonFormNotice["notice29"].elementstatus == "02") {
//			// 均已配置不显示 不做处理
//		} else {
			var mainChildFlag = false;

			var twoChildFlag = false;

			if (maininsuAge <= 2) {
				
				showNoticeELements(topvue, "notice8", "1");
				showNoticeELements(topvue, "notice9", "1");
				showNoticeELements(topvue, "notice28", "1");
				showNoticeELements(topvue, "notice29", "1");
			} else {
				mainChildFlag = true;
				hiddenNoticeELements(topvue, "notice8", "1");
				hiddenNoticeELements(topvue, "notice9", "1");
				hiddenNoticeELements(topvue, "notice28", "1");
				hiddenNoticeELements(topvue, "notice29", "1");
			}

			if (hasInsuTwoFlag) {

				if (twoinsuAge <= 2) {
					
					showNoticeELements(topvue, "notice8", "2");
					showNoticeELements(topvue, "notice9", "2");
					showNoticeELements(topvue, "notice28", "2");
					showNoticeELements(topvue, "notice29", "2");
				} else {
					twoChildFlag = true;
					hiddenNoticeELements(topvue, "notice8", "2");
					hiddenNoticeELements(topvue, "notice9", "2");
					hiddenNoticeELements(topvue, "notice28", "2");
					hiddenNoticeELements(topvue, "notice29", "2");
				}
			} else {
				twoChildFlag = true;
			}
//			if (topvue.form_elementsBYID.commonFormNotice["notice8"].elementstatus !="01"
//				&& topvue.form_elementsBYID.commonFormNotice["notice9"].elementstatus !="01"
//				&& topvue.form_elementsBYID.commonFormNotice["notice28"].elementstatus !="01"
//				&& topvue.form_elementsBYID.commonFormNotice["notice29"].elementstatus !="01"){
//				
//				
//			}
			
			
			if (mainChildFlag && twoChildFlag) {
 
				hiddenFather(topvue,"notice8");
				hiddenFather(topvue,"notice9");
				hiddenFather(topvue,"notice28");
				hiddenFather(topvue,"notice29");
				
			}else{
				
				showFather(topvue,"notice8");
				showFather(topvue,"notice9");
				showFather(topvue,"notice28");
				showFather(topvue,"notice29");
			}
			 

//		}
	} catch (e) {
		// TODO: handle exception
	}

	return true;

}



///////////非多被保人隐藏未成年人告知
/**
* 未成年告知检测
*/
//为什么不用之前的showFather和HideFather？因为在回退修改后再出发不能再次显示和隐藏，所以只能用jq操作DOM。
//全局的隐藏控件的数组
var HideElements=[];

//自定义的hide，隐藏完后会存在全局数组中，方便之后显示
$.fn.MutlHideA=function () {
$(this).hide(0,function() {
HideElements.push($(this));
});
}
//自定义的show，只有再配置为显示的控件显示
$.fn.MutlShowA=function (topvue,noticeid) {
if (topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus != "02") {
console.info(topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus);
this.show();
}
}


/**
* 非多被保人未成年人告知特别设计的隐藏逻辑  未配置年金转万能产品  调用控制未成年人告知方法
* @author loweite
* @param topvue
*/
function hideELementSByImmaturity(topvue){
	
	console.log("非多被保人（joinlife!=M）未配置年金转万能产品  未成年人告知隐藏方法  hideELementSByImmaturity");	
 
  try{	
	 
		if (!topvue.form_elements.commonFormNotice) {
			console.log("hideELementSByImmaturity  !topvue.form_elements.commonFormNotice");
			return true;
		}
		
		//若未成年告知未配置，退出此方法
		if(topvue.form_elementsBYID.commonFormNotice["notice6"].elementstatus != "01"&&topvue.form_elementsBYID.commonFormNotice["notice33"].elementstatus != "01"){
			console.log("hideELementSByImmaturity  若未成年告知未配置，退出此方法");
			return true;
			
		}else{
			
			if(topvue.form_elementsBYID.commonFormNotice["notice6"].elementstatus != "01"){
				
			}else{//已经配置为显示
				 
				if($("#normal_notice .hide_tab").children().eq(5).is(":hidden")){
				     //  $("#test").show();    //如果元素为隐藏,则将它显现
				  
					$("#normal_notice .hide_tab").children().eq(5).MutlShowA(topvue,"notice6");	
				}
				  	
			}
			if(topvue.form_elementsBYID.commonFormNotice["notice33"].elementstatus != "01"){
				
			}else{//已经配置为显示
				  
				if($("#normal_notice .hide_tab").children().eq(36).is(":hidden")){
				     //  $("#test").show();    //如果元素为隐藏,则将它显现
				   	
					$("#normal_notice .hide_tab").children().eq(36).MutlShowA(topvue,"notice33");
				}					
				  
			}
		}
	 	

		//先显示全部，再修改，原因：当被保人修改，保证告知同步的正确
		console.info("hideELementSByImmaturity  ---开始未成年人特殊处理  先显示全部，再修改，原因：当被保人修改，保证告知同步的正确");
	
		//先显示并且清空隐藏控件数组
		var length=HideElements.length;//超级大坑，千万记得先赋值在循环
		for ( var i = 0; i <length; i++){
			var ele=HideElements.pop();
			ele.show();
		}
		
		var maininsuAge =topvue.formdata.lcinsured.lcinsuredage; // 主被保险人年龄
		
		var appntAge = getAgeFromBrithday(topvue.formdata.lcappnt.appntbirthday); // 投保人年龄
		
		
		var twoinsuAge=""; //第二被保人年龄
		var hasInsuTwoFlag = false;
		var formdata = topvue.formdata;
		if (formdata['lcinsured']
		&& formdata['lcinsured'].lcinsuredtwoflag
		&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
		&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
		    twoinsuAge = getAgeFromBrithday(topvue.formdata.lcinsuredtwo.lcinsuredbirthday); // 第二被保人年龄
		    hasInsuTwoFlag = true;
		}
		
		
		console.log("hasInsuTwoFlag --"+hasInsuTwoFlag);
		
		
		console.log("未成年人告知处理");
		
		//投保人大于等于18岁，隐藏选项
		if(appntAge>=18){
			
			//隐藏投保人单选框   id=notice6
			$("input[name='noticeinfos[5].owneryesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			HideElements.push($("input[name='noticeinfos[5].owneryesorno']") .parentsUntil("div.form-group-div").parent("div"));
					
			
			//隐藏投保人单选框   id=notice33
			$("input[name='noticeinfos[36].owneryesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			HideElements.push($("input[name='noticeinfos[36].owneryesorno']") .parentsUntil("div.form-group-div").parent("div"));
			
			console.log("appntAge ="+appntAge);
		}
		
		//主被保人大于等于18岁，隐藏选项
		if(maininsuAge>=18){
			
			//隐藏单选框
			$("input[name='noticeinfos[5].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			HideElements.push($("input[name='noticeinfos[5].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			
			//隐藏单选框
			$("input[name='noticeinfos[36].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			HideElements.push($("input[name='noticeinfos[36].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			
			console.log("maininsuAge ="+maininsuAge);
		}
		
		//第二被保人大于等于18岁，隐藏选项
		if(hasInsuTwoFlag&&twoinsuAge>=18){		
			
			//隐藏第二被保人单选框
			$("input[name='noticeinfos[5].insuredyesorno2']") .parentsUntil("div.form-group-div").parent("div").hide();
			HideElements.push($("input[name='noticeinfos[5].insuredyesorno2']") .parentsUntil("div.form-group-div").parent("div"));
			
			//隐藏第二被保人单选框
			$("input[name='noticeinfos[36].insuredyesorno2']") .parentsUntil("div.form-group-div").parent("div").hide();
			HideElements.push($("input[name='noticeinfos[36].insuredyesorno2']") .parentsUntil("div.form-group-div").parent("div"));
			
			console.log("twoinsuAge ="+twoinsuAge);
		}
		
		
		if(hasInsuTwoFlag){
			if(twoinsuAge>=18&&maininsuAge>=18&& appntAge>= 18){
					
				$("#normal_notice .hide_tab").children().eq(5).hide();
				$("#normal_notice .hide_tab").children().eq(36).hide();
			
				console.log("twoinsuAge>=18&&maininsuAge>=18&& appntAge>= 18隐藏未成年人告知   notice6 notice33");
		   }else{			   
				console.log("twoinsuAge<18||maininsuAge<18|| appntAge< 18 显示未成年人告知  notice6 notice33");
				/////
				//div_notice33a136 投保人  divnotice33i136被保人1  divnotice33i236被保人2
				if($("#normal_notice .hide_tab").children().eq(36).find("#div_notice33a136").is(":hidden")
				 &&$("#normal_notice .hide_tab").children().eq(36).find("#divnotice33i136").is(":hidden")
				 &&$("#normal_notice .hide_tab").children().eq(36).find("#divnotice33i236").is(":hidden")){
					console.log("notice33对应投被保人单选按钮页面已经隐藏，隐藏notice33告知");
					$("#normal_notice .hide_tab").children().eq(36).hide();
				}
				
				//divnotice6a15 投保人  divnotice6i15被保人1  divnotice6i25被保人2
				if($("#normal_notice .hide_tab").children().eq(5).find("#divnotice6a15").is(":hidden")
				 &&$("#normal_notice .hide_tab").children().eq(5).find("#divnotice6i15").is(":hidden")
				 &&$("#normal_notice .hide_tab").children().eq(5).find("#divnotice6i25").is(":hidden")){
					console.log("notice6对应投被保人单选按钮页面已经隐藏，隐藏notice6告知");
					$("#normal_notice .hide_tab").children().eq(5).hide();
				}
			   ////
		   }
		}else{
			if(maininsuAge>=18&& appntAge>= 18){
			
				$("#normal_notice .hide_tab").children().eq(5).hide();
				$("#normal_notice .hide_tab").children().eq(36).hide();
				
				console.log("maininsuAge>=18&& appntAge>= 18隐藏未成年人告知   notice6 notice33");
			}else{
				
				console.log("maininsuAge<18||appntAge<18 显示未成年人告知  notice6 notice33");
				/////
				//div_notice33a136 投保人  divnotice33i136被保人1 
				if($("#normal_notice .hide_tab").children().eq(36).find("#div_notice33a136").is(":hidden")
				 &&$("#normal_notice .hide_tab").children().eq(36).find("#divnotice33i136").is(":hidden")){
					console.log("notice33对应投被保人单选按钮页面已经隐藏，隐藏notice33告知");
					$("#normal_notice .hide_tab").children().eq(36).hide();
				}
				
				//divnotice6a15 投保人  divnotice6i15被保人1  
				if($("#normal_notice .hide_tab").children().eq(5).find("#divnotice6a15").is(":hidden")
				 &&$("#normal_notice .hide_tab").children().eq(5).find("#divnotice6i15").is(":hidden")){
					console.log("notice6对应投被保人单选按钮页面已经隐藏，隐藏notice6告知");
					$("#normal_notice .hide_tab").children().eq(5).hide();
				}
			   ////
				
			}
			
		}
		
 	} catch (e) {
 		console.log("hideELementSByImmaturity 未成年人告知异常  catch");
		// TODO: handle exception
	}
	
}




/**
* 非多被保人未成年人告知特别设计的隐藏逻辑
* @author loweite
* @param topvue
*/
function hideELementSById(topvue){

console.log("非多被保人 且配置了年金转万能产品（joinlife!=M）未成年人告知隐藏方法  hideELementSById");

 try{

		if (!topvue.form_elements.commonFormNotice) {
			console.log("hideELementSById  !topvue.form_elements.commonFormNotice");
			return true;
		}
		
		//年金转万能为N 告知不显示
		 if(null!=topvue.formdata.lcpol&&topvue.formdata.lcpol.whetherconvert!=''&&"N"==topvue.formdata.lcpol.whetherconvert){
			 console.log("hideELementSById N==topvue.formdata.lcpol.whetherconvert");
			 return true;
		 }
		
		//若未成年告知未配置，退出此方法
		if(topvue.form_elementsBYID.commonFormNotice["notice6"].elementstatus != "01"&&topvue.form_elementsBYID.commonFormNotice["notice33"].elementstatus != "01"){
			console.log("hideELementSById  若未成年告知未配置，退出此方法");
			return true;
			
		}else{
			
	
		if(topvue.form_elementsBYID.commonFormNotice["notice6"].elementstatus != "01"){
			
		}else{
			    //已经配置为显示
				if($("#normal_notice .hide_tab").children().eq(5).is(":hidden")){
				     //  $("#test").show();    //如果元素为隐藏,则将它显现
				  $("#normal_notice .hide_tab").children().eq(5).MutlShowA(topvue,"notice6");	
				}
			  	
		}
		if(topvue.form_elementsBYID.commonFormNotice["notice33"].elementstatus != "01"){
			
		}else{
			    //已经配置为显示
			    if($("#normal_notice .hide_tab").children().eq(36).is(":hidden")){
				     //  $("#test").show();    //如果元素为隐藏,则将它显现
				   	$("#normal_notice .hide_tab").children().eq(36).MutlShowA(topvue,"notice33");	
				}
		    
		}
	}

		//先显示全部，再修改，原因：当被保人修改，保证告知同步的正确
		console.info("hideELementSById  ---开始未成年人特殊处理  先显示全部，再修改，原因：当被保人修改，保证告知同步的正确");	
		
		//先显示并且清空隐藏控件数组
		var length=HideElements.length;//超级大坑，千万记得先赋值在循环
		for ( var i = 0; i <length; i++){
				var ele=HideElements.pop();
				ele.show();
		}
							
	var maininsuAge =topvue.formdata.lcinsured.lcinsuredage; // 主被保险人年龄
	
	var appntAge = getAgeFromBrithday(topvue.formdata.lcappnt.appntbirthday); // 投保人年龄
	
	
	var twoinsuAge=""; //第二被保人年龄
	var hasInsuTwoFlag = false;
	var formdata = topvue.formdata;
	if (formdata['lcinsured']
	&& formdata['lcinsured'].lcinsuredtwoflag
	&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
	&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
	    twoinsuAge = getAgeFromBrithday(topvue.formdata.lcinsuredtwo.lcinsuredbirthday); // 第二被保人年龄
	    hasInsuTwoFlag = true;
	}
	
	
	console.log("hasInsuTwoFlag --"+hasInsuTwoFlag);
	
	//投保人大于等于18岁，隐藏选项
	if(appntAge>=18){
		
		//隐藏投保人单选框   id=notice6
		$("input[name='noticeinfos[5].owneryesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
		HideElements.push($("input[name='noticeinfos[5].owneryesorno']") .parentsUntil("div.form-group-div").parent("div"));
				
		
		//隐藏投保人单选框   id=notice33
		$("input[name='noticeinfos[36].owneryesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
		HideElements.push($("input[name='noticeinfos[36].owneryesorno']") .parentsUntil("div.form-group-div").parent("div"));
		
		console.log("appntAge>=18 ="+appntAge);
	}
	
	//主被保人大于等于18岁，隐藏选项
	if(maininsuAge>=18){
		
		//隐藏单选框
		$("input[name='noticeinfos[5].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
		HideElements.push($("input[name='noticeinfos[5].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
		
		//隐藏单选框
		$("input[name='noticeinfos[36].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
		HideElements.push($("input[name='noticeinfos[36].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
		
		console.log("maininsuAge>=18 ="+maininsuAge);
	}
	
	//第二被保人大于等于18岁，隐藏选项
	if(hasInsuTwoFlag&&twoinsuAge>=18){		
		
		//隐藏第二被保人单选框
		$("input[name='noticeinfos[5].insuredyesorno2']") .parentsUntil("div.form-group-div").parent("div").hide();
		HideElements.push($("input[name='noticeinfos[5].insuredyesorno2']") .parentsUntil("div.form-group-div").parent("div"));
		
		//隐藏第二被保人单选框
		$("input[name='noticeinfos[36].insuredyesorno2']") .parentsUntil("div.form-group-div").parent("div").hide();
		HideElements.push($("input[name='noticeinfos[36].insuredyesorno2']") .parentsUntil("div.form-group-div").parent("div"));
		
		console.log("hasInsuTwoFlag&&twoinsuAge>=18 ="+twoinsuAge);
	}
	
	
	if(hasInsuTwoFlag){
		if(twoinsuAge>=18&&maininsuAge>=18&& appntAge>= 18){
				
			$("#normal_notice .hide_tab").children().eq(5).hide();
			$("#normal_notice .hide_tab").children().eq(36).hide();
		
			console.log("twoinsuAge>=18&&maininsuAge>=18&& appntAge>= 18隐藏未成年人告知   notice6 notice33");
	   }else{
		   
			console.log("twoinsuAge<18||maininsuAge<18|| appntAge< 18 显示未成年人告知  notice6 notice33");
			/////
			//div_notice33a136 投保人  divnotice33i136被保人1  divnotice33i236被保人2
			if($("#normal_notice .hide_tab").children().eq(36).find("#div_notice33a136").is(":hidden")
			 &&$("#normal_notice .hide_tab").children().eq(36).find("#divnotice33i136").is(":hidden")
			 &&$("#normal_notice .hide_tab").children().eq(36).find("#divnotice33i236").is(":hidden")){
				console.log("notice33对应投被保人单选按钮页面已经隐藏，隐藏notice33告知");
				$("#normal_notice .hide_tab").children().eq(36).hide();
			}
			
			//divnotice6a15 投保人  divnotice6i15被保人1  divnotice6i25被保人2
			if($("#normal_notice .hide_tab").children().eq(5).find("#divnotice6a15").is(":hidden")
			 &&$("#normal_notice .hide_tab").children().eq(5).find("#divnotice6i15").is(":hidden")
			 &&$("#normal_notice .hide_tab").children().eq(5).find("#divnotice6i25").is(":hidden")){
				console.log("notice6对应投被保人单选按钮页面已经隐藏，隐藏notice6告知");
				$("#normal_notice .hide_tab").children().eq(5).hide();
			}
		   ////
	   
	   }
	}else{
		if(maininsuAge>=18&& appntAge>= 18){
		
			$("#normal_notice .hide_tab").children().eq(5).hide();
			$("#normal_notice .hide_tab").children().eq(36).hide();
			
			console.log("maininsuAge>=18&& appntAge>= 18隐藏未成年人告知   notice6 notice33");
		}else{
			
			console.log("maininsuAge<18||appntAge<18 显示未成年人告知  notice6 notice33");
			/////
			//div_notice33a136 投保人  divnotice33i136被保人1 
			if($("#normal_notice .hide_tab").children().eq(36).find("#div_notice33a136").is(":hidden")
			 &&$("#normal_notice .hide_tab").children().eq(36).find("#divnotice33i136").is(":hidden")){
				console.log("notice33对应投被保人单选按钮页面已经隐藏，隐藏notice33告知");
				$("#normal_notice .hide_tab").children().eq(36).hide();
			}
			
			//divnotice6a15 投保人  divnotice6i15被保人1  
			if($("#normal_notice .hide_tab").children().eq(5).find("#divnotice6a15").is(":hidden")
			 &&$("#normal_notice .hide_tab").children().eq(5).find("#divnotice6i15").is(":hidden")){
				console.log("notice6对应投被保人单选按钮页面已经隐藏，隐藏notice6告知");
				$("#normal_notice .hide_tab").children().eq(5).hide();
			}
		   ////
			
		}
		
	}
	
	
	} catch (e) {
		
		console.log("hideELementSById  未成年人告知异常  catch");
		// TODO: handle exception
	}
	
	return true;
}





/**
 * 多被保人的女性告知和未成年告知检测
 */
//为什么不用之前的showFather和HideFather？因为在回退修改后再出发不能再次显示和隐藏，所以只能用jq操作DOM。
//全局的隐藏控件的数组
var allHideElements=[];

//自定义的hide，隐藏完后会存在全局数组中，方便之后显示
$.fn.MutlHide=function () {
	$(this).hide(0,function() {
		allHideElements.push($(this));
	});
}
//自定义的show，只有再配置为显示的控件显示
$.fn.MutlShow=function (topvue,noticeid) {
	if (topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus != "02") {
			console.info(topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus);
			this.show();
	}
}
/**
 * 为多被保人特别设计的隐藏逻辑
 * @author loweite
 * @param topvue
 */
function hideELementSByInsuMuti(topvue){
	//这里我只用第二个投保人选项来判定是否隐藏了控件
	try {
		hasappntflag=topvue.form_elementsBYID.commonFormNotice["notice2"]["appntquestion"]["notice2a1"].elementstatus == "02";
		
	} catch (e) {
		return ;
	// TODO: handle exception
	}
	//先显示全部，再修改，原因：当被保人修改，保证告知同步的正确
	console.info("开始多被保人特殊处理");
	$("#notice_tabinfoform  .col-sm-12 > div:nth-child(8)").MutlShow(topvue,"notice8");
	$("#notice_tabinfoform  .col-sm-12 > div:nth-child(9)").MutlShow(topvue,"notice9");
	$("#notice_tabinfoform  .col-sm-12 > div:nth-child(32)").MutlShow(topvue,"notice28");
	$("#notice_tabinfoform  .col-sm-12 > div:nth-child(33)").MutlShow(topvue,"notice29");
	$("#notice_tabinfoform  .col-sm-12 > div:nth-child(7)").MutlShow(topvue,"notice7");
	$("#notice_tabinfoform  .col-sm-12 > div:nth-child(29)").MutlShow(topvue,"notice37");
	$("#notice_tabinfoform  .col-sm-12 > div:nth-child(30)").MutlShow(topvue,"notice38");
	$("#notice_tabinfoform  .col-sm-12 > div:nth-child(31)").MutlShow(topvue,"notice39");
	
	
	//先显示并且清空隐藏控件数组
	var length=allHideElements.length;//超级大坑，千万记得先赋值在循环
	for ( var i = 0; i <length; i++){
			var ele=allHideElements.pop();
			ele.show();
	}
	var mutiage_container=[];  //存着所有需要隐藏的序号
	var mutisex_container=[];  //0男1女
	var maininsuAge =topvue.formdata.lcinsured.lcinsuredage; // 主被保险人年龄
	var maininsuSex = topvue.formdata.lcinsured.lcinsuredsex;// 主被保险人性别
	var sublength = topvue.formdata.sublcpols.length;
	var contclassify =[];
	for (var i = 0;i<sublength;i++){
		//附加险的保险分类
		contclassify.push(topvue.formdata.sublcpols[i].contclassify);
	}
	var appntAge = getAgeFromBrithday(topvue.formdata.lcappnt.appntbirthday); // 投保人年龄
	var appntSex = topvue.formdata.lcappnt.appntsex;// 投保人性别
	var mutinum=topvue.formdata.lcinsuredmulti.length; //除去主被保人的多被保人个数
	//先存主被保人
	if(maininsuAge>2)
		mutiage_container.push(0);
	if(maininsuSex=='0'||(maininsuSex=='1'&&maininsuAge<15))
		mutisex_container.push(0);

	for (var i=1;i<=mutinum;i++){   //从1开始，因为0是主被保人
		if(getAgeFromBrithday(topvue.formdata.lcinsuredmulti[i-1].lcinsuredbirthday)> 2)
			mutiage_container.push(i);
		if(topvue.formdata.lcinsuredmulti[i-1].lcinsuredsex==0||(topvue.formdata.lcinsuredmulti[i-1].lcinsuredsex==1&&getAgeFromBrithday(topvue.formdata.lcinsuredmulti[i-1].lcinsuredbirthday)< 15)){
			mutisex_container.push(i); 
		}
			 
	}
	console.log(mutiage_container);
	console.log(mutisex_container);
	for (var i=0;i<contclassify.length;i++){
		//附加险所属被保人
		var maininsured = topvue.formdata.sublcpols[i].maininsured;
		if(contclassify[i]=='08'&&maininsured=='999'&&appntAge>2){
			console.info("隐藏豁免险投保人婴幼儿告知");
			//豁免险的主被同投保人
			$("input[name='noticeinfos[31].owneryesorno']").parentsUntil("div.form-group-div").parent("div").hide();
			$("input[name='noticeinfos[32].owneryesorno']").parentsUntil("div.form-group-div").parent("div").hide();
		}
	}
	if(mutiage_container.length==mutinum+1  &&  (appntAge> 2||hasappntflag)){
		console.info("隐藏婴幼儿告知");
		// $("#notice_tabinfoform .col-sm-12 > div:nth-child(8)").hide();
		// $("#notice_tabinfoform .col-sm-12 > div:nth-child(9)").hide();
		// $("#notice_tabinfoform .col-sm-12 > div:nth-child(32)").hide();
		// $("#notice_tabinfoform .col-sm-12 > div:nth-child(33)").hide();
		$(".hide_tab > div:nth-child(8)").hide();
		$(".hide_tab > div:nth-child(9)").hide();
		$(".hide_tab > div:nth-child(32)").hide();
		$(".hide_tab > div:nth-child(33)").hide();
//		alert($("#noticeinsumulti\\[0\\]").attr("value"));
	} else {//否则，隐藏对应index 的单选框
		for (var i=0;i<mutiage_container.length;i++){
			$("input[name='AS7_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			allHideElements.push($("input[name='AS7_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			
			$("input[name='AS8_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			allHideElements.push($("input[name='AS8_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			
			$("input[name='AS31_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			allHideElements.push($("input[name='AS31_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			
			$("input[name='AS32_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			allHideElements.push($("input[name='AS32_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			
		}
	}
	for (var i=0;i<contclassify.length;i++){
		//附加险所属被保人
		var maininsured = topvue.formdata.sublcpols[i].maininsured;
		if(contclassify[i]=='08'&&maininsured=='999'&&(appntSex=='0'||((appntSex=='1'&&(appntAge<15))))){
			console.info("隐藏豁免险投保人女性告知");
			//豁免险的主被同投保人
			$("input[name='noticeinfos[28].owneryesorno']").parentsUntil("div.form-group-div").parent("div").hide();
			$("input[name='noticeinfos[29].owneryesorno']").parentsUntil("div.form-group-div").parent("div").hide();
			$("input[name='noticeinfos[30].owneryesorno']").parentsUntil("div.form-group-div").parent("div").hide();
		}
	}
	if((mutisex_container.length==mutinum+1&&appntSex=='0')&&(appntSex=='0'||(appntSex=='1'&&(appntAge<15))||hasappntflag)){//全是男人或者女的小于15，隐藏女性告知
		console.info("隐藏女性告知");
		$(".hide_tab > div:nth-child(7)").hide();
		$(".hide_tab > div:nth-child(29)").hide();
		$(".hide_tab > div:nth-child(30)").hide();
		$(".hide_tab > div:nth-child(31)").hide();
		// $("#notice_tabinfoform .col-sm-12 > div:nth-child(7)").hide();
		// $("#notice_tabinfoform .col-sm-12 > div:nth-child(29)").hide();
		// $("#notice_tabinfoform .col-sm-12 > div:nth-child(30)").hide();
		// $("#notice_tabinfoform .col-sm-12 > div:nth-child(31)").hide();
//		alert($("#noticeinsumulti\\[0\\]").attr("value"));
	}else {//否则，隐藏对应index 的单选框
		for (var i=0;i<mutisex_container.length;i++){
			$("input[name='AS6_impartContentInsus["+mutisex_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			allHideElements.push($("input[name='AS6_impartContentInsus["+mutisex_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			$("input[name='AS28_impartContentInsus["+mutisex_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			allHideElements.push($("input[name='AS28_impartContentInsus["+mutisex_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			$("input[name='AS29_impartContentInsus["+mutisex_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			allHideElements.push($("input[name='AS29_impartContentInsus["+mutisex_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			$("input[name='AS30_impartContentInsus["+mutisex_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			allHideElements.push($("input[name='AS30_impartContentInsus["+mutisex_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
		}
	}
}






///////////多被保人隐藏未成年人告知
/**
* 未成年告知检测
*/
//为什么不用之前的showFather和HideFather？因为在回退修改后再出发不能再次显示和隐藏，所以只能用jq操作DOM。
//全局的隐藏控件的数组
var  OwnHideElements=[];

//自定义的hide，隐藏完后会存在全局数组中，方便之后显示
$.fn.MutlHideB=function () {
$(this).hide(0,function() {
	OwnHideElements.push($(this));
});
}
//自定义的show，只有再配置为显示的控件显示
$.fn.MutlShowB=function (topvue,noticeid) {
if (topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus != "02") {
console.info(topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus);
this.show();
}
}





/**
 * 为六个被保人产品未成年人告知特别设计的隐藏逻辑
 * @author loweite
 * @param topvue
 */
function hideELementSByIdLi(topvue){
	

	try{
		
	if (!topvue.form_elements.commonFormNotice) {
		console.log("hideELementSByIdLi  !topvue.form_elements.commonFormNotice");
		return true;
	}
		
	//若未成年告知未配置，退出此方法
	if(topvue.form_elementsBYID.commonFormNotice["notice6"].elementstatus != "01"&&topvue.form_elementsBYID.commonFormNotice["notice33"].elementstatus != "01"){
		console.log("hideELementSByIdLi  若未成年告知未配置，退出此方法");
		return true;
		
	}else{
		
		if(topvue.form_elementsBYID.commonFormNotice["notice6"].elementstatus != "01"){
			
		}else{//已经配置为显示
			 
			if($("#normal_notice .hide_tab").children().eq(5).is(":hidden")){
			     //  $("#test").show();    //如果元素为隐藏,则将它显现
			  $("#normal_notice .hide_tab").children().eq(5).MutlShowB(topvue,"notice6");	
			}
			  	
		}
		if(topvue.form_elementsBYID.commonFormNotice["notice33"].elementstatus != "01"){
			
		}else{//已经配置为显示
			  
			if($("#normal_notice .hide_tab").children().eq(36).is(":hidden")){
			     //  $("#test").show();    //如果元素为隐藏,则将它显现
			   	$("#normal_notice .hide_tab").children().eq(36).MutlShowB(topvue,"notice33");
			}
		}
	}
 

	
	//先显示全部，再修改，原因：当被保人修改，保证告知同步的正确
	console.info("hideELementSByIdLi---开始六个被保人产品未成年人告知特殊处理");
 
		//先显示并且清空隐藏控件数组
		var length=OwnHideElements.length;//超级大坑，千万记得先赋值在循环
		for ( var i = 0; i <length; i++){
				var ele=OwnHideElements.pop();
				ele.show();
		}
		var mutiage_container=[];  //存着所有需要隐藏的序号
		var maininsuAge =topvue.formdata.lcinsured.lcinsuredage; // 主被保险人年龄
	
		var appntAge = getAgeFromBrithday(topvue.formdata.lcappnt.appntbirthday); // 投保人年龄
		var mutinum=topvue.formdata.lcinsuredmulti.length; //除去主被保人的多被保人个数
		//先存主被保人
		if(maininsuAge>=18)
			mutiage_container.push(0);
	
		for (var i=1;i<=mutinum;i++){   //从1开始，因为0是主被保人
			if(getAgeFromBrithday(topvue.formdata.lcinsuredmulti[i-1].lcinsuredbirthday)>=18){
				mutiage_container.push(i);
				console.log('--'+i);
			}
		}
		console.log("六个被保人产品未成年人告知------------------------------------");
		console.log(mutiage_container);
	
		if(mutiage_container.length==mutinum+1  &&  (appntAge>=18)){//所有人大于等于18，隐藏未成年人告知
			console.info("六个被保人产品隐藏所有未成年人告知  notice6 notice33");
			//$("#normal_notice .hide_tab").children().eq(0).hide();
			$("#normal_notice .hide_tab").children().eq(5).hide();
			//$("#normal_notice .hide_tab").children().eq(9).hide();
			$("#normal_notice .hide_tab").children().eq(36).hide();
		}else {
			//否则，隐藏对应index 的单选框
			console.info("六个被保人产品，隐藏对应index 的单选框");
		 for (var i=0;i<mutiage_container.length;i++){
	
		  //隐藏被保人单选框      id=notice6
			$("input[name='AS5_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			OwnHideElements.push($("input[name='AS5_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
	
			//隐藏被保人单选框   id=notice33
			$("input[name='AS36_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			OwnHideElements.push($("input[name='AS36_impartContentInsus["+mutiage_container[i]+"].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
			
		 }
			
			
		//投保人
		if(appntAge>=18){
			//否则，隐藏对应index 的单选框
			console.info("appntAge>=18六个被保人产品，隐藏投保人对应index 的单选框");

			//隐藏单选框          id=notice6
			$("input[name='noticeinfos[5].owneryesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			OwnHideElements.push($("input[name='noticeinfos[5].owneryesorno']") .parentsUntil("div.form-group-div").parent("div"));

			//隐藏单选框          id=notice33
			$("input[name='noticeinfos[36].owneryesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
			OwnHideElements.push($("input[name='noticeinfos[36].owneryesorno']") .parentsUntil("div.form-group-div").parent("div"));

		}
		
	
	}
	
	
	} catch (e) {
		// TODO: handle exception
	}
	
	return true;
}






////////////////////

// 告知加载后的处理
afterloadNewElements.notice_tabinfo = function(url, form_element) {
	console.info( " 告知加载后的处理");
	var topvue = getTopvueObj(this);
	//不是多被保人才执行这个
	if(this.formdata.newContApply.investment !='M'){
		checkInsuTwoNotice(topvue);
		showELementSByInsu(topvue);
        
		console.info("============================"+topvue.formdata.newContApply.currentSID);
		
		console.info($("#tab_notice_tabinfo").attr("class"))
		//年金转万能产品
		if(null!=topvue.form_elements.commonFormNotice
		   &&vueobj["testdivchange"].formdata.lcpol.universalmark!=''
		   &&"Y"==vueobj["testdivchange"].formdata.lcpol.universalmark&&vueobj["testdivchange"].formdata.lcpol.whetherconvert!=''
		   &&"Y"==vueobj["testdivchange"].formdata.lcpol.whetherconvert){
			$("#notice_submit").trigger("click");
		}
		
		
	}


	var showElement= 0 ;
	for ( var index in topvue.form_elements.commonFormNotice) {
		if(topvue.form_elements.commonFormNotice[index].elementstatus=='01'){
			showElement++;
		}
		
	}
	

	
	if(showElement==0){
		
		$("#notice_submit").trigger("click");
	}else{
		$("#tab_notice_tabinfo").removeClass("disabled");
		$("#notice_tabinfo").removeClass("disabled");
		
	}
	
};
var showdilog_notice;

//告知提交前 清空所有不显示的数据
beforesubmitvueform.notice_tabinfoform = function() {
	
	$("tab_notice a:first").tab("show");

	 var otherinsunum =this.formdata.otherinsured.length; // 附加险页面被保人个数
	 if(otherinsunum==0){//如果没有附加险被保人，提交时触发清空方法
	
		 $("#normal_notice").find("input:checked[type='radio'][elementstatus]:hidden[value!=''],input[type!='radio'][elementstatus]:hidden[value]").val('').click();
	 }
	 
	$("#tab_notice a:last").tab("show");
	$("#123123").find("input:checked[type='radio'][elementstatus]:hidden[value!=''],input[type!='radio'][elementstatus]:hidden[value]").val('').click();
//	showdilog_notice= layer.load(2, {
//		  shade:0.3, //0.2透明度的白色背景
//	});
	
	//alert("告知保存时间可能较长，请耐心等待");
	
//	v-bind:elementstatus ="form_element.elementstatus"
//	$("#notice_tabinfoform").find("[elementstatus][elementstatus!='01']").val('').trigger("click");
//	if($("#notice_tabinfoform").find("[elementstatus][elementstatus!='01']").length==0){
//		
//		
////		this.$set(this.formdata.newContApply,"currentSIDIndex",7);
//		
//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit_tabinfo");
////		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
////		$("#tab_notice_tabinfo").removeClass("active");
////		$("#tab_notice_tabinfo").addClass("disabled");
////		$("#notice_tabinfo").removeClass("active");
////		$("#notice_tabinfo").addClass("disabled");
////		$("#tab_contsubmit_tabinfo").addClass("active");
////		$("#contsubmit_tabinfo").addClass("active");
//	}else{
		 
		
//	}
//if($("#notice_tabinfoform").find("[elementstatus][elementstatus='01']").length==0){
//		
//		
//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit");
//		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
// con
//	}else{
//		 
//		
//	}
	return true; 
};

aftersubmitvueform.notice_tabinfoform = function() {
//	if($("#notice_tabinfoform").find("[name^='noticeinfo'][elementstatus][elementstatus='01']").length==0){
//		
//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit");
//		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
//		this.$set(this.formdata.newContApply,"contsubmit", false);
//		$('#tab_contsubmit_tabinfo').trigger("click");
//		this.$set(this.form_elementsBYID.ANZLinsuranceContInput['notice_tabinfo'],
//				"elementstatus", "04");
//		
//		
//	}else{
//		 
//		
//	}
	try {
		var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
		buttonControl(proposalcontno);
	} catch (e) {

	}
	
	
//	this.$nextTick(function () {
//		layer.close(showdilog_notice);
//	});
	
	return true; 
};


var afterInitTab={
		 
};
//初始化后,这里执行后期的隐藏显示逻辑
afterInitTab.notice_tabinfo= function() {
	var topvue = getTopvueObj(this);
	if(this.formdata.newContApply.investment =='M'){
//		康哥写的试例
//		if(this.formdata.lcinsured&&this.formdata.lcinsured.lcinsuredname=="张三"){
//			$("#notice_tabinfo").find("input[name='AS0_impartContentInsus[0].insuredyesorno']")
//			.parentsUntil("div.form-group-div").parent("div").hide();
//		}else{
//			$("#notice_tabinfo").find("input[name='AS0_impartContentInsus[0].insuredyesorno']")
//			.parentsUntil("div.form-group-div").parent("div").show();
//		}

		
		if($("#tab_notice_tabinfo").attr("class")=="active"){//所有逻辑卸载这里，避免多余的触发
			if($("#notice_tabinfoform").data('bootstrapValidator')!=null&&
					$("#notice_tabinfoform").data('bootstrapValidator')!=undefined){
					console.info("重置校验");	
				    $("#notice_tabinfoform").data('bootstrapValidator').resetForm();
			}
			
//			for(i=0;i<topvue.formdata.lcinsuredmulti.length;i++){
//				form.data('bootstrapValidator').resetField($('#multiStature\\['+i+'\\]'));
//				form.data('bootstrapValidator').resetField($('#multiAvoirdupois\\['+i+'\\]'));
//			}
			hideELementSByInsuMuti(topvue);
			hideELementSByIdLi(topvue);
			

			
			var otherinsunum =topvue.formdata.otherinsured.length; // 附加险页面被保人个数

			if(otherinsunum>0){
			var otherinsure=topvue.formdata.otherinsured[0];//附加险被保人

				var  otherInsuNoID='otherNotice_'+otherinsure.lcinsuredidno;
				
			if (!topvue.form_elements[otherInsuNoID]) {
				console.log("hiddenOtherinsuredByid  !vue_obj.form_elements[otherInsuNoID]");
				return true;
			}
			
			hiddenOtherinsuredById(topvue);
			
			}
		}
	}else{
		
		if($("#notice_tabinfoform").data('bootstrapValidator')!=null&&
				$("#notice_tabinfoform").data('bootstrapValidator')!=undefined){
				console.info("重置校验");	
			    $("#notice_tabinfoform").data('bootstrapValidator').resetForm();
		}

		//年金转万能产品未成年人告知控制
		if(null!=topvue.formdata.lcpol&&topvue.formdata.lcpol.whetherconvert!=''&&"Y"==topvue.formdata.lcpol.whetherconvert
		 ||null!=topvue.formdata.lcpol&&topvue.formdata.lcpol.whetherconvert!=''&&"N"==topvue.formdata.lcpol.whetherconvert){
			
			this.$nextTick(function () {
				
				console.info("================inie============$nextTick");
				console.info("==this.formdata.newContApply.currentSID.indexOf(notice)!=-1="+topvue.formdata.lcpol.whetherconvert);
					//joinlife!=M   非多被保人处理未成年人告知			
					////年金/生存金是否需要转入万能账户 不为空时，后台重新加载告知  调用控制未成年人告知方法
				hideELementSById(topvue);
			});		
				
		}else{
			
			//未配置年金转万能产品  调用控制未成年人告知方法
			hideELementSByImmaturity(topvue);
		}
		
		
		
		
		var otherinsunum =topvue.formdata.otherinsured.length; // 附加险页面被保人个数

		if(otherinsunum>0){
		var otherinsure=topvue.formdata.otherinsured[0];//附加险被保人

			var  otherInsuNoID='otherNotice_'+otherinsure.lcinsuredidno;
			
		if (!topvue.form_elements[otherInsuNoID]) {
			console.log("hiddenOtherinsuredByid  !vue_obj.form_elements[otherInsuNoID]");
			return true;
		}
		
		hiddenOtherinsuredById(topvue);
		
		}
	}
	
}


/**
 * 附加险保存后
 */
 aftersubmitvueform.subriskcode_tabinfoform = function() {
		
		var otherinsunum =this.formdata.otherinsured.length; // 附加险页面被保人个数

		if(otherinsunum>0){
		var otherinsure=this.formdata.otherinsured[0];//附加险被保人

			var  otherInsuNoID='otherNotice_'+otherinsure.lcinsuredidno;
			
		if (!this.form_elements[otherInsuNoID]) {
			console.log("hiddenOtherinsuredByid  !vue_obj.form_elements[otherInsuNoID]");
			return true;
		}
		
		hiddenOtherinsuredById(this);
		
		}
	
	 return true; 
 };




///////////非多被保人隐藏未成年人告知
/**
* 未成年告知检测
*/
//为什么不用之前的showFather和HideFather？因为在回退修改后再出发不能再次显示和隐藏，所以只能用jq操作DOM。
//全局的隐藏控件的数组
var HideElementsOther=[];

//自定义的hide，隐藏完后会存在全局数组中，方便之后显示
$.fn.MutlHideO=function () {
$(this).hide(0,function() {
HideElementsOther.push($(this));
});
}
//自定义的show，只有再配置为显示的控件显示
$.fn.MutlShowO=function (topvue,otherInsuNoID,noticeid) {
if (topvue.form_elementsBYID[otherInsuNoID][noticeid].elementstatus!= "02") {
console.info("other===="+topvue.form_elementsBYID[otherInsuNoID][noticeid].elementstatus);
this.show();
}
}



//附加险页面被保人未成年人告知控制
function hiddenOtherinsuredById(vue_obj){

console.log("未成年人告知隐藏方法  hiddenOtherinsuredById");	

var otherinsunum =vue_obj.formdata.otherinsured.length; // 附加险页面被保人个数

if(otherinsunum>0){
	var otherinsure=vue_obj.formdata.otherinsured[0];//附加险被保人
	var  lcinsuredidno=otherinsure.lcinsuredidno;
	var  otherInsuNoID='otherNotice_'+otherinsure.lcinsuredidno;
	
	console.log(vue_obj.form_elements[otherInsuNoID]);
	console.log(vue_obj.form_elementsBYID[otherInsuNoID]);
	if (!vue_obj.form_elements[otherInsuNoID]||vue_obj.form_elementsBYID[otherInsuNoID]==undefined||vue_obj.form_elementsBYID[otherInsuNoID]==0) {
		console.log("hiddenOtherinsuredByid  !vue_obj.form_elements[otherInsuNoID]");
		return true;
	}
	
try{	

	//notice6
	var  otherinsu6='otherinsu_'+otherinsure.lcinsuredidno+"_notice6";
	var  otherinsu33='otherinsu_'+otherinsure.lcinsuredidno+"_notice33";


	  if(vue_obj.form_elementsBYID[otherInsuNoID][otherinsu6]==undefined&&vue_obj.form_elementsBYID[otherInsuNoID][otherinsu33]==undefined){
		  console.log("hiddenOtherinsuredByid  otherinsu6 undefined otherinsu33undefined");
		  return true;
	  }
	
	
	 console.log(vue_obj.form_elementsBYID[otherInsuNoID][otherinsu6].elementstatus);
	 console.log(vue_obj.form_elementsBYID[otherInsuNoID][otherinsu33].elementstatus);
	//若未成年告知未配置，退出此方法
	if(vue_obj.form_elementsBYID[otherInsuNoID][otherinsu6].elementstatus != "01"&&vue_obj.form_elementsBYID[otherInsuNoID][otherinsu33].elementstatus != "01"){
		console.log("hiddenOtherinsuredByid  若未成年告知未配置，退出此方法");
		return true;
		
	}else{
		
		if(vue_obj.form_elementsBYID[otherInsuNoID][otherinsu6].elementstatus != "01"){
			
		}else{//已经配置为显示
			
			if($("#"+lcinsuredidno+" div").children().eq(5).is(":hidden")){
			     //  $("#test").show();    //如果元素为隐藏,则将它显现
			  
				$("#"+lcinsuredidno+" div").children().eq(5).MutlShowO(vue_obj,otherInsuNoID,otherinsu6);	
			}
			console.log("hiddenOtherinsuredByid  otherinsu6 01");	
		}
		if(vue_obj.form_elementsBYID[otherInsuNoID][otherinsu33].elementstatus != "01"){
			
		}else{//已经配置为显示
			if($("#"+lcinsuredidno+" div").children().eq(36).is(":hidden")){
			     //  $("#test").show();    //如果元素为隐藏,则将它显现
			   	
				$("#"+lcinsuredidno+" div").children().eq(36).MutlShowO(vue_obj,otherInsuNoID,otherinsu33);
			}					
			console.log("hiddenOtherinsuredByid  otherinsu33 01");	
		}
	}
	

	//先显示全部，再修改，原因：当被保人修改，保证告知同步的正确
	console.info(HideElementsOther.length+"hiddenOtherinsuredById  ---开始未成年人特殊处理  先显示全部，再修改，原因：当被保人修改，保证告知同步的正确");

	//先显示并且清空隐藏控件数组
	var length=HideElementsOther.length;//超级大坑，千万记得先赋值在循环
	for ( var i = 0; i <length; i++){
		var ele=HideElementsOther.pop();
		ele.show();
	}

	
	console.log("附加被保人个数="+otherinsunum);
	if(otherinsunum==1){
		// 附加险页面被保人年龄
		var otherinsuAge=getAgeFromBrithday(vue_obj.formdata.otherinsured[0].lcinsuredbirthday);
		console.log("附加被保人年龄="+otherinsuAge);
		
	if(otherinsuAge>=18){
		
		//隐藏单选框 notice33
		$("input[name='otherinsured_"+lcinsuredidno+"_36noticeinfos[0].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
		HideElementsOther.push($("input[name='otherinsured_"+lcinsuredidno+"_36noticeinfos[0].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
		
		//隐藏单选框 notice6
		$("input[name='otherinsured_"+lcinsuredidno+"_5noticeinfos[0].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div").hide();
		HideElementsOther.push($("input[name='otherinsured_"+lcinsuredidno+"_5noticeinfos[0].insuredyesorno']") .parentsUntil("div.form-group-div").parent("div"));
		
		console.log("otherinsuAge>=18="+otherinsuAge);
		
		
		$("#"+lcinsuredidno+" div").children().eq(5).hide();
		$("#"+lcinsuredidno+" div").children().eq(36).hide();
		
		console.log("otherinsuAge>=18隐藏未成年人告知   notice6 notice33");
	}else{
		
		console.log("otherinsuAge<18显示未成年人告知  notice6 notice33");
		/////
		//div_otherinsu_321421_notice33a10附加险页面被保人 notice33
		if($("#"+lcinsuredidno+" div").children().eq(36).find("#otherinsu_"+lcinsuredidno+"_notice6a1").is(":hidden")){
			console.log("notice33对应投被保人单选按钮页面已经隐藏，隐藏notice33告知");
			$("#"+lcinsuredidno+" div").children().eq(36).hide();
		}
		
		//divotherinsu_321421_notice6a10附加险页面被保人  notice6
		if($("#"+lcinsuredidno+" div").children().eq(5).find("#otherinsu_"+lcinsuredidno+"_notice33a1").is(":hidden")){
			console.log("notice6对应投被保人单选按钮页面已经隐藏，隐藏notice6告知");
			$("#"+lcinsuredidno+" div").children().eq(5).hide();
		}
	   ////
		
	}
	
	}else{
		
		
		
	}
      } catch (e) {
	  console.log("hiddenOtherinsuredById 未成年人告知异常  catch");
	  // TODO: handle exception
     }
  }
}




function ClearAll() {
	$("#notice_tabinfoform input").val("");
	$('#notice_tabinfoform input[type=radio]:checked').prop("checked", false);
}


//其他被保险人
vueMethods.getNoticeElements=function($event, otherinsure,index){
//	String otherInsuNo=request.getParameter("otherInsuNo");
//	String otherInsuNoID=request.getParameter("otherInsuNoID");
	var vue_obj = this;
	
	 var otherinsunum =vue_obj.formdata.otherinsured.length; // 附加险页面被保人个数
	 if(otherinsunum>0){//如果有附加险被保人，切换tab时触发清空	 
	  
		 $("#normal_notice").find("input:checked[type='radio'][elementstatus]:hidden[value!=''],input[type!='radio'][elementstatus]:hidden[value]").val('').click();
	 }	 
	
	if(this.form_elements['otherNotice_'+otherinsure.lcinsuredidno].length!=0){
		specialNoticeControl.call(vue_obj,otherinsure);
		hiddenOtherinsuredById(vue_obj);
	}else{
		var showdilog= layer.load(2, {
			  shade:0.3, //0.2透明度的白色背景
		 });
		
		var  otherInsuNo=index;
		var  otherInsuNoID=otherinsure.lcinsuredidno;
		var initUrl =path +"/newCont/common/init/OtherInsuNotice/ANZL/"+this.formdata.newContApply.transno+".do?otherInsuNo="+otherInsuNo+"&otherInsuNoID="+otherInsuNoID;
		$.ajax({				
			type : "POST",
			url: initUrl,// 后台请求URL地址	
			data : {"formdata": JSON.stringify(this.formdata) },
//			dataType: "json" ,
//			contentType :"application/json;charset=UTF-8" ,
			success : function(data) {
//				vue_obj.$set("form_elements",'otherNotice_'+otherinsure.lcinsuredidno
//						,);
				
				fillformelements(vue_obj , data.form_elements);
				setIDIndexForEachElement(vue_obj, vue_obj.form_elements, vue_obj.form_elementsBYID);
				specialNoticeControl.call(vue_obj,otherinsure);
				
				vue_obj.$nextTick(function () {
					
					initData(getActivePanelDIV(),true);
					layer.close(showdilog);
					hiddenOtherinsuredById(vue_obj);
				});
				
					
				
				
			},
			 error : function() {
				 alert("系统异常");
				 layer.close(showdilog);
			}
		});
		
//		for ( var index in this.form_elements.commonFormNotice) {
//			this.form_elements['otherNotice_'+otherinsure.lcinsuredidno].push(this.form_elements.commonFormNotice[index]);
//		}
		
	}
	
};
function hideotherinsure(topvueobj,otherinsure,noticeid){
	
	if(topvueobj.form_elementsBYID['otherNotice_'+otherinsure.lcinsuredidno][noticeid].elementstatus=="02"){
		
	}else{
		topvueobj.$set(topvueobj.form_elementsBYID['otherNotice_'+otherinsure.lcinsuredidno][noticeid],
				"elementstatus", "04");
	}
	
}

function showotherinsure(topvueobj,otherinsure,noticeid){
	
	if(topvueobj.form_elementsBYID['otherNotice_'+otherinsure.lcinsuredidno][noticeid].elementstatus=="02"){
		
	}else{
		topvueobj.$set(topvueobj.form_elementsBYID['otherNotice_'+otherinsure.lcinsuredidno][noticeid],
				"elementstatus", "01");
	}
	
}
/***
 * 
 * @param otherinsure
 */
function checkOtherWomen(topvueobj,otherinsure){
	
	var notice7   = "otherinsu_"+otherinsure.lcinsuredidno+"_"+"notice7";
	var notice37  = "otherinsu_"+otherinsure.lcinsuredidno+"_"+"notice37";
	var notice38  = "otherinsu_"+otherinsure.lcinsuredidno+"_"+"notice38";
	var notice39  = "otherinsu_"+otherinsure.lcinsuredidno+"_"+"notice39";
	var age = getAgeFromBrithday(otherinsure.lcinsuredbirthday); // 年龄
	var sex = otherinsure.lcinsuredsex;
	if (sex == '1' && age >= 15) {
		
		showotherinsure(topvueobj,otherinsure, notice7);
		showotherinsure(topvueobj,otherinsure, notice37);
		showotherinsure(topvueobj,otherinsure, notice38);
		showotherinsure(topvueobj,otherinsure, notice39);
		
 
	} else {
		
		hideotherinsure(topvueobj,otherinsure, notice7);
		hideotherinsure(topvueobj,otherinsure, notice37);
		hideotherinsure(topvueobj,otherinsure, notice38);
		hideotherinsure(topvueobj,otherinsure, notice39);
 
	}
	
} 
/***
 * 其他被保人
 * @param otherinsure
 */
function checkchild(topvueobj,otherinsure){
	
	var notice8   = "otherinsu_"+otherinsure.lcinsuredidno+"_"+"notice8";
	var notice9  = "otherinsu_"+otherinsure.lcinsuredidno+"_"+"notice9";
	var notice28  = "otherinsu_"+otherinsure.lcinsuredidno+"_"+"notice28";
	var notice29  = "otherinsu_"+otherinsure.lcinsuredidno+"_"+"notice29";
	var age = getAgeFromBrithday(otherinsure.lcinsuredbirthday); // 年龄
	
	if (age<=2) {
		showotherinsure(topvueobj,otherinsure, notice8);
		showotherinsure(topvueobj,otherinsure, notice9);
		showotherinsure(topvueobj,otherinsure, notice28);
		showotherinsure(topvueobj,otherinsure, notice29);
		
 
	} else {
		hideotherinsure(topvueobj,otherinsure, notice8);
		hideotherinsure(topvueobj,otherinsure, notice9);
		hideotherinsure(topvueobj,otherinsure, notice28);
		hideotherinsure(topvueobj,otherinsure, notice29);
		
		
	}
	
}
/***
 * 其他被保人告知控制
 * @param otherinsure
 */
function specialNoticeControl(otherinsure){
	
 
	checkOtherWomen(this,otherinsure);
	checkchild(this,otherinsure);
	
}