afterloadNewElements.krisk_tabinfo = function(url, form_element) {
	
		setTimeout(function(){
			  if(($("#AccountBranchinsh").is(":visible")||$("#AccountBranchinsh").length>0)){
				    $("#AccountBranchinshTitle").remove();
			        $("#AccountBranchinsh").parent().append("<small id='AccountBranchinshTitle' class='help-block' style='color: red;'>须填写完整的银行信息：XX银行XX分行XX支行</small>");
			  }
			  if(($("#AccountBranchinshinsured").is(":visible")||$("#AccountBranchinshinsured").length>0)){
				   $("#AccountBranchinshinsuredTitle").remove();
					$("#AccountBranchinshinsured").parent().append("<small id='AccountBranchinshinsuredTitle' class='help-block' style='color: red;'>须填写完整的银行信息：XX银行XX分行XX支行</small>");
			  }
			  

			  
			  if(($("#AutoPayFlaginsh").is(":visible")||$("#AutoPayFlaginsh").length>0)){
				   $("#AutoPayFlaginshTitle").remove();
				   $("#AutoPayFlaginsh").parent().append("<small id='AutoPayFlaginshTitle' class='help-block'>" +
					    /*"<b style='color:red'>此选项须征求客户意见后选择 ,并告知客户该选择项的实际意义和作用</b><br>" +*/
				      	"<b style='color:red'>*保险费自动垫交：</b>*投保人未按时交纳续期保费，若保单当时已具有足够现金价值，保险公司将以该合同基本保险金额对应的现金价值扣除尚未偿还的各项欠款之后的余额自动垫交到期应交的保险费，使保单继续有效。垫交保险费视作保单贷款，并自保险费自动垫交发生之日起以保单贷款利率予以计息。"
				      	+"<br><b style='color:red'>*合同中止：</b>*投保人未按时交纳续期保费，保险合同暂时失去效力。" +
				      	"</small>");
			  }
			  var riskcode = vueobj["testdivchange"].formdata.lcpol.riskcode;
			  //MIH @Y1增加plan描述
			  if(riskcode !=null && riskcode != undefined && riskcode !=""&&riskcode=="@Y1"){
				  //productplanninginsh
				  if($("#productplanninginsh").is(":visible")||$("#productplanninginsh").length>0){
					  $("#productplanninginshTitle").remove();
					  $("#productplanninginsh").parent().append("<small id='productplanninginshTitle' class='help-block' style='color: red;'>计划一代表计划A，计划二代表计划B</small>")
				  }
			  }
			  
			  if(riskcode != null && riskcode != undefined && riskcode != ""){
				  $.ajax({
						type : "POST",
						async: false,
						url:path + "/newCont/codeselect/getrisktype.do",// 后台请求URL地址
						data : {"riskcode":riskcode},
						dataType : "json",
						success : function(data) {						
							//投连险主险页面字段-首次投资方式 下面加文字解释  
							if(($("#investmentStartDateFlaginsh").is(":visible")||$("#investmentStartDateFlaginsh").length>0)){
								if("01"==data){
									$("#investmentStartDateFlaginshTitle").remove();
							      $("#investmentStartDateFlaginsh").parent().append("<small id='investmentStartDateFlaginshTitle' class='help-block'>"
								      	+"<b>[犹豫期后投资] 自签收保单之日24时起，您有XX天的犹豫期。犹豫期内退保保险公司将无息退还全部所缴保费。【立即投资】：自签收保单之日24时起，您有XX天的犹豫期。犹豫期内退保，除资产管理费以外，保险公司将按收到合同终止申请书后的下一个资产评估日的个人账户价值连同其他已收取的费用一并退还给您，这部分价值可能会低于您所缴的保费。</b><br>"
								      	+"<b style='color:red'>说明：</b><br>"
								      	+"<b style='color:red'>犹豫期为 15个自然日</b><br>"
								      	+"<b style='color:red'>山东（青岛除外）、浙江（宁波除外）、江苏：投保年龄男≥60岁、女≥55岁或残疾人或低保人群享有30天犹豫期</b><br>"
								      	+"<b style='color:red'>深圳：10个工作日或15个自然日犹豫期（以对客户有利者为准）</b><br>"
								      	+"</small>");
							    }
							}
						},
					});			
			  }

			 },50);
	
};



//保险产品
commonCombobox_option.commonCombobox_riskcode = {
	///#lccont.insurancecom
	url:path + '/newCont/codeselect/searchrisk/#newContApply.insurancecom',
	valueField : "riskcode",
	relateType: "vue",
	// 显示在输入框的
	inputText : "riskname",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : ["riskname"],
	
	afterselect:function(){
		var vueobjtemp =vue_config[vue_config.length-1].vueobj;
		var riskData = this.data;
		var risktype = "";
		
		riskData.forEach(function(val,index,array){
			if($("#riskcode").val()==val.riskcode){
				risktype=val.risktype;
				return;
			}
		});

		vueobjtemp.formdata['investmentrisk']=risktype=="01"?"true":"false";

	}
};




//定期追加缴费频率
commonCombobox_option.commonCombobox_regularaddpayintv = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/regularaddpayintv.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};


//账户所有人
commonCombobox_option.commonCombobox_AccountHolderinsh = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/AccountHolderinsh.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"],
afterselect : function() {
	var accountHolderinshinsh = $("#AccountHolderinshinsh").val();
	if(accountHolderinshinsh!='2'){
		if(vueobj["testdivchange"].formdata.lcpol!=null){
			vueobj["testdivchange"].$set(
					vueobj["testdivchange"].formdata.lcpol,
					"anotherHolderFlag1", ""); 
		}
	}

  }
};


//第二被保险人的账户所有人
commonCombobox_option.commonCombobox_AccountHolderinshinshinsured = {
		url : path
		+ '/LdcodeController/selectIdTypeByCodetype.do?codetype=AccountHolderinsh',
valueField : "code",
// 显示在输入框的
inputText : "codename",
// 显示在下拉列表的项，默认空，空则全部显示
textShow : [ "codename" ],
afterselect : function() {
	var accountHolderinshinsh = $("#AccountHolderinshinshinsured").val();
	if(accountHolderinshinsh!='2'){
		if(vueobj["testdivchange"].formdata.insuredannuityaccount!=null){
			vueobj["testdivchange"].$set(
					vueobj["testdivchange"].formdata.insuredannuityaccount,
					"anotherHolderFlag2", ""); 
		}
	}

  }
};

//年金/生存保险金领取年龄
commonCombobox_option.commonCombobox_InshAnnuityGetYearage = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/InshAnnuityGetYearage.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"],
  afterselect:function(){    
	  $('#InshAnnuityGetYearageinshinsured').combobox('clear');
	     vueobj["testdivchange"].$set(
					vueobj["testdivchange"].formdata.insuredannuityaccount,
					"bonusgetage",vueobj["testdivchange"].formdata.lcpol.bonusgetage);

	    }
};


//第二被保人年金/生存保险金领取年龄
commonCombobox_option.commonCombobox_InshAnnuityGetYearageinshinsured = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/InshAnnuityGetYearage.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};

//年金/生存保险金领取期间
commonCombobox_option.commonCombobox_survivalInsurancePeriod = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/survivalInsurancePeriod.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};
//额外年金领取年龄
commonCombobox_option.commonCombobox_extragetyear = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/extragetyear.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};


//风险标识
commonCombobox_option.commonCombobox_MortalityFlag = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/MortalityFlag.do',
	valueField: "paramscode",
  // 显示在输入框的
  inputText: "paramsname",
  // 显示在下拉列表的项，默认空，空则全部显示
  textShow: ["paramsname"]
};

//保险期间
commonCombobox_option.commonCombobox_insuyears = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/insuyear.do',
	valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};
//缴费期间
commonCombobox_option.commonCombobox_payendyears = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/payendyear.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};
//年金领取方式
commonCombobox_option.commonCombobox_BonusGetYearFlag = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/BonusGetYearFlag.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};


//INSH年金领取方式
commonCombobox_option.commonCombobox_InshAnnuityGetYearFlag = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/InshAnnuityGetYearFlag.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"],
    afterselect:function(){    
     $('#InshAnnuityGetYearFlaginshinsured').combobox('clear');
     vueobj["testdivchange"].$set(
				vueobj["testdivchange"].formdata.insuredannuityaccount,
				"inshAnnuityGetYearFlag",vueobj["testdivchange"].formdata.lcpol.inshAnnuityGetYearFlag);
    }
};

//INSH第二被保人年金领取方式
commonCombobox_option.commonCombobox_InshAnnuityGetYearFlagInsured = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/InshAnnuityGetYearFlag.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};


//缴费方式
commonCombobox_option.commonCombobox_payintvs = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/payintv.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};

//红利给付方式
commonCombobox_option.commonCombobox_bonuspayment = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/bonuspayment.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};


//投资账户类型
commonCombobox_option.commonCombobox_investmentaccount = {
	    url: path + '/newCont/codeselect/searchRiskParamsdef/#newContApply.riskcode/InvestmentAccount',
	    valueField: "paramscode",
	    relateType: "vue",
	    mutually_exclusive:true,
	    // 显示在输入框的
	    inputText: "paramsname",
	    // 显示在下拉列表的项，默认空，空则全部显示
	    textShow: ["paramsname"]
};

//续期保费逾期
commonCombobox_option.commonCombobox_AutoPayFlag = {
	    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/AutoPayFlag.do',
	    valueField: "paramscode",
	    // 显示在输入框的
	    inputText: "paramsname",
	    // 显示在下拉列表的项，默认空，空则全部显示
	    textShow: ["paramsname"]
};

//产品类型
commonCombobox_option.commonCombobox_producttype = {
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/producttype.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};

//产品计划
commonCombobox_option.commonCombobox_productplanning = {
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/productplanning.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]

};

//年金累积生息
commonCombobox_option.commonCombobox_CashAccumulation = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/CashAccumulation.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//自动申请续保
commonCombobox_option.commonCombobox_AutoRenewal = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/AutoRenewal.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//申请使用优选体费用
commonCombobox_option.commonCombobox_PremiumRate = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/PremiumRate.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//自动转换
commonCombobox_option.commonCombobox_autorebalance = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/AutoRebalance.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};

//投资生效期
commonCombobox_option.commonCombobox_investmentStartDateFlag = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/investdateformanu.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};




//年金帐户帐号开户省
commonCombobox_option.commonCombobox_areaprovince = {
		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
};

//年金帐户帐号开户市
commonCombobox_option.commonCombobox_areacity = {
		url :  path + '/newCont/codeselect/allcity/#AccountAreaProvinceinsh.do',
		valueField : "cityid",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
};



//第二被保人年金帐户帐号开户省
commonCombobox_option.commonCombobox_areaprovinceinsured = {
		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
};
//第二被保人年金帐户帐号开户市
commonCombobox_option.commonCombobox_areacityinsured = {
		url :  path + '/newCont/codeselect/allcity/#AccountAreaProvinceinshinsured.do',
		valueField : "cityid",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
};
//首次额外年金领取日
commonCombobox_option.commonCombobox_BonusGetYearDay={
	url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcodeinsh/extragetyearday.do',
	valueField: "paramscode",
	// 显示在输入框的
	inputText: "paramsname",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow: ["paramsname"]
};


//主险保存后
aftersubmitvueform.krisk_tabinfoform = function() {
 
	if(this.form_elementsBYID.INSHinsuranceContInput['subriskcode_tabinfo']["elementstatus"]!='01'){
		
		if(this.formdata.newContApply.currentSIDIndex>6){
			
		}else{
			this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
			this.$set(this.formdata.newContApply,"currentSIDIndex",6);
			$('#tab_FATACACRS_tabinfo').trigger("click");
		}
		
 
	}else{
		 
		
	}
/*	if(this.formdata.newContApply.currentSIDIndex> 6){
		
		if(!checkCRSShow.call(this)){
			this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
			this.$set(this.formdata.newContApply,"currentSIDIndex",6);
			this.$set(this.formdata.newContApply,"FATACACRS",false);
			
			$('#tab_FATACACRS_tabinfo').trigger("click");
		}
	}*/
	
	return true; 
};

//提交前 判断
beforesubmitvueform.krisk_tabinfoform = function() {
	var krisk_flag=false;	
	var topvue = getTopvueObj(this);

	if(topvue.form_elementsBYID.krisk["preminsh"].elementstatus=="01"){
		 var prem=$("#preminsh").val().trim();
		 if(prem==0){
			alert("保费输入有误，请重新输入！");
			return false;
		 }
		 if(topvue.formdata.lccont&&topvue.formdata.lccont.commonchannel=="SC"||
					topvue.formdata.lccont&&topvue.formdata.lccont.commonchannel=="RS"){
				if((topvue.formdata.lcpol!=null&&topvue.formdata.lcpol.anotherHolderFlag1=="Y")||(
						topvue.formdata.insuredannuityaccount!=null&&topvue.formdata.insuredannuityaccount.anotherHolderFlag2=="Y")){
					alert("购物车流程不支持此联名账户的签署确认方式")
					return false;
				}
			} 
	}
	
	
	//主险被保人判断
	if(topvue.form_elementsBYID.krisk!=null&&topvue.form_elementsBYID.krisk["InshAnnuityGetYearFlaginsh"]!=undefined
	 &&topvue.form_elementsBYID.krisk["InshAnnuityGetYearFlaginsh"].elementstatus=="01"
	 &&$("#InshAnnuityGetYearFlaginsh").val()=="4"&&topvue.form_elementsBYID.annuity!=null){
	if(topvue.form_elementsBYID.annuity["AccountBranchinsh"]!=undefined&&topvue.form_elementsBYID.annuity["AccountBranchinsh"].elementstatus=="01"&&$("#AccountBranchinsh").val().trim()==""
		  ||topvue.form_elementsBYID.annuity["AccountBranchinsh"]!=undefined&&topvue.form_elementsBYID.annuity["AccountBranchinsh"].elementstatus=="01"&&$("#AccountBranchinsh").val().trim()==null){
			alert("年金帐户帐号开户分行不能为空！");
			return false;
		}

	if(topvue.form_elementsBYID.annuity["AccountNoinsh"]!=undefined&&topvue.form_elementsBYID.annuity["AccountNoinsh"].elementstatus=="01"&&$("#AccountNoinsh").val().trim()==""
		||topvue.form_elementsBYID.annuity["AccountNoinsh"]!=undefined&&topvue.form_elementsBYID.annuity["AccountNoinsh"].elementstatus=="01"&&$("#AccountNoinsh").val().trim()==null){
		alert("年金/生存保险金/增额红利帐户帐号不能为空！");
		return false;
	}
	if(topvue.form_elementsBYID.annuity["AccountHolderinshinsh"]!=undefined&&topvue.form_elementsBYID.annuity["AccountHolderinshinsh"].elementstatus=="01"&&$("#AccountHolderinshinsh").val().trim()==""
		||topvue.form_elementsBYID.annuity["AccountHolderinshinsh"]!=undefined&&topvue.form_elementsBYID.annuity["AccountHolderinshinsh"].elementstatus=="01"&&$("#AccountHolderinshinsh").val().trim()==null){
		alert("账户所有人不能为空！");
		return false;
	}
	
	}
	
	
	
	//第二被保人判断
	if(topvue.form_elementsBYID.kriskinsured!=null&&topvue.form_elementsBYID.kriskinsured["InshAnnuityGetYearFlaginshinsured"]!=undefined
	  &&topvue.form_elementsBYID.kriskinsured["InshAnnuityGetYearFlaginshinsured"].elementstatus=="01"
      &&$("#InshAnnuityGetYearFlaginshinsured").val()=="4"&&topvue.form_elementsBYID.annuitytwo!=null){
	
	if(topvue.form_elementsBYID.annuitytwo["AccountBranchinshinsured"]!=undefined&&topvue.form_elementsBYID.annuitytwo["AccountBranchinshinsured"].elementstatus=="01"&&$("#AccountBranchinshinsured").val().trim()==""
		  ||topvue.form_elementsBYID.annuitytwo["AccountBranchinshinsured"]!=undefined&&topvue.form_elementsBYID.annuitytwo["AccountBranchinshinsured"].elementstatus=="01"&&$("#AccountBranchinshinsured").val().trim()==null){
			alert("第二被保人年金帐户帐号开户分行不能为空！");
			return false;
		}
	if(topvue.form_elementsBYID.annuitytwo["AccountNoinshinsured"]!=undefined&&topvue.form_elementsBYID.annuitytwo["AccountNoinshinsured"].elementstatus=="01"&&$("#AccountNoinshinsured").val().trim()==""
		||topvue.form_elementsBYID.annuitytwo["AccountNoinshinsured"]!=undefined&&topvue.form_elementsBYID.annuitytwo["AccountNoinshinsured"].elementstatus=="01"&&$("#AccountNoinshinsured").val().trim()==null){
		alert("第二被保人年金/生存保险金/增额红利帐户帐号不能为空！");
		return false;
	}
	if(topvue.form_elementsBYID.annuitytwo["AccountHolderinshinshinsured"]!=undefined&&topvue.form_elementsBYID.annuitytwo["AccountHolderinshinshinsured"].elementstatus=="01"&&$("#AccountHolderinshinshinsured").val().trim()==""
		||topvue.form_elementsBYID.annuitytwo["AccountHolderinshinshinsured"]!=undefined&&topvue.form_elementsBYID.annuitytwo["AccountHolderinshinshinsured"].elementstatus=="01"&&$("#AccountHolderinshinshinsured").val().trim()==null){
		alert("第二被保人账户所有人不能为空！");
		return false;
	}
	
	}
	
	
	
	//缴费方式为年缴时，续期保费逾期选项不能选择不适用
	if(topvue.form_elementsBYID.krisk["payintvinsh"]!=undefined&&topvue.form_elementsBYID.krisk["payintvinsh"].elementstatus=="01"&&$("#payintvinsh").val().trim()!=null
	  &&topvue.form_elementsBYID.krisk["AutoPayFlaginsh"]!=undefined&&topvue.form_elementsBYID.krisk["AutoPayFlaginsh"].elementstatus=="01"&&$("#AutoPayFlaginsh").val().trim()!=null
		){
    var payintvinsh=$("#payintvinsh").val();
    var AutoPayFlaginsh=$("#AutoPayFlaginsh").val();
    if(payintvinsh=='Y'&&AutoPayFlaginsh==0){
	   alert("缴费方式为年交时，续期保费逾期选项不能选择不适用，请修改！");
	   return false;
    }   
    if(payintvinsh=='S'&&AutoPayFlaginsh!=0){
  	   alert("缴费方式为趸交时，续期保费逾期选项只能选择不适用，请修改！");
  	   return false;
      }
    
    
	}
	
	//追溯校验
	/*if(vueobj["testdivchange"].formdata.lcpol.retroactDateFlag == "Y"){
		//追溯日期
		var realtimeRetroactDate = topvue.formdata.lcpol.retroactDate;
		//系统日期-180
		var theDayBefore180 = getDay(new Date(new Date().getTime()- 24*60*60*1000*180));
		if(new Date(realtimeRetroactDate).getTime() < new Date(theDayBefore180).getTime()){
			alert("追溯日期需为系统日期的前6个月内");
			return false;
		}
		//不能超过系统日期
		//系统日期 new Date(getDay(new Date())).getTime()
		var x = new Date(getNextDate(getDay(new Date()),-1)).getTime() - new Date(realtimeRetroactDate).getTime();
		if(x < 0){
			alert("追溯日期需早于系统当前日期");
			return false;
		}
		
	}else{
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"retroactDate", null);
	}*/
	
	//ips提示
	if(confirm(("请注意，此页面上的产品投保信息若有修改，您可以点击【确认】保存银保通录入的投保信息，但请检查建议书系统是否需要更新建议书（IPS No:"+topvue.formdata.lccont.ipsno+"）"))){
		krisk_flag=true;
	}else{
		krisk_flag=false;
	}
	if(null!=topvue.formdata.subFormData.lccont) {
		initData(getActivePanelDIV(), true);
		var pflag = topvue.formdata.lccont.pageflag;
		if(topvue.formdata.subFormData.lcpol.payintv=='999'){
			topvue.formdata.subFormData.lcpol.payintv=null;
		}
		fillinObj(topvue, topvue.formdata, topvue.formdata.subFormData, false, 0);
		topvue.formdata.lccont.pageflag = pflag;
		checkPaperChange = true;
	}
	return true&&krisk_flag;


};

/*$.fn.bootstrapValidator.validators.checkRetroactDate = {
		validate : function(validator, $field, options) {
			var topvueobj = getTopvueObj(options.vueobj);
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			//追溯日期
			var realtimeRetroactDate = topvueobj.formdata.lcpol.retroactDate;
			//系统日期-180
			var theDayBefore180 = getDay(new Date(new Date().getTime()- 24*60*60*1000*180));
			
			//校验
			if(new Date(realtimeRetroactDate).getTime() >= new Date(theDayBefore180).getTime()){//追溯日期符合大于系统日期-180天需求
				var time = new Date(getNextDate(getDay(new Date()),-1)).getTime() - new Date(realtimeRetroactDate).getTime();
				if(time < 0){//追溯日期大于等于今日
					if(null != document.getElementById("retro_date2") ){
						$("#retro_date2").remove();
					}
					if(null == document.getElementById("retro_date1") ){
						$("#retroactDateinsh").after("<small class='help-block'  id='retro_date1'>追溯日期需早于系统当前日期</small>");
					}
//					$("#retro_date").html("追溯日期需早于系统当前日期");
					return false;
				}
				form.data('bootstrapValidator').resetField($("#retroactDateinsh"));
				form.data('bootstrapValidator').updateStatus($field, "VALID");
				form.find("input[id='retroactDateinsh']").each(function() {
					if (!form.data('bootstrapValidator').isValidField($(this))) {
						form.data('bootstrapValidator').revalidateField($(this));
					}

				});
				
				if(null != document.getElementById("retro_date1")){
					$("#retro_date1").remove();
				}
				if(null != document.getElementById("retro_date2")){
					$("#retro_date2").remove();
				}
//				$("#retro_date").html("");
				return true;
			}
			
			if(null != document.getElementById("retro_date1") ){
				$("#retro_date1").remove();
			}
			if(null == document.getElementById("retro_date2")){
				$("#retroactDateinsh").after("<small class='help-block' id='retro_date2'>追溯日期需为系统日期的前6个月内</small>");
			}
//			$("#retro_date").html("追溯日期需为系统日期的前6个月内");
			return false;
		}
	};
//追溯日期需为系统日期的前6个月内
	bootstrap_valid.checkRetroactDate = function(validitem) {
		var vueobj = this;
		var validobj = {
			message : " ",
			vueobj : vueobj
		};

		return validobj;

	};*/

/*afterVueSelect.retroactDateFlaginsh = function(){
	var topvue = getTopvueObj(this);
	if("Y" == $("#retroactDateFlaginsh").val()){
		topvue.form_elementsBYID.krisk["retroactDateinsh"].elementstatus="01";
//		document.getElementById("div_retroactDateinsh").style.display = "block";
		$("#div_retroactDateinsh").css("display","block");
		var existDate = vueobj["testdivchange"].formdata.lcpol.retroactDate;
		var insuredBirthDate = vueobj["testdivchange"].formdata.lcinsured.lcinsuredbirthday;
		
//		var lastBirthDay = getNextDate(insuredBirthDate, -1);
		if(existDate == null || existDate == undefined || existDate == ""){
//			lastBirthDay = "2003-01-01";
			//默认显示第一被保险人最近一个生日的前一天
			var birthArr = insuredBirthDate.split("-");
			
			var newYear  = new Date().getFullYear();
			var now_1 = getNextDate(newYear +"-"+birthArr[1]+"-"+birthArr[2], -1);
			var birthDay_1 = Number(now_1.split("-")[0]);
			if(birthDay_1 == newYear){//本年度
				var time = new Date(getNextDate(getDay(new Date()),-1)).getTime() - new Date(now_1).getTime();
				if(time < 0){
//					alert("追溯日期大于等于系统日期，回推一年");
					var date = new Date(now_1);
					date.setFullYear(date.getFullYear() -1);
					var y = date.getFullYear();
				　　    var m = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
				　　    var d = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
				　   　 now_1 =  y + "-" + m + "-" + d;
				}
				
				var theDayBefore180 = getDay(new Date(new Date().getTime()- 24*60*60*1000*180));
				if(new Date(now_1).getTime() < new Date(theDayBefore180).getTime()){
					alert("追溯日期不符合大于系统日期-180天需求");
					return;
				}
				
//				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"retroactDate", now_1);
			}else if(birthDay_1 < newYear){
//				alert("前一年度：" + now_1);
//				var theDayBefore180 = getDay(new Date(new Date().getTime()- 24*60*60*1000*180));
//				if(new Date(now_1).getTime() < new Date(theDayBefore180).getTime()){
//					alert("追溯日期不符合大于系统日期-180天需求");
//					return;
//				}
//				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"retroactDate", now_1);
			}
			
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"retroactDate", now_1);
			
		}
		
	}else {
//		var form =$(this.$el).parentsUntil("form").parent("form");
		topvue.form_elementsBYID.krisk["retroactDateinsh"].elementstatus="02";
		$("#div_retroactDateinsh").css("display","none");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"retroactDate", null);
	}
	
}*/

//获取当日前N天
/*function getDayBeforeN(N){
	var time=(new Date).getTime()-24*60*60*1000*N;
	var yesterday=new Date(time);
	var month=yesterday.getMonth();
	var day=yesterday.getDate();
	return yesterday.getFullYear() + "-" + (yesterday.getMonth()> 9 ? (yesterday.getMonth() + 1) : "0" + (yesterday.getMonth() + 1)) + "-" +(yesterday.getDate()> 9 ? (yesterday.getDate()) : "0" + (yesterday.getDate()));
	 
}*/

/**date 代表指定的日期，格式：yyyy-MM-dd
day 传-1表始前一天，传1表始后一天*/
function getNextDate(date, day) { 
	　　var dd = new Date(date);
	　　dd.setDate(dd.getDate() + day);
	　　var y = dd.getFullYear();
	　　var m = dd.getMonth() + 1 < 10 ? "0" + (dd.getMonth() + 1) : dd.getMonth() + 1;
	　　var d = dd.getDate() < 10 ? "0" + dd.getDate() : dd.getDate();
	　　return y + "-" + m + "-" + d;
	};
//格式化日期
function getDay(dd){
	var y = dd.getFullYear();
	var m = dd.getMonth() + 1 < 10 ? "0" + (dd.getMonth() + 1) : dd.getMonth() + 1;
	var d = dd.getDate() < 10 ? "0" + dd.getDate() : dd.getDate();
	return y + "-" + m + "-" + d;
}