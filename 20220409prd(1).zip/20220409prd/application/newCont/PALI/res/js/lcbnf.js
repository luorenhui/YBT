var sameFieldLcbnfpali={
		"name"	:"appntname",
		"naity"	:"nativeplace",//国籍
		"sex"	:"appntsex",//性别
		"idtype"	:"idtype",//证件类型
		"idno"	:"idno",//证件号码
		"birthday"	:"appntbirthday",//出生日期
		"bnfvalidYear"	:"appntenddate",//证件有效止期
		"occupation"	:"occupationcode",//职业代码
		"islongitems":"islongitems",//证件长期有效
		"company":"company",//工作单位及名称
		"startingDate":"startingDate"//证件有效起期
};
var sameFieldLcbnfAddresspali={
		"zipcode"	:"zipcode",//联系地址邮政编码
		"mobile"	:"mobile",//移动电话
		"province"	:"postprovince",//居住地址省
		"district"	:"postdistrict",//居住地址区
		"city"	:"postcity",//居住地址市
		"address"	:"postdetails",//居住地址
		"areacodetel" : "areacodetel", //固定电话区号
		"homephone"	:"phone"//固定电话	
	};
/**
 * 受益人 同 投保人
 */
afterVueSelect.lcbnfrelationtoappnt = function(form_element) {

	var topvue = getTopvueObj(this);
//	var length=topvue.formdata.bnf.length;
//	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
//			+ form_element.name + "']");
	var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
	var index = this.elementindex.replace(/[^0-9]/ig,"");	
	var obj= topvue.formdata.bnf[index].lcbnfrelationtoappnt;
	var form =$(this.$el).parentsUntil("form").parent("form");
	if (obj=='Y') {

		for ( var key in topvue.form_elements.bnf) {
			
			var targetName= topvue.form_elements.bnf[key].name;
			var targetElement= topvue.form_elements.bnf[key];
			if (sameFieldLcbnfpali[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.lcappnt, sameFieldLcbnfpali[targetName],
						topvue.formdata.bnf[index],targetName,targetElement,targetObj);
			}
			if (sameFieldLcbnfAddresspali[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcbnfAddresspali[targetName],
						topvue.formdata.bnf[index],targetName,targetElement,targetObj);
			}
		}
		
		
		topvue.$nextTick(function () { 
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});		
	} else {			
		for ( var key in topvue.form_elements.bnf) {
			
			var targetName= topvue.form_elements.bnf[key].name;
			var targetElement= topvue.form_elements.bnf[key];
			if (sameFieldLcbnfpali[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				unbindSameElementByJqobj.call(topvue, sameFieldLcbnfpali[targetName],
						targetElement,targetObj);
			}
			if (sameFieldLcbnfAddresspali[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				unbindSameElementByJqobj.call(topvue, sameFieldLcbnfAddresspali[targetName],
						targetElement,targetObj);
			}	
		}
			//清空受益人信息	输入框处理
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"islongitems", new Array());//证件长期有效
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"name", null);//姓名
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"birthday", null);//出生日期
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"idno", null);//证件号码
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"bnfvalidYear", null);//证件有效期
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"occupation", null);//职业代码
//			//地址信息
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"areacodetel", null);//固定电话区号
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"homephone", null);//固定电话	
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"mobile", null);//移动电话
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"address", null);//居住地址
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"zipcode", null);//联系地址邮政编码
//			topvue.$nextTick(function () { 
//				try {
//			//下拉框处理		
//			$('#lcbnfidtype\\['+index+'\\]').combobox("clear");//证件类型
//			$('#lcbnfsex\\['+index+'\\]').combobox("clear");//性别
//			$('#lcbnfnaity\\['+index+'\\]').combobox("clear");//国籍
//			$('#lcbnfprovince\\['+index+'\\]').combobox("clear");//居住地址省
//			$('#lcbnfdistrict\\['+index+'\\]').combobox("clear");//居住地址区
//			$('#lcbnfcity\\['+index+'\\]').combobox("clear");//居住地址市
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"idtype","");
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"sex", "");
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"naity","");
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"province", "");
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"district", "");
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"city", "");
//				} catch (e) {
//				}
//			});
			
	}

};

afterVueSelect.lcbnfidtype= function(form_element) {
	var topvue = getTopvueObj(this);
	for(var i=0;i<topvue.formdata.bnf.length;i++){
		if(topvue.formdata.bnf[i].idtype!="O"){
			topvue.$set(topvue.formdata.bnf[i],"othercardtype","");
			$(" input[ name='bnf["+i+"].othercardtype' ] ").attr("disabled",true);
			$(" input[ name='bnf["+i+"].othercardtype' ] ").val("");
		}
		else {
			$(" input[ name='bnf["+i+"].othercardtype' ] ").removeAttr("disabled");
		}
	}
};
//这里被同事更改了为lcbnfreippali，上线时记得数据库不要遗漏
afterVueSelect.lcbnfreippali= function(form_element) {
	var topvue = getTopvueObj(this);
	for(var i=0;i<topvue.formdata.bnf.length;i++){
		if(topvue.formdata.bnf[i].reip!="04"){ //上线是04
			topvue.$set(topvue.formdata.bnf[i],"otherrelation","");
			$(" input[ name='bnf["+i+"].otherrelation' ] ").attr("disabled",true);
			$(" input[ name='bnf["+i+"].otherrelation' ] ").val("");
		}
		else {
			$(" input[ name='bnf["+i+"].otherrelation' ] ").removeAttr("disabled");
		}
	}
};

$.fn.bootstrapValidator.validators.bnf_ratio = {
	validate : function(validator, $field, options) {
		var topvueobj = getTopvueObj(options.vueobj);
		var insuidStart = options.vueobj.namepref.indexOf("_");
		var insuid = options.vueobj.namepref.substring(insuidStart + 1);
		var bnfAry = topvueobj.formdata.bnf;

		var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
		// options.vueobj.formdata ;

		var bnflot1 = 0;
		var bnflot2 = 0;
		//多个框
		for (var i = 0; i < bnfAry.length; i++) {
			var bnf = bnfAry[i];
			
			//Relevant表
			for ( var key in bnf.mapRelevant) {
				if (insuid == key) {
					// if($("[id='bnflot"+i+"']").is(":visible")){
					if (!isNaN(bnf.mapRelevant[insuid].bnflot)) {
						if(bnf.mapRelevant[insuid].bnfgrade==1)
							bnflot1 = bnflot1+ Number(bnf.mapRelevant[insuid].bnflot);
						if(bnf.mapRelevant[insuid].bnfgrade==2)
							bnflot2 = bnflot2+ Number(bnf.mapRelevant[insuid].bnflot);
					}

					// }
					//					
				}

			}

		}
		if (bnflot1==0||bnflot1==100) {
			if(bnflot2==100){
				form.data('bootstrapValidator').updateStatus($field, "VALID");

				form.find("input[id*='bnflot']").each(function() {

					if (!form.data('bootstrapValidator').isValidField($(this))) {
						form.data('bootstrapValidator').revalidateField($(this));
					}

				});

				return true;
			}
		}
		if (bnflot2==0||bnflot2==100) {
			if(bnflot1==100){
				form.data('bootstrapValidator').updateStatus($field, "VALID");

				form.find("input[id*='bnflot']").each(function() {

					if (!form.data('bootstrapValidator').isValidField($(this))) {
						form.data('bootstrapValidator').revalidateField($(this));
					}

				});

				return true;
			}
		}

		return false;
	}
};

bootstrap_valid.bnf_ratio = function(validitem) {

	var vueobj = this;
	var validobj = {
		message : "该被保人受益人比例之和不为100",
		vueobj : vueobj
	};

	return validobj;

};

vueMethods.getBnfRelTitle = function(value, indexbnfno, insuids) {
	if (value == "1") {
		return "被保人1身故受益人";
	}
	if (value == "2") {
		return "被保人2身故受益人";
	}

	if (value == "1,2") {
		return "两被保人均身故";
	}

};
vueMethods.getBnFRelData = function(formdata, mapkey, key) {
	if (formdata[mapkey] == undefined) {

		this.$set(formdata, mapkey, {});
	} else {

	}

	if (formdata[mapkey][key] == undefined) {

		this.$set(formdata[mapkey], key, {});
	} else {

	}

	return formdata[mapkey][key];
};


commonCombobox_option.commonCombobox_insuredrelaToInsu = {
		url : path + '/newCont/codeselect/common/relationforpingan',   //这是要上线的
//		url : path + '/newCont/codeselect/common/anzl_relation',   //这是方便本地调试
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "codename" ,
		textShow : [ "codename" ]
	};





// getBnFRelData(formdata['bnf'][n-1]['mapRelevant'],insuid)
/*******************************************************************************
 * 受益人 与被保人关系
 */
vueMethods.getBnfRelship = function(SID, objvalue, num_index) {
	var elments = [];
	var aryindex = {};

	if (this.form_elements[SID]) {
		try {
			console.log("objvalue length" + objvalue + " SID:" + SID);
		} catch (e) {
			console.log(e);
		}
		var formdata = this.formdata;
		if (formdata['lcinsured']
		&& formdata['lcinsured'].lcinsuredtwoflag
		&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
		&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {

		} else {

			if(formdata['bnf'][num_index].insuids
					&&formdata['bnf'][num_index].insuids.length==1
					&&formdata['bnf'][num_index].insuids[0]=="1"){
				
			}else{
				objvalue=["1"];
				formdata['bnf'][num_index].insuids=[];
				formdata['bnf'][num_index].insuids.push("1");
//				this.$set(formdata['bnf'][num_index].insuids,"insuids",["1"]);
			}
			
		}
		if (objvalue != undefined) {

			var firstInsu = false;
			var secondInsu = false;
			var bothInsu = false;
		
			

			for ( var index in objvalue) {

				if (objvalue[index] == "1") {
					firstInsu = true;
				}

				if (objvalue[index] == "2") {
					secondInsu = true;
				}

				if (objvalue[index] == "1,2") {
					firstInsu = true;
					secondInsu = true;
					bothInsu = true;
				}
			}

			// 显示与第一个被保险人关系
			if (firstInsu) {
				elments.push(this.form_elements[SID][0]);
				aryindex[0] = true;

			} else {

			}
			// 显示与第二个被保险人关系
			if (secondInsu) {
				elments.push(this.form_elements[SID][1]);
				aryindex[1] = true;

			} else {

			}

			var changeFlag = false;// 变化 标志
			if (!firstInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['1'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['1'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '1', {});
				changeFlag = true;

			}

			if (!secondInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['2'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['2'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '2', {});
				changeFlag = true;

			}

			if (!bothInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['1,2'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['1,2'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '1,2', {});
				changeFlag = true;
			}
			// 受益人所属被保人 变化后 重新 valid 部分字段
			if (changeFlag) {
				$("#lcbnf_tabinfoform").find("input[id*='bnflot']").each(
						function() {

							$("#lcbnf_tabinfoform").data('bootstrapValidator')
									.revalidateField($(this));

						});

			}

		}
		// 清空元素值
		for ( var index in this.form_elements[SID]) {
			if (aryindex[index]) {

			} else {

				var element = this.form_elements[SID][index];
				this.$set(this.formdata[element.groupid][num_index],
						element.name, "");
			}
		}

	}

	return elments;

};


//根据身份证号，同步出生日期
afterVueSelect.lcbnfidno = function(form_element) {
	var topvue = getTopvueObj(this);
	for(var i=0;i<topvue.formdata.bnf.length;i++){
		if(topvue.formdata.bnf[i].idtype != "I"&&topvue.formdata.bnf[i].idtype != "J"){
			return;
		}
		if(topvue.formdata.bnf[i].idtype == "I"||topvue.formdata.bnf[i].idtype == "J"){
				var idno = topvue.formdata.bnf[i].idno;
				var birthday = idno.substring(6,14);
				var year = birthday.substring(0,4);
				var mon = birthday.substring(4,6);
				var day = birthday.substring(6);
				var formatBirth = year + "-" + mon + "-" + day;
				topvue.$set(topvue.formdata.bnf[i],"birthday",formatBirth);		
		}
	}
}
$.fn.bootstrapValidator.validators.bnf_idno = {
		validate : function(validator, $field, options) {
			var num=$(options.vueobj.$el).children().attr("id").split("[")[1].substring(0,1);
			var topvueobj = getTopvueObj(options.vueobj);
			var bnfAry = topvueobj.formdata.bnf;
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			var length=bnfAry.length;
			bnf=bnfAry[num];
			if(bnf.idno.length==18||(bnf.idtype!="I"&&bnf.idtype!="J")){
				form.data('bootstrapValidator').resetField($("#lcbnfbirthday\\["+num+"\\]"));
				form.data('bootstrapValidator').updateStatus($field, "VALID");
				form.find("input[id*='lcbnfidno']").each(function() {
					if (!form.data('bootstrapValidator').isValidField($(this))) {
						form.data('bootstrapValidator').revalidateField($(this));
					}

				});
				return true;
			}
			return false;
		}
	};
	bootstrap_valid.bnf_idno = function(validitem) {

		var vueobj = this;
		var validobj = {
			message : "当前证件类型下证件号码必须为18位，请重新输入",
			vueobj : vueobj
		};

		return validobj;

	};
	
	
commonCombobox_option.commonCombobox_lcbnfprovince ={

		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
};

commonCombobox_option.commonCombobox_lcbnfcity  =  {
		url :  path + '/newCont/codeselect/allcity/#lcbnfprovince.do',
		valueField : "cityid",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
};
commonCombobox_option.commonCombobox_lcbnfdistrict =  {
		url :  path + '/newCont/codeselect/allcounty/#lcbnfcity.do',
		valueField : "countyid",
		// 显示在输入框的
		inputText : "countyname",
		textShow : [ "countyname" ]
};
afterVueSelect.lcbnfislongitem = function(form_element) {
	var topvue = getTopvueObj(this);
//	topvue.$set(topvue.formdata.lcinsured,"insureidenddate","2099-01-01");
	var index=$(this.$el).children().children().children().attr("id").split("[")[1].substring(0,1);
	if(topvue.formdata.bnf[index].islongitems.length>0){
		topvue.$set(topvue.formdata.bnf[index],"bnfvalidYear","9999-12-31");
		$("#lcbnfbnfvalidYear\\["+index+"\\]").attr("disabled",true);
	}
	else{
		$("#lcbnfbnfvalidYear\\["+index+"\\]").attr("disabled",false);
	}
	
}