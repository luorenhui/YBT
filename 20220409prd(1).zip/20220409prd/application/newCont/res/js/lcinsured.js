var sameFieldLcinusred={
	"bankcustomertype":"bankcustomertype",
	"lcinsuredname"	:"appntname",
	"lcinsurednativeplace"	:"nativeplace",//国籍
	"lcinsuredsex"	:"appntsex",//性别
	"lcinsuredroccupationcode"	:"occupationcode",//职业代码
	"lcinsuredidtype"	:"idtype",//证件类型
	"lcinsuredidno"	:"idno",//证件号码
	"lcinsuredcompany"	:"company",//工作单位及名称
	"lcinsuredbirthday"	:"appntbirthday",//出生日期
	"insureidenddate"	:"appntenddate",//证件有效止期
	"rgtaddress"	:"rgtaddress",//个人年收入(万元)
	"occupationtype"	:"occupationtype",// 行业代码
	"lcinsuredbirthcounty":"birthcounty",
//	"lcinsuredbirthcounty"	:"appntenddate",// 被保人出生地国家
	"industrytype"	:"industrytype",// 行业类别
	"jade":"jade",
	"islongitems":"islongitems",//证件长期有效
	"startingDate"	:"startingDate"//证件有效始期
//	"renewCount"	:"renewCount"//证件有效始期

};

var sameFieldLcinusredAddress={
		"zipcode"	:"zipcode",//联系地址邮政编码
		"postprovince"	:"postprovince",//通讯地址省
		"postdistrict"	:"postdistrict",//通讯地址区
		"postcity"	:"postcity",//通讯地址市
		"postaladdress"	:"postaladdress",//通讯地址
		"mobile"	:"mobile",//移动电话
		"homezipcode"	:"homezipcode",//
		"homeprovince"	:"homeprovince",//
		"homephone"	:"homephone",//家庭电话
		"homedistrict"	:"homedistrict",//居住地址区
		"homecity"	:"homecity",//居住地址市
		"homeaddress"	:"homeaddress",//居住地址
		"email"	:"email",
		"postalflags"	:"postalflags",
		"countrycodetel_tel":"countrycodetel_tel",
		"areacodetel":"areacodetel",
		"countrycodetel_mob":"countrycodetel_mob"
	};

var onlysameFieldLcinusredAddress={
		"zipcode"	:"zipcode",//联系地址邮政编码
		"postprovince"	:"postprovince",//通讯地址省
		"postdistrict"	:"postdistrict",//通讯地址区
		"postcity"	:"postcity",//通讯地址市
		"postaladdress"	:"postaladdress"//通讯地址

	};

//选择了身份证类型时
afterVueSelect.lcinsuredidtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcinsured.lcinsuredidtype;
	//非本人才进来
	if($('#lcinsuredrelationtoappnt').val() != "8"){
/*	if (idtype == "X"){
		$("#insuredrenewCount").attr("disabled",false);
	}else {
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"renewCount", null);
			$("#insuredrenewCount").attr("disabled",true);
	}*/
	if (idtype != "I"){
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"startingDate", null);
		$("#insuredstartingDate").attr("disabled",true);
		}else {
		$("#insuredstartingDate").attr("disabled",false);
		}
		if (idtype == "H" || idtype == "C"){
			//证件有效止期置灰  证件长期有效按钮置灰
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"insureidenddate", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"islongitems", new Array());
			$("#lcinsuredidenddate").attr("disabled",true);
			$("#lcinsuredislongitemmeli").attr("disabled",true);
			}else {
				if(vueobj["testdivchange"].formdata.lcinsured.islongitems.length==0){
			$("#lcinsuredidenddate").attr("disabled",false);
			$("#lcinsuredislongitemmeli").attr("disabled",false);
				}
			}
	}
};

afterVueSelect.lcinsuredidtype1 = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
		//第二被保人
		var idtype1= topvue.formdata.lcinsuredtwo.lcinsuredidtype;
/*		if((idtype1 !=null && idtype1 != "") && (idtype1 == "X")){
			$("#insuredrenewCount1").attr("disabled",false);
		}else{
			 vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"renewCount", null);
			$("#insuredrenewCount1").attr("disabled",true);
		}*/
		if((idtype1 !=null && idtype1 != "") && idtype1 != "I"){
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"startingDate", null);//证件有效始期
			$("#insuredstartingDate1").attr("disabled",true);
		}else{
			$("#insuredstartingDate1").attr("disabled",false);
		}
		if((idtype1 !=null && idtype1 != "") && (idtype1 == "H" || idtype1 == "C")){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"insureidenddate", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"islongitems", new Array());
			$("#insureidenddate1").attr("disabled",true);
			$("#twolcinsuredislongitem").attr("disabled",true);
		}else{
			if(vueobj["testdivchange"].formdata.lcinsuredtwo.islongitems.length==0){
			$("#insureidenddate1").attr("disabled",false);
			$("#twolcinsuredislongitem").attr("disabled",false);
			}
		}
		//多被保人
		var idtype2 = null;
		if(index !=null && index != ""){
			idtype2= topvue.formdata.lcinsuredmulti[index].lcinsuredidtype;
/*			if ((idtype2 !=null && idtype2 != "") && (idtype2 == "X")){
				$("#insuredrenewCount1\\["+index+"\\]").attr("disabled",false);
			}else {
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[index],"renewCount", null);//证件有效始期
			$("#insuredrenewCount1\\["+index+"\\]").attr("disabled",true);
			}*/
			if ((idtype2 !=null && idtype2 != "") && idtype2 != "I"){
		    vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[index],"startingDate", null);
				$("#insuredstartingDate1\\["+index+"\\]").attr("disabled",true);
			}else {
				$("#insuredstartingDate1\\["+index+"\\]").attr("disabled",false);
			}
			if((idtype2 !=null && idtype2 != "") && (idtype2 == "H" || idtype2 == "C")){
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[index],"insureidenddate", null);
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredmulti[index],"islongitems", new Array());
				$("#insureidenddate1\\["+index+"\\]").attr("disabled",true);
				$("#multilcinsuredislongitem\\["+index+"\\]").attr("disabled",true);
			}else{
				if(vueobj["testdivchange"].formdata.lcinsuredmulti[index].islongitems.length==0){
				$("#insureidenddate1\\["+index+"\\]").attr("disabled",false);
				$("#multilcinsuredislongitem\\["+index+"\\]").attr("disabled",false);
			}
			}
	}
};

/**
 * 投保人 同被保人
 */
afterVueSelect.lcinsuredrelationtoappnt = function(form_element) {

	var topvue = getTopvueObj(this);

	var form =$(this.$el)
	.parentsUntil("form").parent("form");
	if (this.formdata.relationtoappnt=="8") {

		for ( var key in topvue.form_elements.lcinsured) {

			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {

				bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusred[targetName],
						topvue.formdata.lcinsured,targetName,targetElement);
			}

			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {

				bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredAddress[targetName],
						topvue.formdata.lcinsuredaddress,targetName,targetElement);
			}

		}


		topvue.$nextTick(function () {
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});


		$("#lcinsuredpostalflag").hide();
//		topvue.$set(topvue.form_elementsBYID.lcinsured,"","04");
	} else {



		for ( var key in topvue.form_elements.lcinsured) {

			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {

				unbindSameElement.call(topvue, sameFieldLcinusred[targetName],
						targetElement);
			}

			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {

				unbindSameElement.call(topvue, sameFieldLcinusredAddress[targetName],
						targetElement);
			}

		}
		$("#lcinsuredpostalflag").show();
//		topvue.$set(topvue.form_elementsBYID.lcinsured,"lcinsuredpostalflag","01");

		//2.投被保险人为本人，修改为非本人选项，则系统会清空被保险人信息，需要重新填写  （ 8为本人）
		 if($('#lcinsuredrelationtoappnt').val() != "8" && $('#lcinsuredrelationtoappnt').val() != "" ){
			   //清空主被保人信息   输入框处理
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredbirthcounty", null);//出生地国家/地区
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredbirthday", null);//出生日期
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"rgtaddress", null);//个人年收入(万元)
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredcompany", null);//工作单位
			 vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"bankcustomertype", null);//银行客户类型
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredname", null);//被保人姓名
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"lcinsuredidno", null);//证件号码
//			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"renewCount", null);//换证次数
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"startingDate", null);//证件有效始期
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"insureidenddate", new Array());//证件有效止期
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"islongitems", new Array());//证件长期有效
			   //清空被保人地址信息
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"areacodetel", null);//固定电话区号
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postaladdress", null);//详细地址
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"zipcode", null);//邮政编码
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"mobile", null);//移动电话
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"homephone", null);//固定电话
			   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"email", null);//E-mail

				topvue.$nextTick(function () {
					try {
				//下拉框处理
				//清空被保人信息
				$('#lcinsuredbankcustomertype').combobox("clear");//银行客户类型
				$('#lcinsuredsex').combobox("clear");//性别
				$('#lcinsuredtype').combobox("clear");//被保人类型
				$('#lcinsuredroccupationcode').combobox("clear");//职业代码
				$('#lcinsurednativeplace').combobox("clear");//国籍/地区
				$('#lcinsuredidtype').combobox("clear");//证件类型
				$('#lcinsuredindustry').combobox("clear");//行业类别
				$('#lcinsuredcoveredlocalsociomedical').combobox("clear");//当地社会医疗保险参保人员
				$('#lcinsuredindustrycode').combobox("clear");//行业代码
				$('#lcinsuredbirthcounty').combobox("clear");//出生地国家/地区
				$('#lcinsuredindustry').combobox("clear");//lcinsuredjade
				$('#lcinsuredbirthcounty').combobox("clear");//出生地国家/地区
				$('#lcinsuredjade').combobox("clear");//尚玉客户
				 //清空被保人地址信息
				$('#lcinsuredcountrycode_anzl1').combobox("clear");//移动电话国家/地区代码
				$('#lcinsuredpostalflag').combobox("clear");// 同投保人地址
				$('#lcinsuredpostprovince').combobox("clear");// 地址省
				$('#lcinsuredpostdistrict').combobox("clear");// 地址区
				$('#lcinsuredpostcity').combobox("clear");// 地址市
				$('#lcinsuredcountrycode_anzl').combobox("clear");// 固定电话国家/地区代码
					} catch (e) {
					}
				});
		  }


	}

};


//证件长期有效
afterVueSelect.lcinsuredislongitemmeli = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcinsured.lcinsuredidtype;
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
		+ form_element.name + "']");
	if($('#lcinsuredrelationtoappnt').val() != "8" && $('#lcinsuredrelationtoappnt').val() != ""
		&& idtype != "H" && idtype != "C"){
		if (obj.is("[type='checkbox']:checked")){
			topvue.$set(topvue.formdata.lcinsured,"insureidenddate","9999-01-01");
//			$("#lcinsured_tabinfoform").data('bootstrapValidator').resetField($("#lcinsuredidenddate"));
			$("#lcinsuredidenddate").attr("disabled",true);
		}else {
			$("#lcinsuredidenddate").attr("disabled",false);
		}
	}
}
afterVueSelect.twolcinsuredislongitem = function(form_element) {
	var topvue = getTopvueObj(this);
	var idtype= topvue.formdata.lcinsuredtwo.lcinsuredidtype;
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
		+ form_element.name + "']");
	if($('#relationtoappnt1').val() != "8" && $('#relationtoappnt1').val() != ""
		&& idtype != "H" && idtype != "C"){
		if (obj.is("[type='checkbox']:checked")){
			topvue.$set(topvue.formdata.lcinsuredtwo,"insureidenddate","9999-01-01");
//			$("#lcinsured_tabinfoform").data('bootstrapValidator').resetField($("#insureidenddate1"));
			$("#insureidenddate1").attr("disabled",true);
		}else {
			$("#insureidenddate1").attr("disabled",false);
		}
	}
}
afterVueSelect.multilcinsuredislongitem = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
	var idtype= topvue.formdata.lcinsuredmulti[index].lcinsuredidtype;
	var obj = $("#multilcinsuredislongitem\\["+index+"\\]");
	if($("#relationtoappnt1\\["+index+"\\]").val() != "8" && $("#relationtoappnt1\\["+index+"\\]").val() != ""
		&& idtype != "H" && idtype != "C"){
		if (obj.is("[type='checkbox']:checked")){
			topvue.$set(topvue.formdata.lcinsuredmulti[index],"insureidenddate","9999-01-01");
			$("#insureidenddate1\\["+index+"\\]").attr("disabled",true);
		}else {
			$("#insureidenddate1\\["+index+"\\]").attr("disabled",false);
		}
	}
}
/**
 * 投保人 同被保人
 */

afterVueSelect.lcinsuredtwoflag = function(form_element) {

/*	setTimeout(function(){
 		if($("#insuredrenewCount1").is(":visible")){
 			 $(".zh").remove();
			 $("input[id^='insuredrenewCount']").parent().append("<small class='help-block zh' style='color: red;'>请注意，" +
			   				"请按证件上的换证次数填写，例如：01。</small>");
			 }
	},50);*/

	var formdata = this.formdata;
	if(   formdata['lcinsured']
		&&formdata['lcinsured'].lcinsuredtwoflag
		&&formdata['lcinsured'].lcinsuredtwoflag.length>=1
		&&formdata['lcinsured'].lcinsuredtwoflag[0]=='lcinsuredtwoflag'){

		return true;
	}else{

		return false;
	}

};

/**
 * 投保人地址同被保人地址
 */
afterVueSelect.lcinsuredpostalflag = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (topvue.formdata.lcinsured.relationtoappnt!="8") {


		if (obj.is("[type='checkbox']:checked")) {

			for ( var key in topvue.form_elements.lcinsured) {

				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredaddress,targetName,targetElement);
				}
			}

		} else {
			for ( var key in topvue.form_elements.lcinsured) {
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					unbindSameElement.call(topvue, onlysameFieldLcinusredAddress[targetName],
							targetElement);
				}
			}
		}


	}


};

/**
 * 投保人地址 同被保人2地址
 */
afterVueSelect.lcinsuredtwopostalflag = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);


	if(topvue.formdata.newContApply.investment=='M'
		&&topvue.formdata['lcinsuredmulti']){

		var eleName = this.namepref
			+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;

		obj=$("input[name='"+eleName+"']");

		if (obj.is("[type='checkbox']:checked")) {

			for ( var key in topvue.form_elements.lcinsuredmulti) {

				var targetName= topvue.form_elements.lcinsuredmulti[key].name;
				var targetElement= topvue.form_elements.lcinsuredmulti[key];
				var index = getIndex(eleName);
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				if(targetName.indexOf("zip")>0){
					var tttt="";
				}
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredmulti[key].name]!=undefined) {
					bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredmulti[index].lcaddress,targetName,targetElement,targetObj);
				}
			}

		} else {
			for ( var key in topvue.form_elements.lcinsuredmulti) {

				var targetName= topvue.form_elements.lcinsuredmulti[key].name;
				var targetElement= topvue.form_elements.lcinsuredmulti[key];
				var index = getIndex(eleName);
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredmulti[key].name]!=undefined) {
					unbindSameElementByJqobj.call(topvue, onlysameFieldLcinusredAddress[targetName],
							targetElement,targetObj);
				}
			}
		}

	}else{
		if (obj.is("[type='checkbox']:checked")) {

			for ( var key in topvue.form_elements.lcinsured) {

				var targetName= topvue.form_elements.lcinsuredtwo[key].name;
				var targetElement= topvue.form_elements.lcinsuredtwo[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredtwo[key].name]!=undefined) {
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredtwoaddress,targetName,targetElement);
				}
			}

		} else {
			for ( var key in topvue.form_elements.lcinsured) {
				var targetName= topvue.form_elements.lcinsuredtwo[key].name;
				var targetElement= topvue.form_elements.lcinsuredtwo[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredtwo[key].name]!=undefined) {
					unbindSameElement.call(topvue, onlysameFieldLcinusredAddress[targetName],
							targetElement);
				}
			}
		}

	}



};
commonCombobox_option.commonCombobox_bankcustomertype = {

	url : path + '/newCont/codeselect/common/bankcustomertype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText :  "codename" ,
	textShow : [ "codename" ]

};
//dbs_city  dbs_province dbs_area 被保人通讯地址省
commonCombobox_option.commonCombobox_insuredpostprovince ={

	url :  path + '/newCont/codeselect/allprovinceid/province.do',
	valueField : "provinceid",
	// 显示在输入框的
	inputText : "provincename",
	textShow : [ "provincename" ]
};
//dbs_city  dbs_province dbs_area 被保人通讯地址
commonCombobox_option.commonCombobox_insuredpostcity  =  {
	url :  path + '/newCont/codeselect/allcity/#lcinsuredpostprovince.do',
	valueField : "cityid",
	// 显示在输入框的
	inputText : "cityname",
	textShow : [ "cityname" ]
};
//dbs_city  dbs_province dbs_area 被保人通讯地址
commonCombobox_option.commonCombobox_insuredpostdistrict = {

	url :  path + '/newCont/codeselect/allcounty/#lcinsuredpostcity.do',
	valueField : "countyid",
	// 显示在输入框的
	inputText : "countyname",
	textShow : [ "countyname" ]
};

//dbs_city  dbs_province dbs_area 被保人居住地址(省)
commonCombobox_option.commonCombobox_insuredhomeprovince = {

	url :  path + '/newCont/codeselect/allprovinceid/province.do',
	valueField : "provinceid",
	// 显示在输入框的
	inputText : "provincename",
	textShow : [ "provincename" ]
};
//dbs_city  dbs_province dbs_area 被保人居住地址(市)
commonCombobox_option.commonCombobox_insuredhomecity = {
	url :  path + '/newCont/codeselect/allcity/#lcinsuredhomeprovince.do',
	valueField : "cityid",
	// 显示在输入框的
	inputText : "cityname",
	textShow : [ "cityname" ]
};
//dbs_city  dbs_province dbs_area 被保人居住地址(区)
commonCombobox_option.commonCombobox_insuredhomedistrict = {
	url :  path + '/newCont/codeselect/allcounty/#lcinsuredhomecity.do',
	valueField : "countyid",
	// 显示在输入框的
	inputText : "countyname",
	textShow : [ "countyname" ]
};
//var showdilog="";
//beforesubmitvueform.lcinsured_tabinfoform = function() {
//	showdilog= layer.load(0, {
//			  shade: [0.1,'#fff'] //0.1透明度的白色背景
//		   });
//	return true;
//}

//根据身份证号，同步出生日期
afterVueSelect.lcinsuredidno = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");
	/*var form = $(this.$el).parentsUntil("form").parent("form");*/
	if($("#lcinsuredidtype").val() != "I" && $("#lcinsuredidtype").val() != "J"){
		return;
	}
	if($("#lcinsuredidtype").val() == "I"||$("#lcinsuredidtype").val() == "J"){
		if (obj.is("[id='lcinsuredidno']")){
//			topvue.$set(topvue.formdata.lcinsured,"insureidenddate","2099-01-01");
			var idno = $("#lcinsuredidno").val();
			var birthday = idno.substring(6,14);
			var year = birthday.substring(0,4);
			var mon = birthday.substring(4,6);
			var day = birthday.substring(6);
			var formatBirth = year + "-" + mon + "-" + day;
			topvue.$set(topvue.formdata.lcinsured,"lcinsuredbirthday",formatBirth);

		}
	/*	//重置出生日期的校验
		if($("#lcinsuredidno").val().length == 18){
			form.data('bootstrapValidator').resetField($('#lcinsuredbirthday'));
//			$.fn.bootstrapValidator.validators.lcinsured_idno;
		}*/
	}

}
$.fn.bootstrapValidator.validators.lcinsured_idno = {
		validate : function(validator, $field, options) {
			var topvueobj = getTopvueObj(options.vueobj);
			var lcinsured = topvueobj.formdata.lcinsured;
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			if (null!=lcinsured.lcinsuredidno){
				if(lcinsured.lcinsuredidno.length==18||(lcinsured.lcinsuredidtype!="I"&&lcinsured.lcinsuredidtype!="J")){
					form.data('bootstrapValidator').resetField($("#lcinsuredbirthday"));
					form.data('bootstrapValidator').updateStatus($field, "VALID");
					form.find("input[id*='lcinsuredidno']").each(function() {
						if (!form.data('bootstrapValidator').isValidField($(this))) {
							form.data('bootstrapValidator').revalidateField($(this));
						}

					});
					return true;
				}
			}
			return false;
		}
	};
	bootstrap_valid.lcinsured_idno = function(validitem) {

		var vueobj = this;
		var validobj = {
			message : "当前证件类型下证件号码必须为18位，请重新输入",
			vueobj : vueobj
		};

		return validobj;

	};

aftersubmitvueform.lcinsured_tabinfoform = function() {
	var topvue = getTopvueObj(this);
   console.log("lcinsured_tabinfoform==="+topvue.formdata.newContApply.investment);
	//判断主险是否是六个被保人
   if(topvue.formdata.newContApply.investment=='M'){
		console.log(vueobj["testdivchange"].formdata.newContApply.insChangeFlag);
		if(vueobj["testdivchange"].formdata.newContApply.insChangeFlag){
			incuredall();
			ClearAll();
			try {
				if($("#subriskcode_tabinfoform").data('bootstrapValidator')!=null&&
						$("#subriskcode_tabinfoform").data('bootstrapValidator')!=undefined){
						$("#subriskcode_tabinfoform").data('bootstrapValidator').destroy();
				        $('#subriskcode_tabinfoform').data('bootstrapValidator', null);
					}
			} catch (e) {
				// TODO: handle exception
			}

		}
	}
   return true;
};
var temp_birthday="";

afterloadNewElements.lcinsured_tabinfo=function(){

	setTimeout(function(){
		if(($("#lcinsuredidtype").is(":visible")||$("#lcinsuredidtype").length>0)){
   		 $("#lcinsuredidtypeTitle").remove();
   		$("#lcinsuredidtype").parent().append("<small id='lcinsuredidtypeTitle' class='help-block' style='color: red;'>请注意，" +
   				"此处选择的被保险证件类型，需和其之后通过手机银行上传的证件文件（e.g.,图片）的类型保持一致。若被保险人选择了“身份证”，则需上传其身份证的图片，不能上传户口本上有证件号码的图片。</small>");
		 }
	},50);

	var _this=this;
	var topvue = getTopvueObj(this);
	temp_birthday=topvue.formdata.lcinsured.lcinsuredbirthday;
	 this.$nextTick(function(){
		     setTimeout(function(){
		    	if(($("#lcinsuredname").is(":visible")||$("#lcinsuredname").length>0)){
		    		 $("#lcinsurednameTitle").remove();
					 $("input[id^='lcinsuredname']").parent().append("<small id='lcinsurednameTitle' class='help-block ti' style='color: red;'>请确保此处输入被保险人姓名和其证件姓名完全一致。若使用身份证，请输入中文姓名！</small>");
				 }
/*		    	if($("#insuredrenewCount").is(":visible")){
		    		 $(".zh").remove();
					 $("input[id^='insuredrenewCount']").parent().append("<small class='help-block zh' style='color: red;'>请注意，" +
					   				"请按证件上的换证次数填写，例如：01。</small>");
					 }*/
			 },50);
		});
	 $("input[value='增加新被保人']").click(function(){
		 _this.$nextTick(function(){
			 $(".ti").remove();
			 $("input[id^='lcinsuredname']").parent().append("<small class='help-block ti' style='color: red;'>请确保此处输入被保险人姓名和其证件姓名完全一致。若使用身份证，请输入中文姓名！</small>");
	 		/* $(".zh").remove();
			 $("input[id^='insuredrenewCount']").parent().append("<small class='help-block zh' style='color: red;'>请注意，" +
			   				"请按证件上的换证次数填写，例如：01。</small>");*/
	 })
	 })
}
//IPS生日
beforesubmitvueform.lcinsured_tabinfoform=function(){
	var topvue = getTopvueObj(this);
	var flag=true;

	if(temp_birthday!=""){
		if(topvue.formdata.lcinsured.lcinsuredbirthday!=temp_birthday){
			if(confirm("客户证件生日与建议书系统的录入生日不一致，请点击【确认】保存或【取消】修改证件信息。")){
				flag=true;
			}else{
				flag=false;
			}
		}
	}

	//3.保存被保险人信息时， 若投被保险人信息非同一人时，请检查投保人和被保险人的证件号码是否相同，
	//若相同，则报错“投保人和被保险人证件号码相同，请检查投被保险人关系是否填写正确！”		  8为本人
	if (topvue.formdata.lcinsured.relationtoappnt!="8"&&topvue.formdata.lcinsured.relationtoappnt!= "") {
			var idno= topvue.formdata.lcappnt.idno;//投保人证件号码
			var lcinsuredidno= topvue.formdata.lcinsured.lcinsuredidno;////被保人证件号码
			if(idno!=""&&lcinsuredidno!=""){
				if(idno.trim()==lcinsuredidno.trim()){
					alert("投保人和被保险人证件号码相同，请检查投被保险人关系是否填写正确！");
					flag=false;
				}
			}
	}
	var date = new Date();
    var seperator1 = "-";
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;
	//主被保人
	if(topvue.formdata.lcinsured.lcinsuredidtype!= "H" && topvue.formdata.lcinsured.lcinsuredidtype!= "C"){
		if(!(new Date(topvue.formdata.lcinsured.insureidenddate)>new Date(currentdate))){
			alert("证件有效止期必须大于今天")
			return false;
		}

	}
	if(topvue.formdata.lcinsured.lcinsuredidtype =="I"){

		if(topvue.formdata.lcinsured.startingDate==null
				|| topvue.formdata.lcinsured.startingDate=="" ){
				alert("证件有效起期不能为空");
				return false;
		}
			if(new Date(topvue.formdata.lcinsured.startingDate)>new Date(currentdate)){
				alert("证件有效起期必须小于等于当前日期");
				return false;
			}
			if(new Date(topvue.formdata.lcinsured.startingDate)>=
				new Date(topvue.formdata.lcinsured.appntenddate)){
				alert("证件有效起期必须小于证件有效止期");
				return false;
			}

	}
/*	if(topvue.formdata.lcinsured.lcinsuredidtype== "X" ){

		if(topvue.formdata.lcinsured.renewCount==null
				|| topvue.formdata.lcinsured.renewCount=="" ){
			alert("证件为港澳台通行证，换证次数不可为空");
			return false;
		}
		var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.lcinsured.renewCount)).slice(-2);//01
		topvue.$set(topvue.formdata.lcinsured,"renewCount",newrenewcount);
	}*/
	//第二被保人
	if(topvue.formdata.lcinsuredtwo.lcinsuredidtype!=null && topvue.formdata.lcinsuredtwo.lcinsuredidtype!=""){
		if(topvue.formdata.lcinsuredtwo.lcinsuredidtype!= "H" && topvue.formdata.lcinsuredtwo.lcinsuredidtype!= "C"){
		if(!(new Date(topvue.formdata.lcinsuredtwo.insureidenddate)>new Date(currentdate))){
			alert("证件有效止期必须大于今天");
			return false;
		}
	}
		if(topvue.formdata.lcinsuredtwo.lcinsuredidtype== "I"){
		if(topvue.formdata.lcinsuredtwo.startingDate==null
				|| topvue.formdata.lcinsuredtwo.startingDate=="" ){
			alert("证件有效起期不可为空");
			return false;
		}

		if(new Date(topvue.formdata.lcinsuredtwo.startingDate)>new Date(currentdate)){
			alert("有效起期必须小于等于当前日期");
			return false;
		}
		if((new Date(topvue.formdata.lcinsuredtwo.startingDate))>=
			(new Date(topvue.formdata.lcinsuredtwo.insureidenddate))){
			alert("有效起期必须小于有效止期");
			return false;
		}
		}
	}
/*if((topvue.formdata.lcinsuredtwo.lcinsuredidtype!=null && topvue.formdata.lcinsuredtwo.lcinsuredidtype!="")&&
		topvue.formdata.lcinsuredtwo.lcinsuredidtype== "X"){

	if(topvue.formdata.lcinsuredtwo.renewCount==null
			|| topvue.formdata.lcinsuredtwo.renewCount=="" ){
		alert("证件为港澳台通行证，换证次数不可为空");
		return false;
	}
	var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.lcinsuredtwo.renewCount)).slice(-2);//01
	topvue.$set(topvue.formdata.lcinsuredtwo,"renewCount",newrenewcount);
}*/
	//多被保人
	var lcinsuredlist = topvue.formdata.lcinsuredmulti;
	for(var i=0;i<lcinsuredlist.length;i++){

		if(lcinsuredlist[i].lcinsuredidtype!=null && lcinsuredlist[i].lcinsuredidtype!=""){
			if(lcinsuredlist[i].lcinsuredidtype!= "H" && lcinsuredlist[i].lcinsuredidtype!= "C"){
			if(!(new Date(lcinsuredlist[i].insureidenddate)>new Date(currentdate))){
				alert("证件有效止期必须大于今天");
				return false;
			}
			}
			if(lcinsuredlist[i].lcinsuredidtype== "I"){
			if(lcinsuredlist[i].startingDate==null
					|| lcinsuredlist[i].startingDate=="" ){
				alert("证件有效起期不可为空");
				return false;
			}

			if(new Date(lcinsuredlist[i].startingDate)>new Date(currentdate)){
				alert("有效起期必须小于等于当前日期");
				return false;
			}
			if((new Date(lcinsuredlist[i].startingDate))>=
				(new Date(lcinsuredlist[i].insureidenddate))){
				alert("有效起期必须小于有效止期");
				return false;
			}
		}
		}
/*		if((lcinsuredlist[i].lcinsuredidtype!=null && lcinsuredlist[i].lcinsuredidtype!="")&&
				lcinsuredlist[i].lcinsuredidtype== "X"){
			if(lcinsuredlist[i].renewCount==null
					|| lcinsuredlist[i].renewCount=="" ){
				alert("证件为港澳台通行证，换证次数不可为空");
				return false;
			}
			var newrenewcount = (Array(2).join(0) + parseInt(lcinsuredlist[i].renewCount)).slice(-2);//01
			topvue.$set(lcinsuredlist[i],"renewCount",newrenewcount);

		}*/
	}
	if(null!=topvue.formdata.subFormData.lcinsured&&null!=topvue.formdata.subFormData.lcinsured.relationtoappnt) {
		initData(getActivePanelDIV(), true);
		var pflag = topvue.formdata.lccont.pageflag;
		fillinObj(topvue, topvue.formdata, topvue.formdata.subFormData, false, 0);
		if (topvue.formdata.subFormData.lcinsured.relationtoappnt=="00") {

			for ( var key in topvue.form_elements.lcinsured) {

				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {

					bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusred[targetName],
						topvue.formdata.lcinsured,targetName,targetElement);
				}

				if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {

					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredAddress[targetName],
						topvue.formdata.lcinsuredaddress,targetName,targetElement);
				}

			}


			topvue.$nextTick(function () {
				try {
					form.data('bootstrapValidator').resetForm();
				} catch (e) {
				}
			});


			$("#lcinsuredpostalflag").hide();
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredaddress,"postalflags", "");

		}
		topvue.formdata.lccont.pageflag = pflag;
		checkPaperChange = true;
	}
	return flag;
}
