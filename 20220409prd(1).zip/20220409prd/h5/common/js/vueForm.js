//var vueoOption.url_suffix=".do";
//var vueoOption.defaultWaitMessage="数据处理中，请稍后";
//var init
//groupid 是form_elements的对应键值  ， 
var  lay_check; //遮罩层
var update_element={};
var checkClose = false;
var loadingflag= false;
var interval = null;//计时器
var firstLoadFlag=true; //页面第一次加载
var animateTime=200;
var H5flag=false;
function preventTouchmove(){
	document.addEventListener('touchmove', function (event) { 
	       event.preventDefault(); 
	}) ;
	
}
function removePreventTouchmove(){
//	document.removeEventListener('touchmove', function (event) { 
//	       event.preventDefault(); 
//	}) 
	
	$("body").unbind( "touchmove" );
}

function start_closeLay_check(){//启动计时器函数
	if(interval!=null){//判断计时器是否为空
		clearInterval(interval);
		interval=null;
	}
	interval = setInterval(closeLay_check,200);//启动计时器，调用overs函数，
}

function closeLay_check(){

	if(checkClose&&(JSON.stringify(update_element))=="{}"){
		checkClose = false;
		layer.close(lay_check);
		stopcloseLay_check();
	}
}

function stopcloseLay_check(){
	
	clearInterval(interval);
	interval = null;
}
 

 $.fn.bootstrapValidator.validators.ageFromBrithDay = {  
        validate: function(validator, $field, options) {

		 		var age =getAgeFromBrithday($field.val());
 
	            return age>=options.minage
	            			&& age<=options.maxage;
	            
        }  
    }; 
 $.fn.bootstrapValidator.validators.valueBetween = {  
	        validate: function(validator, $field, options) {
			 		var val = $field.val();
			 		if(val == "" || val == null){
			 			return true;
			 		}else{
			 			return val>=options.minVal
            			&& val<=options.maxVal;
			 		}
	        }  
	    }; 
 $.fn.bootstrapValidator.validators.max = {  
	        validate: function(validator, $field, options) {
			 		var length = $field.val().length;
			 		var message= options.message;
			 		if(length<=options.max){
			 			return true;
			 		}else{
			 			$("[data-bv-validator='max'][data-bv-for='"+$field.attr("name")+"'] ").text(message+",但现在长度为"+length)
			 			return false;
			 		}
	        }  
}; 
 $.fn.bootstrapValidator.validators.onlyEnglish = {  
	        validate: function(validator, $field, options) {
			 		var content = $field.val();
			 		var message= options.message;
			 		var reg = new RegExp("[\\u4E00-\\u9FFF]+","g");
			 	    if(reg.test(content)){
			 	    	return false;
			 	    }
			 	    else{
			 	    	return true;
			 	    }
	        }  
}; 
 $.fn.bootstrapValidator.validators.onlyAZ = {  
	        validate: function(validator, $field, options) {
			 		var content = $field.val().replace(/\s+/g,"");
			 		var message= options.message;
			 		var reg=/^[a-zA-Z]+$/;
			 		return reg.test(content);
	        }  
};
$.fn.bootstrapValidator.validators.dateAfterNow = {
	        validate: function(validator, $field, options) {
			 		var content = $field.val();
			 		var message= options.message;
			 		var reg = /^[1-9]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/;
			 		var regExp = new RegExp(reg);
			 		if(regExp.test(content)){
			 			if(!(new Date(content)>new Date())){
			 				return false;
			 			}else{
			 				return true;
			 			}
			 		}
	        }  
};
var reg_vueform_url = new RegExp("#([\\s\\S]*?[\\/\\\\\])|#([\\s\\S]*)?", "g");
var TIMEOUT_MESSAGE="Time out,please login again";
var TIMEOUT_MESSAGE_ALERT="页面超时，请刷新页面后重新登陆";
var validAndSaveflag=false;
var saveflag=false;
var lastscrollTop=0;
var tempvueoOption={
		 url_suffix :".do", //URL 后缀
		 defaultWaitMessage  :"数据处理中，请稍后",
		 debugmode:false,
		 inittabIndex :1 ,
		 tab_SID:"insuranceContInput",
		 initformdata:{
			 "title":{}
		 },
		 tab_toggle_before:function(activeid){
			 
			 try {
				 return tab_toggle_check(activeid);
			} catch (e) {
			}
			 return true;
		 },
		 vueMethods:{
//			 
			 addToTitle:function(title){
					
					if(!this.formdata['title'][title]){
						this.$set(this.formdata['title'],title,"title_"+title);
					}
					
					return "title_"+title;
				},
			 
			 //滚动事件触发相关的保存和加载功能
			 	handleScroll: function($event) {
			 		
			 		if(validAndSaveflag){
			 			$event.preventDefault; 
 						
 						return ;
			 		}
			 		
			 		
 					
 					var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
			 		//文档的总高度
			 		var documentScrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
				 //浏览器窗口的高度
			 		var getWindowHeight = document.documentElement.clientHeight || document.body.clientHeight;
			 		
 					if(scrollTop + getWindowHeight +50 <= documentScrollHeight){
 						//开始处理
	 					var timestamp=new Date().getTime();
	 					if(!this['timestamp']){
	 						this['timestamp']=0;
	 					}
	 					
	 					if(timestamp-this['timestamp']<=100){
	 						console.log("时间戳过早被拒绝： "+timestamp);
	 						$event.preventDefault; 
	 						
	 						return ;
	 					}
	 					console.log("timestamp： "+timestamp);
	 					console.log("this['timestamp']： "+this['timestamp']);
	 					this['timestamp']=timestamp;
	 					if(scrollTop-lastscrollTop>=100||scrollTop==0||lastscrollTop-scrollTop>=100){
							lastscrollTop=scrollTop;
						}else{
							
							console.log("滚动过少返回： "+scrollTop);
							return ;
						}
 					
 					}else{
// 						if(scrollTop>400){
 							console.log("移动到底部开始回移： ");
// 	 						 $("html,body").animate({scrollTop:documentScrollHeight-300},animateTime);
// 	 						this['timestamp']=0;
// 	 						 return;		
// 							
// 						}
 						
 					}
 					
 					
 					
			 		try{
			 			var that = this;
						 //滚动条在y轴上的滚动距离
					 	
						

					 		if (scrollTop > 10) {
					 			that.isclass = true;
					 			that.iswhite= true;
					 		} else {
					 			
					 			that.isclass = false;
					 			that.iswhite= false;
					 		}
					 		
					 		//判断当前是表单的哪一个部分 
//					 		lccont_tabinfo_start    //"lccont_tabinfo"  lccont_tabinfoform  topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",curindex+1);
					 		var elements =this.form_elements[ this.formdata.newContApply.insurancecom+'H5insuranceContInput'];
					 		
					 		var curindex=Number(this.formdata.newContApply.currentSIDIndex);
					 		if(!curindex){
		 						curindex=0;
		 					}
					 		
					 		var show_index=-1;
					 		for (var index in elements){
					 			if(scrollTop==0){
					 				break;
					 			}
					 			index=Number(index);
					 			try{
					 				if($("#"+elements[index]['id']+"_start").offset()){
					 					elements[index]['offset_start']=$("#"+elements[index]['id']+"_start").offset().top; 
					 				}
					 				if($("#"+elements[index]['id']+"_end").offset()){
					 					elements[index]['offset_end']=$("#"+elements[index]['id']+"_end").offset().top; 
					 				}
					 				
					 				if((scrollTop + getWindowHeight)>=elements[index]['offset_end']+50
					 						&&elements[index].loadflag){
					 					
					 					show_index=index;
					 				}
					 				try{
					 					if(elements.length>index+1&&!elements[index+1].loadflag){
					 						break;
					 					}
					 				}catch(e){
					 					
					 				}
					 				
//					 				if(index>=1){
//					 					if((scrollTop + getWindowHeight)>=elements[index]['offset_start']+150
//						 						&&elements[index].loadflag){
//						 					
//						 					show_index=index;
//						 					
//						 					break;
//						 				}
//					 				}
					 				
				 					 
					 			}catch(e){
					 				console.log(e);;
					 			}
					 		}
					 		
					 		
					 		
					 		if ( show_index>=0){

					 			
					 			var index=Number(show_index);
					 			this.$set(this.formdata.newContApply,"currentSIDIndex",index);
					 			try{
					 				console.log("当前SID:    "+index + " "+elements[index]['offset_start'] 
				 						+ " "+(scrollTop + getWindowHeight)
				 						+ " "+elements[index]['offset_end'] );
							 			

				 					
				 					
				 					
				 					
				 					var form =$("#"+elements[index]['id']+"form");;

			 						//标签开始切换  开始保存等相关操作
			 						
			 						//开始校验
			 						var flag=true;
			 						try {
										 if(form.data("bootstrapValidator")){
											var isvalid = form.data("bootstrapValidator").validate();
											form.data("bootstrapValidator_hasvalid",true);
											flag =flag&& isvalid.isValid();
										 }
									 } catch (e) {
										 flag=false;
										 console.log(e);
									 }
								  
									 if(!flag){
											//解决有值但是校验不通过的问题
										 form.data("bootstrapValidator").getInvalidFields().each(function(){
											 if($(this).val()){
												 form.data('bootstrapValidator').revalidateField($(this) );
											 }
											 
										  });
//										 for(var keyIndex in form.data("bootstrapValidator").getInvalidFields()){
//											var field= $(form.data("bootstrapValidator").getInvalidFields().get(keyIndex));
//											 
//											 if(field.val()){
//												 form.data('bootstrapValidator').revalidateField(field);
//											 }
//											 
//										 }
										 
										 if(form.data("bootstrapValidator").getInvalidFields().length>0){
											 
											 
											 
											 console.log("有未校验通过的数据，开始移动页面");
											 var offset_scroll =$(form.data("bootstrapValidator").getInvalidFields()).offset().top;
											 if(offset_scroll>350){
												 $("html,body").stop(true,true);
												 console.log("***********************scrollTop： "+(offset_scroll-350));
												 $("html,body").animate({scrollTop:offset_scroll-350},animateTime);
												 this['timestamp']=this['timestamp']+animateTime+200;

												 
											 }else{
												 $("html,body").stop(true,true);
												 $("html,body").animate({scrollTop:0},animateTime);
												 this['timestamp']=this['timestamp']+animateTime+200;
											 }
											
										 }
										 //处理完毕
										 return ;
									 }else{
										 
									 }
									 try{
										//有修改过的数值开始保存
										 if(index==1){
											 saveflag=!checkChange($("#"+elements[0]['id']+"form"));
										 }
										 if(!checkChange(form)||saveflag){
//										if(true||saveflag){
											//开始保存
											 
											 	//第一个tab 不做处理
						 						if(index!=0){
//						 							alert(elements[index]['id']);
						 							if(elements[index]['id'] == "notice_tabinfo" 
						 								&& !confirm("请您确认是否已完成信息录入？")){
						 								return;
						 							}
						 							saveflag=false;
						 							validAndSaveflag=true;
							 						var  beforeFlag =this.submitformH5(form, elements[index]['id'].replace("_tabinfo", ""));
							 						if(!beforeFlag){
							 							//滚动页面
							 							 $("html,body").animate({scrollTop:elements[index]['offset_end']- getWindowHeight},0);
														
							 						}
						 							 this['timestamp']=this['timestamp']+animateTime+1000;
						 							return;
						 						}else{
						 							saveflag=true;
//							 						this.$set(this.formdata.newContApply,"lastSIDIndex",curindex);
//							 						this.$set(this.formdata.newContApply,"currentSIDIndex",curindex+1);
						 						}
										 }else{
											 
										 }
										 

										//加载元素
			 							var topvue =this;
			 							//加载元素
			 							
			 							topvue.$set(topvue.formdata.newContApply,"lastSIDIndex",index);
			 							topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",index+1);
			 							if( !elements[index+1].loadflag){
			 								validAndSaveflag=true;
			 								loadNewElements(topvue, elements[index+1].relateObjectField ,elements[index+1]);
			 								elements[index+1].loadflag=true;
			 							}
//			 							
				 						
									 }catch(e){
										 console.log(e);;
										 
									 }
				 					 
					 			}catch(e){
					 				console.log(e);;
					 			}
					 			
					 			
				 			}
					 		
					 		
					 		//1.滚动到表单末尾开始判断是否有数据修改，如有修改则保存
					 		//2.校验数据，数据通过则保存
					 		//3.判断下一张表单是否加载，未加载则加载
					 		//4.
					 		
//					 		 $("#menuBar").css({"display":'block', 'top':'10px', 'left':'15px',  'position':'fixed','z-index': '999999999'});   
//					 		if ((firstLoadFlag&&scrollTop==0)) {
//					 			firstLoadFlag=false;
//					 			var index =Number(this.formdata.newContApply.currentSIDIndex);
//					 			if(!index){
//					 				index =0;
//					 			}
//					 			if(index ==0){
//					 				loadNewElements(this, elements[index].relateObjectField ,elements[index]);
////						 			loadNewElements(this, elements[index+1].relateObjectField ,elements[index+1]);
//					 			}
//					 			
//					 		}
					 		if (scrollTop + getWindowHeight +200 >= documentScrollHeight&&!loadingflag||(firstLoadFlag&&scrollTop==0)) {
					 			firstLoadFlag=false;
					 			var index =Number(this.formdata.newContApply.currentSIDIndex);
					 			if(!index){
					 				index =0;
					 			}
					 			
					 			if(!elements[index].loadflag&&!loadingflag){
					 				if(index>0){
					 					return ;
					 				}
				 					loadingflag=true;
				 					elements[index].loadflag=true;
				 					this.$set(this.formdata.newContApply,"currentSIDIndex",index);
				 					loadNewElements(this, elements[index].relateObjectField ,elements[index]);

				 					
				 				}
					 			
					 			
//					 			firstLoadFlag=false;
//					 			form_elements[ formdata.newContApply.insurancecom+'H5insuranceContInput']
//					 			loadNewElements(this, url,form_element);
					 		
//					 			for (var index in elements){
//					 				
//					 				if(!elements[index].loadflag){
//					 					loadingflag=true;
//					 					loadNewElements(this, elements[index].relateObjectField ,elements[index]);
//					 					elements[index].loadflag=true;
//					 					break;
//					 				}
//					 			}

					 		}
			 		}catch(e){
			 			
			 		}
			 		
			 		
				 },
				 
				 showMenu:function () {
//					 
//					 if(this.formstatus.showmenu){
//						 this.formstatus.showmenu=false;
//					 }else{
//						 this.formstatus.showmenu=true;
//					 }
					 if($("#tailcheck_nav").is(':visible')){
						 $("#tailcheck_nav").hide();
					 }else{
						 $("#tailcheck_nav").show();
					 }
				 },
				 checkMenu:function (id) {
					  
					  if($("#"+id).is(':visible')){
						  return true;
					  }
					  return false;
				 },
				 submitformH5:function ($form , sid) {
					
					 
					 try{
						 $form.attr("id");
					 }catch(e){
						 $form= $($form.target).parentsUntil("form").parent("form");
					 }
					
				      console.log("submitform  sid: " + sid +  "   NewContApply :" +$form.attr("id"));
				      var url = "/newCont/common/saveOrUpdate/"+sid
				        +"/"+ this.formdata.newContApply.insurancecom+ "/"+
				        this.formdata.newContApply.transno;
				      
				      submitvueformH5.call(this ,$form  ,url);
				     },
			 
				submitform:function ($event , sid) {

					console.log("submitform  sid: " + sid +  "   NewContApply :" +JSON.stringify(this.formdata.newContApply));
//					saveOrUpdate/{SID}/{insurancecom}/{transno}
					var url = "/newCont/common/saveOrUpdate/"+sid
							+"/"+ this.formdata.newContApply.insurancecom+ "/"+
							this.formdata.newContApply.transno;
					
					submitvueformH5.call(this ,$event  ,url);
				},
				reduceEleFromFormData:function (groupid,index) {

					
					if(this.formdata[groupid].length>= index ){
						this.formdata[groupid].splice(index,1);
					}
					console.log("reduceEleFromFormData element from formdata index:"
							+ index + " groupid: " +	groupid  
							+ " formdata.length: " +	this.formdata[groupid].length  );
					
				
				},
				reduceEleFromFormDataByFormdata:function (formdata ,groupid,index) {

					
					if(formdata[groupid].length>= index ){
						formdata[groupid].splice(index,1);
					}
					console.log("reduceEleFromFormData element from formdata index:"
							+ index + " groupid: " +	groupid  
							+ " formdata.length: " +	formdata[groupid].length  );
					
				
				},
				getFormelemnts:function (key ,subsids) {
					
					if(this.form_elements[key]==undefined){
						this.$set(this.form_elements ,key,[]);
					}
					
					
					if(subsids!=undefined){
						var act_form_elements=[];
						for (var index=0;index<this.form_elements[key].length;index++ ) {
							
							for ( var y in subsids) {
								
								if(subsids[y]==this.form_elements[key][index].subsid){
									act_form_elements.push(this.form_elements[key][index]);
									break;
								}
								
							}
						}
						return act_form_elements;
					}
					
					
					return this.form_elements[key];
				},
				addEleToFormData :function (groupid,index) {

					addEmptyEleToFormData(this.formdata,groupid,index);
				},
				addEleToFormDataByFormdata :function (formdata ,groupid,index) {

					addEmptyEleToFormData(formdata,groupid,index);
				}
				,
				showformdata :function () {

					console.log(JSON.stringify(this.formdata));
					
				}

			 
		 },
		 vuecomputeds:{
				 
		},
		 // 值变化钩子
		 afterVueSelect:{
			 
		 },
		 //元素加载完成后的钩子函数 参数   url ,form_element
		 afterloadNewElements:{
			 
		 },
		 //保单提交前钩子
		 beforesubmitvueform:{
			 
		 },
		 //保单提交后的钩子
		 aftersubmitvueform:{
			 
		 },
		 //表单初始化后处理
		 afterInitTab:{
			 
		 },
		 bootstrap_valid:{
 
		 
			 choice: function(validitem   ){
				 
				
//					 choice: 
				 var validobj= {
					 		min: validitem.min,
					 		message: this.form_element.text
				 		}
				 if(validitem.min){
					 validobj.min=validitem.min;
					 validobj.message=  validobj.message + "  至少需要选择"+validitem.min+"项"
				 }
				 
				 if(validitem.max){
					 validobj.max=validitem.max;
					 validobj.message=  validobj.message + "   最多可以选择"+validitem.max+"项"
				 }
				 return validobj;
	                 
	         },
			 emailAddress: function(validitem   ){
				 
				 var validobj= {
				 		 message: this.form_element.text+'格式有误,不是一个有效的电子邮箱地址'
				 };
				 
				 return validobj;
	                 
	         },
	         digits: function(validitem   ){
				 
				 var validobj= {
				 		 message: this.form_element.text+'格式有误,该值只能包含数字。'
				 };
				 
				 return validobj;
	                 
	         },
	         phone: function(validitem   ){
				 
				 var validobj= {
				 		 message: this.form_element.text+'格式有误,不是一个有效的电话号码。',
				 		 country:validitem.country
				 };
				 
				 return validobj;
	                 
	         },
			 date: function(validitem   ){
				 
				 var validobj= {
						 	format: 'YYYY-MM-DD',
				 			 message: this.form_element.text+'日期格式有误'
				 };
				 
				 return validobj;
	                 
	         },
	         notEmpty: function(validitem   ){
				 
				 var validobj= {
				 			 message: this.form_element.text+'不能为空'
				 };
				 
				 return validobj;
	                 
	         },
	         ageFromBrithDay: function(validitem   ){
	        	 	var min =getRealValueFromVueObj.call( validitem.vueobj,validitem.min);
			 		var max =getRealValueFromVueObj.call( validitem.vueobj,validitem.max);
			 		var validobj= {
			 				message:validitem.tempmessage + "年龄必须大于"+ min+ "小于"+ max,
			 				minage:min,
			 				maxage:max
			 		};
				 
			 		return validobj;
	                 
	         },
	         valueBetween: function(validitem   ){//校验 值在某个范围内
	        	 	var min = validitem.min;
			 		var max = validitem.max;	
			 		var validobj= {
			 				message: this.form_element.text + "必须大于"+ min+ "小于"+ max,
			 				minVal:min,
			 				maxVal:max
			 		};
				 
			 		return validobj;
	                 
	         },
	         
	         stringLength:function(validitem  ) {/* 长度提示 */
	        	 
	        	 var message; 
	        	 
	        	 if(validitem.min ==validitem.max){
	        		 message=this.form_element.text +'长度必须为'+validitem.max;
	        	 }else{
	        		 message=this.form_element.text +'长度必须在'+validitem.min+'到'+validitem.max+'之间';
	        	 }
	        	 var validobj=  {/* 长度提示 */
	        			 /* 长度提示 */
	   		              min: validitem.min,
	   		              max: validitem.max,
	   		              message: message
	   		           
		           };
	        	 
	        	 return validobj;
	           },
	           
	           max:function(maxnum){
	        	   var message=this.form_element.text +'长度必须小于'+maxnum;
		        	 var validobj=  {/* 长度提示 */
		        			 /* 长度提示 */
		   		              max: maxnum,
		   		              message: message
		   		           
			         };
		        	 return validobj;
	           },
	           onlyEnglish:function(validitem){
	        	   var message=this.form_element.text +'仅允许录入非中文';
		        	 var validobj=  {
		   		              message: message
			         };
		        	 return validobj;
	           },
	           onlyAZ:function(validitem){
	        	   var message=this.form_element.text +'仅允许录入拼音或英文';
		        	 var validobj=  {
		   		              message: message
			         };
		        	 return validobj;
	           },
	           dateAfterNow:function(validitem){
	        	   var message=this.form_element.text +'必须大于今天';
		        	 var validobj=  {
		   		              message: message
			         };
		        	 return validobj;
	           }
		 }
};


if(vueoOption){
	jQuery.extend(tempvueoOption ,vueoOption);
}
var vueoOption =tempvueoOption;

try {
	if(options){
		jQuery.extend(vueoOption, options);
	}
} catch (e) {
}

try {
	if(afterInitTab){
		jQuery.extend(vueoOption.afterInitTab, afterInitTab);
	}
} catch (e) {
}

try {
	if(afterVueSelect){
		jQuery.extend(vueoOption.afterVueSelect, afterVueSelect);
	}
} catch (e) {
}

try {
	if(vueMethods){
		jQuery.extend(vueoOption.vueMethods, vueMethods);
	}
} catch (e) {
}

try {
	if(computeds){
		jQuery.extend(vueoOption.vuecomputeds, computeds);
	}
} catch (e) {
}

try {
	if(initFormdata){
		jQuery.extend(vueoOption.initformdata, initFormdata);
	}
} catch (e) {
}

try {
	if(bootstrap_valid){
		jQuery.extend(vueoOption.bootstrap_valid, bootstrap_valid);
	}
} catch (e) {
}
try {
	if(beforesubmitvueform){
		jQuery.extend(vueoOption.beforesubmitvueform, beforesubmitvueform);
	}
} catch (e) {
}

try {
	if(aftersubmitvueform){
		jQuery.extend(vueoOption.aftersubmitvueform, aftersubmitvueform);
	}
} catch (e) {
}
try {
	if(afterloadNewElements){
		jQuery.extend(vueoOption.afterloadNewElements, afterloadNewElements);
	}
} catch (e) {
}
try {
	if(vuecomputeds){
		jQuery.extend(vueoOption.vuecomputeds, vuecomputeds);
	}
} catch (e) {
}






//Vue.component("formgroup-common-list", {
//	template : '#formgroup-common-list',
//	//numbnf循环次数，group 组名，
//	props : {form_elements:{}
//	,group:{}
//	,form_element:{}
//	,formdata:{}
//	,numbnf:{default:''}
//	,relatedata:{}
//	,namepref:{default:''}
//	,title:{}
//	,subsids:{default:''}
//	,showSubmitButton:{default:false}
//	,groupsize:{default:2}//页面显示几列
//}
//,beforeCreate : function(){
//	
////	console.log('beforeCreate  start formgroup-common-list');
//}
//,computed:{
//	
//	
//}
//,mounted : function (){
//	
//	try {
//		//vue 渲染完成后调用的页面初始化方法
////		console.log('computed  start formgroup-common-list' + this.numbnf);
//	} catch (e) {
//
//	}
//}
//,methods:{ 
//	addEleToFormData :function (groupid,index) {
//		addEmptyEleToFormData(this.formdata,groupid,index);
//	}
//	,
//	addObjToFormData :function (formdata , groupid) {
//		this.$set(formdata,groupid,{});
//	}
//}
//,beforeUpdate : function() {
//	try {
//		//vue 渲染完成后调用的页面初始化方法
//		console.log('beforeupdated  start formgroup-common-list' + this.numbnf);
//	} catch (e) {
//
//	}
//
//},create : function() {
//	try {
//		//vue 渲染完成后调用的页面初始化方法
//		console.log('beforeupdated  start formgroup-common-list' + this.numbnf);
//	} catch (e) {
//
//	}
//
//},updated : function() {
//	
//	this.$nextTick(function () {
//		try {
//			var form =$(this.$el).parentsUntil("form").parent("form");
//			if(form.data("bootstrapValidator")){
//				if(form.data("bootstrapValidator_hasvalid")){
//					 form.data("bootstrapValidator").validate();
//				}
//			}
//		} catch (e) {
//			console.log(e);
//		}
//		
//		
//	});
//}
//})
/**
 *  
 * 通用 表格  
 */
/*Vue.component("common-table-vue", {
	template : '#common-table-vue',
	//numbnf循环次数，group 组名，
	props : {form_elements:{},group:{},form_element:{},formdata:{}
	,rowno:{default:1}
	,relatedata:{}
	,title:{}
	,fixtitle:{}
	,namepref:{default:''}
	,subsids:{default:''}
	,showSubmitButton:{default:false}
	,groupsize:{default:2}//页面显示几列
}
})*/
/***
 * 通用 表格 TD
 */
Vue.component("common-table-vue", {
	template : '#common-table-vue',
	//numbnf循环次数，group 组名，
	props : {form_elements:{},group:{},form_element:{},formdata:{}
	,rowno:{default:1}
	,relatedata:{}
	,title:{}
	,fixtitle:{}
	,namepref:{default:''}
	,subsids:{default:''}
	,showSubmitButton:{default:false}
	,groupsize:{default:2}//页面显示几列
}
,beforeCreate : function(){
	
//	console.log('beforeCreate  start formgroup-common-list');
}
,computed:{
	
	
}
,mounted : function (){
	
	try {
		//vue 渲染完成后调用的页面初始化方法
//		console.log('computed  start formgroup-common-list' + this.numbnf);
	} catch (e) {

	}
}
,methods:{
	getShowElement :function (form_elements,groupsize,subsids) {
		var showAry = new Array();
		var groupAry = new Array();
		var lastshowflag = false;
		if( form_elements  instanceof Array){
			for ( var index in form_elements) {
				var notexist =false;
				for ( var y in subsids) {
					
					if(subsids[y]==form_elements[index].subsid){
						notexist=notexist||true;
					}
					
				}
				if(!notexist&&subsids.length>0){
					continue;
				}
				
				if(groupAry.length==groupsize){
					showAry.push(groupAry);
					groupAry= new Array();
				}
				
				
				if(form_elements[index].elementstatus=='01'){
					groupAry.push(form_elements[index]);
				}else{
				}
			}
			
			if(groupAry.length!=0){
				showAry.push(groupAry);
			}
		}
		
		return showAry;
	}
	,
	getHiddenElement :function (form_elements,groupsize ,subsids) {
		var hideAry = new Array();
		var groupAry = new Array();
		var lastshowflag = false;
		if(form_elements  instanceof Array){
			for ( var index in form_elements) {
				
				var notexist =false;
				for ( var y in subsids) {
					
					if(subsids[y]==form_elements[index].subsid){
						notexist=notexist||true;
					}
					
				}
				if(!notexist&&subsids.length>0){
					continue;
				}
				
				if(groupAry.length==groupsize){
					hideAry.push(groupAry);
					groupAry= new Array();
				}
				
				if(form_elements[index].elementstatus!='01'){
					groupAry.push(form_elements[index]);
				}else{
				}
			}
			
			if(groupAry.length!=0){
				hideAry.push(groupAry);
			}
		}
		
		return hideAry;
	}
	,
	addEleToFormData :function (groupid,index) {
		addEmptyEleToFormData(this.formdata,groupid,index);
	}
	,
	addObjToFormData :function (formdata , groupid) {
		this.$set(formdata,groupid,{});
	}
 
}
,beforeUpdate : function() {
	try {
		//vue 渲染完成后调用的页面初始化方法
//		console.log('beforeupdated  start formgroup-common-list' + this.numbnf);
	} catch (e) {

	}

},create : function() {
	try {
		//vue 渲染完成后调用的页面初始化方法
//		console.log('beforeupdated  start formgroup-common-list' + this.numbnf);
	} catch (e) {

	}

},updated : function() {
	
	this.$nextTick(function () {
		
		try {
			var form =$(this.$el).parentsUntil("form").parent("form");
			if(form.data("bootstrapValidator")){
				if(form.data("bootstrapValidator_hasvalid")){
					 form.data("bootstrapValidator").validate();
				}
			}
		} catch (e) {
			console.log(e);
		}
		
//		if(this.formdata["temp_update_count"]){
//			
//			this.$set(this.formdata,"temp_update_count",this.formdata["temp_update_count"]++);
//			 	
//		}else{
//			this.$set(this.formdata,"temp_update_count",1);
//			
//		}
		
	});
	
},
computed: {
	
	
}
})
/**
 * 通用 双列表单  模板 
 */
Vue.component("formgroup-common-list", {
	template : '#formgroup-common-list',
	//numbnf循环次数，group 组名，
	props : {form_elements:{},group:{},form_element:{},formdata:{}
	,numbnf:{default:''}
	,elementindex:{default:undefined}
	,relatedata:{}
	,title:{}
	,showopfield:{default:false}
	,fixtitle:{}
	,isdisabled:{default:false}
	,namepref:{default:''}
	,textsuffix:{default:''}
	,subsids:{default:''}
	,ignoregroupid:{default:false}
	,showSubmitButton:{default:false}
	,groupsize:{default:2}//页面显示几列
}
,beforeCreate : function(){
	
//	console.log('beforeCreate  start formgroup-common-list');
}
,computed:{
	
},
data:function(){
	return{
//		hidelist:[],
//		showlist:[],
		triggerupdate:1,
		flag:false,
		isRouterAlive: true
	}
}
,mounted : function (){
	
	try {
		//vue 渲染完成后调用的页面初始化方法
		console.log('mounted  start formgroup-common-list' + this.title);
	} catch (e) {

	}
}
,methods:{
	addToTitle:function(){
		var title="";
		if(this.title){
			title =this.title+(this.numbnf==''?'':(this.numbnf+1));
		}
		if(this.fixtitle){
			title =this.fixtitle;
		}
		if(!this.form_elements){
			return false;
		}
		
		if(this.form_elements.length>0){
			
			
			if(!this.$root.formdata['title'][title]){
				this.$root.$set(this.$root.formdata['title'],title,"title_"+title);
			}
			return true;
		}else{
			
//			if(this.$root.formdata['title'][title]){
//				this.$root.$set(this.$root.formdata['title'],title,"");
//			}
//			
//			return false;
		}

	},
	UpdateFlag:function(){
		if(this.flag){
			this.flag=false
		}else{
			this.flag=true
		}
	},
	
	getShowElement :function (form_elements,groupsize,subsids) {
		
		var showAry = new Array();
		var groupAry = new Array();
		var lastshowflag = false;
		if( form_elements  instanceof Array){	
			if(form_elements.length>0&&form_elements[0]!=undefined){
				console.info( " getShowElement groupsize:" +groupsize 
						+" subsids :" + subsids +" form_elements[0]："+form_elements[0].id );
			}
			
			for ( var index in form_elements) {
				
				if(!form_elements[index]){
					continue;
				}
				
				var notexist =false;
				for ( var y in subsids) {
					
					if(subsids[y]==form_elements[index].subsid){
						notexist=notexist||true;
					}
					
				}
				if(!notexist&&subsids.length>0){
					continue;
				}
				
				if(groupAry.length==groupsize){
					showAry.push(groupAry);
					groupAry= new Array();
				}
				
				
				if(form_elements[index].elementstatus=='01'||form_elements[index].elementstatus=='11'){
					groupAry.push(form_elements[index]);
				}else{
				}
			}
			
			if(groupAry.length!=0){
				showAry.push(groupAry);
			}
//			this.showlist=showAry;
		}
		return showAry;
	}
	,
	//form-group-list
	getHiddenElement :function (form_elements,groupsize ,subsids) {
		var hideAry = new Array();
		var groupAry = new Array();
		var lastshowflag = false;
		if(form_elements  instanceof Array){
			for ( var index in form_elements) {
				if(!form_elements[index]){
					continue;
				}
				
				var notexist =false;
				for ( var y in subsids) {
					
					if(subsids[y]==form_elements[index].subsid){
						notexist=notexist||true;
					}
					
				}
				if(!notexist&&subsids.length>0){
					continue;
				}
				
				if(groupAry.length==groupsize){
					hideAry.push(groupAry);
					groupAry= new Array();
				}
				//11 表示有值就隐藏
				if(form_elements[index].elementstatus!='01'&&form_elements[index].elementstatus!='11'){
					groupAry.push(form_elements[index]);
				}else{
				}
			}
			
			if(groupAry.length!=0){
				hideAry.push(groupAry);
			}
//			this.hidelist=hideAry;
		}
		return hideAry;
	}
	,
	addEleToFormData :function (groupid,index) {
		addEmptyEleToFormData(this.formdata,groupid,index);
	},
	checkFormElements :function ( ) {
		
		if(this.form_elements==undefined){
			this.form_elements=[];
		}
	}
	,
	addObjToFormData :function (formdata , groupid) {
		this.$set(formdata,groupid,{});
	},
	reload :function (){
	     this.isRouterAlive = false
	     this.$nextTick(function(){(this.isRouterAlive = true)} )
	} 
	
}
,beforeUpdate : function() {
	try {
		
			
			console.log('******* beforeUpdate formgroup-common-list vue  ******');
		 
		//vue 渲染完成后调用的页面初始化方法
//		console.log('beforeupdated  start formgroup-common-list' + this.numbnf);
	} catch (e) {

	}

},create : function() {
	try {
		//vue 渲染完成后调用的页面初始化方法
//		console.log('beforeupdated  start formgroup-common-list' + this.numbnf);
	} catch (e) {

	}

},updated : function() {
	console.log("group-list updated");
	this.$nextTick(function () {
		
		try {
			var form =$(this.$el).parentsUntil("form").parent("form");
			if(form.data("bootstrapValidator")){
				if(form.data("bootstrapValidator_hasvalid")){
					 form.data("bootstrapValidator").validate();
				}
			}
		} catch (e) {
			console.log(e);
		}
		
//		if(this.formdata["temp_update_count"]){
//			
//			this.$set(this.formdata,"temp_update_count",this.formdata["temp_update_count"]++);
//			
//		}else{
//			this.$set(this.formdata,"temp_update_count",1);
//			
//		}
		
	});
	
}
})

function formelementUpdateOrMounted(){

	console.log("formelement updated "+ this.form_element.name +" sid: "+ this.form_element.sid);
	
//	try {
//		layer.close(lay_check);
//		lay_check=layer.load(0, {time: 20*1000
//			,shade:0.3,
//			content:'<div>正在渲染页面</div>'
//			});
//	} catch (e) {
//	// TODO: handle exception
//	}
	var eleName = this.namepref +this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
	this.$nextTick(function () {
		try {
			
			if(this.form_element.elementstatus=="02"){
				return ;
			}
			if (this.form_element.elementstatus == "01"||this.form_element.elementstatus == "11") {

				var comboboxflag = false;
				eleName = this.namepref + this.form_element.groupid + '' + this.elementindex + '.' + this.form_element.name;

				update_element[eleName] = "";
				checkClose = true;

				//			console.log(  'update start form-element combobox:  ' + eleName 
				//					+" comboboxoption: " +this.form_element.checkboxoption
				//					+" count: " +this.form_element[eleName+"_mountedFlag_sys"]);
				var obj = $(this.$el).find("[name='" + eleName + "']");
				/**
				 * form_element 更新后 更新DOM
				 * 加载组件combobox
				 */
				if (this.form_element.type == 'combobox') {

					var checkboxoption = this.form_element.checkboxoption;
					if (checkboxoption) {
						var index = checkboxoption.indexOf("commonCombobox_");



						try {
							if (commonCombobox_option[checkboxoption] || $.parseJSON(checkboxoption)) {

							} else {
								console.log("  error   *****  字段类型错误 没有找到对应  Combobox 配置请检查  ID：" + this.form_element.id)
							}
						} catch (e) {
							console.log("  error   *****  字段类型错误 没有找到对应  Combobox 配置请检查  ID：" + this.form_element.id);
						}

						if (index >= 0) {
							obj.combobox(commonCombobox_option[checkboxoption]);
						} else {
							obj.combobox($.parseJSON(checkboxoption));
						}
					//					obj.combobox("setValue",obj.val());
					}
				}

				/**
				 * form_element 更新后 更新DOM
				 * 加载组件databox
				 */
				if (this.form_element.type == 'databox' || this.form_element.type == 'datebox') {
					var obj = null;
					try {
						obj = $("#" + this.form_element.id + this.elementindex.replace("[", "\\[").replace("]", "\\]"));

					} catch (e) {
						// TODO: handle exception
						obj = $(this.$el).find("input");
					}
					
					var databox_option = undefined ;
					
					
					var datebox_de={
							minView : "month", //选择日期后，不会再跳转去选择时分秒 
							forceParse : true,
							language : 'zh-CN',
							format : 'yyyy-mm-dd',
							todayBtn : true,
							autoclose : true
						};
					try {
						databox_option = $.parseJSON(this.form_element.checkboxoption);
						jQuery.extend(datebox_de, databox_option);
					} catch (e) {
					}
					try{
						if(H5flag){
							obj.attr("readonly","readonly");
//							clearBtn: true,
							datebox_de["clearBtn"]=true;
						}
					}catch(e){
						
					}
					
					
					obj.datetimepicker(datebox_de);
					
					//				obj.attr("readonly","readonly");
					obj.bind("change", function(event) {
						obj.trigger("input").trigger("click");
					});

				}



				/**
				 * form_element 更新后 更新DOM
				 * 加载组件bootstrap - valid
				 * 
				 */
				var form = $(this.$el)
				.parentsUntil("form").parent("form");
				
				if (this.form_element.validitem
						&&form.length>0) {
					
					var validinitflag = true;
					var comboboxobj = $(this.$el).find("[name='" + eleName + "_combobox']");

					if (form.data('bootstrapValidator')) {
						if (this.form_element.type == 'combobox') {

							if (form.data('bootstrapValidator').options.fields[eleName + "_combobox"]
								&& $("[name='" + eleName + "']").parent().find("i.form-control-feedback").length > 0) {
								validinitflag = false;
							}
						} else {
							if (form.data('bootstrapValidator').options.fields[eleName]
								&& $("[name='" + eleName + "']").parent().find("i.form-control-feedback").length > 0) {
								validinitflag = false;
							}
						}

					} else {

						form.bootstrapValidator({
							message : '验证未通过',
							feedbackIcons : { /* 输入框不同状态，显示图片的样式 */
								valid : 'glyphicon glyphicon-ok',
								invalid : 'glyphicon glyphicon-remove',
								validating : 'glyphicon glyphicon-refresh'
							}
						});
					}

					if (validinitflag) {
						var valids;
						try {
							valids = JSON.parse(this.form_element.validitem);
						} catch (e) {
							console.log("校验配置出错 , 请检查:" + this.form_element.validitem);
						}

						var validitem = {
							validators : {}
						};
						for (var key in valids) {


							if (valids[key]) {
								valids[key].vueobj = getTopvueObj(this);
							}

							if (vueoOption.bootstrap_valid[key]) {
								validitem.validators[key] = vueoOption.bootstrap_valid[key].call(this, valids[key]);
							} else {
								validitem.validators[key] = valids[key];
							}
						}

						//					if(eleName.indexOf("mobile")>=0){
						//						alert("11");
						//					}
						if (this.form_element.type == 'combobox') {
							form.data('bootstrapValidator').addField(comboboxobj, validitem);
						} else {
							if (this.form_element.type == 'text') {
								form.data('bootstrapValidator').addField(obj, validitem);
							} else {
								
								if (this.form_element.type == 'checkbox') {
									//for(var index_checkbox in obj){
										
									//	form.data('bootstrapValidator').addField($(obj[index_checkbox]), validitem);
									//}
									 
									form.data('bootstrapValidator').addField(eleName, validitem);
								} else {
									form.data('bootstrapValidator').addField(obj, validitem);
								}
								
							}

						}

					} else {
						if ($("input[name='" + eleName + "']").val() == "") {

							if (this.form_element.type == 'combobox') {

								form.data('bootstrapValidator').resetField(comboboxobj);
							} else {
								form.data('bootstrapValidator').resetField(obj);
							}
						}else{
							if (this.form_element.type == 'combobox') {

								// 值不为空 重新校验
								if(!form.data('bootstrapValidator').isValidField(comboboxobj)&&comboboxobj.val()!=""){
									form.data('bootstrapValidator').revalidateField(comboboxobj); 
								}
								
//								if(!form.data('bootstrapValidator').isValidField(comboboxobj)&&comboboxobj.val()==""){
//									form.data('bootstrapValidator').resetField(comboboxobj); 
//								}
							} else {
								if(!form.data('bootstrapValidator').isValidField(obj)){
									form.data('bootstrapValidator').revalidateField(obj); 
								}
							}
							
						}

					}
				}
				/**
				 * form_element 更新后 更新DOM
				 * 加载组件bootstrap - valid
				 * 结束
				 */

				if (!comboboxflag) {

					delete update_element[eleName];
				}

			}
			/**
			 * 数据跟新后的钩子函数
			 */
			try {
				if(vueoOption.afterVueSelect[this.form_element.id]){
					vueoOption.afterVueSelect[this.form_element.id].call(this ,this.form_element);
				}
				if(vueoOption.afterVueSelect[this.form_element.name+"_SYS_"]){
					
					for ( var funName in vueoOption.afterVueSelect[this.form_element.name+"_SYS_"]) {
						vueoOption.afterVueSelect[this.form_element.name+"_SYS_"][funName].call(this ,this.form_element);
					}
				}
				
			} catch (e) {
			}
		
			
		} catch (e) {
			if(!comboboxflag){
				
				delete update_element[eleName];
				
			}
			console.log(e);
		}
		
		
	});
	


	
}

Vue.component("form-element", {
	template : '#form-element',
	props : {  
				triggerupdate:{default:1},
				form_elements:{},
				index:{},
				isdisabled:{default:false},
				form_element:{},
				namepref:{default:''},
				formdata:{},
				elementindex:{default:''},
				relatedata:{},
				updateflag:{default:0},
			},
	
	updated : function() {
		
		formelementUpdateOrMounted.call(this);
	},beforeCreate : function() {
		
		
	},beforeUpdate : function() {
		
		console.log('******* beforeUpdate form-element vue  ******');
	 
	}
	,mounted : function() {
		if(this.formdata[this.form_element.name]==undefined){
			this.$set(this.formdata,this.form_element.name,null);
		}
		/**
		 * form_element 设置默认值
		 */
		if(this.formdata[this.form_element.name]){
			
		}else{
			if(this.form_element.defaultValue){
				this.$set(this.formdata,this.form_element.name,this.form_element.defaultValue);
			}
			
		}
		
//		this.$nextTick(function () { })
			
			/**
			 * 确保可以触发 form_element 的update
			 */
			
//			console.log('mounted start form-element:  ' +this.form_element.id );
			var eleName = this.namepref +this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
			var tempkey = eleName+"_mountedFlag_sys";
			if(this.form_element[tempkey]==undefined){
				
				this.$set(this.form_element,tempkey,0);
			}else{
				var index = this.form_element[tempkey]+1;
				this.$set(this.form_element,tempkey,index);
				
			}
			
			formelementUpdateOrMounted.call(this);
		
	
	},methods:{
		updateformdata :function ($event, formdata,form_element ) {
//			this.$set(formdata, form_element.name,$("#"+form_element.id).val());
			this.$set(formdata, form_element.name,$event.target.value);
			console.log("update:  " +$event);
		},
		setEmeptyAry :function ( obj,key ) {
//			this.$set(formdata, form_element.name,$("#"+form_element.id).val());
			this.$set(obj, key,[]);
			console.log("setEmeptyAry obj:"
					+ obj + " key:" +	key  
					+JSON.stringify(obj));
			
		},
		setEmeptyObj :function ( obj,key ) {
			
			
//			this.$set(formdata, form_element.name,$("#"+form_element.id).val());
			this.$set(obj, key,{});
//			console.log("setEmeptyAry obj:"
//					+ obj + " key:" +	key  
//					+JSON.stringify(obj));
			
		},
		afterClickCheckbox :function ($event, formdata,form_element ){
			
			try {
				afterClickCheckbox($event, form_element,formdatabind,this);
			} catch (e) {
			}
		},
		afterClickRadioBox :function ($event, formdata,form_element ){
			if(!$($event.target).is(':visible')){
				this.$set(formdata, form_element.name,"");
			}
			try {
				if(form_element.elementstatus!='01'){
					if($($event.target).is(":checked")){
						$($event.target).removeAttr("checked");
						this.$set(formdata, form_element.name,"");
					}
				}
//				afterClickRadioBox($event, form_element,formdatabind,this);
			} catch (e) {
			}
		},
		checkdisabled :function (){
		 
			if(this.form_element.cssClass){
				if(this.form_element.cssClass.indexOf("disabled")>=0){
					return true;
				}
			}
			return false;
			 
		}
		,
		alertMsg :function (){
			
			console.info(JSON.stringify(this));
		},
		getUpdate_count :function(){
			
			var eleName = this.namepref +this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
			var tempkey = eleName+"_mountedFlag_sys";
			var index;
			if(this.form_element[tempkey]==undefined){
				
				this.$set(this.form_element,tempkey,0);
			}else{
				index = this.form_element[tempkey]+1;
				this.$set(this.form_element,tempkey,index);
				
			}
			return this.form_element[tempkey];
		},
		clearText : function ($event, formdata,form_element,name){
			this.$set(formdata,name,"");
		},
		
		opendate : function ($event,id){
			if(!$("#"+id).data('datetimepicker').isVisible){
				$("#"+id).datetimepicker('show');
				$("#"+id).data('datetimepicker').isVisible=true; 
			}else{
				$("#"+id).datetimepicker('hide');
				$("#"+id).data('datetimepicker').isVisible=false; 
			}
			
			
		},
		scrolltoend : function (){
			console.info( "2222222222222222222222222");
		},
		showclearText : function (formdata,form_element, name){
			
			try{
				if(!clearTextFlag){
					return false;
				}
				
				
				if(form_element&&form_element.cssClass.indexOf("clearText")>=0&&formdata[name]){
					return true;
				}
			}catch(e){
				return false;
			}
			
		},
		checkshow : function (){
			if(this.form_element.elementstatus=='11'){
				if(!this.formdata[this.form_element.name]){
					this.form_element.elementstatus='01';
					this.$emit('update:triggerupdate',this.triggerupdate+1);
				}
			}
			return true ;
		}

	}


})

/**
 * 受益人类型 组件
 */
Vue.component("bnf-type", {
	template : '#bnf-type',
	props : [ 'bnftype' ,'bnfgroup','formdata']

})
Vue.component("tab-control", {
	template : '#tab-control',
	props : {
			form_elements:{},
			formstatus:{},
			form_element:{},
			formdata:{},
			numbnf:{default:''},
			relatedata:{}
	},
	mounted : function() {
		console.log('******* mounted tab-control vue start ******');
	}
	,beforeUpdate : function() {
		
		console.log('******* beforeUpdate tab-control vue  ******');
//		try {
//			closeds1();
//			shows1();
//		} catch (e) {
//			// shows1();: handle exception
//		}
	},
	methods:{ 
		
		loadFormElement :function ($event , url ,form_element) {
			
				
				
			console.log('start tab-control loadFormElement SID: '  
					+ this.formdata.newContApply.currentSID  +"  loadflag:   "
					+ this.formdata.newContApply[this.formdata.newContApply.currentSID] + " click tab: "+$event);
			 try {
				 
				 	/**
					 * tab 控制
					 */
				 
				 try {
					 
					 var activeid =  $('#tab_'+form_element.id).parent().find("li.active").attr("id");
					 if(activeid==undefined){
						 activeid = this.formdata.newContApply.currentSID;
//						 $("#"+activeid).addClass("active");
					 }
					 
					 if(vueoOption.tab_toggle_before(activeid)){
						 var flag = true;
						 try {
 
							 var form =$("#"+activeid.replace("tab_","")+"form");;
						 
							 if(form.data("bootstrapValidator")){
								var isvalid = form.data("bootstrapValidator").validate();
								form.data("bootstrapValidator_hasvalid",true);
								flag =flag&& isvalid.isValid();
							 }
						 } catch (e) {
							 console.log(e);
						 }
					 
							
					 		if(activeid
					 				&&checkChange($("#"+activeid.replace('tab_','')) ,$("#"+form_element.id) )
					 				&&flag){
					 		}else{
					 			return ; 
					 		}
					 
					 }
				} catch (e) {
					console.log(e);
				}
				
					 
				 if(!$($event.target).parent().hasClass("disabled")){
					 
					 var thisSID =form_element.id.replace('_tabinfo','');
					 if(!this.formstatus[thisSID]){
						 loadNewElements(this, url,form_element);
						 this.$set(this.formstatus,thisSID,true);
					 }
					 
					 for ( var index in this.form_elements) {
						 if(form_element.id!=this.form_elements[index].id){
							 $('#tab_'+this.form_elements[index].id).removeClass("active") ;
							 $('#'+this.form_elements[index].id).removeClass("active") ;
						 }
					 }
					 $($event.target).parent().addClass("active");
					 $('#'+form_element.id).addClass("active");	
					 
				 }
				
			} catch (e) {
				console.log(e);
			}
			
			try {
				closeds1();
			} catch (e) {
			}
			
		}
	
	},updated : function() {
		
		
		/**
		 * tab 控制
		 */
		console.log("tab-control updated");
		  this.$nextTick(function () {
			  console.log('start tab-control updated SID: '  
						+ this.formdata.newContApply.currentSID  
						+"  loadflag:   "+ this.formdata.newContApply[this.formdata.newContApply.currentSID] );
			  
				try {
					closeds1();
				} catch (e) {
				}
			  
			    var showcurent=vueoOption.inittabIndex;//最少显示tab index
				var currentSIDFlag = false ; 
				var loadclickFlag=false;
				
//				var activeid =  $('#tab_'+form_element.id).parent().find("li.active").attr("id");
//				 if(activeid==undefined){
//					 
//				 }
				 var activeid = this.formdata.newContApply.currentSID;
				 
				 
				 
//				 $("#tab_"+activeid+"_tabinfo").addClass("active");
				 
				for ( var index in this.form_elements) {
					
					if((this.formdata.newContApply.currentSID+'_tabinfo')==this.form_elements[index].id){
						showcurent= index;
						currentSIDFlag= true;
						this.formdata.newContApply.currentSIDIndex= index;
						
						if(!this.formstatus[this.formdata.newContApply.currentSID]){
							$('#tab_'+this.form_elements[index].id).trigger("click");
							loadclickFlag=true;
							$('#tab_'+this.form_elements[index].id).removeClass("disabled") ;
						}
//						 initData($("#"+this.form_elements[index].id));
					}else{
						//$('#'+this.form_elements[index].id).removeClass("active") 
					}
					if(index>vueoOption.inittabIndex){
						if(showcurent<index){
							$('#tab_'+this.form_elements[index].id).addClass("disabled");
						}
					}
					if(this.formdata.newContApply.currentSIDIndex >=index){
						
						$('#tab_'+this.form_elements[index].id).removeClass("disabled") ;
					}
					
					/**
					 * 判断是否初始化页面数据 用于 修改后未保存校验
					 * 
					 *  
					 */

					//判断当前SID是否被加载过  0 未加载 1 需要 强行和合并  2 不init
					if(this.formstatus[this.form_elements[index].id+"_init"]==undefined){
						
						this.$set(this.formstatus,this.form_elements[index].id+"_init",0);
					}
					if($('#tab_'+this.form_elements[index].id).hasClass("active")
							&&(this.formstatus[this.form_elements[index].id+"_init"]==0
							||this.formstatus[this.form_elements[index].id+"_init"]==1)){
						//元素为加载则不进行init
						if(getTopvueObj(this).formstatus[this.form_elements[index].id+"_load"]){
							
							console.log("initData formelement id :" +this.form_elements[index].id )
							initData($("#"+this.form_elements[index].id),this.formstatus[this.form_elements[index].id+"_init"]);
							this.$set(this.formstatus,this.form_elements[index].id+"_init",2);
							
							
							 
						}
						
					}
					
					if( vueoOption.afterInitTab[this.form_elements[index].id]){
						var vueobj = getTopvueObj(this);
						  vueoOption.afterInitTab[this.form_elements[index].id].call(vueobj);
					}
				}
				
//				afterInitForm
				
				console.log('end tab-control updated SID: '  + this.formdata.newContApply.currentSID  +"  loadflag:   "+ this.formdata.newContApply[this.formdata.newContApply.currentSID]);
				
		  });

		
	}
})
Vue.component("tab-pane", {
	template : '#tab-pane',
	props : {formstatus:{},tabid:{}}
,beforeUpdate : function() {
	
	console.log('******* beforeUpdate tab-pane vue  ******');
 
}
,mounted : function() {
	
	
	
	
	
},updated : function() { 
	try{
		if(H5flag){
			 this.$nextTick(
					 
					 function () {
						 var topvue =getTopvueObj(this);
						 var elements =topvue.form_elements[ topvue.formdata.newContApply.insurancecom+'H5insuranceContInput'];
						 var index =Number(topvue.formdata.newContApply.currentSIDIndex);
						 console.log('******* updated tab-pane vue  ******' +index );
						 if(!index){
							 index =0;
						 }
						 if(elements&&elements[index]&&elements[index].loadflag&&!elements[index].initflag){
							 initData($("#"+elements[index].id+"form"),false);
							 elements[index].initflag=true;
							 
						 }
						 
						
					 });
		}
	}catch(e){
		
	}
	
}
})
Vue.component("button-common", {
	template : '#button-common'

})

Vue.component("bnf-type-choice", {
	template : '#bnf-type-choice',
	/**
	 * bnftype 受益人类型
	 * bnfgroupthis 当前受益人所属组 是第一被保人受益人还是第二等等
	 * bnfgroups
	 */
	props : [ 'bnftype' ,'bnfgroupthis','formdata',"bnfcount","numbnf"]
})
/**
 * 受益人相同类型选择
 *//*
Vue.component("bnf-same-choice", {
	template : '#bnf-same-choice',
	*//**
	 * bnftype 受益人类型
	 * bnfgroupthis 当前受益人所属组 是第一被保人受益人还是第二等等
	 * bnfgroups
	 *//*
	props : [ 'bnftype' ,'bnfgroupthis','formdata',"bnfcount","numbnf"]
,methods:{
	
	samebnfchoice :function ($event,bnfdata,bnfgroup,bnfgroupthis,numbnf) {

		console.log("bnfgroupthis:"+ bnfgroupthis+ "  bnfgroup:"+bnfgroup + " bnfdata:"+bnfdata  +" 第几个受益人:"+numbnf );
		
		if($($event.target).is(':checked')){
			
			var existBnfFlag= false; 
			for ( var index in this.formdata[bnfgroupthis]) {
				if(this.formdata[bnfgroupthis][index].bnfname==bnfdata.bnfname){
					
					existBnfFlag= true;
					
				}
			}
			
			if(existBnfFlag){
				
				$('#myModal').find('.modal-body').text("该受益人已经被选取");
				$('#myModal').modal('show');

			}else{
				this.formdata[bnfgroupthis].splice(numbnf,1,bnfdata);
				
			}
		}else{
			this.formdata[bnfgroupthis].splice(numbnf,1,{});
		}
		
	
	}
	
}


})*/

/**
 *
Vue.component("formgroup-common-list-singlerow", {
	template : '#formgroup-common-list-singlerow',
	//numbnf循环次数，group 组名，
	props : {form_elements:{},group:{},form_element:{},formdata:{}
	,numbnf:{default:''}
	,relatedata:{}
	,title:{}
}
,methods:{
	
	addEleToFormData :function (groupid,index) {

		addEmptyEleToFormData(this,groupid,index);
	
	}
	
}
,beforeUpdate : function() {

},updated : function() {

}
})
 通用 单列表单 模板
 */
Vue.component("formgroup-common", {
	template : '#formgroup',
	props 	 : [ 'id', 'index' ,'commonFormElements',"formdata" ]
})
/**
 * 简单常用 表单 元素 组件
 */


/**
 * 简单常用 表单 元素title 组件
 */
Vue.component("label-element", {
	template : '#label-element',
	props : { 'form_elements':{}, 'index':{} ,'form_element':{} ,formdata:{}
		,elementindex:{default: ''}
		,textsuffix:{default: ''}}
})

Vue.component("text-element-english", {
	template : '#text-element-english',
	props : [ 'form_elements', 'index','form_element'  ,"formdata" ]
})

/**
 * 通用告知组件
 */
/*Vue.component("notice-group-list", {
	template : '#notice-group-list',
	props : [ 'form_elements', 'index',"formdata"  ]
	,methods:{}
})*/

/*Vue.component("formgroup-list-singlerow", {
	template : '#formgroup-list-singlerow',
	props : [ 'form_elements', 'index',"formdata"  ]

	
})*/

Vue.component("formgroup-list-bnf", {
	template : '#formgroup-list-bnf',
	props : [ 'form_elements',"formdata","form_elements_tbody" ,"totoalbnfindex","table_title"]
	,methods:{

		addEleToFormData :function (groupid,index) {

			addEmptyEleToFormData(this.formdata,groupid,index);
		}
	}
})

/**
 * 表格编辑维护
 */
Vue.component("formgroup-list-edit", {
	template : '#formgroup-list-edit',
	props : ['form_elements',"formdata","form_elements_tbody" ]
,
updated : function() {
	
	console.log('update formgroup-list-edit');
	
//	try {
//		
//		//vue 渲染完成后调用的页面初始化方法
//		vue_config[vue_config.length-1].initFunction.call(this,vue_config[vue_config.length-1].id);
//		
//	} catch (e) {
//
//	}

	}
	,methods:{
		getFormElementElementstatus :function (form_element) {
			var element ={};
		
		/*
		 * <input v-model="form_element.elementstatus"
		 * v-bind:id="'elementstatus'+form_element.id" class="form-control
		 * input-sm " @click="updateElementstatus($event,form_element)"
		 * checkboxoption="commonCombobox_elementstatus" />
		 */
			this.$set(this.form_elements_tbody[index],"tempelement",element);
			if(form_element){
				element["id"]="elementstatus" +form_element.id;
				element.groupid ="elementstatus"
				element.checkboxoption="commonCombobox_elementstatus";
				element.name="elementstatus";
				element.elementindex=form_element.id;
				element.type='combobox';
			}
			return element ;
		}
		,
		updateElementstatus :function (event, form_element) {
			
			this.$set(form_element, "elementstatus",$("#elementstatus"+form_element.id).val());
			
			
	    },
	    updatedefaultValue :function (event,form_element) {
			
			this.$set(form_element, "defaultValue",$("#"+form_element.id).val());
			
	    },
	    
	    /**
	     * 上移 元素
	     */
	    upElement :function (tbody   ,index ,form_element) {
			if(index == 0){
				alert("已经是第一个元素了");
			}else{
				var obj = tbody[index-1];
				this.$set(form_element, "order",index-1);
				this.$set(tbody, index-1,form_element);
				
				this.$set(tbody, index  ,obj);
				this.$set(tbody[index], "order",index);
			}
			
			
	    },
	    /**
	     * 下移 元素 
	     */
	    downElement :function (tbody   ,index ,form_element) {
			
	    	if(index == tbody.length-1){
				alert("已经是最后一个元素了");
			}else{
				
				var obj = tbody[index+1];
				this.$set(form_element, "order",index+1);
				this.$set(tbody, index+1,form_element);
				
				this.$set(tbody, index  ,obj);
				this.$set(tbody[index], "order",index);
			}
//	    	$("#"+form_element.id).trigger("change").trigger("click");
	    },
	    /**
	     * 下移 元素 
	     */
	    showChildElement :function (form_element) {
	    	
	    	if(form_element.childshowlfag){
	    		this.$set(form_element, "childshowlfag",false);
	    	}else{
	    		this.$set(form_element, "childshowlfag",true);
	    	}
			
	    }
	}
})

Vue.component("form-modal-simple", {
	template : '#form-modal-simple',
	props : {
		formdata:{},
		formstatus:{},
		relatedata:{}
	}
})

/**
Vue.component("thead-list", {
	template : '#thead-list',
	props : [ 'form_elements', 'index','form_element' ,"formdata"  ]
})

Vue.component("tbody-list", {
	template : '#tbody-list',
	props : [ 'form_elements', 'index','form_element' ,"formdata"  ]
})
**/
/**
 * combobox配置
 */



var mountedFlag = false;
/**
 * vue_config是VUE所有的 配置集合
 * vueobj 是以 vue_config配置的ID为KEY,value 为VUE对象的 集合
 */
$(function(){});


vue_config[vue_config.length-1].vueobj= new Vue({
	el : '#' + vue_config[vue_config.length-1].id,
	data : {
		
		showopfield:false,//是否显示可选项
		formdata : vueoOption.initformdata,//表单数据
		vueobjid :vue_config[vue_config.length-1].id,//vue id
		form_elements : {},//页面元素
		relatedata:{},//相关数据
		form_elementsBYID:{},//为每一个元素  设置ID 索引 ，
		//ex: form_elementsBYID.lcappnt.idno 获得对应的element 对象 其中的lcappnt 是elements的索引 推荐使用SID 作为key
		formstatus:{
			showmenu:false,//h5菜单显示
			desc:vueoOption.defaultWaitMessage,
			submitFlag:false
		}//页面中间变量，状态
	},
	beforeCreate : function() {
		
		console.info("beforeCreate top vue ");
		//额外的 自定义方法加载
		jQuery.extend(this.methods, vueoOption.vueMethods);
		//额外的 自定义方法加载
		jQuery.extend(this.computed, vueoOption.vuecomputeds);
		//初始化
		var topvue = this ; 
		var url = vue_config[vue_config.length-1].url;
		
		
		sinoAjax(
				getRealURL(url,vueoOption.initformdata,topvue), 
				{"formdata": JSON.stringify(vueoOption.initformdata) }, 
				function (data){
					
					fillAllvueFormElements(topvue,data);
					vueobj[topvue.vueobjid]=topvue;
					try {
						afterVueInitDataLoad.call(topvue);
					} catch (e) {
						// TODO: handle exception
					}
					
					try{
						if(H5flag){
							topvue.handleScroll();
						}
					}catch(e){
						
					}
				}, "POST",this);
		
 
	},
	mounted : function() {
		console.log('mounted top vue start' +this.vueobjid);
		
		document.addEventListener('scroll', this.handleScroll);

	},
	updated : function() {

	},methods:vueoOption.vueMethods,
	computed: vueoOption.vuecomputeds
});

vueobj[vue_config[vue_config.length-1].id]=vue_config[vue_config.length-1].vueobj;




/***
 * 获取顶级VUE OBJ
 */
function getTopvueObj(vueobj){
	
	if(vueobj.$parent==undefined){
		return vueobj;
	}else{
		vueobj = vueobj.$parent;
		return getTopvueObj(vueobj);
		
	}
}

/**
 * 为formdata 增加空对象以免报错
 * @param vueobj
 * @param groupid
 * @param index
 * @returns
 */
function addEmptyEleToFormData(formdata,groupid,index){
 
	for (var i =  formdata[groupid].length; i <= index; i++) {
		 formdata[groupid].push({});
	}
	
	console.log("add empty element to formdata index:"
			+ index + " groupid:" +	groupid  
			+ " formdata.length:" +	formdata[groupid].length  );
}


 /**
  * URL 规则匹配正则表达
  */



/***
 * 获取真正的URL
 * @param url 定义的URL
 * @param formdata vue 表单数据 对象
 * @returns
 */
function getRealURL(url ,formdata,vueobj) {
    var newurl ;

        newurl = url.replace(reg_vueform_url, function() {
            var args = arguments;
            var value = formdata;
            var exp = args[0].replace("/","").replace("\\","");
            var expAry= exp.split(".");
            for ( var index in expAry) {
            	value =  value [expAry[index].replace("#","")];
			}
            return 	args[0].replace(exp,value);
        });
 
    
    if(newurl){
    	
    	newurl  =path +newurl +vueoOption.url_suffix;
    }
    return newurl;

}

function getFormdataValue(formdata,key){
	
	
}

/**
 * 提交vue form 表单
 * @param vueobj
 * @param url
 * @returns
 */
function submitvueformH5($form ,url){
	
	var topvue =  getTopvueObj(this)
	var formdata = topvue.formdata;
	var vueobj =this;
	
	

//获取next current id 
	
	var currentSIDIndex = Number(topvue.formdata.newContApply.currentSIDIndex);
	//判断是不是后的一个SID更新
	
	
		try {
			topvue.$set(topvue.formdata.newContApply,"lastcurrentSIDIndex",currentSIDIndex);
			topvue.$set(topvue.formdata.newContApply,"currentSID", 
					$form.attr("id").replace("_tabinfoform",""));
		} catch (e) {
			// TODO: handle exception
		}

	topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",currentSIDIndex);
	/**
	 * 设置遮罩层显示
	 */
	 lay_check=layer.load(0, {time: 10*1000
		,shade:0.3,
		content:'<div>校验数据并提交中，请稍等</div>'
		});   
		  
	try {
		
		if(!beforesubmitvueformsys($form , topvue)){
			layer.close(lay_check);
			validAndSaveflag=false;
			return ;
		}
		layer.close(lay_check);
	} catch (e) {
		validAndSaveflag=false;
		layer.close(lay_check);
		return ;
	}
	
	
	/**
	 * 设置遮罩层显示
	 */
	topvue.$set(topvue.formstatus,"submitFlag",false);
	topvue.$set(topvue.formstatus,"desc",vueoOption.defaultWaitMessage);
	topvue.$set(topvue.formdata.newContApply,"nextSID",
			//初始化ID 之前的保存 自动到初始化后第一个SID
			null);
	topvue.$set(topvue.formdata.newContApply,"nextcurrentSIDindex",
			//初始化ID 之前的保存 自动到初始化后第一个SID
			0);
//	$('#contModal').modal('show');
	$('#contModal').find(".modal-body").text(vueoOption.defaultWaitMessage);
	
//	$('#contModal').find(".modal-body").text("数据处理中，请稍后");
	sinoAjax(
			getRealURL(url,formdata,topvue), 
			{"formdata": JSON.stringify(formdata) }, 
			function (data){
				
				try {
					layer.close(lay_check);
				} catch (e) {
					layer.close(lay_check);
					return ;
				}
				
				topvue.$set(topvue.formstatus,"submitFlag",true);
				topvue.$set(topvue.formstatus,"desc",data.formstatus.desc);
//				$('#contModal').modal('hide');
					
					if(data.formstatus.flag){
						
						fillAllvueFormElements(topvue,data);
						initData(getActivePanelDIV(topvue),true);
						if(!aftersubmitvueform_sys($form ,topvue,data)){
							validAndSaveflag=false;
							return ;
						}
						
						aftersubmitvueformSuccessH5($form , topvue,data);
						
						if("notice" == $form.attr("id").replace("_tabinfoform","")){
							alert("录入已完成，请联系客户经理进行后续操作！")
							try{//关闭当前页面
								closeCurrentWebPage();
							}catch(e){
								closeCurrentWebPage2();
							}
						}
						
						
					}else{
						validAndSaveflag=false;
					}
					
					
				
				
			}, "POST",topvue);
}
function closeCurrentWebPage2(){
	 var userAgent = navigator.userAgent;
     if (userAgent.indexOf("Firefox") != -1 || userAgent.indexOf("Chrome") !=-1) {
        window.location.href="about:blank";
     }else if(userAgent.indexOf('Android') > -1 || userAgent.indexOf('Linux') > -1){
        window.opener=null;window.open('about:blank','_self','').close();
     }else {
        window.opener = null;
        window.open("about:blank", "_self");
        window.close();
        //针对苹果不能关闭当前页面
        setTimeout(function(){ 
            WeixinJSBridge.invoke("closeWindow", {}, function (e) {})
         },100)
     }
}

function closeCurrentWebPage(){
	var isLppzApp = false
    var ua = navigator.userAgent.toLowerCase()
    var uaApp = ua ? ua.match(/BeStore/i) : '' // match方法返回的是对象
    var uaAndroid = /android/i.test(ua) // test返回的是true/false
    var uaIos = /iphone|ipad|ipod/i.test(ua)
    if (String(uaApp) === 'bestore') { // 必须将match返回的对象转成字符串
        isLppzApp = true
    } else {
        isLppzApp = false
    }
    if (window.WeixinJSBridge) {
        window.WeixinJSBridge.call('closeWindow') // 微信
    } else if (window.AlipayJSBridge) {
        window.AlipayJSBridge.call('closeWebview') // 支付宝
    } else if (isLppzApp && uaAndroid) {
        window.obj.closePageLppzRequest('') // 安卓app
    } else if (isLppzApp && uaIos) {
        window.webkit.messageHandlers.closePageLppzRequest.postMessage('') //ios app
    } else {
        window.close();
    }
}

/**
 * 提交vue form 表单
 * @param vueobj
 * @param url
 * @returns
 */
function submitvueform($event ,url){
	
	var topvue =  getTopvueObj(this)
	var formdata = topvue.formdata;
	var vueobj =this;
	
	

//获取next current id 
	
	var submitDIV=getActivePanelDIV();
	var currentSIDIndex = Number(topvue.formdata.newContApply.currentSIDIndex);
	//判断是不是后的一个SID更新
	
	
	if(H5flag){
		try {
			topvue.$set(topvue.formdata.newContApply,"lastcurrentSIDIndex",currentSIDIndex);
			topvue.$set(topvue.formdata.newContApply,"currentSID", 
					$($event.target).parentsUntil("form").parent("form").attr("id").replace("_tabinfoform",""));
		} catch (e) {
			// TODO: handle exception
		}
	}else{
		try {
			topvue.$set(topvue.formdata.newContApply,"currentSID", submitDIV.attr("id"));
		} catch (e) {
			// TODO: handle exception
		}
	}

	topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",currentSIDIndex);
	/**
	 * 设置遮罩层显示
	 */
	 lay_check=layer.load(0, {time: 10*1000
		,shade:0.3,
		content:'<div>校验数据并提交中，请稍等</div>'
		});   
		  
	try {
		
		if(!beforesubmitvueformsys($event , topvue)){
			layer.close(lay_check);
			validAndSaveflag=false;
			return ;
		}
		layer.close(lay_check);
	} catch (e) {
		validAndSaveflag=false;
		layer.close(lay_check);
		return ;
	}
	
	
	/**
	 * 设置遮罩层显示
	 */
	topvue.$set(topvue.formstatus,"submitFlag",false);
	topvue.$set(topvue.formstatus,"desc",vueoOption.defaultWaitMessage);
	topvue.$set(topvue.formdata.newContApply,"nextSID",
			//初始化ID 之前的保存 自动到初始化后第一个SID
			null);
	topvue.$set(topvue.formdata.newContApply,"nextcurrentSIDindex",
			//初始化ID 之前的保存 自动到初始化后第一个SID
			0);
//	$('#contModal').modal('show');
	$('#contModal').find(".modal-body").text(vueoOption.defaultWaitMessage);
	
//	$('#contModal').find(".modal-body").text("数据处理中，请稍后");
	sinoAjax(
			getRealURL(url,formdata,topvue), 
			{"formdata": JSON.stringify(formdata) }, 
			function (data){
				
				try {
					layer.close(lay_check);
				} catch (e) {
					layer.close(lay_check);
					return ;
				}
				
				topvue.$set(topvue.formstatus,"submitFlag",true);
				topvue.$set(topvue.formstatus,"desc",data.formstatus.desc);
//				$('#contModal').modal('hide');
					
					if(data.formstatus.flag){
						
						topvue.$set(topvue.formstatus,getActivePanelDIV().attr("id")+"_init",1);
						
						fillAllvueFormElements(topvue,data);
						initData(getActivePanelDIV(topvue),true);
						if(!aftersubmitvueform_sys($event ,topvue,data)){
							validAndSaveflag=false;
							return ;
						}
						
						if(H5flag){
							aftersubmitvueformSuccessH5($event, topvue,data);
						}else{
							aftersubmitvueformSuccess($event, topvue,data);
						}
						
						
						
						
					}else{
						validAndSaveflag=false;
					}
					
					
				
				
			}, "POST",topvue);
}

function getActivePanelDIV(){
	
	
	return $("div.tab-pane.active");
	
}
/**
 * 提交表单前
 * @param topvue
 * @returns
 */
function beforesubmitvueformsys(form ,topvue){
	var flag = true;
	if(form.data("bootstrapValidator")){
		var isvalid = form.data("bootstrapValidator").validate();
		form.data("bootstrapValidator_hasvalid",true);
		flag =flag&& isvalid.isValid();
	}
	
	if( vueoOption.beforesubmitvueform[form.attr("id")]){
		flag =flag && vueoOption.beforesubmitvueform[form.attr("id")].call(topvue);
	}
	return  flag ; 
}
/**
 * 表单提交后的操作
 * @param topvue
 * @param data
 * @returns
 */
function aftersubmitvueform_sys(form ,topvue,data){
	
	
	if( vueoOption.aftersubmitvueform[form.attr("id")]){
		return vueoOption.aftersubmitvueform[form.attr("id")].call(topvue,form);
	}
	return  true ; 
}
	
	

function aftersubmitvueformFail(topvue,desc){
	
	topvue.$set(topvue.formstatus,"submitFlag",true);
	topvue.$set(topvue.formstatus,"desc",desc);
}



/**
 * TAB 控制
 * @param $event
 * @param topvue
 * @param data
 */
function aftersubmitvueformSuccessH5(form ,topvue ,data){
	
	try{
		if(H5flag){
			var elements =topvue.form_elements[ topvue.formdata.newContApply.insurancecom+'H5insuranceContInput'];
			 var lastindex =Number( topvue.formdata.newContApply.lastcurrentSIDIndex);
			var index =Number(topvue.formdata.newContApply.currentSIDIndex);
			 if(!index){
				 index =0;
			 }
			 if(index==1||index==2){
				 initData($("#"+elements[0].id+"form"),true);
			 }
			 
			 initData(form,true);
			 initData($("#"+elements[lastindex].id+"form"),true);
			 topvue.$nextTick(function () {
				 var elements =topvue.form_elements[ topvue.formdata.newContApply.insurancecom+'H5insuranceContInput'];
				
				 if(index-lastindex>1){
					 index=lastindex+1;
				 }
				 if(index-lastindex<=0){
					 index=lastindex+1;
				 }
				 
				 topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",index);
				 topvue.$set(topvue.formdata.newContApply,"currentSID",elements[index].id);
					if( !elements[index].loadflag){
						loadNewElements(topvue, elements[index].relateObjectField ,elements[index]);
						elements[index].loadflag=true;
					}
//					topvue.$set(topvue.formdata.newContApply,"lastSIDIndex",index);
					
			});
			 
			
		}
	}catch (e){
		
	}
	validAndSaveflag=false;
//	var elements =topvue.form_elements[ topvue.formdata.newContApply.insurancecom+'H5insuranceContInput'];
//	//加载元素
//	var index =topvue.formdata.newContApply.currentSIDIndex;
//	if( !elements[index+1].loadflag){
//		loadNewElements(topvue, elements[index+1].relateObjectField ,elements[index+1]);
//		elements[index+1].loadflag=true;
//		
//	}
//	topvue.$set(topvue.formdata.newContApply,"lastSIDIndex",curindex);
//	topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",curindex+1);
	
}
/**
 * TAB 控制
 * @param $event
 * @param topvue
 * @param data
 */
function aftersubmitvueformSuccess($event ,topvue ,data){
	
//	topvue.form_elements[vueoOption.tab_SID]

		if(data.formdata.newContApply.nextSID!=null
				&&data.formdata.newContApply.nextSID!=topvue.formdata.newContApply.currentSID){
			
			topvue.$set(topvue.formdata.newContApply,"currentSID",
					//初始化ID 之前的保存 自动到初始化后第一个SID
					data.formdata.newContApply.nextSID);
			topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",
					//初始化ID 之前的保存 自动到初始化后第一个SID
					data.formdata.newContApply.nextcurrentSIDindex);
			
			topvue.$set(topvue.formdata.newContApply, topvue.formdata.newContApply.currentSID, false);
			$("#tab_"+topvue.formdata.newContApply.currentSID+"_tabinfo").trigger("click");
//			topvue.$set(topvue.formdata.newContApply, topvue.formdata.newContApply.nextcurrentSID, false);
//			topvue.$set(topvue.formdata.newContApply, topvue.formdata.newContApply.nextcurrentSID, false);
//			data.formdata.newContApply.nextcurrentSID =0;
//			data.formdata.newContApply.nextSID =null;
//			for ( var index in topvue.form_elements[vueoOption.tab_SID]) {
//				
//				if((data.formdata.newContApply.nextSID+'_tabinfo')==topvue.form_elements[vueoOption.tab_SID][index].id){
//					
//					topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",index);
//				}
//			}
		
		}else{
			var submitDIV=getActivePanelDIV();
			var curindex = Number(topvue.formdata.newContApply.currentSIDIndex);
			//判断是不是后的一个SID更新
			if(topvue.form_elements[vueoOption.tab_SID]!=undefined&&(submitDIV.attr("id")==topvue.formdata.newContApply.currentSID+'_tabinfo'
					||vueoOption.inittabIndex>=topvue.formdata.newContApply.currentSIDIndex)){
				if(topvue.form_elements[vueoOption.tab_SID].length >(curindex+1)){
					topvue.$set(topvue.formdata.newContApply,"currentSID",
							//初始化ID 之前的保存 自动到初始化后第一个SID
								topvue.form_elements[vueoOption.tab_SID][vueoOption.inittabIndex>= (curindex+1)?Number(vueoOption.inittabIndex)+1:(curindex+1)].id.replace("_tabinfo",""));
					topvue.$set(topvue.formdata.newContApply,"currentSIDIndex",curindex+1);
				}
				
			}else{
				//后台传入
				topvue.$set(topvue.formdata.newContApply,topvue.formdata.newContApply.currentSID,false);
//				topvue.formstatus[topvue.formdata.newContApply.currentSID]=false;
				 
			}
		}
		
		//
		
//		if(data.newContApply.currentSID==topvue.newContApply.currentSID||!data.newContApply.currentSID){}
	
}
function fillformelements(vueobj , newobj){
	
	for(var key in newobj){
		if(!vueobj.form_elements[key]){
			vueobj.form_elements[key]	=[];
		}
	
		vueobj.form_elements[key] =newobj[key];
//		vueobj.$set(vueobj.form_elements,key,[]);
//		vueobj.$set(vueobj.form_elements,key,[]);
		
//		vueobj.$nextTick(function () {
//			vueobj.form_elements[key].push({});
//			
//		});
		
	}
}
function fillAllvueFormElements(topvue,data){
//	console.log("start fill data ");
	
	
	fillformelements(topvue, data.form_elements);
	fillOthervueFormElements(topvue,data);
	
//	console.log("end fill data ");
}


function fillOthervueFormElements(topvue,data){
	console.log("start fill data ");
	
	
	fillinObj(topvue, topvue.formdata, data.formdata);
//	fillinObj(topvue, topvue.form_elements, data.form_elements);
	fillinObj(topvue, topvue.relatedata, data.relatedata);
	fillinObj(topvue, topvue.formstatus, data.formstatus);
	setIDIndexForEachElement(topvue, topvue.form_elements, topvue.form_elementsBYID);
	
	console.log("end fill data ");
}

function setIDIndexForEachElement(topvue ,form_elements,form_elementsBYID){
	
	if(!form_elementsBYID){
		form_elementsBYID = topvue.form_elementsBYID;
	}
for ( var key  in form_elements) {
		
		if(form_elementsBYID[key]){
		}else{
			form_elementsBYID[key] ={};
		}
		for ( var index in  form_elements[key]) {
			form_elementsBYID[key][form_elements[key][index].id]= form_elements[key][index];
//			topvue.$set(form_elementsBYID[key],form_elements[key][index].id,form_elements[key][index])
			setIDIndexForEachElement(topvue, form_elements[key][index].child_elements,form_elementsBYID[key][form_elements[key][index].id]);
		}
		
		
	}
	
}

/**
 * 加载页面元素
 * @param vueobj
 * @param url
 * @returns
 */
function loadNewElements(vueobj, url ,form_element){
	
		var topvue =  getTopvueObj(vueobj)
		var formdata = topvue.formdata;
		
		lay_check=layer.load(0, {time: 10*1000
			,shade:0.3,
			content:'<div>页面初始化中</div>'
			});
		
		sinoAjax(
				getRealURL(url,formdata,vueobj), 
				{"formdata": JSON.stringify(formdata) }, 
				function (data){
					
					
					
//					fillAllvueFormElements(topvue,data);
					fillformelements(topvue,data.form_elements);
					fillOthervueFormElements(topvue,data);
					try {
						// 加载 
						if(vueoOption.afterloadNewElements[form_element.id]){
							vueoOption.afterloadNewElements[form_element.id].call(vueobj, url ,form_element);
//							for(key in data.form_elements){
//								
//								var tempELements={"elementstatus":"04","temp_sys_loadAndResetDoc":"true"};
//								if(topvue.form_elements[key][topvue.form_elements[key].length-1]["temp_sys_loadAndResetDoc"]){
//									delete topvue.form_elements[key][topvue.form_elements[key].length-1];
//								}else{
//									topvue.form_elements[key].push(tempELements);
//								}
//								
//								
//							}
//							data.form_elements = topvue.form_elements;
//							fillAllvueFormElements(topvue, data)
//							fillformelements(topvue, topvue.form_elements);
						}
						
						try {
							if(afterloadNewElementsTop){
								try {
									afterloadNewElementsTop.call(vueobj, url ,form_element);
									
								} catch (e) {
									console.info("afterloadNewElementsTop exception"  + e );
								}
								
							}
						} catch (e) {
							
						}
					} catch (e) {
						console.info("afterloadNewElements exception"  + e );
					}
					
					
					vueobj.$nextTick(function () {
						validAndSaveflag=false;
						
					if(form_element){
						console.info("set  load flag "  + form_element.id+"_load" );
						vueobj.$set(topvue.formstatus,form_element.id+"_load",true);
					}
					loadingflag = false;
						try {
							if(url.indexOf("bnf")>0||url.indexOf("contsubmit")>0){
								layer.close(lay_check);
							}else{
								start_closeLay_check();
							}
							
							
						} catch (e) {
						}
					
					});
				}, "POST",topvue);
		
	
}
/**
 * 将获得的新元素填充进来
 * @param vueobj
 * @param sourece
 * @param newObj
 * @param syncFlag  强制更新标志 true强制 刷新到目标非空数据
 * @returns
 */
function fillinObj(vueobj ,sourece ,  newObj,syncFlag,deepIndex){
//	console.info("  load  data  ");
	if(!deepIndex){
		deepIndex=0;
	}
	if(!syncFlag){
		syncFlag=true;
	}
	for ( var key in newObj) {
		if(newObj[key]!=undefined&&newObj[key]!=null&&newObj[key].sync_Flag_sys){
			syncFlag=true;
		}
		try {
			if(newObj[key]==null ){
				if(!sourece[key]){
//					if(deepIndex==0){
//						newObj[key]={};
//						vueobj.$set(sourece, key  ,newObj[key]);
//					}
					
				}else{
					
					continue; 
				}
				
			}else if(newObj[key] instanceof Array){
				if(newObj[key].length==0){
					if(sourece[key]){
						continue; 
					}
				}
			}else{
				
			}
			//数组和对象继续迭代
			if(newObj[key] instanceof Array || newObj[key] instanceof Object){
				if(!sourece[key]){
					 
					vueobj.$set(sourece, key  ,newObj[key]);
				}else{
					 
					fillinObj(vueobj ,sourece[key] ,  newObj[key],syncFlag,deepIndex++);
				}
				
			}else{
				if(!sourece[key]||syncFlag){
					try {
						if(key=="relateObjectField"){
							newObj[key] =JSON.parse(newObj[key]);
						}
					} catch (e) {
						console.log(e);
					}
					if(syncFlag){
						if(newObj[key]!=undefined&&newObj[key]!=null&&sourece[key]!=newObj[key]){
							vueobj.$set(sourece, key  ,newObj[key]);
						}
					}else{
						
						if(newObj[key]!=undefined&&newObj[key]!=null){
							vueobj.$set(sourece, key  ,newObj[key]);
						}
					}
					
					
				}
				
			}
			
		} catch (e) {
			console.log(e);
		}
 
		
	}
	
}
 /**
  * 
  * @param url
  * @param ajaxformdata 
  * @param callbackfunction
  * @param type
  * @returns
  */
function sinoAjax(url,ajaxformdata,callbackfunction,type,topvue){
	
	var that = this ;
	if(!type){
		type ="POST";
	}
//	if(!$('#contModal').is(":visible")){
////		$('#contModal').modal('show');
//		$('#contModal').find(".modal-body").text(vueoOption.defaultWaitMessage);
//	}
	
	try {
		closeds1();
		shows1();
	} catch (e) {
		// shows1();: handle exception
	}
	$.ajax({
        type: type,
        url: url,
        data: ajaxformdata,
        error: function (request) {
        	
        	
        	try {
        		layer.close(lay_check);
				closeds1();
			} catch (e) {
				// TODO: handle exception
			}
			
			if(request.status == 403){
		          alert(request.responseText);
		         }
        	aftersubmitvueformFail(topvue,"系统错误");
        	
			$('#contModal').find("[type='button']").show();
//			$('#contModal').find(".modal-body").text(request.formstatus.desc);
			$('#contModal').find(".modal-body").text(request.status+"系统错误");
			loadingflag=false;
        },
        success: function (getdata) {
        	start_closeLay_check();
        	try {
        		if(!getdata.formstatus.flag){
//        			try {
//    					closeds1();
//					} catch (e) {
//						// TODO: handle exception
//					}
    				$('#contModal').modal('show');
    				$('#contModal').find("[type='button']").show();
    				$('#contModal').find(".modal-body").text(getdata.formstatus.desc);
    			}else{
//    				$('#contModal').modal('hide');
    				try {
    					closeds1();
					} catch (e) {
						// TODO: handle exception
					}
    				
    			}
        		
			} catch (e) {
				
				try {
					closeds1();
				} catch (e) {
					// TODO: handle exception
				}
//				$('#contModal').modal('hide');
				try {
					if(getdata.indexOf(TIMEOUT_MESSAGE)>=0){
//						alert(TIMEOUT_MESSAGE_ALERT);
						location.reload();
					}else{
//						alert(getdata.msg);
					}
				} catch (e) {
					// TODO: handle exception
					try {
						if(!getdata.success){
							alert(getdata.msg);
						}
					} catch (e) {
						// TODO: handle exception
					}
					
				}
				
				console.info("success  sinoAjax"  + e );
			}
			loadingflag=false;
        	callbackfunction(getdata);
        	
        	topvue.$nextTick(function () {
				 
//        		layer.close(lay_check);
				
			});
        }
    });
	
}
/**
 * 获取VUE中的值
 * @param key
 * @returns
 */
function getRealValueFromVueObj(key){
    var expAry= key.split(".");
    var value   =this ;
    if(key.indexOf("#")==0){
    	for ( var index in expAry) {
    		 
    		
        	value =  value [expAry[index].replace("#","")];
        	if(value==undefined){
        		return ;
        	}
        	
    	}
    	return value; 
    }else{
    	return key;
    }
	
}
 

/** 
 * @param sourceformdata
 * @param sourceName
 * @param targetformdata
 *            值复制的目标对象
 * @param targetname
 *            值复制的目标对象name
 * @param targetformelement
 *            目标对象
 */
function bindSameElement(sourceformdata, sourceName, targetformdata,
		targetname, targetformelement) {

	this.$set(targetformdata, targetname, sourceformdata[sourceName]);
	if(targetformelement.elementstatus == '01'){
		this.$set(targetformelement, "elementstatus","04");
	}

	try {
		
		var form =$("input[name='"+targetformelement.groupid+"."+targetname+ "']")
		.parentsUntil("form").parent("form");
		form.data('bootstrapValidator').resetField($("input[name='"+targetformelement.groupid+"."+targetname+ "']"));
	} catch (e) {
		// TODO: handle exception
	}
	if (targetformelement.tempcssClass&&targetformelement.tempcssClass.indexOf(" disabled") >= 0) {
		
	}else{
//		var id = targetformelement.id+targetformelement.elementindex;
//		 
//		
//		$("#"+id).parent().find();
		this.$set(targetformelement, "cssClass", targetformelement.cssClass
				+ " disabled");
		this.$set(targetformelement, "tempcssClass", targetformelement.tempcssClass
				+ " disabled");
		//this.form_elements.lcinsured.push("");
		
	}
	this.$emit('update:triggerupdate',this.triggerupdate+1);
	this.$nextTick(function () {
		try {
			
			if(targetformelement.type=="combobox"){
				
				$("input[name='"+targetformelement.groupid+"."+targetname+ "']").combobox("disable");
			}
			
		} catch (e) {
		}
		
	});
	
	
	
	

	if (vueoOption.afterVueSelect[sourceName + "_SYS_"] == undefined) {
		vueoOption.afterVueSelect[sourceName + "_SYS_"] = {};
	}
	vueoOption.afterVueSelect[sourceName + "_SYS_"][targetformelement.sid+"_"+targetformelement.id] = function(
			form_element) {
		this.$set(targetformdata, targetname, sourceformdata[sourceName]);
	};

}

/** 
 * @param sourceformdata
 * @param sourceName
 * @param targetformdata
 *            值复制的目标对象
 * @param targetname
 *            值复制的目标对象name
 * @param targetformelement
 *            目标对象
 */
function bindSameElementByJqobj(sourceformdata, sourceName, targetformdata,
		targetname, targetformelement,jqobj) {

	this.$set(targetformdata, targetname, sourceformdata[sourceName]);
	var target = jqobj;
	try {
		
		var form =target
		.parentsUntil("form").parent("form");
		form.data('bootstrapValidator').resetField(target);
	} catch (e) {
		// TODO: handle exception
	}
	if (targetformelement.tempcssClass&&targetformelement.tempcssClass.indexOf(" disabled") >= 0) {
		
	}else{
		
		target.attr("disabled","disabled");
//		var id = targetformelement.id+targetformelement.elementindex;
//		 
//		
//		$("#"+id).parent().find();
//		this.$set(targetformelement, "cssClass", targetformelement.cssClass
//				+ " disabled");
//		this.$set(targetformelement, "tempcssClass", targetformelement.tempcssClass
//				+ " disabled");
		
		
	}
	this.$nextTick(function () {
		try {
			
			if(targetformelement.type=="combobox"){
				
				target.combobox("disable");
			}
			
		} catch (e) {
		}
		
	});
	
	
	
	

	if (vueoOption.afterVueSelect[sourceName + "_SYS_"] == undefined) {
		vueoOption.afterVueSelect[sourceName + "_SYS_"] = {};
	}
	vueoOption.afterVueSelect[sourceName + "_SYS_"][targetformelement.sid+"_"+targetformelement.id] = function(
			form_element) {
		this.$set(targetformdata, targetname, sourceformdata[sourceName]);
	};

}
/**
 * 
 * @param sourceName
 *            解绑的源数据 name
 * @param targetformelement
 *            目标formelemnt
 */
function unbindSameElementByJqobj(sourceName, targetformelement,jqobj) {

//	vueoOption.afterVueSelect[sourceName + "_SYS_"].remove("appntSameAddresss");''
	
	 delete vueoOption.afterVueSelect[sourceName + "_SYS_"][targetformelement.sid+"_"+targetformelement.id];
	 jqobj.removeAttr("disabled");
		try {
			
			this.$nextTick(function () {
				try {
					
					if(targetformelement.type=="combobox"){
						
						jqobj.combobox("enable");
					}
					
				} catch (e) {
				}
				
			});
			
			
		} catch (e) {
		}

}



/**
 * 
 * @param sourceName
 *            解绑的源数据 name
 * @param targetformelement
 *            目标formelemnt
 */
function unbindSameElement(sourceName, targetformelement) {

//	vueoOption.afterVueSelect[sourceName + "_SYS_"].remove("appntSameAddresss");''
	if(targetformelement.elementstatus == '04'){
		this.$set(targetformelement, "elementstatus","01");
	}
	 delete vueoOption.afterVueSelect[sourceName + "_SYS_"][targetformelement.sid+"_"+targetformelement.id];
	if (targetformelement.tempcssClass.indexOf(" disabled") >= 0) {
		this.$set(targetformelement, "cssClass", targetformelement.cssClass
				.replace(" disabled", ""));
		this.$set(targetformelement, "tempcssClass",
				targetformelement.tempcssClass.replace(" disabled", ""));
		this.$emit('update:triggerupdate',this.triggerupdate+1);
		try {
			
			this.$nextTick(function () {
				try {
					
					if(targetformelement.type=="combobox"){
						
						$("input[name='"+targetformelement.groupid+"."+targetformelement.name+ "']").combobox("enable");
					}
					
				} catch (e) {
				}
				
			});
			
			
		} catch (e) {
		}
	} else {

	}

	
}





/*******************************************************************************
 * 
 * @param url
 * @param type
 * @param data
 * @param callbackfunction
 * @param errcallbackfunction
 */
function simpleAjaxREST(url,type,data,header,callbackfunction,errcallbackfunction){
	var that = this;
	var topvue = getTopvueObj(that);
	 $("#contModal").modal('show');
	 $("#modal-button").hide();
	 $("#contModal_body").text("系统处理中");
	$.ajax({
		   type: type,
		   url: url,
		   data: data,
		   dataType: "json" ,
		   contentType :"application/json;charset=UTF-8" ,
		   beforeSend:function(xhr){
			   if(header){
				   for (var key in  header) {
					   xhr.setRequestHeader(key, header[key]);
					}
			   }
		       
		    },
		    error: function (data) {
		    	
		    	try {
		    		if(errcallbackfunction){
		    			errcallbackfunction(data);
		    		}
		    		$("#modal-button").show();
					$("#contModal_body").text(data.desc);
				} catch (e) {
					console.error("errcallbackfunction : "  + e );
					
				}
		    	
	        },
		   success: function(data){
			   
			   try {
				   
				   fillinObj(topvue, topvue.formdata, data.reObj);
				   if(callbackfunction){
					   callbackfunction(data);
				   }
				   $("#modal-button").show();
				   if(data.flag){
					   $("#contModal_body").text("操作成功");
				   }else{
					   $("#contModal_body").text(data.desc);
				   }
				
				  
				} catch (e) {
					console.error("callbackfunction : "  + e );
				}
			   
		   }
		});
}

function showModel(desc ){
	 $("#contModal").modal('show');
	 $("#contModal_body").text(desc);
	
}
/*******************************************************************************
 * 
 * @param url
 * @param type
 * @param data
 * @param callbackfunction
 * @param errcallbackfunction
 */
function ajaxREST(url,type,data,header,callbackfunction,errcallbackfunction){
	 $("#contModal").modal('show');
	 $("#modal-button").hide();
	 $("#contModal_body").text("系统处理中......");
	$.ajax({
		   type: type,
		   url: url,
		   data: data,
		   dataType: "json" ,
		   contentType :"application/json;charset=UTF-8" ,
		   beforeSend:function(xhr){
			   if(header){
				   for (var key in  header) {
					   xhr.setRequestHeader(key, header[key]);
					}
			   }
		       
		    },
		    error: function (data) {
		    	
		    	try {
		    		if(errcallbackfunction){
		    			errcallbackfunction(data);
		    		}
		    		$("#modal-button").show();
					$("#contModal_body").text(data.desc);
				} catch (e) {
					console.error("errcallbackfunction : "  + e );
					
				}
		    	
	        },
		   success: function(data){
			   
			   try {
				   
//				   fillinObj(topvue, topvue.formdata, data.reObj);
				   if(callbackfunction){
					   callbackfunction(data);
				   }
				   $("#modal-button").show();
				   if(data.flag){
					   $("#contModal_body").text("操作成功");
				   }else{
					   $("#contModal_body").text(data.desc);
				   }
				
				  
				} catch (e) {
					console.error("callbackfunction : "  + e );
				}
			   
		   }
		});
}

function doKey(e){
    var ev = e || window.event;//获取event对象
    var obj = ev.target || ev.srcElement;//获取事件源
    var t = obj.type || obj.getAttribute('type');//获取事件源类型
    if(ev.keyCode == 8 && t != "password" && t != "text" && t != "textarea"){
        return false;
    }
}
function NoBackSpace(){
	//禁止后退键 作用于Firefox、Opera
    document.onkeypress=doKey;
    //禁止后退键  作用于IE、Chrome
    document.onkeydown=doKey;
}

//ref是给组件取得ref名字，想使用先在jsp配上ref名
function changeElementAndRefresh(ref,regx){
	var eleRegx=regx.split("=")[0]
	var value=regx.split("=")[1]
	var args=eleRegx.split(".")
	var _this=vueobj["testdivchange"]
	var length=args.length
	var attr=""
	args.forEach(function(item,index){
		if(index+1<length)
			_this=_this[item]
		else
			attr=item
	})
	_this[attr]=value
	vueobj["testdivchange"].$refs[ref].reload();
}

function getElementIntex(element){
	
	var  elementindex ="";
	if(element.elementindex){
		elementindex =  element.elementindex.replace(/[^0-9]/ig,"");
	}else{
		elementindex =  element.namepref.replace(/[^0-9]/ig,"");
	}
	return elementindex;
}