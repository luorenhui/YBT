var tab_d = $('#cusTable');
var select2 = '请选择';
//页面初始化 
$(document).ready(function() {
	
	$("#downLoad").attr("disabled", true);
	
	var init_url = "";
	
	/**加载页面表格*/
	       var col = [{field: 'metentid',title: '序号',formatter: function (value, row, index) {  
                       return index+1;  
                     }},
	   				{field: 'insurancecom',title: 'Insurer',align: 'center',valign : 'middle',visible: true},
	   				{field: 'product',title: 'Product',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'devcode',title: 'Region',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'city',title: 'City',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'branchcode',title: 'Sub-Branch Code',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'branchname',title: 'Sub-Branch Name',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'rmid',title: 'Sales Staff',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'customerid',title: 'Customer Number',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'cvalidate',title: 'Effective_Date',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'proposalcontno',title: '投保单号',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'contno',title: '保单号',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'polreceiptDate',title: '回执日期',align: 'center',sortable: true,valign : 'middle'}	,
	   				{field: 'isMZReceipt',title: '是否MZ签收',align: 'center',sortable: true,valign : 'middle'}	
	  			   ];	
	
	var uniqueId = "metentid";
	var sortOrder = "metentid asc";
	
	 $("#search").click(function() {
	
		    var start = $("#StartDate").val();
			var end = $("#endDate").val();
		 	if(start!=null&&start!=""&&end!=null&&end!=""&&CompareDate(end,start)){
		 		    $("#cusTable").bootstrapTable('destroy');
				    $("#downLoad").attr("disabled", false);
				    $("#downLoad").attr("class", "btn btn-primary");    
					var url_d = "/ExcelReportController/polreceiptReportService.do";
					tableInit3(url_d, tab_d, col,uniqueId, queryParams); 					
		 	}else{
		 		if(start==null||start==""){
		 			alert("请输入开始时间");
		 			return false;
		 		}
		 		if(end==null||end==""){
		 			alert("请输入结束时间");
		 			return false;
		 		}		 			 		
		 		if(!CompareDate(end,start)){
		 			alert("开始时间大于结束时间，请正确的选择您的查询时间");
		 			return false;
		 		}
		 	}		     		  		
   });
	
	 $("#downLoad").click(function(){
		 var showdilog= layer.load(2, {
			  shade:0.3, //0.2透明度的白色背景
		 });
		 var start = $("#StartDate").val();
		 var end = $("#endDate").val();
			$.ajax({				
				type : "POST",
				url: path+"/ExcelReportController/downPolreceiptReport.do",// 后台请求URL地址	
				data: {"StartDate":start,"endDate":end},
				success : function(data) {
					if(data.success){
						var url ="download.jsp?path="+data.parm+"&a="+"sdf";
						toback(url);
						layer.close(showdilog);
					}else{
						alert(data.msg);
						layer.close(showdilog);
					}				
				},
				 error : function() {
				 alert("系统异常");
				 layer.close(showdilog);
				}
			});	
		});
});
		
/**
 * 设置表格查询参数
 * @param params
 */
function queryParams(params){	
	//设置查询参数 
	 param = {
	    		limit : params.limit,
		        offset: params.offset,		        
		        sortName:params.sortName,//排序列名
		        sortOrder:params.sortOrder,//排位命令（desc，asc）		        
		        pageSize: params.pageSize,
		        pageNumber:params.pageNumber,		        
				StartDate: $("#StartDate").val(),				
				endDate: $("#endDate").val(),
//				branchno:$("#branchno").val(),
//				datetype:$("#datetype").val(),
		}; 	     
	    return param; 
}

/**
 * 翻页带查询参数及列排序
 * @param url
 * @param obj
 * @param col
 * @param uniqueId 行主键
 * @param sortOrder 排序方式
 * @param queryParams
 * @author TKW
 */
function tableInit3(url, obj, col, uniqueId,queryParams) {
	obj.bootstrapTable({
		url : path + url, // 请求后台的URL（*）
		dataType : "json",
		method : 'post', // 请求方式（*）
		contentType : "application/x-www-form-urlencoded",
		toolbar : '#toolbar',
		columns : col,
		striped : true, // 是否显示行间隔色
		cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		pagination : true, // 是否显示分页（*）
		queryParamsType : "limit",// undefined/limit
		queryParams : queryParams,// 传递参数（*）
		sidePagination : "server", //
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		strictSearch : true,// 设置为 true启用 全匹配搜索，否则为模糊搜索
		showColumns : true, // 是否显示所有的列
		showRefresh : true, // 是否显示刷新按钮
		minimumCountColumns : 2, // 最少允许的列数
		clickToSelect : true, // 是否启用点击选中行
		// height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		// uniqueId: "ID", // 每一行的唯一标识，一般为主键列
		uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
		showToggle : true, // 是否显示详细视图和列表视图的切换按钮
		cardView : false, // 是否显示详细视图
		detailView : false
	});
};

function  DateDiff(sDate1,  sDate2){  
    var  aDate,  oDate1,  oDate2,  iDays  
    aDate  =  sDate1.split("-")  
    oDate1  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0])    
    aDate  =  sDate2.split("-")  
    oDate2  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0])  
    iDays  =  parseInt(Math.abs(oDate1  -  oDate2)  /  1000  /  60  /  60  /24)    //把相差的毫秒数转换为天数  
    return  iDays  
}    

function CompareDate(d1,d2)
{
  return ((new Date(d1.replace(/-/g,"\/"))) >= (new Date(d2.replace(/-/g,"\/"))));
}

//function download(start,end){ 
//	show();
//	$.ajax({
//		type : "POST",
//		data : "start="+start,			
//		url:path+"/ExcelReportController/EsignReport.do",// 后台请求URL地址	
//		success : function(data) {
//		   closed();
//		   var json=eval(data);
//		   if(json.success){			
//			var url ="download.jsp?path="+json.parm+"&a="+"sdf";
//			toback(url);	
//		   }else{
//			   alert("对不起，未找到"+json.parm+"的文件");  
//		   }
//		},
//		 error : function() {
//		 closed();
//		 alert("对不起，未找到文件");		 
//		}
//	}); 	
//}


