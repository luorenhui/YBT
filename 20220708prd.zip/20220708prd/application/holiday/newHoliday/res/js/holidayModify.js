var tab_d = $('#cusTable');
var url_d = "/HolidayController/QueryByDate.do";
// 页面初始化
$(document).ready(function() {
	selectLacom();
	
	
	
	
	/**加载页面表格*/
	var col = [{field: 'state',align: 'center',valign : 'middle',checkbox: true,visible: true},
	  			   {field: 'metentid',title: '序号',formatter: function (value, row, index) {  
	  				   row.metentid=index;
                       return index+1;  
                   }},
                   {field: 'seqnumber',title: '序号',align: 'center',valign : 'middle',visible: true},
	   				{field: 'startdate',title: '原节假日日期',align: 'center',valign : 'middle',visible: true},
	   				{field: 'enddate',title: '节假日日期',align: 'center',valign : 'middle',
	                editable: {
	                    type: 'date',
	                    title: '生日',
	                }
	            },
	   			   {field: 'flag',title: '处理状态',align: 'center',sortable: true,valign : 'middle'},
	           
	           {title: '操作',align: 'center',formatter: actionFormatter,events: actionEvents},
	   			 
	   				];


	
	var uniqueId = "metentid";
	var sortOrder = "metentid asc";

	 $("#search").click(function() {
	 	
   		//参数
        var urla = path+"/HolidayController/uploadOne.do";
        var showdilog = layer.load(0, {
            shade: 0.3, //0.3透明度的白色背景
            anim:-1
        });
            
        
        $.ajax({
            //几个参数需要注意一下
                type: "POST",//方法类型
                dataType: "json",//预期服务器返回的数据类型
                url:urla,//url
                data:new FormData($('#filesubmit')[0]),
                cache:false,
                processData:false,
                contentType:false,
                success: function (result) {
                	
                	layer.close(showdilog);

                    if(result=="-1"){
                    	alert("文件读取异常");
                    }
                    if(result=="0"){
                    	alert("文件上传成功");
                    }
                    if(result=="1"){
                    	alert("文件名错误");
                    }
                    
                    if(result=="2"){
                    	alert("数据解析错误");
                    }else{
                    	var resultarray=result.split("_");
                    	if(resultarray[0]=="10"){
                    		alert("第"+resultarray[1]+"行数据的格式错误,请使用正确的日期格式YYYY-MM-DD");
                    	}
                    }
                   $("#file").val("");
                   
                   
                   
                   
                },
                error : function() {
                	 layer.close(showdilog);
                    alert("异常！");
                    $("#file").val("");
                }
            });
   		
   		
	 });



});








function actionFormatter(value, row, index) {      
	return [
		'<button class="btn btn-primary remove">删除</button>'
	].join('');
}



//公共代码
function queryTable(url , obj , data){
	obj.bootstrapTable('refresh', {
		  url: path+url,
		  query: data
	 });  
};

/**
 * 设置表格查询参数
 * @param params
 */
function queryParams(params){
	//设置查询参数 
    var param = {
	        //这里是在ajax发送请求的时候设置一些参数 params有什么东西，
	    	//自己看看源码就知道了 limit: params.pageSize,
    		limit : params.limit,
	        offset: params.offset,
	        
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        startdate : $("#startdate").val(),
			enddate : $("#enddates").val(),
	    }; 
	    return param; 
}

/**
 * 翻页带查询参数及列排序
 * @param url
 * @param obj
 * @param col
 * @param uniqueId 行主键
 * @param sortOrder 排序方式
 * @param queryParams
 * @author TKW
 */
function tableInit3( url,obj,col,uniqueId,sortOrder,queryParams){
	 obj.bootstrapTable({
		 url: path+url, // 请求后台的URL（*）
		 dataType: "json",
		 method: 'post', // 请求方式（*）
		
		 contentType: "application/x-www-form-urlencoded",
		 toolbar: '#toolbar',
		 toolbar: '#toolbar2',// 工具按钮用哪个容器
		 columns:  col,
		 striped: true, // 是否显示行间隔色
		 cache: false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		 pagination: true, // 是否显示分页（*）
		 sortable: true, // 是否启用排序
		 sortOrder: "asc", // 排序方式
		 sortOrder: sortOrder, // 排序方式
		 queryParamsType : "limit",// undefined/limit
		 queryParams: queryParams,//传递参数（*）
		 sidePagination: "server", //
		 
		 //分页方式：client客户端分页，server服务端分页（*）
		 // pageNumber:1, //初始化加载第一页，默认第一页
		 // pageSize: 10, //每页的记录行数（*）
		 pageList: [10, 25, 50, 100], // 可供选择的每页的行数（*）
		 search: false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		 strictSearch: true,//设置为 true启用 全匹配搜索，否则为模糊搜索
		 showColumns: true, // 是否显示所有的列
		 showRefresh: true, // 是否显示刷新按钮
		 minimumCountColumns: 2, // 最少允许的列数
		 //editable:true,//开启编辑模式 
		 clickToSelect: true, // 是否启用点击选中行
		 // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		 uniqueId: "ID", // 每一行的唯一标识，一般为主键列
		 uniqueId: uniqueId, // 每一行的唯一标识，一般为主键列
		 showToggle:true, // 是否显示详细视图和列表视图的切换按钮
		 cardView: false	, // 是否显示详细视图
		 detailView: false,// 是否显示父子表
	     onEditableSave: function (field, row,oldValue, $el) {
              $.ajax({
                   type: "post",
                   url: path+"/HolidayController/update.do",
                   data:"startdate="+row.startdate+"&enddate="+row.enddate+"&seqnumber="+row.seqnumber+"&operator="+row.operator,
                   dataType: 'JSON',
                   success: function (data, status) {
                       if (status == "success") {
                           alert('提交数据成功');
                       }
                   },
                   error: function () {
                       alert('编辑失败');
                   },
                   complete: function () {

                   }

               });
         
	   
	   },
		
			 }); 
	 

}



//获取ID
function getIdSelections() {
	return $.map($cusTable.bootstrapTable('getSelections'), function(row) {
		return row.contNo;
	});
}



//获取保险公司
function selectLacom(){//保险公司
	$.ajax({
		 url:path + '/newContEnter/selectFromLacom.do',  
        type: "POST",
		 success: function(data){
		 for(var i=0;i<data.length;i++){
			var select=document.getElementById("BX");
		    var option=document.createElement("option");
			option.value=data[i].agentcom.replace(/^\s+|\s+$/g, '');;
			option.innerHTML=data[i].agentcom+"-"+data[i].name;
			select.appendChild(option);	
			
		 	 }
		 
		 //$("#BX").select2("val","INSH");
		 }
	})
	}


$('.datepickerA1').datepicker({
    format: 'yyyy',
    language: "zh-CN",
    autoclose:true,
    startView: 2,
    minViewMode: 2,
    maxViewMode: 2
 });