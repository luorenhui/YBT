var tab_d = $('#cusTable'),
$remove = $('#remove');

var init_url = "/LaprodqualiController/selectBylaprodqualiall.do";
	
var url_d = "";

var col;

var uniqueId;
var sortOrder;

// 页面初始化
$(document).ready(function() {
	/**加载页面表格*/
	col = [{field: 'state',align: 'center',valign : 'middle',checkbox: true,visible: true},
	  			   {field: 'metentid',title: '序号',formatter: function (value, row, index) {  
                       return index+1;  
                   }},
                    {field: 'qualifitypecode',title: '资质类型',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'qualifitype',title: '资质名称',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'flag',title: '标识',align: 'center',sortable: true,valign : 'middle'},
	   				{title: '操作',align: 'center',formatter: actionFormatter,events: actionEvents}
	  			   ];
	
	uniqueId = "metentid";
	sortOrder = "metentid asc";
	tableInit3(init_url,tab_d,col,uniqueId,sortOrder,queryParams);

	selqualiinfo();
	 
	 $("#save").click(function() {
		    var flag=$("#flag").val().trim();
			var qualifitypecode=$("#qualifitypecode").val().trim();
			

			if(qualifitypecode==""){
				alert("资质类型不能为空");
				return;
			}
			if(flag==""){
				alert("标识不能为空");
				return;
			}

	
			var ids1 =$("form").serialize();
            insert(ids1);
		
        
    });
	
});


//公共代码
function queryTable(url , obj , data){
	obj.bootstrapTable('refresh', {
		  url: path+url,
		  query: data
	 });  
};



/**
* 设置表格查询参数
* @param params
*/
function queryParams(params){
	//设置查询参数 
  var param = {
  		limit : params.limit,
	        offset: params.offset,
	        
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	      
	    }; 
	    return param; 
}

/**
* 翻页带查询参数及列排序
* @param url
* @param obj
* @param col
* @param uniqueId 行主键
* @param sortOrder 排序方式
* @param queryParams
* @author TKW
*/
function tableInit3( url,obj,col,uniqueId,sortOrder,queryParams){
	 obj.bootstrapTable({
		 url: path+url, // 请求后台的URL（*）
		 dataType: "json",
		 method: 'post', // 请求方式（*）
		 contentType: "application/x-www-form-urlencoded",
		 toolbar: '#toolbar',
		 toolbar: '#toolbar2',// 工具按钮用哪个容器
		 columns:  col,
		 striped: true, // 是否显示行间隔色
		 cache: false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		 pagination: true, // 是否显示分页（*）
		 sortable: true, // 是否启用排序
		 sortOrder: "asc", // 排序方式
		 sortOrder: sortOrder, // 排序方式
		 queryParamsType : "limit",// undefined/limit
		 queryParams: queryParams,//传递参数（*）
		 sidePagination: "server", //
		 
		 //分页方式：client客户端分页，server服务端分页（*）
		 // pageNumber:1, //初始化加载第一页，默认第一页
		 // pageSize: 10, //每页的记录行数（*）
		 pageList: [10, 25, 50, 100], // 可供选择的每页的行数（*）
		 search: false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		 strictSearch: true,//设置为 true启用 全匹配搜索，否则为模糊搜索
		 showColumns: true, // 是否显示所有的列
		 showRefresh: false, // 是否显示刷新按钮
		 minimumCountColumns: 2, // 最少允许的列数
		 clickToSelect: true, // 是否启用点击选中行
		 // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		 uniqueId: "ID", // 每一行的唯一标识，一般为主键列
		 uniqueId: uniqueId, // 每一行的唯一标识，一般为主键列
		 showToggle:true, // 是否显示详细视图和列表视图的切换按钮
		 cardView: false	, // 是否显示详细视图
		 detailView: false, // 是否显示父子表

	 });
};

//获取ID
function getIdSelections() {
	return $.map($cusTable.bootstrapTable('getSelections'), function(row) {
		return row.uid;
	});
}



function actionFormatter(value, row, index) {      
	return [
      '<button class="btn btn-red remove">删除</button>'
	].join('');
}


window.actionEvents = {
		'click .remove': function (e, value, row, index) {
		var r=confirm("确认要删除么？");
		if (r==true)
		  {
			$.ajax({
				type : "POST",
				url:path+"/LaprodqualiController/deleteBylaprodqualiall.do",// 后台请求URL地址
				data : "productid="+ row.riskcode+"&qualifitype="+row.qualifitype + "&qualifitypecode="+row.qualifitypecode ,
				dataType : "json",
				success : function(data) {
					if(data=="1"){
						alert("删除成功");
						var url ="addall.jsp";
						toback(url);
						
					}
					if(data==2){
						alert("删除失败！");
					}
				},
				error : function() {
					alert("plus failed");
				}
			});
		  }
		else
		  {
			$remove.attr('disabled',true);
			
		  }
 },
		
	};


$(function(){
//查询flag给下拉框赋值	
//返回
$(".back").click(function(){
	var url ="laprodqualiAdd.jsp";
	toback(url);
	});


	
});



 function selqualiinfo(){
	 document.getElementById("qualifitypecode").options.length = 1;
	 $.ajax({
			type : "POST",
			url : path + "/LaqualiinfoController/SelectByCodetypeAll.do",// 后台请求URL地址
			success : function(data) {
				for(var i=0;i<data.length;i++){
				var select=document.getElementById("qualifitypecode");
             var option=document.createElement("option");

             if(data[i].qualifitype=="Structured Product Accreditation 2015 (For China Only)"){
            	 data[i].qualifitypecode=data[i].qualifitypecode+"s";
             }
				option.value=data[i].qualifitypecode;
				option.innerHTML=data[i].qualifitypecode+"--"+data[i].qualifitype;
				select.appendChild(option);
			
				}
					
			},
			
		});
 }


function bytype(){
	var s=$('#qualifitypecode option:selected').text();
	var arr=new Array();
	arr=s.split("--");
	$("#qualifitype").val(arr[1]);//资质类型	

	
}
//新增
function insert(ids1){
	$.ajax({
			type : "POST",
			url : path+"/LaprodqualiController/insertlaprodqualiall.do",// 后台请求URL地址
			data:ids1,
			success : function(data) {
			
			if(data=="1"){
				alert("添加成功");
				var url ="addall.jsp";
				toback(url);
				}
				
			if(data=="2"){
				 alert("添加失败，资质已经存在");
				 
			 }	
			
			},
			error : function() {
				alert("plus failed");
			}
	});
	
	
}

