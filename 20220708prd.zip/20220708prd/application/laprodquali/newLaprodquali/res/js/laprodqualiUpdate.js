$(function(){
	
	$(".back").click(function(){
		alert('bask');
		var url ="laprodquali.jsp";
		toback(url);
	});
	
	$("#save").click(function() {
		//alert('save');
		//update();
	});
	
});


