var tab_d = $('#cusTable');

//页面初始化
$(document).ready(function() {
	 $("#save").click(function() {
		 var laqualiinfo=$("#laqualiinfo").val().trim();
		 var flag=$("#flag").val().trim();
		 var codealias=$("#codealias").val().trim();
		 if(laqualiinfo==""){
				alert("资质类型不能为空");
				return;
			}
		 if(codealias==""){
				alert("证书类型不能为空");
				return;
			}	
		 if(flag==""){
				alert("标识不能为空");
				return;
			}
		 
		 mycheckbox();
	 });
});

//获取CheckBox选中的行
function mycheckbox(){
	var qualifitypecode=$('#laqualiinfo option:selected').val();//资质类型
	var qualifitype=$('#laqualiinfo option:selected').text();//资质类型
	var flags=$('#flag option:selected') .val();//flag
	var type=$('#type') .val();//表格显示顺序
	 //01  附加险关系
	 var arr=$('#cusTable').bootstrapTable('getSelections');
	 if(arr.length>0){
		 for(var i=0;i<arr.length;i++){
			 insert(arr[i].codename,arr[i].code,arr.length-1,i,flags,qualifitype,qualifitypecode,type);
		 } 
	 }else{
		 $("#btn").attr("disabled", false);
		 alert("请勾选资质！");
		
	 }
	 
	
}


//新增
function insert(qualiinfo,certificateCode,i,j,flags,qualifitype,qualifitypecode,type){
	
	$.ajax({
			type : "POST",
			url : path+"/LaqualiinfoController/saveAddBean.do",// 后台请求URL地址
			data:"qualiinfo="+ qualiinfo+"&qualifitype="+ qualifitype+"&qualifitypecode="+ qualifitypecode+"&flags="+ flags
			+"&certificateCode="+certificateCode+"&type="+type,
			success : function(data) {
			
			if(data=="1"&&i==j){
				alert("添加成功");
				var url ="laqualiinfoAdd.jsp";
				toback(url);
				}
				
			if(data=="2"){
				 alert(qualiinfo+"添加失败");
				 
			 }	
			 if(data=="3"){
				 alert(qualiinfo+"添加失败，数据已经存在");
				 
			 }	
			
			},
			error : function() {
				alert("plus failed");
			}
	});
	
	
}

//公共代码
function queryTable(url , obj , data){
	obj.bootstrapTable('refresh', {
		  url: path+url,
		  query: data
	 });  
};



function selbycs(){
	var codealias=$('#codealias option:selected').val();//资质类型
	if(codealias=="6"){
		$("#userCode").val("othertraining");
		$("#codealias").val("");
		
	}else{
		$("#userCode").val("natural");
	
	}
	 url_d = "/LdcodeController/SelectByCodes.do";
	 /**加载页面表格*/
		col = [{field: 'state',align: 'center',valign : 'middle',checkbox: true,visible: true},
		  			   {field: 'metentid',title: '序号',formatter: function (value, row, index) {  
	                       return index+1;  
	                   }},
	                   /*{field: 'codetype',title: 'codetype',align: 'center',sortable: true,valign : 'middle',visible: true},*/
	                   {field: 'code',title: 'code',align: 'center',sortable: true,valign : 'middle',visible: true},
	                    {field: 'codename',title: 'codename',align: 'center',sortable: true,valign : 'middle',visible: true}
		               
		   				];

						var uniqueId = "metentid";
						sortOrder = "metentid asc";
				
				//tableInit3("",tab_d,col,uniqueId,sortOrder,queryParams);
	$("#cusTable").bootstrapTable('destroy');

	 tableInit3(url_d,tab_d,col,uniqueId,sortOrder,queryParams);
	 if(codealias=="6"){
	 $("#codealias").select2("val","6");
	 }

}

/**
* 设置表格查询参数
* @param params
*/
function queryParams(params){
	//设置查询参数 
  var param = {
	        //这里是在ajax发送请求的时候设置一些参数 params有什么东西，
	    	//自己看看源码就知道了 limit: params.pageSize,
  		limit : params.limit,
	        offset: params.offset,
	        codealias:$("#codealias option:selected").val(),
	        userCode:$("#userCode").val(),
	       
	    }; 
	    return param; 
}

/**
* 翻页带查询参数及列排序
* @param url
* @param obj
* @param col
* @param uniqueId 行主键
* @param sortOrder 排序方式
* @param queryParams
* @author TKW
*/
function tableInit3( url,obj,col,uniqueId,sortOrder,queryParams){
	 obj.bootstrapTable({
		 url: path+url, // 请求后台的URL（*）
		 dataType: "json",
		 method: 'post', // 请求方式（*）
		
		 contentType: "application/x-www-form-urlencoded",
		 toolbar: '#toolbar',
		 toolbar: '#toolbar2',// 工具按钮用哪个容器
		 columns:  col,
		 striped: true, // 是否显示行间隔色
		 cache: false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		 pagination: true, // 是否显示分页（*）
		 sortable: true, // 是否启用排序
		 sortOrder: "asc", // 排序方式
		 sortOrder: sortOrder, // 排序方式
		 queryParamsType : "limit",// undefined/limit
		 queryParams: queryParams,//传递参数（*）
		 sidePagination: "server", //
		 
		 //分页方式：client客户端分页，server服务端分页（*）
		  pageNumber:1, //初始化加载第一页，默认第一页
		 pageSize: 10, //每页的记录行数（*）
		 pageList: [10, 25, 50, 100], // 可供选择的每页的行数（*）
		 search: false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		 strictSearch: true,//设置为 true启用 全匹配搜索，否则为模糊搜索
		 showColumns: true, // 是否显示所有的列
		 showRefresh: true, // 是否显示刷新按钮
		 minimumCountColumns: 2, // 最少允许的列数
		 //editable:true,//开启编辑模式 
		 clickToSelect: true, // 是否启用点击选中行
		 // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		 uniqueId: "ID", // 每一行的唯一标识，一般为主键列
		 uniqueId: uniqueId, // 每一行的唯一标识，一般为主键列
		 showToggle:true, // 是否显示详细视图和列表视图的切换按钮
		 cardView: false	, // 是否显示详细视图
		 detailView: false,// 是否显示父子表
	
			 }); 
	 

}



//获取ID
function getIdSelections() {
	return $.map($cusTable.bootstrapTable('getSelections'), function(row) {
		return row.contNo;
	});
}


$(function(){
	
	/*showLocation('loc_province-sub2','loc_city-sub2','loc_town-sub2');*/
	
	//showUser();
	
	
	
	$("#save").click(function() {
		//alert('save');
		//update();
	});
	
});


//查询
function showUser(a,b){

	$.ajax({
			type : "POST",
			url : path+"/LaqualiinfoController/selectBytypeAndinfo.do",// 后台请求URL地址
			data:"qualiinfo="+ a+"&qualifitype="+ b + "",    
			success : function(data) {
			
				var json=eval(data);
				alert(json[0].certificate);
				$("#qualiinfo").val(json[0].certificate); 
				$("#qualifitype").val(json[0].qualifitype); 
				$("#makedate").val(json[0].getmydate); 
				$("#maketime").val(json[0].maketime); 
							
			//选择				
			var select=document.getElementById("flag");
			for(var i=0;i<select.options.length;i++){
			if(select.options[i].innerHTML==json[0].flag){
			select.options[i].selected=true;
			break;
			
			}
			
			}
				
			},
			error : function() {
				alert("plus failed");
			}
	});
	
	

}


function selflag(mytype){
	$.ajax({
				type : "POST",
				url : path + "/LdcodeController/SelectByCodetype.do",// 后台请求URL地址
				data : "userCode="+mytype,
				success : function(data) {
				for(var i=0;i<data.length;i++){
					//创建option，给下拉框赋值
					var select=document.getElementById(mytype);
                  var option=document.createElement("option");
					option.value=data[i].code;
					option.innerHTML=data[i].codename;
					select.appendChild(option);
					
					}
					
					}
				
							});

}

function selflags(mytype){
	$.ajax({
				type : "POST",
				url : path + "/LdcodeController/SelectByCodetype.do",// 后台请求URL地址
				data : "userCode="+mytype,
				success : function(data) {
				for(var i=0;i<data.length;i++){
					//创建option，给下拉框赋值
					var select=document.getElementById(mytype);
                  var option=document.createElement("option");
					option.value=data[i].code;
					option.innerHTML=data[i].codename;
					select.appendChild(option);
					
					
					}
					
					}
				
	});

}



function selbytype(){
	
	var laqualiinfo=$('#laqualiinfo option:selected').val();//资质类型
	$.ajax({
				type : "POST",
				url : path + "/LdcodeController/SelectByCodetype.do",// 后台请求URL地址
				data : "userCode=laqualiinfo"+"&code="+laqualiinfo,
				success : function(data) {
				
					$("#type").val(data[0].codealias);
					
				}
					
					
				
							});

}