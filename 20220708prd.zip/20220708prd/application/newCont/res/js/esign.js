var filetype_jpg=".jpg,.jpeg";
var filetype_tif=".tif,.jpg";
var allPicture=".jpg,.jpeg,.tif,.tiff,.pdf";
var upload_valid_type={
	"JPG"	:".jpg,.jpeg" ,
	"TIF"   :".tif,.tiff" ,
	"PDF"   :".pdf"
};
var hiddenindex =[]; 

var url_sign= path+"/esign/fileupload.do";
var showdilog_esign;
var dropzoneParams_esgin ={
		url: url_sign,
	    addRemoveLinks: true,
	    method: 'post',
	    timeout:600000,
	    enctype:"multipart/form-data",
	    filesizeBase: 1000,
	    dictRemoveFile:"移除文件",
	    dictCancelUpload: "取消上传",
	    autoProcessQueue:false,
	    acceptedFiles: allPicture,
	    dictInvalidFileType: "仅支持"+filetype_tif+"类型文件上传.",
	    thumbnailWidth:100,
	    thumbnailHeight:100,
	    maxThumbnailFilesize:5,
//	    maxFiles:40,
	    maxFilesize:3,
	    uploadMultiple:true,
	    parallelUploads:100,
	    previewTemplate: document.querySelector('#preview-template_esign').innerHTML,
	    sendingmultiple: function(file, xhr, formData) {
	    	
	    	var contno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
	    	var insurancecom=vueobj["testdivchange"].formdata.newContApply.insurancecom;
	    	var transno =vueobj["testdivchange"].formdata.newContApply.transno;
	    	formData.append("filesize", file.size);
	        formData.append("contno", contno);
	        formData.append("transno", transno);
	        formData.append("insurancecom", insurancecom);
	        formData.append("formData", JSON.stringify(vueobj["testdivchange"].formdata));

	    },
	    init: function() {
	    	var closeEsignButton=document.querySelector("#closeEsign");
	        var submitButton = document.querySelector("#upFiles_esign");
	        var upstatus = true;
	        dropzoneObj = this;
	        
	        closeEsignButton.addEventListener("click", function() {
	        	dropzoneObj.removeAllFiles();
	        });
	        
	    	submitButton.addEventListener("click", function() {
	    		if(dropzoneObj.files!=null&&dropzoneObj.files!=""){
	    			showdilog_esign= layer.load(0, {
	   			  shade: [0.1,'#fff'] //0.1透明度的白色背景
	    		   });
	    		}
					dropzoneObj.processQueue(); 
	    	
			});
	    	
	    	this.on("canceled", function(file) {

	    	
	    	});
	    	
	    	this.on("addedfile",function(file){
	    		console.info("file.type : "  + file.type );
	    		setTimeout(function(){
	    			console.info(file.accepted);
	    			if(!file.accepted){   				
	    				upstatus=false;
	    				} 			
	    		!upstatus?$("#upFiles_esign").attr("disabled",true):$("#upFiles_esign").removeAttr("disabled");
	    		},10);
//	    		if(file.type!="image/tiff")upstatus=false;
//		    	!upstatus?$("#upFiles").attr("disabled",true):$("#upFiles").removeAttr("disabled");
	    	});
	    	
	    	this.on("removedfile", function(file) {

//	    		if(uploadData!=""){
//	        		$.ajax({
//	        			url:path+"/contUploadController/removeUpDoc.do",
//	        			type:"POST",
//	        			data:{"upcode":uploadData.map.upcode,
//	        				  "contno":uploadData.map.contno},
//	        			success:function(data){
//	        				uploadData="";
//	        				var _ref;
//	        				var reg=/ /g;
//	        				if(data.parm == 'undefined' || data.parm == undefined){
//	                            alert("Time out,please login again!");
//	                        }else{
//	                            alert("系统成功"+data.parm);
//	                        }
	//
//	        				//移除当前页面所有上传的文件元素
//	        				return (_ref = file.previewElement) != null ? _ref.className!=null?$("."+_ref.className.replace(reg,'.')).remove():void 0 : void 0;
//	        			},
//	        			error:function(data){
//	        				console.log(data);
//	        			}
//	        		});
//	    		}else{
	    			var _ref;
	    			//仅移除单个文件
	    			(_ref = file.previewElement) != null ? _ref.parentNode!=null?_ref.parentNode.removeChild(file.previewElement):void 0 : void 0;
	        		
	    			var upfiles = this.files;
	    	    	var len = 0;
	    	    	var check = 0;
	    	    	for(var j = 0,len=upfiles.length; j < len; j++) {
	    	    		if(upfiles[j].accepted)check++;
	    	    	}
	    	    	
	    	    	if(len==check)upstatus=true;
	    	    	
	    	    	!upstatus?$("#upFiles_esign").attr("disabled",true):$("#upFiles_esign").removeAttr("disabled");
//	    		}

			}); 
	    	
	    	this.on("successmultiple", function(file, response, e){
	            
	    		var reg=/ /g;
				var _ref;
				var dropzoneObj =this;
				var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
				var insurancecom=vueobj["testdivchange"].formdata.lccont.insurancecom;
				(_ref = file[0].previewElement) != null ? _ref.className!=null?$("."+_ref.className.replace(reg,'.')).remove():void 0 : void 0;
				
				uploadData=response.success?response:"";
				this.files.length=0;
	            var resultMsg = response.msg;
	            console.log("++++"+response.msg+"******");
	            if(resultMsg == 'undefined' || resultMsg == undefined){
	                alert("Time out,please login again!");
	                layer.close(showdilog);
	            }else{
	                layer.close(showdilog);
					if(response.success){
						$("#esing_table").bootstrapTable('refresh');
						//成功后处理
						$("#myModal_esign").modal('hide');
					}
	                if(response.parm=="Y"){
	                	var confirmStr="<br/>点击<span style='color:red;'>确认</span>后，文件将即刻发送给保险公司。<br/>"+
							"点击<span style='color:red;'>取消</span>后，可重新上传文件后再点击<span style='color:red;'>再次发送投保文件</span>按钮进行发送。";
						layer.confirm(response.msg+confirmStr, {
							btn: ['确认','取消'], //按钮
							title:"系统提示",
						}, function(confirmCloseIndex){
							layer.close(confirmCloseIndex);
							//发送文件到保险公司
							sendToWdcAgain();
						});
					}else{
						layer.alert(response.msg,{title:"系统提示"});
					}
	            }
			});
	    	this.on("completemultiple",function(){
	    		try {
	    			layer.close(showdilog_esign);
				} catch (e) {
					// TODO: handle exception
				}
	   		 
	   	    }); 
//	    	this.on("maxfilesreached",function(){
//	    		alert("文件数量达到最大数量,请确认上传的文件. ");
//	    	});    	  	
	  }
	    
	};

var  create

window.actionEvents = {
    //投保单复制
 
		
		
	'click .create': function (e, value, row, index) {
		
		try {
			printPol_anzl(row);
			$("#esing_table").bootstrapTable('refresh');
		} catch (e) {
			// TODO: handle exception
			alert("打印遇到问题，如果之前有生成或打印投保单，请将之前打开的投保单页面关闭");
		}
		
	    	
	},
    'click .addOrUpdate': function (e, value, row, index) {
    	var  esignBeanData  = encodeURIComponent(JSON.stringify(row));
    	//check 状态 需求不敢
    	openIframe(row.esignaturelogic.filedesc,
    			path+row.esignaturelogic.pageuri+"?esignBean="+esignBeanData);
    	
    },
    'click .updatefile': function (e, value, row, index) {
		let context ='上传后，之前上传的文件将被覆盖，本次的文件将作为最终文件发送保险公司。请确认。';
		let totalflag = row.lcconteform.totalflag;
		let filetypeCode = row.esignaturelogic.filetypecode;
		if( totalflag != 2 && (filetypeCode.indexOf("INS-1163-1") != -1 || filetypeCode.indexOf("INS-1163-2") != -1 || filetypeCode.indexOf("INS-1163-3") != -1
		||filetypeCode.indexOf("INS-INSH-6009-1") != -1 || filetypeCode.indexOf("INS-INSH-6009-2") != -1 || filetypeCode.indexOf("INS-INSH-6009-3") != -1 )){
			layer.confirm(context, {
				btn: ['确认','取消'], //按钮
				title:"系统提示",
				closeBtn:false
			}, function(confirmIndex){
				layer.close(confirmIndex);
				if($("#upfilezone_esign")[0].dropzone==undefined){
					$("#upfilezone_esign").dropzone(dropzoneParams_esgin);
				}
				//只支持多种类型
				if(row.esignaturelogic.filetype){
					$("#upfilezone_esign")[0].dropzone.options.acceptedFiles=row.esignaturelogic.filetype;
					$("#upfilezone_esign")[0].dropzone.options.dictInvalidFileType
						= "仅支持"+row.esignaturelogic.filetype + "类型文件上传.";
				}

				var  formdate = vueobj["testdivchange"].formdata;
				$("#upfilezone_esign")[0].dropzone.options.url= url_sign
					+"?"+"esignBean="+encodeURIComponent(JSON.stringify(row));

				$("#myModal_esign").modal('show');

			});
		}else {
			if($("#upfilezone_esign")[0].dropzone==undefined){
				$("#upfilezone_esign").dropzone(dropzoneParams_esgin);
			}
			//只支持多种类型
			if(row.esignaturelogic.filetype){
				$("#upfilezone_esign")[0].dropzone.options.acceptedFiles=row.esignaturelogic.filetype;
				$("#upfilezone_esign")[0].dropzone.options.dictInvalidFileType
					= "仅支持"+row.esignaturelogic.filetype + "类型文件上传.";
			}

			var  formdate = vueobj["testdivchange"].formdata;
			$("#upfilezone_esign")[0].dropzone.options.url= url_sign
				+"?"+"esignBean="+encodeURIComponent(JSON.stringify(row));

			$("#myModal_esign").modal('show');
		}
},
    'click .viewfile': function (e, value, row, index) {
    	
    	
    	if(row.lcconteform.localfilename){
    		
    		//开户系统上传过来得证件照，只能进行下载后进行预览
    		var filea=row.lcconteform.filetypecode;
    		var grops=row.esignaturelogic.groups;
    		var insufilecode = row.esignaturelogic.insufiletypecode;
    		if((filea.indexOf("INS-1163-1")!=-1&&grops!=""&&grops!=null)||
    				(filea.indexOf("INS-INSH-6009-1")!=-1&&grops!=""&&grops!=null)){
    				alert("请下载后进行预览！");
//    			}
    		} else {
			if((row.lcconteform.filetypecode.indexOf("1153-1")!=-1)&&
					  (row.esignaturelogic.insufiletypecode.indexOf("1153")!=-1)&&
					   row.esignaturelogic.channel=='RS'){
				$.ajax({
					type:"POST",
					url:path+"/queryFlileStatus/updateConfirmFlag.do?transno="+initFormdata.newContApply.transno,
					timeout:60000,
					async:false,
					success:function(data){
					if(data.success){
						$("#esing_table").bootstrapTable('refresh');
					}else{
						alert(data.msg);
					}	
													  
					  },
					error:function(){
						console.log(e);
					}
				});
			}
    			
    		var urlpdf= path +"/signatureBase/printSignature.do?filePath="+row.lcconteform.localfilename;
    		
        	
        	if (!!window.ActiveXObject || "ActiveXObject" in window){
    				//ie
        			window.open('javascript:window.name;', '<script>window.location.replace("'+urlpdf+'")<\/script>');
    			}else{
    				//google
    				 window.open(urlpdf,"_blank");
    			}
    		}
    	}else{
    		alert("请先录入该信息或者上传该文件");
    	}
    	 //  打印或者预览
    }
    ,
'click .download': function (e, value, row, index) {
    	
	var transno=vueobj["testdivchange"].formdata.lccont.transno;
	var logicid=row.esignaturelogic.logicid;
    	if(row.lcconteform.localfilename){
    		if(row.lcconteform.totalflag<5 && (row.esignaturelogic.filetypecode.indexOf("INS-1163-1")!=-1
				||row.esignaturelogic.filetypecode.indexOf("INS-INSH-6009-1")!=-1)){
					var lcconteformBean = encodeURIComponent(JSON.stringify(row.lcconteform));
					openIframe_test("查阅并选择影像件", path + "/application/newCont/jsp/idpictureDisplay.jsp?lcconteformBean=" + lcconteformBean);
				}else{
    		var urlpdf= path +"/esign/esigntable/filedownload.do?filePath="+row.lcconteform.localfilename+"&logicid="+logicid+"&transno="+transno;
    		
    		window.open(urlpdf,"_blank");
    		$("#esing_table").bootstrapTable('refresh');
					}
    	}else{
    		if(row.lcconteform.totalflag<5 && (row.esignaturelogic.filetypecode.indexOf("INS-1163-1")!=-1
				||row.esignaturelogic.filetypecode.indexOf("INS-INSH-6009-1")!=-1)){
					var lcconteformBean = encodeURIComponent(JSON.stringify(row.lcconteform));
					openIframe_test("查阅并选择影像件", path + "/application/newCont/jsp/idpictureDisplay.jsp?lcconteformBean=" + lcconteformBean);
    		}else{
    		alert("请先录入该信息或者上传该文件");
    		}
    	}
    	 //  打印或者预览
    }
    ,
'click .confirms': function (e, value, row, index) {	
    if(confirm("确认使用自动获取的文件？")){
    	if(row.lcconteform.downloadflag !="Y"){
    		alert("请先下载预览此文件内容后再点击确认！");
    		return;
    	}
    	var transNo =vueobj["testdivchange"].formdata.newContApply.transno;
    	if(row.lcconteform.filetypecode && transNo){
    	$.ajax({
		type : "POST",
		url:path+'/esign/esigntable/confirms.do',
		data : {
        	"transNo":transNo,
        	"filetypecode":row.lcconteform.filetypecode,
        	"logicid":row.esignaturelogic.logicid,
        					},
        	dataType : "json",
		 	success:function(data){
			        try{
			        	if(data){
			        		 if(data==1){
			        			 alert("确认成功!");
			        			 $("#esing_table").bootstrapTable('refresh');
					         }
			        	}else{
			        		alert("确认失败!");
			        	}
			        }catch(e){
			        	console.log(e);		        	
			        }
		           
				},
				error:function(){
					alert("确认失败了!");
				}
		  });
    	}else{
    		alert("请先录入该信息或者上传该文件");
    	}   	
    }   
}
    ,
'click .photograph': function (e, value, row, index) {
	var insurancecom=vueobj["testdivchange"].formdata.newContApply.insurancecom;
	var transNo =vueobj["testdivchange"].formdata.newContApply.transno;
	var filetypecode=row.lcconteform.filetypecode;
	var logicid=row.esignaturelogic.logicid;
	var lcinsuredTwo=vueobj["testdivchange"].formdata.lcinsuredtwo;
	var num="";
	if(!isEmpty(lcinsuredTwo.transno)){
		num=num+1;
	}
	var lcinsureds=Number((vueobj["testdivchange"].formdata.lcinsuredmulti.length))+Number(num)+Number(1);	
	var bnfs=vueobj["testdivchange"].formdata.bnf.length;
//	var arg ='transNo='+transNo+',insurancecom='+insurancecom+',filetypecode='+filetypecode;
	var arg =transNo+','+insurancecom+','+filetypecode+','+logicid;
	var filea=row.lcconteform.filetypecode;
	var grops=row.esignaturelogic.groups;
	if((filea.indexOf("INS-1163-1")!=-1&&grops!=""&&grops!=null)||
			(filea.indexOf("INS-INSH-6009-1")!=-1&&grops!=""&&grops!=null)){

		openIframe("证件拍照",path+"/application/newCont/jsp/camera.jsp?"+arg+'&'+1);
	}
	if((filea.indexOf("INS-1163-2")!=-1&&grops!=""&&grops!=null)||
			(filea.indexOf("INS-INSH-6009-2")!=-1&&grops!=""&&grops!=null)){

		openIframe("证件拍照",path+"/application/newCont/jsp/camera2.jsp?"+arg+'&'+lcinsureds);
	}
	if((filea.indexOf("INS-1163-3")!=-1&&grops!=""&&grops!=null)||
			(filea.indexOf("INS-INSH-6009-3")!=-1&&grops!=""&&grops!=null)){

		openIframe("证件拍照",path+"/application/newCont/jsp/camera3.jsp?"+arg+'&'+bnfs);
	}
    },
'click .signature': function (e, value, row, index) {
   	 
	 var customerId=vueobj["testdivchange"].formdata.lccont.grpcontno;
	 var staffId=vueobj["testdivchange"].formdata.lccont.operator;
	 var transno= row.lcconteform.id.transno;
	 var tokenId=vueobj["testdivchange"].formdata.newContApply.tokenId;
	 var channl = row.esignaturelogic.channel;
	 var filea=row.lcconteform.filetypecode;
	 var logicid=row.esignaturelogic.logicid;
	 var proposalcontno =vueobj["testdivchange"].formdata.newContApply.proposalcontno;
	 var filepath =row.lcconteform.localfilename;	 
	 var insurance = row.esignaturelogic.insurance;
	 if(channl=='RS'){
		 let url = path + "/qrCodeController/generateSignatureQRcode.do?customerId=" + customerId
			+"&staffId=" + staffId + "&transno=" + transno+"&h5filetypecode="+filea
			+"&h5logicid="+logicid+"&h5proposalcontno="+proposalcontno+"&h5filepath="+filepath
			+"&insurance="+insurance;
               if(tokenId != "" && tokenId!= null){
                       url += "&tokenId=" +tokenId;
				}
				openH5Iframe("人身投保提示书签字", url);	
				}
         }
     };
var col_lccont=[{
    checkbox: true
}, {
    field : 'lccont.proposalcontno',
    title : '投保单号'
}, {
    field : 'lccont.grpcontno',
    title : '客户姓名'
}, {
    field : 'lccont.appflag',
    title : '状态' 
},{
    field : 'lccont.riskcode',
    title : '产品代码' ,
    visible : true
}];


var col_esignTable = [
			{
			    field : 'esignaturelogic.groups',
			    title : '文件类型',
			    formatter: esignFileGroup
			},{
               field : 'esignaturelogic.filedesc',
               title : '文件名' ,
               formatter: filedescFormatter
           },{
			    field : 'esignaturelogic.filetype',
			    title : '文件格式' 
			},{
               field : 'lcconteform.totalflag',
               title : '文件状态', 
               formatter: esignStatusFormat
           },{
               title: '操作',
               align: 'center',
               formatter: actionFormatter,
               events: actionEvents/*,
               switchable: false*/
           }];
 
   
$(function() {
    
	esignTable();
});
function esignTable(forceUpdateflag){
	
	 var url_d = "/esign/esigntable/init/"+initFormdata.newContApply.insurancecom+"/"+initFormdata.newContApply.transno+".do?riskcode="+initFormdata.newContApply.riskcode;
	 if(forceUpdateflag){
		 url_d =url_d+"&forceUpdateflag=Y"
	 }
	 $('#esing_table').bootstrapTable('destroy');
	 tableInitEsign(url_d, $('#esing_table'), col_esignTable);
}
 
var queryFileStatusTimer=null;
function tableInitEsign(url, obj, col_esignTable,  queryParams) {
    obj.bootstrapTable({
        url : path + url, // 请求后台的URL（*）
        dataType : "json",
        method : 'GET', // 请求方式（*）
        contentType : "application/x-www-form-urlencoded",
        columns : col_esignTable,
        toolbar : '#Tabletoolbar',
//        striped : true, // 是否显示行间隔色
        cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        rowStyle:function(row,index){
        	if((((row.esignaturelogic&&row.esignaturelogic.delayuploadflag=="1"&&vueobj["testdivchange"].formdata.lccontTemp&&vueobj["testdivchange"].formdata.lccontTemp.eSignFlag=="E")
        		||(row.esignaturelogic&&row.esignaturelogic.delayuploadflag=="1"&&vueobj["testdivchange"].formdata.lccontTemp&&vueobj["testdivchange"].formdata.lccontTemp.eSignFlag=="S")
        		||(row.esignaturelogic&&row.esignaturelogic.delayuploadflag=="1"&&vueobj["testdivchange"].formdata.lccontTemp&&vueobj["testdivchange"].formdata.lccontTemp.eSignFlag=="P"
        			&&row.esignaturelogic&&row.esignaturelogic.groups!="3")
        		||(row.esignaturelogic&&(row.esignaturelogic.filetypecode=="INS-INSH-1153-4"||row.esignaturelogic.filetypecode=="INS-INSH-1153-5"
        			||row.esignaturelogic.filetypecode=="INS-ALZ-1153-6"||row.esignaturelogic.filetypecode=="INS-ALZ-1153-7"
            		||row.esignaturelogic.filetypecode=="INS-ALZ-1153-8"||row.esignaturelogic.filetypecode=="INS-ALZ-1153-9"))
        		||(row.esignaturelogic&&row.esignaturelogic.uploadflag=="2"&&vueobj["testdivchange"].formdata.lccontTemp&&vueobj["testdivchange"].formdata.lccontTemp.eSignFlag=="P"))
        		&&(row.lcconteform&&(row.lcconteform.totalflag=="1"||row.lcconteform.totalflag=="0"||row.lcconteform.totalflag=="2")))
        		||(row.esignaturelogic&&row.esignaturelogic.channel=="RS"&&row.esignaturelogic.signYorN=='Y'
        			&&row.lcconteform&&row.lcconteform.totalflag<6)
        		||(row.esignaturelogic&&vueobj["testdivchange"].formdata.lccontTemp&&vueobj["testdivchange"].formdata.lccontTemp.eSignFlag=="P"&&row.esignaturelogic.paperUploadFlag=='0'
        			&&row.lcconteform.paperUploadFlag!='Y')	
        		){
        		return {css:{"background-color":"#FFFF99"}};
        	}else if(row.esignaturelogic&&row.esignaturelogic.delayuploadflag=="2"
        		&&(row.lcconteform&&(row.lcconteform.totalflag=="1"||row.lcconteform.totalflag=="0"||row.lcconteform.totalflag=="2")&&
        				vueobj["testdivchange"].formdata.lccontTemp&&vueobj["testdivchange"].formdata.lccontTemp.eSignFlag!="P")
        		){
            		return {css:{"background-color":"#99FF99"}};
            	}
        	return "";
        },
        showColumns : true, // 是否显示所有的列
        showRefresh : true, // 是否显示刷新按钮
//        minimumCountColumns : 2, // 最少允许的列数
//        clickToSelect : true, // 是否启用点击选中行
        // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
        // uniqueId: "ID", // 每一行的唯一标识，一般为主键列
        uniqueId : "esignaturelogic.logicid", // 每一行的唯一标识，一般为主键列
        showToggle : true, // 是否显示详细视图和列表视图的切换按钮
        cardView : false, // 是否显示详细视图
        detailView : false,
        onPreBody:function(){
        	if(document.getElementsByName("refresh")&&document.getElementsByName("refresh").length>0){
        		if(vueobj["testdivchange"].formdata.lccontTemp&&vueobj["testdivchange"].formdata.lccontTemp.eSignFlag){
        			document.getElementsByName("refresh")[0].style.display='inline';
        			document.getElementsByName("refresh")[0].innerHTML
            		='<i class="glyphicon glyphicon-refresh icon-refresh"></i>  请按刷新按钮刷新文件状态';
        		}else{
        			document.getElementsByName("refresh")[0].style.display='none';
        		}
        		
        	}
        },
        onLoadSuccess: function(data){   
        	for(var i=0;i<hiddenindex.length;i++){
        		$("#esing_table").bootstrapTable('hideRow', {index: hiddenindex[i]});
        	}
        	hiddenindex = [];
        	
        	if(data){
        	//自动打印
	    		try {
	    			
	    				
	    				for(var i=0;i<data.length;i++){
	    					if(data[i].esignaturelogic
	    					   &&"4"==data[i].esignaturelogic.infoenterflag
	    					   &&data[i].lcconteform&&"0"==data[i].lcconteform.totalflag
	    					   &&vueobj["testdivchange"].formdata.lccontTemp){
	    					   if(autoPrintLccont(data[i])){
	    						  $("#esing_table").bootstrapTable('refresh');
	    					   }
	    	        		
	    					}
	    				}
	    			
	    			
	    		} catch (e) {
	    			// TODO: handle exception
	    			alert("打印遇到问题，如果之前有生成或打印投保单，请将之前打开的投保单页面关闭");
	    		}
	    		
	    		var esignFlag=vueobj["testdivchange"].formdata.lccontTemp&&(vueobj["testdivchange"].formdata.lccontTemp.eSignFlag=="E"||vueobj["testdivchange"].formdata.lccontTemp.eSignFlag=="S");
	    		if(esignFlag){
		    		for(var j=0;j<data.length;j++){
		    			if((data[j].esignaturelogic.filetypecode=="GEN-RPQ"&&data[j].lcconteform.totalflag<9)
		    			 ||(data[j].esignaturelogic.filetypecode=="GEN-FPR"&&data[j].lcconteform.totalflag<9)){
		    				//页面轮询 查询FPR RPQ文件是否签名
		    				queryFileStatusTimer=setInterval("queryFileStatus()",12000);
		    				break;
		    			}
		    		}
	    		}
    		
			}
    		
    		
        	
        }
        
    });
};


function queryFileStatus(){
	
	$.ajax({
		type:"GET",
		url:path+"/queryFlileStatus/query.do?transno="+initFormdata.newContApply.transno,
		timeout:60000,
		async:false,
		success:function(data,textStatus){
			        try{
			        	if(data){
			        		 if(data==2){
					            	clearInterval(queryFileStatusTimer);
					            	$("#esing_table").bootstrapTable('refresh');
					         }
			        	}else{
			        		clearInterval(queryFileStatusTimer);
			        	}
			        }catch(e){
			        	console.log(e);
			        	clearInterval(queryFileStatusTimer);
			        }

				},
				error:function(){
					clearInterval(queryFileStatusTimer); 
				}
			  });
    
}

function checkEnterButton(row,paperflag){
	
	if(row.esignaturelogic){
				
		if(vueobj["testdivchange"].formdata.lcnotConclusion&&(vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="F"
			||vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="Y")){
			return false; 
		}
		
		if(row.lcconteform.totalflag>=6){
			
			return false; 
		}
		if(row.esignaturelogic.infoenterflag=='0'){
			return true;
		}
		
	}
	
	
	
	return false;
}



function checkViewButton(row,paperflag){
	
	
	if(row.esignaturelogic){
		
		//开户系统上传过的的rules，显示预览和下载按钮
		var filea=row.lcconteform.filetypecode;
		var grops=row.esignaturelogic.groups;
		if((filea.indexOf("INS-1163-1")!=-1&&grops!=""&&grops!=null)||
				(filea.indexOf("INS-INSH-6009-1")!=-1&&grops!=""&&grops!=null)){
			if((vueobj["testdivchange"].formdata.lcnotConclusion&&(vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="F"
				||vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="Y"))){
				return false; 
			}
			if(row.lcconteform.totalflag<5 && (vueobj["testdivchange"].formdata.lccont.eSignFlag!="P")){
				return true;
			}
		}
		if(row.lcconteform.filetypecode!="GEN-RPQ"&&row.lcconteform.filetypecode!="GEN-FPR"){
			if(row.lcconteform.localfilename!=null&&(row.lcconteform.localfilename.indexOf("pdf")+3==row.lcconteform.localfilename.length)
			&&!(row.esignaturelogic.signflag=="0"&&row.esignaturelogic.sendtoinsu=="2"&&row.lcconteform.totalflag>6)){
				return true ; 
			}
		}else{
			//if(!paperflag){
				//电子签  RPQ FPR 文件签完名  显示预览和下载按钮
			if(row.esignaturelogic.uploadflag == '1'){
				if(row.lcconteform.totalflag>=9||row.lcconteform.totalflag==3){
					return true;
				}
			}
			//}
		}
		
	}
	
	return false;
}


function checkCreateButton(row,paperflag){
	
	if(row.esignaturelogic){
		
		if(row.lcconteform.totalflag>=6){
			return false; 
		}
		
		if(row.esignaturelogic.infoenterflag=='4'){
			return true;
		}
	}
	
	return false;
}

function checkUploadButton(row,paperflag){
	if (row.esignaturelogic) {
		if(vueobj["testdivchange"].formdata.lcnotConclusion&&(((vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="F"
			||vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="Y")&&row.esignaturelogic.delayuploadflag!='2'))
			||(vueobj["testdivchange"].formdata.lccontTemp.uploadAgainFlag=="Y"&&!isEmpty(vueobj["testdivchange"].formdata.lccontTemp.secondSend)&&row.esignaturelogic.delayuploadflag=='2')
			||((vueobj["testdivchange"].formdata.lccontTemp.secondSend=="Y"||vueobj["testdivchange"].formdata.lccontTemp.secondSend=="N")&&row.esignaturelogic.delayuploadflag=='2')
			||(((vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="F"
				||vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="Y")&&isEmpty(vueobj["testdivchange"].formdata.lccontTemp.uploadAgainFlag))
				&&row.esignaturelogic.delayuploadflag=='2')){
			return false;
		}
		// 纸质需要上传
		if (paperflag && row.esignaturelogic.paperUploadFlag == '0'&&row.lcconteform.paperUploadFlag!='Y') {
			return true
		}
			
		if(row.lcconteform.totalflag>=6){
			return false; 
		}
		
		if ((!paperflag)&&row.esignaturelogic.uploadflag == '0') {
			return true;
		}
		
		if ((paperflag)&&row.esignaturelogic.uploadflag == '0') {
			return true;
		}

		//纸质需要签署的上传 ，此处后面讨论后不需要，所有纸质上传走原有流程
//		if (paperflag && row.esignaturelogic.signflag == '0') {
//			return true
//		}
		
		
		
		
	}
	return false;
	
}
function checkConfirmButton(row,paperflag){
	if(row.esignaturelogic){
		if(vueobj["testdivchange"].formdata.lcnotConclusion&&(vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="F"
			||vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="Y")){
			return false; 
		}
		if(row.lcconteform.localfilename){
		var filea=row.lcconteform.filetypecode;
		var grops=row.esignaturelogic.groups;
		if((filea.indexOf("INS-1163-1")!=-1&&grops!=""&&grops!=null)||
				(filea.indexOf("INS-INSH-6009-1")!=-1&&grops!=""&&grops!=null)){
			if(row.esignaturelogic.elexpression.indexOf("#formData.lccont.kaihuFlag=='Y'")!=-1
					&& row.lcconteform.totalflag=="2"){
				return false;
			}
		
		}
	}else{
		return false;
	}
	}
	return false;
}
function checkPhotographButton(row,paperflag){
	if(row.esignaturelogic){
		if(vueobj["testdivchange"].formdata.lcnotConclusion&&(vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="F"
			||vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="Y")){
			return false; 
		}
		var filea=row.lcconteform.filetypecode;
		var grops=row.esignaturelogic.groups;
		if((filea.indexOf("INS-1163-")!=-1)||
				(filea.indexOf("INS-INSH-6009")!=-1)){
			//法定受益人不显示
//			if((filea.indexOf("INS-1163-3")!=-1)||
//					(filea.indexOf("INS-INSH-6009-3")!=-1)){
//			var bnfs=vueobj["testdivchange"].formdata.bnf.length;
//			if(bnfs<2){
//				return false;
//			}
//			}
			if(row.lcconteform.totalflag<6 && (vueobj["testdivchange"].formdata.lccont.eSignFlag!="P")){
				return false;
			}
		
		}
	}
	return false;
}
function checkSignatureButton(row,paperflag){
	if(row.esignaturelogic){
		if(vueobj["testdivchange"].formdata.lcnotConclusion&&vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag!="U"){
			return false; 
		}
		var filea=row.lcconteform.filetypecode;
		var insufilecode = row.esignaturelogic.insufiletypecode;
		var channl = row.esignaturelogic.channel;
		if((filea.indexOf("1153-1")!=-1)&&(insufilecode.indexOf("1153")!=-1)&&channl=='RS'){
			return true;		
		}
	}
	return false;
}
function filedescFormatter(value, row, index) {
	 
	if(row.esignaturelogic&&row.esignaturelogic.filenametail){
		return value +row.esignaturelogic.filenametail;
	}
	return value ;
}


function actionFormatter(value, row, index) {
	//统计列数，此数列为倒数excel时应除去的列数
	//	numberX[0]  = parseInt($("tr:first")[0].childElementCount) - 1 ;
	//操作列添加按钮
	if (row.esignaturelogic) {

		var paperflag = vueobj["testdivchange"]
				&& vueobj["testdivchange"].formdata
				&& vueobj["testdivchange"].formdata.lccont
				&& vueobj["testdivchange"].formdata.lccont.eSignFlag == "P";
		var enterButtonFlag = checkEnterButton(row, paperflag);
		var viewButtonFlag = checkViewButton(row, paperflag);
		var uploadButtonFlag = checkUploadButton(row, paperflag);
		var confirmButtonFlag = checkConfirmButton(row, paperflag);
		var photographButtonFlag = checkPhotographButton(row, paperflag);
		var signatureButtonFlag = checkSignatureButton(row, paperflag);
		//var createFlag = checkCreateButton(row, paperflag);
		var enterButton =  '<button type="button"  class="btn addOrUpdate">录入/修改</button>';
		var viewButton =   '<button type="button"  class="btn viewfile">预览</button><button type="button"  class="btn download">下载</button>';
		var viewButtonRS =   '<button type="button"  class="btn viewfile">预览确认</button><button type="button"  class="btn download">下载</button>';
		var viewButtonLcappnt =   '<button type="button"  class="btn download">从文件中心导入</button>';
		var uploadButton = '<button type="button"  class="btn updatefile">上传</button>';
		var createButton = '<button type="button"  class="btn create">生成</button>';
		var confirmButton = '<button type="button"  class="btn confirms">确认使用此影像件</button>';
		var photographButton = '<button type="button"  class="btn photograph">拍照</button>';
		var signatureButton = '<button type="button"  class="btn signature">签名</button>';
		if (row.esignaturelogic.uploadflag == '0') {

		}
		var buttonStr = "";
		/*if (createFlag) {
			buttonStr = buttonStr + createButton;
		}*/
		if (signatureButtonFlag) {
			buttonStr = buttonStr + signatureButton;
		}
		if (enterButtonFlag) {
			buttonStr = buttonStr + enterButton;			
		}
		if (viewButtonFlag) {
			//如果是投保人就显示下载预览按钮,非投保人显示 预览、下载两个按钮
			 if(row.esignaturelogic.filetypecode.indexOf("INS-1163-1")!=-1
					 ||row.esignaturelogic.filetypecode.indexOf("INS-INSH-6009-1")!=-1){				 
				 buttonStr = buttonStr + viewButtonLcappnt; 
			 }else if((row.lcconteform.filetypecode.indexOf("1153-1")!=-1)&&
					  (row.esignaturelogic.insufiletypecode.indexOf("1153")!=-1)&&
					   row.esignaturelogic.channel=='RS'){
				 buttonStr = buttonStr + viewButtonRS;
			 }else{
				 buttonStr = buttonStr + viewButton;
			 }
			
		}
		if (confirmButtonFlag) {
			buttonStr = buttonStr + confirmButton;
		}
		if (photographButtonFlag) {
			buttonStr = buttonStr + photographButton;
		}
		if (uploadButtonFlag) {
			buttonStr = buttonStr + uploadButton;
		}
		
		return [ buttonStr ].join('');

	}
	
	return "";
}


/**
 * 发送到WDC 进行电子签名
 */
function sendToWdc(){
	var showdilog= layer.load(2, {
		  shade:0.3, //0.2透明度的白色背景
	 });
	setTimeout(function(){
    	layer.close(showdilog);   	
    	if(vueobj["testdivchange"].formdata.lccont.commonchannel=="RS"){
    		var context="<span style='color:red;'>【销售人员请和客户确认】：</span></br>" +
                        "<span>此投保申请即将加入您的手机银行购物车。请您知晓，您在购物车确认其他投保文件，确认购买此保险产品后，您的签名也会运用于您确认的所有文件。</span></br>"+
                        "<span>您可在”手机银行-银行服务-文件中心-投资保险文件”项下查看您已确认的文件。<span></br>" +
                        "请问您是否确认？<span style='color:red;'>（需客户肯定回答）</span>";
    		layer.confirm( context, {
	  			  btn: ['确认','取消'], //按钮
	  			  title:"系统提示",
	  			  area:["450px","295px"],
	  			  closeBtn:false
	  			}, function(confirmIndex){
	  				layer.close(confirmIndex);
	  				 confirmRsSign();
	  				}, function(){
	  					return;
	  				});	   		   		   		
    	}else{
    		confirmRsSign();
    	}			
	},500);
	
}

function confirmRsSign(){
	if(vueobj["testdivchange"].formdata.lccont
			&&vueobj["testdivchange"].formdata.lccont.insurancecom=="ANZL"		
			&&(vueobj["testdivchange"].formdata.lccont.commonchannel=="SC"||vueobj["testdivchange"].formdata.lccont.commonchannel=="RS")
			&&(vueobj["testdivchange"].formdata.lcpol.conttype=="01"||vueobj["testdivchange"].formdata.lcpol.conttype=="02"||vueobj["testdivchange"].formdata.lcpol.conttype=="08")){
				$.ajax({
			        type : "POST",
			        url:path+'/newContEnter/selecyCityByComCode.do',// 后台请求URL地址
			        data : {
			        	"comcode":vueobj["testdivchange"].formdata.lccont.managecom,
			        	"method":vueobj["testdivchange"].formdata.lcpol.insuyear,
			        	"flag":vueobj["testdivchange"].formdata.lcpol.insuyearflag,
			        	"appntBirthday":vueobj["testdivchange"].formdata.lcappnt.appntbirthday,
			        },
			        dataType : "json",
			        success : function(data) {
			        	layer.close(showdilog);
			        	if(data.success){
			        		//四川&&一年期以上
			        	    if("510100"==data.parm&&data.total>1){
			        	    	 //提示框
			        	    	confirmFuc();
			        	    }else{
			        	    	//直接发送
			        	    	sendToWdcControl();
			        	    }
			        	}else{
			        		layer.alert(data.msg);
			        	}
			        },
			        error:function(e){
			        	console.log(e);
			        	layer.alert("系统异常！");
			        }
			    });
			}else{
				//直接发送
				sendToWdcControl();
			}
	
}

function confirmFuc(){
	//询问框
	var timer ="";
	layer.confirm("<input type='checkbox' id='isRead' style='height:17px;width:17px;vertical-align:middle'/>本人已经向投保人详细讲解保险条款、提示相关风险，并确保投保人、被保险人信息与实际情况相符。", {
	  title:"系统提示",
	  btn: ['确认'], //按钮
	  success: function(layero){
	  	$(':focus').blur();
	  	//title
	  	layero.find(".layui-layer-title")[0].style.fontSize="16px";
	  	//content
	  	layero.find(".layui-layer-content")[0].style.fontSize="17px";
	  	//btns
		var btn=layero.find(".layui-layer-btn0")[0];
		
	    //10秒倒计时
	    var index = 3;
	    // 按钮文字为确认(10)
	    btn.innerHTML = "确认("+index+")";
	    btn.style.pointerEvents="none";
		btn.style.color="#8D8D8D";
		btn.style.backgroundColor="#FBFBFB";
		btn.style.border="1px solid #e6e6e6";
		btn.style.opacity="1";
		$("#isRead").click(function(){
			if($("#isRead").prop("checked")){
			    // 定时器，延迟 1s
			        timer = setInterval(function () {
			        // 倒计时 --，值也跟着改变
			        index--;
			        btn.innerHTML = "确认("+index+")";
			        // 当倒计时等等为0时
			        if (index == 0) {
			         // 停止计时
			         clearInterval(timer);
			         // 按钮禁用取消
			         btn.style.pointerEvents="";
					 btn.style.color="#fff";
				     btn.style.backgroundColor="#1E9FFF";
					 btn.style.borderColor="#1E9FFF";
			         // 将文字重置
			         btn.innerHTML = '确认';
			         //复选框禁用
			         $("#isRead").attr("disabled",true);
			         
			        }
			    }, 1000); 
			}else{
				clearInterval(timer);
			}
		});
	  },
	  cancel: function(cancelIndex, layero){
	  	 //右上角的X图标关闭事件  停止定时器
		  clearInterval(timer);
	     return true; 
	  }    
	}, function(confirmIndex){
	   layer.close(confirmIndex);
	   //点了确认按钮以后再发送
	   sendToWdcControl();
	});
}

function  sendToWdcControl(){
	       if(vueobj["testdivchange"].formdata.anzlRiskEvaluationNb
			   &&vueobj["testdivchange"].formdata.anzlRiskEvaluationNb.row7.radio=="0"
			   &&!vueobj["testdivchange"].formdata.anzlSpecialSuggestionNb){
				alert("请先填写人身保险新型产品投保风险特别提示！");
				return;
			}
			if(vueobj["testdivchange"].formdata.anzlRiskEvaluationRemoveShNb
			  &&vueobj["testdivchange"].formdata.anzlRiskEvaluationRemoveShNb.row7.radio=="0"
			  &&!vueobj["testdivchange"].formdata.anzlSpecialSuggestionRemoveShNb){
			    alert("请先填写人身保险新型产品投保风险特别提示！");
			    return;
			}
			
				var showdilogCFL= layer.load(2, {
					shade:0.3, //0.2透明度的白色背景
				});
				$.ajax({
					type: "POST",
					url: path + '/SFPJsonSend/checkEsignFileList.do',
					data: {"formdata": JSON.stringify(vueobj["testdivchange"].formdata)},
					dataType: "json",
					async: false,
					success: function (data) {
						try {
							layer.close(showdilogCFL);
							if(!data.flag){
								layer.alert(data.desc);
							}else{
								var commonchannelConFirm=isEmpty(vueobj["testdivchange"].formdata.lccont.commonchannel)||vueobj["testdivchange"].formdata.lccont.commonchannel=="BH"?"平板电子签署":"购物车";
								if(confirm("请确认所有文件已填写/上传完毕，再点击\"OK\"发送文件至"+commonchannelConFirm+"。如仍有文件需要上传，请点击\"Cancel\"返回编辑。")){
										var showdilog= layer.load(2, {
											shade:0.3, //0.2透明度的白色背景
										});
										//SEND
										var tempurl = path+"/esign/sendtoWDC/"+vueobj["testdivchange"].formdata.lccont.transno+".do";
										setTimeout(function(){
											if(vueobj["testdivchange"].formdata.lccont.commonchannel=="SC"||vueobj["testdivchange"].formdata.lccont.commonchannel=="RS"){
												if("Y" != vueobj["testdivchange"].formdata.lccont.isshutdown) {
													$.ajax({
														type: "POST",
														url: path + '/SFPJsonSend/JsonSendEsign.do',
														data: {"transNo": vueobj["testdivchange"].formdata.lccont.transno},
														dataType: "json",
														async: false,
														success: function (data) {
															try {
																if(!data.flag){
																	layer.close(showdilog);
																	layer.alert(data.desc);
																}else{
																	if(!isEmpty(data.desc)){
																		var response=JSON.parse(data.desc);
																		if (response.status == "SUCCESS") {
																			//alert("成功/Succeed");isshutdown
																			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"isshutdown","Y");
																		} else if (response.errorInfo[0].code != "OIM0042") {
																			alert("同步SFP失败/Failed to update \n" + data);
																			layer.close(showdilog);
																		}else {
																			alert("发送失败，请重新尝试!");
																			layer.close(showdilog);
																		}
																	}

																}
															} catch (e) {
																alert("发送失败，请重新尝试!");
																layer.close(showdilog);
															}

														},
														error: function () {
															alert("发送失败，请重新尝试！");
															layer.close(showdilog);
														}
													});
												}
												if("Y" == vueobj["testdivchange"].formdata.lccont.isshutdown) {
													$.ajax({
														type: "POST",
														url: tempurl,// 后台请求URL地址
														async: false,
														data: {"formdata": JSON.stringify(vueobj["testdivchange"].formdata)},
														//					dataType: "json" ,
														//					contentType :"application/json;charset=UTF-8" ,
														success: function (data) {
															if (data.flag) {

																//alert("成功上传" + data.desc);
																//更新状态 F 表示成功上传到WDC
																var ScConfirm='<input type="checkbox" id="isSend" style="height:17px;width:17px;vertical-align:middle"/>文件已发送.请确认销售流程完成后，返回SFP页面，点击<br/><span style="color:red;">"关闭双录并加入购物车"</span>将产品加入购物车！';
																if("uploadagain"==data.returnCode){
																	ScConfirm='<input type="checkbox" id="isSend" style="height:17px;width:17px;vertical-align:middle"/>' +
																		'文件已发送.请确认销售流程完成后，返回SFP页面，点击<br/><span style="color:red;">"关闭双录并加入购物车"</span>将产品加入购物车！' +
																		'<br/><span style="color:red;">'+data.desc+'</span>';
																}
																layer.confirm(ScConfirm, {
																	title:"系统提示",
																	btn: ['确认'], //按钮
																	closeBtn:0,
																	success: function(layero){
																		$(':focus').blur();
																		//title
																		layero.find(".layui-layer-title")[0].style.fontSize="16px";
																		//content
																		layero.find(".layui-layer-content")[0].style.fontSize="17px";
																		//btns
																		var btn=layero.find(".layui-layer-btn0")[0];

																		btn.style.pointerEvents="none";
																		btn.style.color="#8D8D8D";
																		btn.style.backgroundColor="#FBFBFB";
																		btn.style.border="1px solid #e6e6e6";
																		btn.style.opacity="1";
																		$("#isSend").click(function(){
																			if($("#isSend").prop("checked")){
																				// 按钮禁用取消
																				btn.style.pointerEvents="";
																				btn.style.color="#fff";
																				btn.style.backgroundColor="#1E9FFF";
																				btn.style.borderColor="#1E9FFF";
																			}else{
																				btn.style.pointerEvents="none";
																				btn.style.color="#8D8D8D";
																				btn.style.backgroundColor="#FBFBFB";
																				btn.style.border="1px solid #e6e6e6";
																				btn.style.opacity="1";
																			}
																		});
																	}
																}, function(confirmIndex){
																	layer.close(confirmIndex);
																	try {
																		$("#sendToWDC").hide();
																		buttonControl(vueobj["testdivchange"].formdata.lccont.proposalcontno);//按钮状态查询
																	} catch (e) {
																		alert("javaScript Error");
																		// TODO: handle exception
																	}
																	$("#esing_table").bootstrapTable('refresh');
																});

															} else {
																alert("发送失败，请重新尝试！"+data.desc);
																//上传失败后强制刷新Rules
																esignTable(true);
															}
															layer.close(showdilog);
														},
														error: function () {
//														alert("系统异常");
															layer.alert("<div>系统异常</div><div>请检查文件是否缺失或者文件上传格式是否正确！仍有问题，请联系YBT support team 进行查询</div>");
															layer.close(showdilog);
														}
													});
												}
											}else{
												$.ajax({
													type: "POST",
													url: tempurl,// 后台请求URL地址
													data: {"formdata": JSON.stringify(vueobj["testdivchange"].formdata)},
													success: function (data) {
														if (data.flag) {
															layer.alert("上传成功！</br><span style='color:red;'>" + data.desc+"</span>",{title:"系统提示"});
															//更新状态 F 表示成功上传到WDC
															try {
																$("#sendToWDC").hide();
																buttonControl(vueobj["testdivchange"].formdata.lccont.proposalcontno);//按钮状态查询
															} catch (e) {
																alert("javaScript Error");
																// TODO: handle exception
															}
															$("#esing_table").bootstrapTable('refresh');

														} else {
															alert(data.desc);
															//上传失败后强制刷新Rules
															esignTable(true);
														}
														layer.close(showdilog);
													},
													error: function () {
//													alert("系统异常");
														layer.alert("<div>系统异常</div><div>请检查身份证扫描件格式是否错误！扫描时，请务必扫描成黑白tiff格式再上传！手工修改文件的后缀名为tiff无效！或请联系YBT support team 查询</div>")
														layer.close(showdilog);
													}
												});
											}

										},50);

									}
							}
							
						} catch (e) {
							alert("查询文件清单状态发生错误！");
							layer.close(showdilogCFL);
						}

					},
					error: function () {
						alert("查询文件清单状态发生错误！");
						layer.close(showdilogCFL);
					}
				});

}

//二次上传按钮
function sendToWdcAgain(){
	
	var showdilog= layer.load(2, {
		shade:0.3, //0.2透明度的白色背景
	});
	//SEND
	var tempurl = path+"/esign/sendtoWDCAgain/"+vueobj["testdivchange"].formdata.lccont.transno+".do";
	$.ajax({
		type: "POST",
		url: tempurl,// 后台请求URL地址
		data: {"formdata": JSON.stringify(vueobj["testdivchange"].formdata)},
		success: function (data) {
			if (data.flag) {

				alert("上传成功！" + data.desc);
				//更新状态 F 表示成功上传到WDC
				try {
					$("#sendToWDCAgain").hide();
					buttonControl(vueobj["testdivchange"].formdata.lccont.proposalcontno);//按钮状态查询
				} catch (e) {
					alert("javaScript Error");
					// TODO: handle exception
				}
				$("#esing_table").bootstrapTable('refresh');

			} else {
				alert(data.desc);
				//上传失败后强制刷新Rules
				esignTable(true);
			}
			layer.close(showdilog);
		},
		error: function () {
//		alert("系统异常");
			layer.alert("<div>系统异常</div><div>请检查上传的文件是否有误！</div>");
			layer.close(showdilog);
		}
	});
}

function esignFileGroup(value, row, index){
	//1-投保单，2- 银行内部销售文件，3-其他核保要求文件，4-保险建议书文件(IPS)
	if(value=="1"){
		return "投保单";
	}else if(value=="2"){
		/*if((vueobj["testdivchange"].formdata.lccont&&vueobj["testdivchange"].formdata.lccont.eSignFlag=="P"
			&&row.esignaturelogic.filetypecode=="GEN-RPQ")||
			(vueobj["testdivchange"].formdata.lccont&&vueobj["testdivchange"].formdata.lccont.eSignFlag=="P"
				&&row.esignaturelogic.filetypecode=="GEN-FPR")){
			hiddenindex.push(index);
		}else{*/
			return "银行内部销售文件";
		/*}*/
	}else if(value=="3"){
		return "其他核保要求文件";
	}else if(value=="4"){
		return "保险建议书文件(IPS)";
	}else{
		hiddenindex.push(index);
	}
}



function esignStatusFormat(value, row, index) {
	
	if(value=="0"){
		return "等待生成该文件";
	}
	
	if(vueobj["testdivchange"]
			&&vueobj["testdivchange"].formdata
			&&vueobj["testdivchange"].formdata.lccont
			&&(vueobj["testdivchange"].formdata.lccont.eSignFlag=="E")){
		
		if(row.esignaturelogic.filetypecode=='GEN-RPQ'&&row.esignaturelogic.signflag!='0'&&value<3){
			//return "<span style='color:red;'>请自行打印客户的RPQ报告作为投保资料,交接给保险公司<span>";
			return "<span style='color:red;'>请上传客户的RPQ报告<span>";
		}
		
		if(value=="1"){
			return "等待录入该投保资料信息";
		}
		
		if(value=="2"){
			return "等待上传到银保通系统";
		}
		
		if(value>="5"&&row.esignaturelogic.senddoc=='1'){
			return "";
		}
		
		if(value=="5"&&row.esignaturelogic.signflag!='0'){
			return "等待发送给文件中心";
		}
		
		
		
		if(value=="5"){
			return "等待发送给文件中心";
		}
		
		if(value=="4"){
			return "尚未从其他系统获得该文件";
		}
		
		if(value=="3"){
			return "成功上传";
		}
		
		if(value=="6"&&(row.esignaturelogic.filetypecode=='GEN-RPQ')){
			return "";
		}
		
		
		if(value=="6"&&(row.esignaturelogic.filetypecode=='GEN-FPR')){
			return "";
		}
		//电子签名状态显示，所有的上传不需要签署的
		if(value=="6"&&row.esignaturelogic.signflag!='0'){
			return "已发送到文件中心";
		}
		if(value=="6"){
			return "等待签署文件";
		}
		
		if(value=="7"||value=="8"){
			return "签署成功";
		}
		
		if(value=="9"){
			return "准备发送到保险公司...";
		}
		
		if(value=="10"){
			return "保险公司已收到文件并开始核保";
		}
		if(value=="12"){
			return "YBT签署成功";
		}
//		public static final String SUCC_GET_FROM_WDC_TO_YBT="8";//成功签名
	}else if(vueobj["testdivchange"]
			&&vueobj["testdivchange"].formdata
			&&vueobj["testdivchange"].formdata.lccont
			&&(vueobj["testdivchange"].formdata.lccont.eSignFlag=="S")){
		
		if(row.esignaturelogic.filetypecode=='GEN-RPQ'&&row.esignaturelogic.signflag!='0'&&value<3){
			//return "<span style='color:red;'>请自行打印客户的RPQ报告作为投保资料,交接给保险公司<span>";
			return "<span style='color:red;'>请上传客户的RPQ报告<span>";
		}
		
		if(value=="1"){
			return "等待录入该投保资料信息";
		}
		
		if(value=="2"){
			return "等待上传到银保通系统";
		}
		
		if(value>="5"&&row.esignaturelogic.senddoc=='1'){
			return "";
		}
		
		if(value=="5"&&row.esignaturelogic.signflag!='0'){
			return "等待传输给文件中心";
		}
		
		
		
		if(value=="5"){
			return "等待传输给文件中心";
		}
		
		if(value=="4"){
			return "尚未从其他系统获得该文件";
		}
		
		if(value=="3"){
			return "成功上传";
		}
		
		if(value=="6"&&(row.esignaturelogic.filetypecode=='GEN-RPQ')){
			return "";
		}
		
		if(value=="6"&&(row.esignaturelogic.filetypecode=='GEN-FPR')){
			return "";
		}
		//电子签名状态显示，所有的上传不需要签署的
		if(value=="6"&&row.esignaturelogic.signflag!='0'){
			return "已加入手机银行财富购物车";
		}
		if(value=="6"){
			return "已加入手机银行财富购物车";
		}
		
		if(value=="7"||value=="8"){
			return "已确认";
		}
		
		if(value=="9"){
			return "准备发送到保险公司...";
		}
		
		if(value=="10"){
			return "保险公司已收到文件并开始核保";
		}
		if(value=="12"){
			return "YBT签署成功";
		}
	}else{
		
		if(row.esignaturelogic.filetypecode=='GEN-RPQ'){
			//return "<span style='color:red;'>请自行打印客户的RPQ报告作为投保资料,交接给保险公司<span>";
			//return "<span style='color:red;'>请上传客户的RPQ报告<span>";
			return "";
		}
		//纸质
		return "";
		if(value=="1"){
			return "等待录入该投保资料信息";
		}
		
		if(value=="2"){
			return "等待上传到银保通系统";
		}
		
		
		if(value=="5"){
			return "等待传输给DC进行电子签名";
		}
		
		if(value=="4"){
			return "尚未从其他系统获得该文件";
		}
		
		if(value=="3"){
			return "成功上传";
		}
		
	}
	
	
	  
}

/*function downloadallfile(){
	//<button type="button"  class="btn addOrUpdate">录入/修改</button>
	if($("button:contains('录入')").next().length!=$("button:contains('录入')").length){
		alert("有未录入的文件，请完成录入后下载")
		return;
	}
	var args="transno="+vueobj["testdivchange"].formdata.newContApply.transno+"&insurancecom="+vueobj["testdivchange"].formdata.newContApply.insurancecom
	window.open(path+"/esign/esigntable/allfiledownload.do?"+args,"_blank");
}*/

/**
 * 一键下载
 */
function downloadallfile(){
	 var url_d = path+"/esign/checkEnterFiles/"+initFormdata.newContApply.insurancecom+"/"+initFormdata.newContApply.transno+".do";
	 $.ajax({
			type:"POST",
			url:url_d,
			timeout:60000,
			async:false,
			success:function(data){
			if(data.success){				 
				 var args="transno="+vueobj["testdivchange"].formdata.newContApply.transno+"&insurancecom="+vueobj["testdivchange"].formdata.newContApply.insurancecom
				window.open(path+"/esign/esigntable/allfiledownload.do?"+args,"_blank");
			}else{
				alert(data.msg);
			}											  
			  },
			error:function(){
				alert("系统异常,请稍等后再试");
			}
		});
	

}

//纸质上传
function uploadallfile(){	
	var showdilog= layer.load(2, {
		shade:0.3, //0.2透明度的白色背景
	});
	//SEND
	var tempurl = path+"/esign/sendInsurancePaper/"+vueobj["testdivchange"].formdata.lccont.transno+".do";
	$.ajax({
		type: "POST",
		url: tempurl,// 后台请求URL地址
		data: {"formdata": JSON.stringify(vueobj["testdivchange"].formdata)},
		success: function (data) {
			if (data.success) {

				alert("上传成功！" + data.msg);
				//更新状态 F 表示成功上传到WDC
				try {
					$("#upload").hide();
				} catch (e) {
					alert("javaScript Error");
					// TODO: handle exception
				}
				$("#esing_table").bootstrapTable('refresh');

			} else {
				alert(data.msg);
				//上传失败后强制刷新Rules
				esignTable(true);
			}
			layer.close(showdilog);
		},
		error: function () {
			layer.alert("<div>系统异常</div><div>请检查上传的文件是否有误！</div>");
			layer.close(showdilog);
		}
	});

}



//判断字符是否为空的方法
function isEmpty(obj){
    if(typeof obj == "undefined" || obj == null || $.trim(obj) == ""){
        return true;
    }else{
        return false;
    }
}
//弹出窗铺满整个父窗口  
function openIframe_test(title,url){
  layer.open({
  type: 2,
  title: title,
  content: url,
  area: ['90%', '90%'],
  closeBtn:0, 
  success: function(){
    $(':focus').blur();
  },end: function () {
   //每次关闭iframe层后解绑resize事件，这样再次打开就绑定另一次新的index。
   $(window).unbind("resize");
  }
 });
 //layer.full(index);
 //layer.iframeAuto(index);
 var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
 layer.iframeAuto(index);
 //自动设置全屏尺寸
 $(window).resize(function() {
    layer.iframeAuto(index);
  //layer.full(index);
 });
}
//public static final String WAIT_FROM_YBT_TO_WDC="3";//等待传输给WDC
//
//public static final String WAIT_INFO_TO_ENTER="1";//等待录入资料信息
//
//public static final String WAIT_UPLOAD_TO_YBT="2";//等待上传到YBT
//
//public static final String SUCCESS_UPLOAD_TO_YBT="5";//成功上传到YBT
//
//public static final String WAIT_OTHERSYS_TO_YBT="4";//等待其他系统上传到YBT
