
$(function(){
var riskType =-1;

//加载参数
if(grpcontno!=null && grpcontno !="" && grpcontno !="null"){
	$("#b").val(grpcontno);
}
if(riskcode!=null && riskcode!="" && riskcode !="null"){
	$("#riskcode").val(riskcode);
}
	//保险公司
	$.ajax({
		 url:path + '/newContEnter/selectFromLacom.do',  
         type: "POST",
		 success: function(data){
		 for(var i=0;i<data.length;i++){
			var select=document.getElementById("BX");
		    var option=document.createElement("option");
			option.value=data[i].agentcom.replace(/^\s+|\s+$/g, '');;
			option.innerHTML=data[i].agentcom+"-"+data[i].name;
			select.appendChild(option);	
			
		 	 }
		 
		 //$("#BX").select2("val","INSH");
		 }
	})
	
})
	

	$("#add").click(function() {
		var concatis=$("#a").val()+$("#b").val();
		$("#grpcontno").val(concatis);
		var grpcontno = $("#grpcontno").val();
		var grpno=$("#b").val();
		
		var tContNo=$("#BX").val();
		
		if(grpno==""||grpno==null){
			alert("投保人客户号不能为空");
			return false;
		}
		if(tContNo==""||tContNo==null){
			alert("保险公司不能为空");
			return false;
		}
		
		if($("#riskcode").val()==""||$("#riskcode").val()==null){
			alert("保险产品不能为空");
			return false;
		}
 

					var grpcontno = $("#grpcontno").val().trim();
					var insurancecom = $("#BX").val();
					var riskcode = $("#riskcode").val();
					var recording = "N"; // 新单 补录标记为N
					var url = "";
					//本系统进入正常新单录入
					/*url = path + "/newCont/enter/" + insurancecom + "/"
								+ riskcode + "/" + grpcontno +".do" +"?recording="+recording;*/
					var orderID = "1990099|123";
					var reportID = "32452";
					var RecordID = "test123";
					var FPRID= "43411";
					url = path + "/newCont/enter/" + insurancecom + "/"
					+ riskcode + "/" + grpcontno +".do" +"?recording=" + recording + "&orderID="+ encodeURI(orderID) + "&reportID=" + reportID
					+ "&recordID=" + RecordID + "&FPRID=" + FPRID
					+ "&prdTypeCode=" + "INS" + "&prdSubTypeCode=" + "INSNI"
					+ "&prdAlternativeNumber=" + "@AH"
					+ "&prdClassificationCode=" + "M"
					+ "&countryTradableCode=" + "CN";
					
					window.location.href = url;
		
		//show();
	
		
//		var YH = $("#riskcode").val();
//		var BX = $("#BX").val();
//		$(function(){
//			$.ajax({
//			type : "POST",
////			url:path+"/customerIDController/selectcustomerID.do",// 后台请求URL地址
//			url:path+"/QueryCifController/queryCif.do",
//			data : {"bankName":$("#grpcontno").val().trim(),"YH":YH,"BX":BX},
//			dataType : "json",
//			success : function(data) {
//				closed();
//				if(data.success==false){
//					alert(data.msg);
//					return;
//				}else{
//					var grpcontno=$("#grpcontno").val().trim();
//					var insurancecom=$("#BX").val();
//					var riskcode=$("#riskcode").val();
//					var parm="";
//					$.ajax({
//					type : "POST",
//					async: false,
//					url:path+"/newContEnter/selectpower.do",// 后台请求URL地址
//					data : {"grpcontno":grpcontno,"insurancecom":insurancecom,"riskcode":riskcode},
//					dataType : "json",
//					success : function(data) {
//						closed();
//						if(data.success==false){
//							alert(data.msg);
//							return;
//						}else{
//							
//							  var url= "";
//	                          
//							if("MELI"==insurancecom){
//								 url=path+"/url_toview/to_newCont.do?grpcontno="+grpcontno+"&tContNo="
//								 +tContNo+"&riskCode="+riskcode+"&parm="+parm+"&flag=1";
//		                           
//					        }else{
//					        	url = path+"/newCont/enter/"+ insurancecom +"/"+ riskcode +"/"+ grpcontno+".do";
//					        	
//					        }
// 
//                            window.location.href=url;
//						}
//					},
//					error:function(data){
//						closed();
//					}
//					});
//				}
// 
//			}
//			,
//			error:function(data){
//				closed();
//			}
//		});
// 
//	});

	
})


function selectRisk(){
		var tContNo = $("#BX").val();
		document.getElementById("riskcode").options.length = 1;
		$("#riskcode").select2("val","");
			$.ajax({
				 url:path + '/newContEnter/searchrisk.do',  
				 //url:path + '/newContEnter/searchmainrisk.do',
		         type: "POST",
		         data:{"insurancecom":tContNo},
				 success: function(data){
					 
					 var select=document.getElementById("riskcode");
				//	 $(select).empty();
				 for(var i=0;i<data.length;i++){
//					var select=document.getElementById("riskcode");
				    var option=document.createElement("option");
					option.value=data[i].riskcode;
					option.innerHTML=data[i].riskcode+"-"+data[i].riskname;
					select.appendChild(option);
				 }
				
			}
		})
}


var tab_d = $('#cusTable');

//页面初始化
$(document).ready(function() {

					var col = [
					{
						field : 'metentid',
						title : '序号',
						formatter : function(value, row, index) {
							return index + 1;
						}
					}, {
						field : 'proposalcontno',
						title : '投保单号',
						align : 'center',
						valign : 'middle',
						visible : true,
					}, {
						field : 'forceuwreason',
						title : '投保日期',
						align : 'center',
						valign : 'middle'
					}, {
						field : 'grpcontno',
						title : '投保人客户号',
						align : 'center',
						valign : 'middle'
					},
					{
						field : 'riskcode',
						title : '产品代码',
						align : 'center',
						valign : 'middle',
						visible : true
					}, 
					{
						field : 'appflag',
						title : '投保单状态',
						align : 'center',
						valign : 'middle'
					},{
						field : 'premiumBudget',
						title : '保费',
						align : 'center',
						valign : 'middle'
					},  {
						title: '操作',
						align: 'center',
						formatter: actionFormatter,
						events: actionEvents
						} ];

					var uniqueId = "metentid";

			$("#search").click(function() {
	
				
				$("#cusTable").bootstrapTable('destroy');
				var url_d = "/newContApply/selectPro.do";
				tableInit3(url_d, tab_d, col,uniqueId, queryParams);
			});
			
});

/**
* 设置表格查询参数
* 
* @param params
*/
function queryParams(params) {
	// 设置查询参数
	var param = {
		limit : params.limit,
		offset : params.offset,
//		transactionNo : $("#transactionNo").val().trim(),
		grpcontNo :"",
		contNo :"",
		tBRBirth : ""
	};
	return param;
}

//公共代码
function queryTable(url , obj , data){
	obj.bootstrapTable('refresh', {
		  url: path+url,
		  query: data
	 });  
};

//获取ID
function getIdSelections() {
	return $.map($cusTable.bootstrapTable('getSelections'), function(row) {
		return row.contNo;
	});
}
/**
* 翻页带查询参数及列排序
*/
function tableInit3(url, obj, col, uniqueId,queryParams) {
	obj.bootstrapTable({
		url : path + url, // 请求后台的URL（*）
		dataType : "json",
		method : 'post', // 请求方式（*）
		contentType : "application/x-www-form-urlencoded",
		toolbar : '#toolbar',
		columns : col,
		striped : true, // 是否显示行间隔色
		cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		pagination : true, // 是否显示分页（*）
		queryParamsType : "limit",// undefined/limit
		queryParams : queryParams,// 传递参数（*）
		sidePagination : "server", //
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		strictSearch : true,// 设置为 true启用 全匹配搜索，否则为模糊搜索
		showColumns : true, // 是否显示所有的列
		showRefresh : true, // 是否显示刷新按钮
		minimumCountColumns : 2, // 最少允许的列数
		clickToSelect : true, // 是否启用点击选中行
		// height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		// uniqueId: "ID", // 每一行的唯一标识，一般为主键列
		uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
		showToggle : true, // 是否显示详细视图和列表视图的切换按钮
		cardView : false, // 是否显示详细视图
		detailView : false
	});
};

function actionFormatter(value, row, index) {      
	return [
     '<button class="btn btn-red select">复制</button>'
	].join('');
}


window.actionEvents = {
		/*		//投保单复制
		'click .select': function (e, value, row, index) {
			
			$.ajax({
				url:path + '/newContApply/copyCont.do',  
		        type: "POST",
		        async: false,
		        data:"proposalcontno="+row.proposalcontno+"&transno=''&insurance="+row.insurancecom,
		        success: function(data){
		        	if(data.success==true){
		        		alert("复制成功");
			        	window.location.href="partNewContEnter.jsp?flag=4&transno="+data.msg;
		        	}else{
		        		alert(data.msg);
		        	}
		        	
		        }
			});
		}*/
		   //投保单复制
	    'click .select': function (e, value, row, index) {
	    	show();
	        $.ajax({
	            url:path + '/newContApply/lccontCopy.do',
	            type: "POST",
	           // async: false,
	            data:{"oldproposalcontno":row.proposalcontno,
	            	  "oldtransno":row.transno},
	            success: function(data){
	                if(data.success==true){
	                    closed();
	                    alert("复制成功");
	                    if(row.insurancecom!="MELI"){
	                    	window.location.href=path+"/newCont/enter/"+ row.insurancecom +"/"+ row.riskcode +"/"+ row.grpcontno+"/"+data.msg+".do?flag=3";
	                    }else{
	                    	 window.location.href="partNewContEnter.jsp?flag=4&transno="+data.msg;
	                    }
	                   
	                }else{
	                	closed();
	                    alert(data.msg);
	                }

	            },error:function(){
					closed();
				}
	        });
	    }
	};

//$(function() {
//	$("#add").click(
//			function() {
//
//				var bankName = $("#bankName").val();
//				var salesChl = $("#salesChl").val();
//				var tContNo = $("#contNo").val();
//				var riskCode = $("#riskCode").val();
//
//				// alert(bankName+"="+salesChl+"="+tContNo+"="+riskCode);
//
//				var url = "partNewContEnter.jsp?bankName=" + bankName
//						+ "&salesChl=" + salesChl + "&tContNo=" + tContNo
//						+ "&riskCode=" + riskCode;
//				toadd(url);
//			});
//});
























