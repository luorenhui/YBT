/*$.fn.bootstrapValidator.validators.bnf_ratio = {
	validate : function(validator, $field, options) { 
	 
		var topvueobj = getTopvueObj(options.vueobj);
		var insuidStart = options.vueobj.namepref.indexOf("_");
		var insuid = options.vueobj.namepref.substring(insuidStart + 1);
		var bnfAry = topvueobj.formdata.bnf;

		var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
		// options.vueobj.formdata ;

		var bnflot=0;
        var bnflot2=0;
        var bnflot3 =0;
		for (var i = 0; i < bnfAry.length; i++) {
			var bnf = bnfAry[i];
			// /判断 //同被保险人
			for ( var key in bnf.mapRelevant) {
				insuid == key;
				if (insuid == key) {
					// if($("[id='bnflot"+i+"']").is(":visible")){
					if (!isNaN(bnf.mapRelevant[key].bnflot)) {
						if(key=="1"){
							bnflot = bnflot
							+ Number(bnf.mapRelevant[key].bnflot);
						}else if(key=="2"){
							bnflot2 = bnflot2
							+ Number(bnf.mapRelevant[key].bnflot);
						}else if(key=="3"){
							bnflot3 = bnflot3
							+ Number(bnf.mapRelevant[key].bnflot);
						}
						else if(key=="1,2"){
							bnflot = bnflot
							+ Number(bnf.mapRelevant[key].bnflot);
							bnflot2 = bnflot2
							+ Number(bnf.mapRelevant[key].bnflot);
						}
						
					}

					// }
					//					
				}

			}
		}
		

		// for (var i = 0; i < bnfAry.length; i++) {
		// var bnf = bnfAry[i];
		// ///判断 //同被保险人
		// for ( var key in bnf.mapRelevant) {
		// if (insuid == key) {
		//					 
		// if($("[id='bnflot"+i+"']").is(":visible")){
		// try {
		//							
		// if(bnflot==100){
		//								
		// form.data('bootstrapValidator').updateStatus($("[id='bnflot"+i+"']:visible"),"VALID");
		//								
		// }else{
		//								
		// form.data('bootstrapValidator').updateStatus($("[id='bnflot"+i+"']:visible"),"INVALID");
		//								
		// }
		// } catch (e) {
		// }
		//						
		// }
		// }
		//				 
		// }
		//			
		// }
		
		if(bnflot == 100){
			form.data('bootstrapValidator').updateStatus($field, "VALID");	
	    			form.find("input[id*='bnflot']").each(function() {
	
	    				if (!form.data('bootstrapValidator').isValidField($(this))) {
	    					form.data('bootstrapValidator').revalidateField($(this));
	    				}
	    			});
		}else{
			return false;
		}
		if(bnflot2 == 100){
			form.data('bootstrapValidator').updateStatus($field, "VALID");	
	    			form.find("input[id*='bnflot']").each(function() {
	
	    				if (!form.data('bootstrapValidator').isValidField($(this))) {
	    					form.data('bootstrapValidator').revalidateField($(this));
	    				}
	    			});
		}else{
			return false;
		}
		if(bnflot3 == 100){
			form.data('bootstrapValidator').updateStatus($field, "VALID");	
	    			form.find("input[id*='bnflot']").each(function() {
	
	    				if (!form.data('bootstrapValidator').isValidField($(this))) {
	    					form.data('bootstrapValidator').revalidateField($(this));
	    				}
	    			});
		}else{
			return false;
		}
       
//        	if (bnflot == 100) {
//
//    			form.data('bootstrapValidator').updateStatus($field, "VALID");
//
//    			form.find("input[id*='bnflot']").each(function() {
//
//    				if (!form.data('bootstrapValidator').isValidField($(this))) {
//    					form.data('bootstrapValidator').revalidateField($(this));
//    				}
//
//    			});
//    			
//    			if(bnflot2!=0){
//    				if(bnflot2==100){
//    					return true;
//    				}else{
//    					return false;
//    				}
//    			}
//    			return true;
//    		}else  if(bnflot2==100){
//    			
//    			return true;
//    		} else {
//			
//			return false;
//		}

		return true;

	}
};

bootstrap_valid.bnf_ratio = function(validitem) {

	var vueobj = this;
	var validobj = {
		message : "该被保人受益人比例之和不为100",
		vueobj : vueobj
	};

	return validobj;

};*/

commonCombobox_option.commonCombobox_lcbnfcountry ={
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]
};
commonCombobox_option.commonCombobox_lcbnfprovince ={

		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
};
commonCombobox_option.commonCombobox_lcbnfcity  =  {
		url :  path + '/newCont/codeselect/allcity/#lcbnfprovince.do',
		valueField : "cityid",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
};
commonCombobox_option.commonCombobox_lcbnfdistrict =  {
		url :  path + '/newCont/codeselect/allcounty/#lcbnfcity.do',
		valueField : "countyid",
		// 显示在输入框的
		inputText : "countyname",
		textShow : [ "countyname" ]
};

var onlysameFieldLcbfAddress={
		"zipcode":"zipcode",//联系地址邮政编码
		"province" : "homeprovince",//通讯地址省
		"city": "homecity",//通讯地址市
		"district" : "homedistrict",//通讯地址区
		"address":"homeaddress",//通讯详细地址
		"naity":"addresscountry"
		 
	};
afterVueSelect.lcbnfpostalflaginsh = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
		var index = getElementIntex(this); 
		var relationtoappnt = topvue.formdata.bnf[index].lcbnfrelationtoappnt;
		var eleName = this.namepref 
			+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
		
		obj=$("input[name='"+eleName+"']");
	
		if (obj.is("[type='checkbox']:checked")||relationtoappnt=="Y") {
			
			for ( var key in topvue.form_elements.bnf) {
				
				var targetName= topvue.form_elements.bnf[key].name;
				var targetElement= topvue.form_elements.bnf[key];
				//地址信息同步
				if (sameFieldLcbnfAddress[topvue.form_elements.bnf[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
					bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcbnfAddress[targetName],
						topvue.formdata.bnf[index],targetName,targetElement,targetObj);
				}
			}
		
		} else {
			for ( var key in topvue.form_elements.bnf) {
 
				var targetName= topvue.form_elements.bnf[key].name;
				var targetElement= topvue.form_elements.bnf[key];
				if (sameFieldLcbnfAddress[topvue.form_elements.bnf[key].name]!=undefined) {
					var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
					unbindSameElementByJqobj.call(topvue, sameFieldLcbnfAddress[targetName],
						targetElement,targetObj);
				}
			}
		}
		
};
//居住地址国家变化时改变居住地址省市区下拉状态
afterVueSelect.lcbnfcountry = function(form_element) {
	var topvue = getTopvueObj(this);
	var eleName = this.namepref+this.form_element.groupid+'.'+ this.form_element.name;
	var num = getElementIntex(this);
	var obj=$("input[name='bnf["+num+"].naity']").val();
	 var postalflag=$("input[name='bnf["+num+"].postalflags']");
	if(postalflag.is("[type='checkbox']:checked")){
		return;
	}
	if(obj!= 'CN'){		
		if(obj!=""&&obj!=null&&obj!=undefined){
			vueobj.testdivchange.formdata.bnf[num].province="";
			vueobj.testdivchange.formdata.bnf[num].city="";
			vueobj.testdivchange.formdata.bnf[num].district="";
			$("input[name='bnf\\["+num+"\\].province']").combobox("clear");
			$("input[name='bnf\\["+num+"\\].city']").combobox("clear");
			$("input[name='bnf\\["+num+"\\].district']").combobox("clear");
		}
		$("input[name='bnf\\["+num+"\\].province']").combobox("disable");
		$("input[name='bnf\\["+num+"\\].city']").combobox("disable");
		$("input[name='bnf\\["+num+"\\].district']").combobox("disable");
	}else{
		$("input[name='bnf\\["+num+"\\].province']").combobox("enable");
		$("input[name='bnf\\["+num+"\\].city']").combobox("enable");
		$("input[name='bnf\\["+num+"\\].district']").combobox("enable");			
	}
};

//基础信息
var sameFieldLcbnfinsh={
	"name"	:"appntname",
	"nationality"	:"nativeplace",//受益人国籍
	"sex"	:"appntsex",//性别
	"idtype"	:"idtype",//证件类型
	"idno"	:"idno",//证件号码
	"birthday"	:"appntbirthday",//出生日期
	"usedname1"	:"appntpreviousname1",/*投保人曾用名1*/
	"usedname2"	:"appntpreviousname2",/*投保人曾用名2*/
	"usedname3"	:"appntpreviousname3",/*投保人曾用名3*/
//	"renewCount"	:"renewCount",//换证次数
	"startingDate"	:"startingDate",//证件有效始期
	"bnfvalidYear"	:"appntenddate",//证件有效止期
	"islongitems" : "islongitems", //证件长期有效
};

//电话信息
var sameFieldLcbnfMoblie={
	//移动电话所在国家/地区
	"mobilecountry":"mobilephonecountry",
	//移动电话
	"mobile":"mobile"
};

//地址信息
var sameFieldLcbnfAddress={
	//国家
	"naity":"addresscountry",
	//省
	"province":"homeprovince",
	//市
	"city":"homecity",
	//区
	"district":"homedistrict",
	//详细地址
	"address":"homeaddress",
	//联系地址邮政编码
	"zipcode":"zipcode"
};

/**
 * 受益人 同 投保人
 */
afterVueSelect.lcbnfrelationtoappnt = function(form_element) {

	var topvue = getTopvueObj(this);
//	var length=topvue.formdata.bnf.length;
//	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
//			+ form_element.name + "']");
	var eleName = this.namepref+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
	var index = this.elementindex.replace(/[^0-9]/ig,"");	
	var obj= topvue.formdata.bnf[index].lcbnfrelationtoappnt;
	var form =$(this.$el).parentsUntil("form").parent("form");
	if (obj=='Y') {

		for ( var key in topvue.form_elements.bnf) {
			
			var targetName= topvue.form_elements.bnf[key].name;
			var targetElement= topvue.form_elements.bnf[key];

			if (sameFieldLcbnfinsh[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.lcappnt, sameFieldLcbnfinsh[targetName],
						topvue.formdata.bnf[index],targetName,targetElement,targetObj);
			}

			if (sameFieldLcbnfMoblie[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcbnfMoblie[targetName],
					topvue.formdata.bnf[index],targetName,targetElement,targetObj);
			}

			//地址信息同步
			if (sameFieldLcbnfAddress[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcbnfAddress[targetName],
					topvue.formdata.bnf[index],targetName,targetElement,targetObj);
			}

		}
		$("#lcbnfpostalflaginsh\\["+index+"\\]").hide();
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"postalflags", new Array());
		topvue.$nextTick(function () { 
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});		
	} else {
		for ( var key in topvue.form_elements.bnf) {
			
			var targetName= topvue.form_elements.bnf[key].name;
			var targetElement= topvue.form_elements.bnf[key];
			if (sameFieldLcbnfinsh[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				unbindSameElementByJqobj.call(topvue, sameFieldLcbnfinsh[targetName],
						targetElement,targetObj);
			}
			if (sameFieldLcbnfMoblie[topvue.form_elements.bnf[key].name]!=undefined) {
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				unbindSameElementByJqobj.call(topvue, sameFieldLcbnfMoblie[targetName],
					targetElement,targetObj);
			}
			//如果同投保人地址 不解绑
			var postalflag=$("input[name='bnf["+index+"].postalflags']");
			if(!postalflag.is("[type='checkbox']:checked")) {
				if (sameFieldLcbnfAddress[topvue.form_elements.bnf[key].name] != undefined) {
					var targetObj = $("input[name='" + eleName.replace(this.form_element.name, targetName) + "']");
					unbindSameElementByJqobj.call(topvue, sameFieldLcbnfAddress[targetName],
						targetElement, targetObj);
				}
			}
		}

			$("#lcbnfpostalflaginsh\\["+index+"\\]").show();
			//清空受益人信息	输入框处理		
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"name", null);//姓名
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"birthday", null);//出生日期
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"idno", null);//证件号码
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"usedname1", null);//曾用名1
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"usedname2", null);//曾用名2
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"usedname3", null);//曾用名3									
//			topvue.$nextTick(function () { 
//				try {
//			//下拉框处理		
//			$('#lcbnfidtype\\['+index+'\\]').combobox("clear");//证件类型
//			$('#lcbnfsex\\['+index+'\\]').combobox("clear");//性别
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"idtype","");
//			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"sex", "");
//				} catch (e) {
//				}
//			});
			
	}
	var idtype= topvue.formdata.bnf[index].idtype;
	var lcbnfrelationtoappnt = topvue.formdata.bnf[index].lcbnfrelationtoappnt;
	if(lcbnfrelationtoappnt !='Y'){
		/*if(idtype != "X"){ 
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"renewCount", null);
		$("#bnfrenewCount\\["+index+"\\]").attr("disabled",true);
	}else {
		$("#bnfrenewCount\\["+index+"\\]").attr("disabled",false);
	}*/
		//证件有效起期只给身份证用
		if(idtype != "I"){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"startingDate", null);
			$("#bnfstartingDate\\["+index+"\\]").attr("disabled",true);
		}else {
			$("#bnfstartingDate\\["+index+"\\]").attr("disabled",false);
		}
	}
};
afterVueSelect.lcbnfidtype = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
	var idtype= topvue.formdata.bnf[index].idtype;
	var lcbnfrelationtoappnt = topvue.formdata.bnf[index].lcbnfrelationtoappnt;
	if(lcbnfrelationtoappnt !='Y'){
		/*if(idtype != "X"){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"renewCount", null);
			$("#bnfrenewCount\\["+index+"\\]").attr("disabled",true);
		}else {
			$("#bnfrenewCount\\["+index+"\\]").attr("disabled",false);
		}*/
		//证件有效起期只给身份证用
		if(idtype != "I"){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[index],"startingDate", null);
			$("#bnfstartingDate\\["+index+"\\]").attr("disabled",true);
		}else {
			$("#bnfstartingDate\\["+index+"\\]").attr("disabled",false);
		}
	}
};

//受益人证件长期有效
afterVueSelect.lcbnfislongitems = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
	var obj = $("#lcbnfislongitems\\["+index+"\\]");
	if (obj.is("[type='checkbox']:checked")){
		topvue.$set(topvue.formdata.bnf[index],"bnfvalidYear","9999-12-31");
		$("#lcbnfbnfvalidYear\\["+index+"\\]").attr("disabled",true);
	}else if(!$("#lcbnfislongitems\\["+index+"\\]").prop('disabled')){
		$("#lcbnfbnfvalidYear\\["+index+"\\]").attr("disabled",false);
	}
}



vueMethods.getBnfRelTitle = function(value, indexbnfno, insuids) {
	
	var topvue = getTopvueObj(this);
	if(topvue.formdata.newContApply.investment=='M'){
		
		return "被保人"+value+"身故受益人";
		
	}else{
		
		if (value == "1") {
			
			if(topvue.formdata.newContApply.investment=='N'){
				return "主被保人身故受益人";
			}else{
				return "被保人1身故受益人";
			}
			
		}
		if (value == "2") {
			return "被保人2身故受益人";
		}

		if (value == "1,2") {
			return "两被保人均身故";
		}
	}
	
	
};

vueMethods.getBnFRelData = function(formdata, mapkey, key) {
	if (formdata[mapkey] == undefined) {

		this.$set(formdata, mapkey, {});
	} else {

	}

	if (formdata[mapkey][key] == undefined) {

		this.$set(formdata[mapkey], key, {});
	} else {

	}

	return formdata[mapkey][key];
};
// getBnFRelData(formdata['bnf'][n-1]['mapRelevant'],insuid)
/*******************************************************************************
 * 受益人 与被保人关系
 */
vueMethods.getBnfRelship = function(SID, objvalue, num_index) {
	
	var topvue = getTopvueObj(this);
	if(topvue.formdata.newContApply.investment=='M'){
		
		return ;
		
	}

	var elments = [];
	var aryindex = {};
	
	if (this.form_elements[SID]) {
		try {
			console.log("objvalue length" + objvalue + " SID:" + SID);
		} catch (e) {
			console.log(e);
		}
		var formdata = this.formdata;
	    
		if (formdata['lcinsured']
		&& formdata['lcinsured'].lcinsuredtwoflag
		&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
		&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
		    			
		} else {			
		  
			if(formdata['bnf'][num_index].insuids
					&&formdata['bnf'][num_index].insuids.length==1
					&&formdata['bnf'][num_index].insuids[0]=="1"){
				
			}else{
				objvalue=["1"];
				formdata['bnf'][num_index].insuids=[];
				formdata['bnf'][num_index].insuids.push("1");
//				this.$set(formdata['bnf'][num_index].insuids,"insuids",["1"]);
			}
			
		}
		if (objvalue != undefined) {

			var firstInsu = false;
			var secondInsu = false;
			var bothInsu = false;
		
			

			for ( var index in objvalue) {

				if (objvalue[index] == "1") {
					firstInsu = true;
				}

				if (objvalue[index] == "2") {
					secondInsu = true;
				}

				if (objvalue[index] == "1,2") {
					firstInsu = true;
					secondInsu = true;
					bothInsu = true;
				}
			}

			// 显示与第一个被保险人关系
			if (firstInsu) {
				elments.push(this.form_elements[SID][0]);
				aryindex[0] = true;

			} else {

			}
			// 显示与第二个被保险人关系
			if (secondInsu) {
				elments.push(this.form_elements[SID][1]);
				aryindex[1] = true;

			} else {

			}

			var changeFlag = false;// 变化 标志
			if (!firstInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['1'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['1'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '1', {});
				changeFlag = true;

			}

			if (!secondInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['2'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['2'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '2', {});
				changeFlag = true;

			}

			if (!bothInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['1,2'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['1,2'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '1,2', {});
				changeFlag = true;
			}
			// 受益人所属被保人 变化后 重新 valid 部分字段
			if (changeFlag) {
				$("#lcbnf_tabinfoform").find("input[id*='bnflot']").each(
						function() {

							$("#lcbnf_tabinfoform").data('bootstrapValidator')
									.revalidateField($(this));

						});

			}

		}
		// 清空元素值
		for ( var index in this.form_elements[SID]) {
			if (aryindex[index]) {

			} else {

				var element = this.form_elements[SID][index];
				this.$set(this.formdata[element.groupid][num_index],
						element.name, "");
			}
		}

	}

	return elments;

};

commonCombobox_option.commonCombobox_relationbnf_insh = {

		url : path + '/newCont/codeselect/common/bnf/relation_insh',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "codename" ,
		textShow : [ "codename" ],
		afterselect:function(ele,$target ,value ,text,comboboxObj){
			var elename =ele[0].name;
			var otherrrlationelename=elename.substring(0,elename.indexOf('.'))+".otherrelation";
			if(value!="30"){				
				$("input[name='"+otherrrlationelename+"']").attr("disabled",true);
				$("input[name='"+otherrrlationelename+"']").val("");
				var num = elename.replace(/[^0-9]/ig, "")
				var i = num.substr(0, 1);
				var j = num.substr(1,1);
				vueobj.testdivchange.formdata.bnf[i].mapRelevant[j].otherrelation=""; 
//				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.bnf[i].mapRelevant[j],"otherrelation", "");
			}else{
				$("input[name='"+otherrrlationelename+"']").attr("disabled",false);
			}
			
		}
	};


afterVueSelect.relationtoinsuredinsh = function(form_element) {
	var topvue = getTopvueObj(this);
	for(var i =0;i<vueobj["testdivchange"].formdata.bnf.length;i++){
	var relationtoinsured=vueobj["testdivchange"].formdata.bnf[i].relationtoinsured;
	if(relationtoinsured!="30"){		
//		$(" input[ name='bnf["+i+"].otherrelation' ] ").attr("disabled",true);
//		$(" input[ name='bnf["+i+"].otherrelation' ] ").val("");
		$("#lcbnfotherrelation\\["+i+"\\]").attr("disabled",true);
		$("#lcbnfotherrelation\\["+i+"\\]").val("");
		topvue.$set(topvue.formdata.bnf[i],"otherrelation","");
	}else{
		$("#lcbnfotherrelation\\["+i+"\\]").removeAttr("disabled");			
	}			
	};
}


//根据身份证号，同步出生日期
afterVueSelect.lcbnfidno = function(form_element) {
	var topvue = getTopvueObj(this);
	for(var i=0;i<topvue.formdata.bnf.length;i++){
		if(topvue.formdata.bnf[i].idtype != "I"&&topvue.formdata.bnf[i].idtype != "J"){
			return;
		}
		if(topvue.formdata.bnf[i].idtype == "I"||topvue.formdata.bnf[i].idtype == "J"){
				var idno = topvue.formdata.bnf[i].idno;
				var birthday = idno.substring(6,14);
				var year = birthday.substring(0,4);
				var mon = birthday.substring(4,6);
				var day = birthday.substring(6);
				var formatBirth = year + "-" + mon + "-" + day;
				topvue.$set(topvue.formdata.bnf[i],"birthday",formatBirth);		
		}
	}
}
$.fn.bootstrapValidator.validators.bnf_idno = {
		validate : function(validator, $field, options) {
			var num=$(options.vueobj.$el).children().attr("id").split("[")[1].substring(0,1);
			var topvueobj = getTopvueObj(options.vueobj);
			var bnfAry = topvueobj.formdata.bnf;
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			var length=bnfAry.length;
			bnf=bnfAry[num];
			if(bnf.idno.length==18||(bnf.idtype!="I"&&bnf.idtype!="J")){
				form.data('bootstrapValidator').resetField($("#lcbnfbirthday\\["+num+"\\]"));
				form.data('bootstrapValidator').updateStatus($field, "VALID");
				form.find("input[id*='lcbnfidno']").each(function() {
					if (!form.data('bootstrapValidator').isValidField($(this))) {
						form.data('bootstrapValidator').revalidateField($(this));
					}

				});
				return true;
			}
			return false;
		}
	};
	bootstrap_valid.bnf_idno = function(validitem) {
		var vueobj = this;
		var validobj = {
			message : "当前证件类型下证件号码必须为18位，请重新输入",
			vueobj : vueobj
		};

		return validobj;

	};
	
	
	
	beforesubmitvueform.lcbnf_tabinfoform = function() {
		var topvue = getTopvueObj(this);
	    if(topvue.formdata&&topvue.formdata.newContApply.bnftype=="2"
	    	&&("RS"==topvue.formdata.lccont.commonchannel||"SC"==topvue.formdata.lccont.commonchannel)){
	    	
	    	layer.alert('购物车模式下，不支持指定受益人的选择！ 请选择"法定"。');
	    	return false;
				/*	$.ajax({
				        type : "POST",
				        url:path+'/newContEnter/selecyCityByComCode.do',// 后台请求URL地址
				        data : {"comcode":topvue.formdata.lccont.managecom},
				        dataType : "json",
				        success : function(data) {
				        	if(data.success){
				        	    if("110100"==data.parm){
				        	    	layer.alert("购物车远程模式不支持北京地区选择指定受益人方式");
				        	    	return false;
				        	    }
				        	}else{
				        		layer.alert(data.msg);
				        		return false;
				        	}
				        },
				        error:function(e){
				        	console.log(e);
				        }
				    });	*/
	    }
	    if(topvue.formdata&&topvue.formdata.newContApply.bnftype=="2"){
			for(var i=0;i<topvue.formdata.bnf.length;i++){
				
				if(topvue.formdata.bnf[i].idtype== "I"){
					if(topvue.formdata.bnf[i].startingDate==null 
							|| topvue.formdata.bnf[i].startingDate=="" ){
						alert("证件有效起期不可为空");
						return false;
					}
					
					if((new Date(topvue.formdata.bnf[i].startingDate)>new Date())){
						alert("证件有效起期必须小于等于当前日期");
						return false;
					}
					if((new Date(topvue.formdata.bnf[i].startingDate))>=
						(new Date(topvue.formdata.bnf[i].bnfvalidYear))){
						alert("证件有效起期必须小于证件有效止期");
						return false;
					}	
				}
				
				/*if(topvue.formdata.bnf[i].idtype== "X"){
					if(topvue.formdata.bnf[i].renewCount==null 
							|| topvue.formdata.bnf[i].renewCount=="" ){
						alert("证件为港澳台通行证，换证次数不可为空");
						return false;
					}
					var newrenewcount = (Array(2).join(0) + parseInt(topvue.formdata.bnf[i].renewCount)).slice(-2);//01
					topvue.$set(topvue.formdata.bnf[i],"renewCount",newrenewcount);
				}*/
			}
		    }
	   return true;
	};
	
