var tab_d = $('#cusTable'),

$remove = $('#remove');

var init_url = "";	
var col;
var uniqueId;
var sortOrder;

var tas = $('#cusTables');
var tasa = $('#cusTablesa');
var tasb = $('#cusTablesb');
var tasc = $('#cusTablesc');

// 页面初始化
$(document).ready(function() {
	
	/**加载附加险页面表格*/
	col = [{field: 'state',align: 'center',valign : 'middle',checkbox: true,visible: true},
	  			   {field: 'id',title: '序号',formatter: function (value, row, index) {  
                       return index+1;  
                   }},
                    {field: 'riskCode',title: '产品代码',align: 'center',sortable: true,valign : 'middle'},
                    {field: 'salesChl',title: '产品名称',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'riskName',title: '产品简称',align: 'center',sortable: true,valign : 'middle',visible: false}
	  			   ];
	

	uniqueId = "id";
	sortOrder = "id asc";
	$("#cusTable").bootstrapTable('destroy');
	//复制功能为主险时查询附加险数据
	 if(insuranceComA!=null&&riskCodeA!=null&&subRiskFlagA=="M"){
		 init_url="/LmriskAController/selectProduct.do";
		 tableInit3(init_url,tab_d,col,uniqueId,sortOrder,queryRelaParamscopy);
	 }else{
		 tableInit3(init_url,tab_d,col,uniqueId,sortOrder,queryParams);
	 }
	
	
	
	/**加载一般参数表格*/
var	cola = [{field: 'state',align: 'center',valign : 'middle',checkbox: true,visible: false},
	  			   {field: 'uid',title: '序号',formatter: function (value, row, index) {  
                       return index+1;  
                   },visible:true},
                    {field: 'codetype',title: '参数类型',align: 'center',sortable: true,valign : 'middle',visible:false},
                    {field: 'code',title: '参数代码',align: 'center',sortable: true,valign : 'middle',visible:false},
	   				{field: 'codename',title: '参数名称',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'codealias',title: '参数组',align: 'center',sortable: true,valign : 'middle',visible:false},
                    {field: 'params',title: '参数显示',align: 'center',sortable: true,valign : 'middle'},
                    {field: 'paramscode',title: '参数代码显示',align: 'center',sortable: true,valign : 'middle',visible:false},
	   				{title: '操作',align: 'center',formatter: actionFormatter,events: actionEvents}
	  			   ];

uniqueId = "id";
sortOrder = "id asc";
var init_urla="/LdcodeController/selectByCodeAnd.do";
$("#cusTables").bootstrapTable('destroy');
//复制功能查询数据
if(insuranceComA!=null&&riskCodeA!=null){
	 init_urla="/LmriskAController/UpdateParamAll.do";
	 
	 tableInit3(init_urla,tas,cola,uniqueId,sortOrder,queryParamscopy);
}else{

	 tableInit3(init_urla,tas,cola,uniqueId,sortOrder,queryParamsa);
}




/**加载年金参数表格*/
var	colaa = [{field: 'state',align: 'center',valign : 'middle',checkbox: true,visible: false},
	  			   {field: 'uid',title: '序号',formatter: function (value, row, index) {  
                       return index+1;  
                   },visible:true},
                    {field: 'codetype',title: '参数类型',align: 'center',sortable: true,valign : 'middle',visible:false},
                    {field: 'code',title: '参数代码',align: 'center',sortable: true,valign : 'middle',visible:false},
	   				{field: 'codename',title: '参数名称',align: 'center',sortable: true,valign : 'middle'},
	   				{field: 'codealias',title: '参数组',align: 'center',sortable: true,valign : 'middle',visible:false},
                    {field: 'params',title: '参数显示',align: 'center',sortable: true,valign : 'middle'},    
                    {field: 'paramscode',title: '参数代码显示',align: 'center',sortable: true,valign : 'middle',visible:false},
	   				{title: '操作',align: 'center',formatter: actionFormatter,events: actionEvents}
	  			   ];

uniqueId = "id";
sortOrder = "id asc";
var init_urla="/LdcodeController/selectByCodeAnd.do";




$("#cusTablesa").bootstrapTable('destroy');

//复制功能查询数据
if(insuranceComA!=null&&riskCodeA!=null){
	 init_urla="/LmriskAController/UpdateParamAllA.do";
	 
	 tableInit3(init_urla,tasa,colaa,uniqueId,sortOrder,queryParamscopy);
}else{

	 tableInit3(init_urla,tasa,colaa,uniqueId,sortOrder,queryParamsa_a);
}





/**加载投连参数表格*/
var	colab = [{field: 'state',align: 'center',valign : 'middle',checkbox: true,visible: false},
	  			   {field: 'uid',title: '序号',formatter: function (value, row, index) {  
                       return index+1;  
                   },visible:true},
                    {field: 'codetype',title: '参数类型',align: 'center',sortable: true,valign : 'middle',visible:false},
                    {field: 'code',title: '参数代码',align: 'center',sortable: true,valign : 'middle',visible:false},
	   				{field: 'codename',title: '参数名称',align: 'center',sortable: true,valign : 'middle'},
                    {field: 'params',title: '参数显示',align: 'center',sortable: true,valign : 'middle'},       
                    {field: 'codealias',title: '参数组',align: 'center',sortable: true,valign : 'middle',visible:false},
                    {field: 'paramscode',title: '参数代码显示',align: 'center',sortable: true,valign : 'middle',visible:false},
	   				{title: '操作',align: 'center',formatter: actionFormatter,events: actionEvents}
	  			   ];

uniqueId = "id";
sortOrder = "id asc";
var init_urla="/LdcodeController/selectByCodeAnd.do";

$("#cusTablesb").bootstrapTable('destroy');

//复制功能查询数据
if(insuranceComA!=null&&riskCodeA!=null){
	 init_urla="/LmriskAController/UpdateParamAllb.do";
	 
	 tableInit3(init_urla,tasb,colab,uniqueId,sortOrder,queryParamscopy);
}else{

	 tableInit3(init_urla,tasb,colab,uniqueId,sortOrder,queryParamsa_b);
}



	/**加载万能参数表格*/
	var	colac = [{field: 'state',align: 'center',valign : 'middle',checkbox: true,visible: false},
		{field: 'uid',title: '序号',formatter: function (value, row, index) {
				return index+1;
			},visible:true},
		{field: 'codetype',title: '参数类型',align: 'center',sortable: true,valign : 'middle',visible:false},
		{field: 'code',title: '参数代码',align: 'center',sortable: true,valign : 'middle',visible:false},
		{field: 'codename',title: '参数名称',align: 'center',sortable: true,valign : 'middle'},
		{field: 'params',title: '参数显示',align: 'center',sortable: true,valign : 'middle'},
		{field: 'codealias',title: '参数组',align: 'center',sortable: true,valign : 'middle',visible:false},
		{field: 'paramscode',title: '参数代码显示',align: 'center',sortable: true,valign : 'middle',visible:false},
		{title: '操作',align: 'center',formatter: actionFormatter,events: actionEvents}
	];

	uniqueId = "id";
	sortOrder = "id asc";
	var init_urla="/LdcodeController/selectByCodeAnd.do";

	$("#cusTablesc").bootstrapTable('destroy');

//复制功能查询数据
	if(insuranceComA!=null&&riskCodeA!=null){
		init_urla="/LmriskAController/UpdateParamAllc.do";

		tableInit3(init_urla,tasc,colac,uniqueId,sortOrder,queryParamscopy);
	}else{

		tableInit3(init_urla,tasc,colac,uniqueId,sortOrder,queryParamsa_c);
	}

	


	$("#save").click(function() {
		
		var insuranceCom=$("#insuranceCom").val().trim();
		var riskCode=$("#riskCode").val().trim();
		var subRiskVer=$("#subRiskVer").val().trim();
		var salesChl=$("#salesChl").val().trim();
		var subRiskFlag=$("#subRiskFlag").val().trim();
		var riskName=$("#riskName").val().trim();
		var riskProp=$("#riskProp").val().trim();
		var riskType=$("#riskType").val().trim();
		var StartDate=$("#StartDate").val().trim();
		var endDate=$("#endDate").val().trim();
		var char1=$("#char1").val().trim();
		/*var char2=$("#char2").val().trim();
		var char5=$("#char5").val().trim();*/
		var char6=$("#char6").val().trim();
		//var char3=$("#char3").val().trim();
		var risk=$("#risk").val().trim();
		var char4=$("#char4").val().trim();
		//var premmin=$("#premmin").val();
		var amntmin=$("#amntmin").val();
		var agemax=$("#agemax").val();
		var agemin=$("#agemin").val();
		var amntunit=$("#amntunit").val();
		var premunit=$("#premunit").val();
		var jointlife=$("#jointlife").val().trim();
		var otherinsured=$("#otherinsured").val().trim();
		//第二被保人
		var agemaxtwo=$("#agemaxtwo").val();
		var agemintwo=$("#agemintwo").val();
	    var riskClassify=$("#riskClassify").val();
	    
	    var char5=$("#char5").val().trim();
	    
		 var regu = /^[1-9]\d*$/;
		 
		 if (char5 != "") {
		 if (!regu.test(char5)) {
			 alert("投连产品可追加年限只能为正整数！");
			 return;
		 }
		 }
	    
	/*	if(premmin!=null&&premmin!=""){
			var reg=/^\d+(\.\d+)?$/;
				if(!reg.test(premmin.trim())){
					alert("最低保费只能是数字，请重新输入");
					return;
				}
		}*/
		
		if(amntmin!=null&&amntmin!=""){
			var reg=/^\d+(\.\d+)?$/;
			if(!reg.test(amntmin.trim())){
					alert("最低保额只能是数字，请重新输入");
					return;
				}
		}

		if(agemin!=null&&agemin!=""){

			var reg=/^\d+(\.\d+)?$/;
				if(!reg.test(agemin.trim())){
					alert("被保人起始年龄只能是数字，请重新输入");
					return;
				}
		}

		if(agemax!=null&&agemax!=""){
			var reg=/^\d+(\.\d+)?$/;
				if(!reg.test(agemax.trim())){
					alert("被保人截止年龄只能是数字，请重新输入");
					return;
				}
		}
		

		if(agemintwo!=null&&agemintwo!=""){

			var reg=/^\d+(\.\d+)?$/;
				if(!reg.test(agemintwo.trim())){
					alert("第二被保人起始年龄只能是数字，请重新输入");
					return;
				}
		}
		if(agemaxtwo!=null&&agemaxtwo!=""){
			var reg=/^\d+(\.\d+)?$/;
				if(!reg.test(agemaxtwo.trim())){
					alert("第二被保人截止年龄只能是数字，请重新输入");
					return;
				}
		}
		
		
		if(premunit!=null&&premunit!=""){
			var reg=/^\d+(\.\d+)?$/;
				if(!reg.test(premunit.trim())){
					alert("保费单位只能是数字，请重新输入");
					return;
				}
		}
		if(amntunit!=null&&amntunit!=""){
			var reg=/^\d+(\.\d+)?$/;
				if(!reg.test(amntunit.trim())){
					alert("保额单位只能是数字，请重新输入");
					return;
				}
		}
		
		
		
		if(insuranceCom==""){
			alert("保险公司不能为空");
			return;
		}
		if(subRiskFlag==""){
			alert("主附险标志不能为空");
			return;
		}	
		
		
		if(salesChl==""){
			alert("产品名称不能为空");
			return;
		}

		if(riskName==""){
			alert("产品简称不能为空");
			return;
		}	
		if(riskCode==""){
			alert("产品代码(@XX)不能为空");
			return;
		}

		if(riskProp==""){
			alert("产品外部代码不能为空");
			return;
		}
		
		if(subRiskVer==""){
			alert("产品代码简称不能为空");
			return;
		}
		if(char6==""){
			alert("产品状态不能为空");
			return;
		}
		if(char1==""){
			alert("保费计算方式不能为空");
			return;
		}
		if(StartDate==""){
			alert("销售起期不能为空");
			return;
		}
		
		if(endDate==""){
			alert("销售止期不能为空");
			return;
		}
		
		if(endDate<StartDate){
			
			alert("销售止期不能小于销售起期");
			return;
		}

		if(risk==""){
			alert("产品风险等级不能为空");
			return;
		}
		
		if(riskType==""){
			alert("产品类型不能为空");
			return;
		}
		if(riskClassify==""){
			alert("保险分类不能为空");
			return;
		}
		
		if(char4==""){
			alert("是否存在份数不能为空");
			return;
		} 

		if(jointlife==""){
			alert("请选择是否支持多被保险人");
			return;
		}
		if(subRiskFlag!=""&&subRiskFlag=="S"&&otherinsured==""){
			alert("附加险是否有被保人豁免险不能为空");
			return;
		}
		distinctriskCode("2");
		
	

   });
	


	


});


//判断数据是否已经加载完毕
$("#cusTable").on('load-success.bs.table',function(data){//alert(subRiskFlag);
	//复制功能为主险时查询附加险数据
	if(insuranceComA!=null&&riskCodeA!=null&&subRiskFlagA=="M"){
    changeRela();
	}
	
 });

//查询是否有附加险并设置选中
function changeRela(){
	$.ajax({
			type : "POST",
			url:path+"/LmriskAController/selectRela.do",// 后台请求URL地址
			data:{riskCode:riskCodeA,checkFlag:checkFlagA},
			dataType : "json",
			traditional : true,
			success : function(data) {
				var json=eval(data);
				  var arr=$('#cusTable').bootstrapTable('getData');
				  for(var i=0;i<arr.length;i++){
					  for(var j=0;j<json.length;j++)
					  if(arr[i].riskCode==json[j].relariskcode){
						  $('#cusTable').bootstrapTable('check',i);
						  break;
					  }
					  
				 }
				 
			},
			error : function() {
				alert("plus failed");
			}
		});
}


function distinctriskCode(va){
	var riskCode=$("#riskCode").val().trim();
	if(riskCode!=""&&riskCode!=null){
		$.ajax({
					type : "POST",
					url:path+"/LmriskAController/distinctByRiskCode.do",// 后台请求URL地址
					data :  "riskCode="+riskCode.trim(),
					dataType : "json",
					success : function(data) {
						if(data==false){
								alert("险种代码已存在，请重新填写！");
								return;
						}else{
							   if(va=="2"){
								var ids1 =$("form").serialize();
								riskVerSel();
								addParamall(ids1);
							
								
							  }
						}
					},
					error : function() {
						alert("plus failed");
					}
			});
		
	}
	
}



function riskVerSel(){
/*	var a=$('#char3').find("option:selected").text();
	$("#riskVer").val(a);*/
	var b=$('#char6').find("option:selected").text();
	$("#riskShortName").val(b);
}




function actionFormatter(value, row, index) {      
	return [
		'<button class="btn btn-primary update" id="update">添加</button>'
	].join('');
}

var indexs="";
var mytype="";
var myname="";
var tableParamId="#cusTables";
window.actionEvents = {
		//修改
		'click .update': function (e, value, row, index) {
		    indexs=index;
		    mytype=row.code;
		    myname=row.code;
		    if(row.codealias=="1"){
		    	tableParamId="#cusTables";
		    }
		    if(row.codealias=="2"){
		    	tableParamId="#cusTablesa";
		    }
		    if(row.codealias=="3"){
		    	tableParamId="#cusTablesb";
		    }
			if(row.codealias=="4"){
				tableParamId="#cusTablesc";
			}
			//保险期间
		    if(row.code=="insuyear"){
		    	var mycount=0;
		    	if(row.params!=null){
		    	var val =row.params.split(",");
		    	mycount=val.length;
		    	}
		    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoA.jsp?code='+row.code+'&id='+indexs
		    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycount='+mycount);  
		    }
		    //交费期间
		    else if(row.code=="payendyear"){
		    	var mycountB=0;
		    	if(row.params!=null){
		    	var val =row.params.split(",");
		    	mycountB=val.length;
		    	}
		    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoB.jsp?code='+row.code+'&id='+indexs
		    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountB='+mycountB); 
		    }
		    //最低保费
		    else if(row.code=="premmin"){
		    	var mycountC=0;
		    	if(row.params!=null){
		    	var val =row.params.split(",");
		    	mycountC=val.length;
		    	}
		    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoC.jsp?code='+row.code+'&id='+indexs
		    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountC='+mycountC); 
		    }		    
		    //年金/生存保险金领取年龄
		    else if(row.code=="InshAnnuityGetYearage"){
		    	var mycountD=0;
		    	if(row.params!=null){
		    	var val =row.params.split(",");
		    	mycountD=val.length;
		    	}
		    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoD.jsp?code='+row.code+'&id='+indexs
		    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountD='+mycountD); 
		    }		    
		    //年金/生存保险金领取期间
		    else  if(row.code=="survivalInsurancePeriod"){
		    	var mycountE=0;
		    	if(row.params!=null){
		    	var val =row.params.split(",");
		    	mycountE=val.length;
		    	}
		    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoE.jsp?code='+row.code+'&id='+indexs
		    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountE='+mycountE); 
		    }
		    //额外年金领取年龄
		    else  if(row.code=="extragetyear"){
		    	var mycountF=0;
		    	if(row.params!=null){
		    	var val =row.params.split(",");
		    	mycountF=val.length;
		    	}
		    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoF.jsp?code='+row.code+'&id='+indexs
		    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountF='+mycountF); 
		    }
		    //最高保费
		    else if(row.code=="premmax"){
		    	var mycountM=0;
		    	if(row.params!=null){
		    	var val =row.params.split(",");
		    	mycountM=val.length;
		    	}
		    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoM.jsp?code='+row.code+'&id='+indexs
		    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountM='+mycountM); 
		    }
		    //首次额外年金领取日
		    else  if(row.code=="extragetyearday"){
		    	var mycountG=0;
		    	if(row.params!=null){
		    	var val =row.params.split(",");
		    	mycountG=val.length;
		    	}
		    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoG.jsp?code='+row.code+'&id='+indexs
		    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountG='+mycountG);
		    }
			//根据缴费期限设置最低保费校验
		    else if(row.code=="premiumlimit"){
			    	var mycountP=0;
			    	if(row.params!=null){
			    	var val =row.params.split(",");
			    	mycountP=val.length;
			    	}
			    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoP.jsp?code='+row.code+'&id='+indexs
			    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountP='+mycountP); 
			 }
			 //根据缴费期限设置最高保费校验
		     else if(row.code=="maximumpremiumlimit"){
			    	var mycountI=0;
			    	if(row.params!=null){
			    	var val =row.params.split(",");
			    	mycountI=val.length;
			    	}
			    	$('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfoI.jsp?code='+row.code+'&id='+indexs
			    			+'&params='+encodeURI(encodeURI(row.params))+'&paramscode='+encodeURI(encodeURI(row.paramscode))+'&mycountI='+mycountI); 
			 }else{
			  
			    	var insuranceCom=$("#insuranceCom").val();
				    if(row.params!=null){
				    	var paramsarr=new Array();
				    	var paramsarrb=new Array();
				    	paramsarr=row.paramscode.split(",");
				    	paramsarrb=row.params.split(",");
				    	var rowis="";
				    	for(var i=0;i<paramsarr.length;i++){
				    		rowis=rowis+paramsarr[i]+"--"+paramsarrb[i]+",";
				    	}
				    	 $('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfo.jsp?code='+row.code+'&id='
					        		+indexs+'&insuranceCom='+insuranceCom+'&params='+encodeURI(encodeURI(rowis))); 
				    }else{    	
				        $('#dialog-form').load(path+'/application/insuranceproducts/newinsuranceproducts/jsp/bookinfo.jsp?code='+row.code+'&id='
				        		+indexs+'&insuranceCom='+insuranceCom+'&params='+encodeURI(encodeURI(row.params))); 
				    }
			    	
			    }		    
		    
	        $( "#dialog-form" ).dialog( "open" );

		      
	 },
};


$(function() {




$( "#dialog-form" ).dialog({
    autoOpen: false,
    height: 500,
    width: 900,
    modal: true,
    buttons: {
      "添加": function() {
	      
	    	   $( this ).dialog( "close" );
	    	   if (mytype!=null&&indexs!=null) {

	           	if(myname=="insuyear"){
	           		 chkb(indexs); 
	           	}else if(myname=="payendyear"){
	           		 chkj(indexs); 
	           	}else if(myname=="premmin"){
	           		chkm(indexs); 
          	    }else if(myname=="premmax"){
          	    	chkmax(indexs); 
          	    }else if(myname=="InshAnnuityGetYearage"){
          	    	chkI(indexs); 
          	    }else if(myname=="survivalInsurancePeriod"){
          	    	chkq(indexs); 
          	    }else if(myname=="extragetyear"){
              		 chkx(indexs); 
           	    }else if(myname=="extragetyearday"){
          	    	chkI(indexs);
				}else if(myname=="premiumlimit"){
	       	    	chkpre(indexs);
	       	    }else if(myname=="maximumpremiumlimit"){
	       	    	chkpre(indexs);
	       	    }else{
	       	     chk(indexs); 
	       	    }
	           	
	           }
	      },
      "关闭": function() {
        $( this ).dialog( "close" );
      }
    },
    
  });


$("#dialog-form").dialog({ 

    closeOnEscape:false, 

    open:function(event,ui){
    	$(".ui-dialog-titlebar-close").hide();
      } 
});



});






function chk(indexs){ 
var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组 
//取到对象数组后，我们来循环检测它是不是被选中 
		var pa="";
		var pb="";
		for(var i=0;i<obj.length;i++){
				if(obj[i].checked){
					var p=i%20;
				  	if(p==0){
				  	pa+="";
				  }
				  	if(obj[i].value!=''){
				  		if(obj[i].value!='999'){
				  			var mycars=new Array();
						  	  mycars=obj[i].value.trim().split("--");
							  pa=pa+mycars[1].trim()+",";
							  pb=pb+mycars[0].trim()+",";
				  		}else{
				  			 pa=pa+"终身"+","; 
							 pb=pb+obj[i].value.trim()+","; 
				  		}
				  	}
			  	  /*var mycars=new Array();
			  	  mycars=obj[i].value.trim().split("--");
				  pa=pa+mycars[1].trim()+",";
				  pb=pb+mycars[0].trim()+",";*/ 
				  
			}
	}//如果选中，将value添加到变量s中 
		if(pa.length>1){
		pa=pa.substring(0,pa.length-1);
		pb=pb.substring(0,pb.length-1);
		$(tableParamId).bootstrapTable('updateRow',{
		index:indexs,
		row:{
		params:pa,
		paramscode:pb
		}
		});
  		}else{
  			$(tableParamId).bootstrapTable('updateRow',{
  				index:indexs,
  				row:{
  				params:null,
  				paramscode:null
  				}
  				})
  		}
 
} 



function chkb(indexs){ 
var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组 
var objs=document.getElementsByName('sub'+indexs+'s'); //选择所有name="'test'"的对象，返回数组 
//取到对象数组后，我们来循环检测它是不是被选中 
		var pa="";
		var pb="";
		for(var i=0;i<obj.length;i++){
			var ob="";
			var p=i%20;
			  	if(p==0){
			  	pa+="";
			  	pb+="";
			  	}
			 if(obj[i].value!=''){
				 ob=obj[i].value;
				 if(objs[i].value.indexOf('A')>=0){
					 obj[i].value='至'+obj[i].value;
				}
			 if(obj[i].value!='999'){
				 if(objs[i].value.trim()!=null&&objs[i].value.trim()!=''){
					 var valuea="";
					 var valueb="";
						if(objs[i].value.trim()=="Y"){
						valuea="年";
						}
						if(objs[i].value.trim()=="A"){
						valuea="周岁";
						}
					}
			  pa=pa+obj[i].value.trim()+valuea+",";
			  pb=pb+ob.trim()+objs[i].value.trim()+",";
			}else{
			  pa=pa+"终身"+","; 
			  pb=pb+ob.trim()+","; 
			}
			 }
	}//如果选中，将value添加到变量s中 
		
		
		
		
		if(pa.length>1){
		   pa=pa.substring(0,pa.length-1);
		   pb=pb.substring(0,pb.length-1);
		$(tableParamId).bootstrapTable('updateRow',{
			index:indexs,
			row:{
			params:pa,
			paramscode:pb
			}
			});
  		}else{
  			$(tableParamId).bootstrapTable('updateRow',{
  				index:indexs,
  				row:{
  				params:null,
  				paramscode:null,
  				}
  				})
  		}
 
}

function chkj(indexs){ 
var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组 
var objs=document.getElementsByName('sub'+indexs+'s'); //选择所有name="'test'"的对象，返回数组 
//取到对象数组后，我们来循环检测它是不是被选中 
		var pa="";
		var pb="";
		for(var i=0;i<obj.length;i++){
			var ob="";
			var p=i%20;
			  	if(p==0){
			  	pa+="";
			  	pb+="";
			  	}
			 if(obj[i].value!=''){
				 ob=obj[i].value;
				 if(objs[i].value.indexOf('A')>=0){
					 obj[i].value='至'+obj[i].value;
				}
			 if(obj[i].value!='0Y'){
				 if(objs[i].value.trim()!=null&&objs[i].value.trim()!=''){
					 var valuea="";
					 var valueb="";
						if(objs[i].value.trim()=="Y"){
						valuea="年";
						}
						if(objs[i].value.trim()=="A"){
						valuea="周岁";
						}
					}
			  pa=pa+obj[i].value.trim()+valuea+",";
			  pb=pb+ob.trim()+objs[i].value.trim()+",";
			}else{
			  pa=pa+"趸交"+","; 
			  pb=pb+ob.trim()+","; 
			}
			 }
	}//如果选中，将value添加到变量s中 
		
		
		
		
		if(pa.length>1){
		   pa=pa.substring(0,pa.length-1);
		   pb=pb.substring(0,pb.length-1);
		$(tableParamId).bootstrapTable('updateRow',{
			index:indexs,
			row:{
			params:pa,
			paramscode:pb
			}
			});
  		}else{
  			$(tableParamId).bootstrapTable('updateRow',{
  				index:indexs,
  				row:{
  				params:null,
  				paramscode:null,
  				}
  				})
  		}
 
}


function chkm(indexs){ 
var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组 
var objs=document.getElementsByName('sub'+indexs+'s'); //选择所有name="'test'"的对象，返回数组 
//取到对象数组后，我们来循环检测它是不是被选中 
		var pa="";
		var pb="";
		for(var i=0;i<obj.length;i++){
			var ob="";
			var p=i%20;
			  	if(p==0){
			  	pa+="";
			  	pb+="";
			  	}
			 if(obj[i].value!=''){
				 ob=obj[i].value;
				 if(objs[i].value.indexOf('A')>=0){
					 obj[i].value=obj[i].value;
				}
				 if(objs[i].value.trim()!=null&&objs[i].value.trim()!=''){
					 var valuea="";
					 var valueb="";
						if(objs[i].value.trim()=="Y"){
						valuea="年交";
						}
						if(objs[i].value.trim()=="M"){
						valuea="月交";
						}
						if(objs[i].value.trim()=="R"){
							valuea="元";
						}
						if(objs[i].value.trim()=="S"){
							valuea="趸交";
						}
						if(objs[i].value.trim()=="Q"){
							valuea="季交";
						}
						if(objs[i].value.trim()=="H"){
							valuea="半年交";
						}
					}
			  pa=pa+obj[i].value.trim()+valuea+",";
			  pb=pb+ob.trim()+objs[i].value.trim()+",";
			}
			 }
	//如果选中，将value添加到变量s中 
		
		
		
		
		if(pa.length>1){
		   pa=pa.substring(0,pa.length-1);
		   pb=pb.substring(0,pb.length-1);
		$(tableParamId).bootstrapTable('updateRow',{
			index:indexs,
			row:{
			params:pa,
			paramscode:pb
			}
			});
  		}else{
  			$(tableParamId).bootstrapTable('updateRow',{
  				index:indexs,
  				row:{
  				params:null,
  				paramscode:null,
  				}
  				})
  		}
 
}

function chkmax(indexs){ 
	var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组 
	var objs=document.getElementsByName('sub'+indexs+'s'); //选择所有name="'test'"的对象，返回数组 
	//取到对象数组后，我们来循环检测它是不是被选中 
			var pa="";
			var pb="";
			for(var i=0;i<obj.length;i++){
				var ob="";
				var p=i%20;
				  	if(p==0){
				  	pa+="";
				  	pb+="";
				  	}
				 if(obj[i].value!=''){
					 ob=obj[i].value;
					 if(objs[i].value.indexOf('A')>=0){
						 obj[i].value=obj[i].value;
					}
					 if(objs[i].value.trim()!=null&&objs[i].value.trim()!=''){
						 var valuea="";
						 var valueb="";
							if(objs[i].value.trim()=="Y"){
							valuea="年交";
							}
							if(objs[i].value.trim()=="M"){
							valuea="月交";
							}
							if(objs[i].value.trim()=="R"){
								valuea="元";
							}
							if(objs[i].value.trim()=="0Y"){
								valuea="趸交";
							}
						}
				  pa=pa+obj[i].value.trim()+valuea+",";
				  pb=pb+ob.trim()+objs[i].value.trim()+",";
				}
				 }
		//如果选中，将value添加到变量s中 
			
			
			
			
			if(pa.length>1){
			   pa=pa.substring(0,pa.length-1);
			   pb=pb.substring(0,pb.length-1);
			$(tableParamId).bootstrapTable('updateRow',{
				index:indexs,
				row:{
				params:pa,
				paramscode:pb
				}
				});
	  		}else{
	  			$(tableParamId).bootstrapTable('updateRow',{
	  				index:indexs,
	  				row:{
	  				params:null,
	  				paramscode:null,
	  				}
	  				})
	  		}
	 
	}





//根据缴费期限设置保费校验
function chkpre(indexs){ 	
	
		var obje=document.getElementsByName('sub'+indexs+'e'); //保费数组 
		var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组  参数期限
		var objs=document.getElementsByName('sub'+indexs+'s'); //选择所有name="'test'"的对象，返回数组 参数类型
		//取到对象数组后，我们来循环检测它是不是被选中 
		 var pa="";
		 var pb="";
		 for(var i=0;i<obj.length;i++){
		  //保费
		  var oe="";
		  // 参数期限
		  var ob="";
		  
		  var p=i%20;
		     if(p==0){
		    	 pa+="";
		    	 pb+="";
		     }
		if(obj[i].value!=''){
			    
			    if(obje[i].value!=''){
			    	//保费
			    	oe=obje[i].value;
			    }
			    // 参数期限
			    ob=obj[i].value;
			    
			    //趸交回显
			    if(objs[i].value.trim()!=null&&objs[i].value.trim()!=''&&objs[i].value=='0Y'){
			    	
			    	pa=pa+"趸交"+oe.trim()+",";
				    pb=pb+ob.trim()+"|"+objs[i].value.trim()+"|"+oe.trim()+",";
				   
			    }else{//非趸交
			    	 var valuea="";
				     var valueb="";
				     if(objs[i].value.trim()=="Y"){
				    	 valuea="年";
				     }
				     if(objs[i].value.trim()=="A"){
				    	 valuea="岁";
				     } 
				    
			        pa=pa+obj[i].value.trim()+valuea+oe.trim()+",";
				    pb=pb+ob.trim()+"|"+objs[i].value.trim()+"|"+oe.trim()+",";
				   
			    }
			   
	     }
		   
	 }
		//如果选中，将value添加到变量s中 		 		 
		 if(pa.length>1){
		    pa=pa.substring(0,pa.length-1);
		    pb=pb.substring(0,pb.length-1);
		 $(tableParamId).bootstrapTable('updateRow',{
		  index:indexs,
		  row:{
		  params:pa,
		  paramscode:pb
		  }
		  });
		   }else{
		    $(tableParamId).bootstrapTable('updateRow',{
		     index:indexs,
		     row:{
		     params:null,
		     paramscode:null,
		     }
		     })
		   }

}










function chkI(indexs){ 
var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组 
var objs=document.getElementsByName('sub'+indexs+'s'); //选择所有name="'test'"的对象，返回数组 
//取到对象数组后，我们来循环检测它是不是被选中 
		var pa="";
		var pb="";
		for(var i=0;i<obj.length;i++){
			var ob="";
			var p=i%20;
			  	if(p==0){
			  	pa+="";
			  	pb+="";
			  	}
			 if(obj[i].value!=''){
				 ob=obj[i].value;
				 if(objs[i].value.indexOf('A')>=0){
					 obj[i].value=obj[i].value;
				}
			
				 if(objs[i].value.trim()!=null&&objs[i].value.trim()!=''){
					 var valuea="";
					 var valueb="";
						if(objs[i].value.trim()=="Y"){
						valuea="保单生效";
						pa=pa+valuea+obj[i].value.trim()+"年后"+",";
						}
						if(objs[i].value.trim()=="A"){
						valuea="周岁";
						pa=pa+obj[i].value.trim()+valuea+",";
						}
						if(objs[i].value.trim()=="J"){
							valuea="缴费期满后（第";
							pa=pa+valuea+obj[i].value.trim()+"年）"+",";
						}
						if(objs[i].value.trim()=="X"){
							valuea="第";
							pa=pa+valuea+obj[i].value.trim()+"个保单周年日"+",";
						}
						
						if(objs[i].value.trim()=="D"){
							valuea="第";
							pa=pa+valuea+obj[i].value.trim()+"个保单年度"+",";
						}
						
					}
			  
			  pb=pb+ob.trim()+objs[i].value.trim()+",";
			
			 }
	}//如果选中，将value添加到变量s中 
		
		if(pa.length>1){
		   pa=pa.substring(0,pa.length-1);
		   pb=pb.substring(0,pb.length-1);
		$(tableParamId).bootstrapTable('updateRow',{
			index:indexs,
			row:{
			params:pa,
			paramscode:pb
			}
			});
  		}else{
  			$(tableParamId).bootstrapTable('updateRow',{
  				index:indexs,
  				row:{
  				params:null,
  				paramscode:null,
  				}
  				})
  		}
 
}

function chkq(indexs){ 
	var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组 
	var objs=document.getElementsByName('sub'+indexs+'s'); //选择所有name="'test'"的对象，返回数组 
	//取到对象数组后，我们来循环检测它是不是被选中 
			var pa="";
			var pb="";
			for(var i=0;i<obj.length;i++){
				var ob="";
				var p=i%20;
				  	if(p==0){
				  	pa+="";
				  	pb+="";
				  	}
				 if(obj[i].value!=''){
					 ob=obj[i].value;
					 if(objs[i].value.indexOf('A')>=0){
						 obj[i].value='至'+obj[i].value;
					}
				 if(obj[i].value!='0Y' && obj[i].value!='999'){
					 if(objs[i].value.trim()!=null&&objs[i].value.trim()!=''){
						 var valuea="";
						 var valueb="";
							if(objs[i].value.trim()=="Y"){
							valuea="年";
							pa=pa+obj[i].value.trim()+valuea+",";
							}
							if(objs[i].value.trim()=="A"){
							valuea="周岁";
							pa=pa+obj[i].value.trim()+valuea+",";
							}
							if(objs[i].value.trim()=="X"){
							valuea="至第";
							pa=pa+valuea+obj[i].value.trim()+"个保单周年日"+",";
							}
						}
				  pb=pb+ob.trim()+objs[i].value.trim()+",";
				}else if(obj[i].value === "999"){
					 pa=pa+"终身"+",";
					 pb=pb+ob.trim()+",";
				 }else{
				  pa=pa+"至保单满期"+",";
				  pb=pb+ob.trim()+",";
				}
				 }
		}//如果选中，将value添加到变量s中 
			
			if(pa.length>1){
			   pa=pa.substring(0,pa.length-1);
			   pb=pb.substring(0,pb.length-1);
			$(tableParamId).bootstrapTable('updateRow',{
				index:indexs,
				row:{
				params:pa,
				paramscode:pb
				}
				});
	  		}else{
	  			$(tableParamId).bootstrapTable('updateRow',{
	  				index:indexs,
	  				row:{
	  				params:null,
	  				paramscode:null,
	  				}
	  				})
	  		}
	 
	}

function chkx(indexs){ 
	var obj=document.getElementsByName('sub'+indexs); //选择所有name="'test'"的对象，返回数组 
	var objs=document.getElementsByName('sub'+indexs+'s'); //选择所有name="'test'"的对象，返回数组 
	//取到对象数组后，我们来循环检测它是不是被选中 
			var pa="";
			var pb="";
			for(var i=0;i<obj.length;i++){
				var ob="";
				var p=i%20;
				  	if(p==0){
				  	pa+="";
				  	pb+="";
				  	}
				 if(obj[i].value!=''){
					 ob=obj[i].value;
					 if(objs[i].value.indexOf('A')>=0){
						 obj[i].value=obj[i].value;
					}
				 if(obj[i].value!='0Y'){
					 if(objs[i].value.trim()!=null&&objs[i].value.trim()!=''){
						 var valuea="";
						 var valueb="";
							if(objs[i].value.trim()=="Y"){
							 valuea="年";
							 pa=pa+obj[i].value.trim()+valuea+",";
							}
							if(objs[i].value.trim()=="A"){
							 valuea="周岁";
							 pa=pa+obj[i].value.trim()+valuea+",";
							}
							if(objs[i].value.trim()=="X"){
								valuea="第";
								pa=pa+valuea+obj[i].value.trim()+"个保单周年日"+",";
							}
						}
				 
				  pb=pb+ob.trim()+objs[i].value.trim()+",";
				}
				 }
		}//如果选中，将value添加到变量s中 
			
			if(pa.length>1){
			   pa=pa.substring(0,pa.length-1);
			   pb=pb.substring(0,pb.length-1);
			$(tableParamId).bootstrapTable('updateRow',{
				index:indexs,
				row:{
				params:pa,
				paramscode:pb
				}
				});
	  		}else{
	  			$(tableParamId).bootstrapTable('updateRow',{
	  				index:indexs,
	  				row:{
	  				params:null,
	  				paramscode:null,
	  				}
	  				})
	  		}
	 
	}


//获取CheckBox选中的行
function mycheckbox(){

	 //01  附加险关系
	 var arr=$('#cusTable').bootstrapTable('getSelections');
	 var riskcode=$("#riskCode").val();
	 for(var i=0;i<arr.length;i++){
		 addDef(arr[i].riskCode,riskcode,'01',arr.length-1,i);
	 }
	
}


//获取CheckBox选中的行
function mycheckboxparam(){

	 //参数关系
	 var arrs=$('#cusTables').bootstrapTable('getSelections');
	 var riskcode=$("#riskCode").val();
	  for(var i=0;i<arrs.length;i++){
		 insertParam(arrs[i].code,arrs[i].params,riskcode,arrs.length-1,i);
		
	 }
	
}





//查询所有产品
function myquery(){
			var a=$('#insuranceCom').val();
			var b=$('#subRiskFlag').val();
			$('#otherinsured').attr("disabled",true);
			if(a!=null&&a!=""){
			//s附加险，m主险
			if(b=="M"){
				var data  = new Object();
 		   	//保险公司代码	
		   		data.agentcom =a;
		   		var url_d = "/LmriskAController/selectProduct.do";
		   		queryTable(url_d , tab_d ,data);
		   		
			}else{
			var data  = new Object();
 		   	//保险公司代码	
		   		data.agentcom ="";
		   		var url_d = "/LmriskAController/selectProduct.do";
		   		queryTable(url_d , tab_d ,data);
		   		
		   		$('#otherinsured').attr("disabled",false);
		   		
			}
			}else{
				if(a==null||a==""){
					alert("请先选择保险公司！");
					var b=$('#subRiskFlag').val("S");
					$('#otherinsured').attr("disabled",true);
					return;
				}
		   }
}

function riskVerSels(){
	var a=$('#char3').find("option:selected").text();
	//$("#riskVer").val(a);
}

function shortname(){
var b=$('#char6').find("option:selected").text();
$("#riskShortName").val(b);
}

function shortnames(){
	var a=$('#char3').find("option:selected").text();
	//$("#riskVer").val(a);
}


function addParamall(ids1){	
	var insuranceCom=$("#insuranceCom").val().trim();
	var riskCode=$("#riskCode").val().trim();
	var subRiskVer=$("#subRiskVer").val().trim();
	var salesChl=$("#salesChl").val().trim();
	var subRiskFlag=$("#subRiskFlag").val().trim();
	var riskName=$("#riskName").val().trim();
	var riskProp=$("#riskProp").val().trim();
	var riskType=$("#riskType").val().trim();
	var StartDate=$("#StartDate").val().trim();
	var endDate=$("#endDate").val().trim();
	var char1=$("#char1").val().trim();
	var char6=$("#char6").val().trim();
	var jointlife=$("#jointlife").val().trim();
	var risk=$("#risk").val().trim();
	var char4=$("#char4").val().trim();
	var operator=$("#operator").val().trim();
	var riskShortName=$("#riskShortName").val().trim();
	//var riskVer=$("#riskVer").val().trim();
	var otherinsured=$("#otherinsured").val().trim();
	//var premmin=$("#premmin").val().trim();
	var premunit=$("#premunit").val();
	var amntmin=$("#amntmin").val();
	var amntunit=$("#amntunit").val();
	var riskClassify=$("#riskClassify").val();
	var char5=$("#char5").val().trim();
	//单位
	//var premmintype=$("#premmintype").val().trim();
	var premunittype=$("#premunittype").val().trim();
	var amntmintype=$("#amntmintype").val().trim();
	var amntunittype=$("#amntunittype").val().trim();
	
	
	var agemins=$("#agemin").val();
	var agemintype=document.getElementsByName("agemintype");
	var agemaxtype=document.getElementsByName("agemaxtype");
	var agemaxs=$("#agemax").val();
	var mint="";
	var maxt="";
	var agemin="";
	var agemax="";

	
	for(var i=0; i<agemintype.length; i ++){
	        if(agemintype[i].checked){
	            mint=agemintype[i].value;
	        }
	    }

	
	for(var i=0; i<agemaxtype.length; i ++){
        if(agemaxtype[i].checked){
            maxt=agemaxtype[i].value;
        }
    }
	if(mint!=null&&mint!=""&&agemins!=null&&agemins!=""){
		
		agemin=agemins.trim()+mint;
	}
	if(maxt!=null&&maxt!=""&&agemaxs!=null&&agemaxs!=""){
		
		agemax=agemaxs.trim()+maxt;
	}
	
	//第二被保人
	var agemintwos=$("#agemintwo").val();
	var agemintypetwo=document.getElementsByName("agemintypetwo");
	var agemaxtypetwo=document.getElementsByName("agemaxtypetwo");
	var agemaxtwos=$("#agemaxtwo").val();
	var minttwo="";
	var maxttwo="";
	var agemintwo="";
	var agemaxtwo="";
	
	
	for(var i=0; i<agemintypetwo.length; i ++){
        if(agemintypetwo[i].checked){
            minttwo=agemintypetwo[i].value;
        }
    }


	for(var i=0; i<agemaxtypetwo.length; i ++){
	    if(agemaxtypetwo[i].checked){
	        maxttwo=agemaxtypetwo[i].value;
	    }
	}
	if(minttwo!=null&&minttwo!=""&&agemintwos!=null&&agemintwos!=""){
		
		agemintwo=agemintwos.trim()+minttwo;
	}
	if(maxttwo!=null&&maxttwo!=""&&agemaxtwos!=null&&agemaxtwos!=""){
		
		agemaxtwo=agemaxtwos.trim()+maxttwo;
	}

	
	


	/*if(premmin!=null&&premmin!=""){
		premmin=parseInt(parseFloat(premmin)*parseFloat(premmintype));
	}*/
	if(premunit!=null&&premunit!=""){
		premunit=parseInt(parseFloat(premunit.trim())*parseFloat(premunittype));
	}

	if(amntmin!=null&&amntmin!=""){
		amntmin=parseInt(parseFloat(amntmin.trim())*parseFloat(amntmintype));
	}
	if(amntunit!=null&&amntunit!=""){
		amntunit=parseInt(parseFloat(amntunit.trim())*parseFloat(amntunittype));
	}

	
	 //参数关系
	 var arrs=$('#cusTables').bootstrapTable('getData');
	 var arrsa=$('#cusTablesa').bootstrapTable('getData');
	 var arrsb=$('#cusTablesb').bootstrapTable('getData');
	 var arrsc=$('#cusTablesc').bootstrapTable('getData');
	 var arr=$('#cusTable').bootstrapTable('getSelections');
	 var riskcode=$("#riskCode").val();
	 var countlength=0;
	 for(var i=0;i<arrs.length;i++){
		  if(arrs[i].params!=null&&arrs[i].params!=""){
			  countlength++;
		  }
	 }
	 
	 for(var i=0;i<arrsa.length;i++){
		  if(arrsa[i].params!=null&&arrsa[i].params!=""){
			  countlength++;
		  }
	 }
	 for(var i=0;i<arrsb.length;i++){
		  if(arrsb[i].params!=null&&arrsb[i].params!=""){
			  countlength++;
		  }
	 }
	for(var i=0;i<arrsc.length;i++){
		if(arrsc[i].params!=null&&arrsc[i].params!=""){
			countlength++;
		}
	}
	 
	
	 $("#countparam").val(parseInt(countlength));

		if(arrs.length>0||arrsa.length>0||arrsb.length>0||arrsc.length>0&&count){
			  var arr=$('#cusTable').bootstrapTable('getSelections');
	  		  $("#countdef").val(arr.length);
	  	    var jsonData=new Array();
	  		var ta = {
					"insuranceCom" : insuranceCom,
					"riskCode" : riskCode,
					"subRiskVer"   :subRiskVer,
					"salesChl"   : salesChl,
					"subRiskFlag":subRiskFlag,
					"riskName"   : riskName,
					"riskProp" : riskProp,
					"riskType" : riskType,
					"startDate"   :StartDate,
					"endDate"   : endDate,
					"char1":char1,
					"char6"   : char6,
					"jointlife":jointlife,
					"risk":risk,
					"char4"   : char4,
					"operator"   : operator,
					"riskShortName":riskShortName,
					//"riskVer"   : riskVer,
					"riskShortName":riskShortName,
					"countdef"   : $("#countdef").val().trim(),
					"countparam"   : $("#countparam").val().trim(),
					//"premmin":premmin,
					"premunit":premunit,
					"amntmin":amntmin,
					"amntunit":amntunit,
					"agemin":agemin,
					"agemax":agemax,
					"agemintwo":agemintwo,
					"agemaxtwo":agemaxtwo,
					"otherinsured":otherinsured,
					"riskClassify":riskClassify,
					"char5"   : char5,
				};
	  		
	  	         jsonData.push(ta);
	  	         
	  	         for(var i=0;i<arr.length;i++){
	  				 var trs = {
		  						"riskcodes" : riskCode,
	  							"relariskcode" :arr[i].riskCode ,
	  							"relacode" : "01",
	  					       };
	  						jsonData.push(trs);
	  			 }
	  			for (var i=0;i<arrs.length;i++) {
	  				if(arrs[i].paramscode!=null&&arrs[i].paramscode!=""){
					var tr = {
						"paramstype" : arrs[i].code,
						"paramscode" : arrs[i].paramscode,
						"paramsname" : arrs[i].params,
						
					};
					jsonData.push(tr);
	  				}
					
	  			}
	  			
	  			for (var i=0;i<arrsa.length;i++) {
	  				if(arrsa[i].paramscode!=null&&arrsa[i].paramscode!=""){
					var tr = {
						"paramstype" : arrsa[i].code,
						"paramscode" : arrsa[i].paramscode,
						"paramsname" : arrsa[i].params,
						
					};
					jsonData.push(tr);
	  				}
					
	  			}
	  			
	  			for (var i=0;i<arrsb.length;i++) {
	  				if(arrsb[i].paramscode!=null&&arrsb[i].paramscode!=""){
					var tr = {
						"paramstype" : arrsb[i].code,
						"paramscode" : arrsb[i].paramscode,
						"paramsname" : arrsb[i].params,
						
					};
					jsonData.push(tr);
	  				}
	  			}
			for (var i=0;i<arrsc.length;i++) {
				if(arrsc[i].paramscode!=null&&arrsc[i].paramscode!=""){
					var tr = {
						"paramstype" : arrsc[i].code,
						"paramscode" : arrsc[i].paramscode,
						"paramsname" : arrsc[i].params,

					};
					jsonData.push(tr);
				}
			}
	  		      myaddParam(jsonData);
	  		}else{
	  			
	  			 var arr=$('#cusTable').bootstrapTable('getSelections');
		  		  $("#countdef").val(arr.length);
		  	    var jsonData=new Array();
		  		var ta = {
						"insuranceCom" : insuranceCom,
						"riskCode" : riskCode,
						"subRiskVer"   :subRiskVer,
						"salesChl"   : salesChl,
						"subRiskFlag":subRiskFlag,
						"riskName"   : riskName,
						"riskProp" : riskProp,
						"riskType" : riskType,
						"startDate"   :StartDate,
						"endDate"   : endDate,
						"char1":char1,
						"char6"   : char6,
						"jointlife":jointlife,
						"risk":risk,
						"char4"   : char4,
						"operator"   : operator,
						"riskShortName":riskShortName,
						//"riskVer"   : riskVer,
						"riskShortName":riskShortName,
						"countdef"   : $("#countdef").val().trim(),
						"countparam"   : $("#countparam").val().trim(),
						//"premmin":premmin,
						"premunit":premunit,
						"amntmin":amntmin,
						"amntunit":amntunit,
						"agemin":agemin,
						"agemax":agemax,
						"agemintwo":agemintwo,
						"agemaxtwo":agemaxtwo,
						"otherinsured":otherinsured,
						"riskClassify":riskClassify,
						"char5"   : char5,
					};
		  	         jsonData.push(ta);
		  	         
		  		  
		  		
		  			 for(var i=0;i<arr.length;i++){
		  				 var trs = {
		  							"riskcodes" : riskCode,
		  							"relariskcode" :arr[i].riskCode ,
		  							"relacode" : "01",
		  							
		  						};
		  						jsonData.push(trs);
		  			 }
		  		 
		  		  
		 			for (var i=0;i<arrs.length;i++) {
		  				if(arrs[i].paramscode!=null&&arrs[i].paramscode!=""){
						var tr = {
							"paramstype" : arrs[i].code,
							"paramscode" : arrs[i].paramscode,
							"paramsname" : arrs[i].params,
							
						};
						jsonData.push(tr);
		  				}
						
		  			}
		  			
		  			for (var i=0;i<arrsa.length;i++) {
		  				if(arrsa[i].paramscode!=null&&arrsa[i].paramscode!=""){
						var tr = {
							"paramstype" : arrsa[i].code,
							"paramscode" : arrsa[i].paramscode,
							"paramsname" : arrsa[i].params,
							
						};
						jsonData.push(tr);
		  				}
						
		  			}
		  			
		  			for (var i=0;i<arrsb.length;i++) {
		  				if(arrsb[i].paramscode!=null&&arrsb[i].paramscode!=""){
						var tr = {
							"paramstype" : arrsb[i].code,
							"paramscode" : arrsb[i].paramscode,
							"paramsname" : arrsb[i].params,
							
						};
						jsonData.push(tr);
		  				}
		  			}
					for (var i=0;i<arrsc.length;i++) {
						if(arrsc[i].paramscode!=null&&arrsc[i].paramscode!=""){
							var tr = {
								"paramstype" : arrsc[i].code,
								"paramscode" : arrsc[i].paramscode,
								"paramsname" : arrsc[i].params,

							};
							jsonData.push(tr);
						}
					}
		  		
		  		    myaddParam(jsonData);
	  		}
		
}




function myaddParam(jsonData){
	$.ajax({
			type : "POST",
			url:path+"/LmriskparamsdefaController/saveAddBean.do",// 后台请求URL地址
			data : JSON.stringify(jsonData),
			dataType : "json",
			contentType : 'application/json;charset=utf-8',
			traditional : true,
			success : function(data) {
				if(data=="1"){
					
					var url ="add.jsp";
					//window.location.href = url;
					
					if($("#subRiskFlag").val().trim() != 'M'){
						//cdk 2020-06 新增逻辑汇丰的有被保人的附加险 需要单独配置告知
						if($("#otherinsured").val().trim() == 'N'||$("#insuranceCom").val().trim()!='INSH'){
							alert("产品添加成功！");
							var url ="add.jsp";
							window.location.href = url;

							return;
						}
						
					}
					alert("产品添加成功,请配置产品告知！");
					$("#riskCode").attr("disabled","disabled");
					$("#save").attr("disabled","disabled");
					$("#save").removeClass("btn btn-primary");
	       			$("#save").addClass("btn btn-primaryis");
	       			$("#reset").attr("disabled","disabled");
					$("#reset").removeClass("btn btn-primary");
	       			$("#reset").addClass("btn btn-primaryis");
	       			
	       			//获取选中的附加险
	       			var arrwlength=$('#cusTable').bootstrapTable('getSelections');
	       			
	       		   //复制功能查询告知数据 主险
	       			if(insuranceComA!=null&&riskCodeA!=null&&subRiskFlagA=="M"){
	       				selectrela();
	       			  
	       			}else{
					//新增页面入口告知
					$("#append").append(
							"<li>"+
								"<a href="+'#fwv-' + num +' '+ " data-toggle='tab'>"+
								 "告知配置 <span>"+num+"</span>"+
								"</a>"+
							"</li>");
					additionRisk();
					 var new_element = document.createElement("script");
	                    new_element.setAttribute("type", "text/javascript");
	                    new_element.setAttribute("src", path+"/application/insuranceproducts/newinsuranceproducts/vuetemplate/vueForm.js");
	                    document.body.appendChild(new_element);
	                    vue_config.push({
	                        id : "testdivchange",
	                        url : "/vue/common/testnotice/"+$("#insuranceCom").val(),
	                        initFunction : pageinit
	                    });
					
					
	       			}
					
					for(var i=0;i<arrwlength.length;i++){
						bootstrapSelection.set(arrwlength[i].riskCode,arrwlength[i].salesChl);
					}
					$("#cusTable").bootstrapTable('hideColumn', 'state');
					$("#save").attr("disabled","disabled");
					$("#save").removeClass("btn btn-primary");
	       			$("#save").addClass("btn btn-primaryis");
	       		   
                    // document.write(" <script type=\"text/javascript\" src=\"../vuetemplate/vueForm.js\"></script>");

                   



                }else{
					alert("产品添加失败");
					var url ="add.jsp";
					//window.location.href = url;

				}
			},
			error : function() {
				alert("plus failed");
			}
		});
}




//公共代码
function queryTable(url , obj , data){
	obj.bootstrapTable('refresh', {
		  url: path+url,
		  query: data
	 });  
};




function selLacom(id){
	document.getElementById(id).options.length = 0;
	$.ajax({
		type : "POST",
		url : path + "/InsuComController/QueryAll.do",// 后台请求URL地址
		success : function(data) {
			for(var i=0;i<data.length;i++){
			var select=document.getElementById(id);
            var option=document.createElement("option");
			option.value=data[i].agentcom;
			option.innerHTML=data[i].name;
			select.appendChild(option);
			
			
			}
			
				
		},
		
	});
	
}

//根据保险公司查出对应的投保单打印类型
function selLower(mytype,id){
	var b=$('#'+mytype+' option:selected').val();
	
	document.getElementById(id).options.length = 1;
	$.ajax({
		type : "POST",
		url : path + "/LdcodeController/selectBylower.do",// 后台请求URL地址
		data : "userCode=" +b,
		success : function(data) {
			for(var i=0;i<data.length;i++){
			var select=document.getElementById(id);
            var option=document.createElement("option");
			option.value=data[i].code;
			option.innerHTML=data[i].codename;
			select.appendChild(option);
			
			
			}
				
		},
		
	});
	
}



function mychange(mytype,param){
	var a=$('#'+mytype+' option:selected').val();
	var b=$('#'+param+' option:selected').val();
	if(a=="S"){
		$.ajax({
			type : "POST",
			url : path + "/LmriskController/queryProduct.do",// 后台请求URL地址
			data : "agentcom=" +b,
			success : function(data) {
			
			},
			
		});
		
	}
}



function sel(mytype,id){
	/*if(mytype=='riskinputtype01'){
		document.getElementById(id).options.length =0;
		$('#b'+num+'').attr("disabled","disabled");
	}else{
		document.getElementById(id).options.length = 1;
	}*/
	document.getElementById(id).options.length = 0;
	$.ajax({
					type : "POST",
					url : path + "/LdcodeController/selectByParam.do",// 后台请求URL地址
					data : "userCode=" +mytype,
					success : function(data) {
						for(var i=0;i<data.length;i++){
						var select=document.getElementById(id);
	                    var option=document.createElement("option");
						option.value=data[i].code;
						option.innerHTML=data[i].codename;
						select.appendChild(option);
						
						
						}
							
					},
					
				});
}


function mychan2(param,id){
	var a=$('#'+param).find("option:selected").text();
	var b=$('#'+param+' option:selected').val();
	
}

function selByThree(param,myval){
	var b=$('#'+param+' option:selected').val();
	sub(b,myval);
}



function sub(str,myval){
	var i = str.length;
	var num =str.substring(0,(i-1));
	var myyear = str.substring((i-1), i);
    $('#'+myval+'').val(myyear);
	
}


/**
 * 设置表格查询参数
 * @param params
 */
function queryParamsa(params){
	//设置查询参数 
    var param = {
    		limit : params.limit,
	        offset: params.offset,
	        
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        codes: "riskinputtype01",
	        userCode:"1",
	    }; 
	    return param; 
}



/**
 * 设置表格查询参数
 * @param params
 */
function queryParamscopy(params){
	//设置查询参数 
    var param = {
    		limit : params.limit,
	        offset: params.offset,
	        
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        checkFlag:checkFlagA,
	        riskCode:riskCodeA,
	    }; 
	    return param; 
}


/**
 * 设置表格查询参数
 * @param params
 */
function queryParamsa_a(params){
	//设置查询参数 
    var param = {
    		limit : params.limit,
	        offset: params.offset,
	        
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        codes: "riskinputtype01",
	        userCode:"2",
	    }; 
	    return param; 
}

/**
 * 设置表格查询参数
 * @param params
 */
function queryParamsa_b(params){
	//设置查询参数 
    var param = {
    		limit : params.limit,
	        offset: params.offset,
	        
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        codes: "riskinputtype01",
	        userCode:"3",
	    }; 
	    return param; 
}
/**
 * 设置表格查询参数
 * @param params
 */
function queryParamsa_c(params){
	//设置查询参数
	var param = {
		limit : params.limit,
		offset: params.offset,

		sortName:params.sortName,//排序列名
		sortOrder:params.sortOrder,//排位命令（desc，asc）

		pageSize: params.pageSize,
		pageNumber:params.pageNumber,
		codes: "riskinputtype01",
		userCode:"4",
	};
	return param;
}
/**
 * 设置表格查询参数
 * @param params
 */
function queryParams(params){
	//设置查询参数 
    var param = {
    		limit : params.limit,
	        offset: params.offset,
	        
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        userCode : $("#userCode").val(),
			userName : $("#userName").val()
	    }; 
	    return param; 
}




/**
 * 设置表格查询参数
 * @param params
 */
function queryRelaParamscopy(params){
	//设置查询参数 
    var param = {
	        //这里是在ajax发送请求的时候设置一些参数 params有什么东西，
	    	//自己看看源码就知道了 limit: params.pageSize,
    		limit : params.limit,
	        offset: params.offset,
	        
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        agentcom:insuranceComA,
	    }; 
	    return param; 
}






/**
 * 翻页带查询参数及列排序
 * @param url
 * @param obj
 * @param col
 * @param uniqueId 行主键
 * @param sortOrder 排序方式
 * @param queryParams
 * @author TKW
 */
function tableInit3( url,obj,col,uniqueId,sortOrder,queryParams){
	 obj.bootstrapTable({
		 url: path+url, // 请求后台的URL（*）
		 dataType: "json",
		 method: 'post', // 请求方式（*）
		 contentType: "application/x-www-form-urlencoded",
		 toolbar: '#toolbar',
		 toolbar: '#toolbar2',// 工具按钮用哪个容器
		 columns:  col,
		 striped: true, // 是否显示行间隔色
		 cache: false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		 pagination: true, // 是否显示分页（*）
		 sortable: true, // 是否启用排序
		 sortOrder: "asc", // 排序方式
		 sortOrder: sortOrder, // 排序方式
		 queryParamsType : "limit",// undefined/limit
		 queryParams: queryParams,//传递参数（*）
		 sidePagination: "server", //
		 //分页方式：client客户端分页，server服务端分页（*）
		 // pageNumber:1, //初始化加载第一页，默认第一页
		 pageSize: 100, //每页的记录行数（*）
		 editable:true,//开启编辑模式 
		 pageList: [15, 25, 50, 100], // 可供选择的每页的行数（*）
		 search: false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		 strictSearch: false,//设置为 true启用 全匹配搜索，否则为模糊搜索
		 showColumns: false, // 是否显示所有的列
		 showRefresh: false, // 是否显示刷新按钮
		 minimumCountColumns: 2, // 最少允许的列数
		 clickToSelect: true, // 是否启用点击选中行
		 // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		 uniqueId: uniqueId, // 每一行的唯一标识，一般为主键列
		 showToggle:false, // 是否显示详细视图和列表视图的切换按钮
		 cardView: false	, // 是否显示详细视图
		 detailView: false // 是否显示父子表
	 });
};

//获取ID
function getIdSelections() {
	return $.map($cusTable.bootstrapTable('getSelections'), function(row) {
		return row.uid;
	});
}


function additionRisk(){
	var arr=$('#cusTable').bootstrapTable('getSelections');
	for(var i=0;i<arr.length;i++){
			  $("#headId").append("<th><input  style='vertical-align:middle;' type='checkbox' style='margin-bottom:0px' value=" + arr[i].riskCode + " name='additionRiskCode'/><font style='vertical-align:middle;' >&nbsp;"+ arr[i].riskCode+"\t"+arr[i].salesChl+ "</font></th>");
	}
} 

function changerisk(){
    var riskType=$("#riskType").val().trim();
	if(riskType=="01"){
		$("#risk").val("0");
		$("#risk").attr("disabled","disabled");
	}else{
		$("#risk").attr("disabled",false);
	}
}





//查询下拉参数
function selectByParam(mytype,id,param){
	$.ajax({
					type : "POST",
					url : path + "/LdcodeController/selectByParam.do",// 后台请求URL地址
					data : "userCode=" +mytype,
					success : function(data) {
						for(var i=0;i<data.length;i++){
						var select=document.getElementById(id);
	                    var option=document.createElement("option");
						option.value=data[i].code;
						option.innerHTML=data[i].codename;
						select.appendChild(option);
						
						
						}
						$("#"+id).val(param);
					},
					
				});
	
}




//保险查询页面复制功能回显参数
function seldata(insuranceCom,riskCode){
	
	$.ajax({
			type : "POST",
			url:path+"/LmriskAController/selectByInsu.do",// 后台请求URL地址
			data : "insuranceCom="+insuranceCom+"&riskCode="+riskCode+"&checkFlag="+checkFlagA,
			dataType : "json",
			success : function(data) {
				var json=eval(data);
				
				$("#char6").val(json[0].char6); //产品状态
				$("#subRiskFlag").val(json[0].subRiskFlag); //主附险标志				
				$("#char1").val(json[0].char1);//保费计算方式				
				$("#char2").val(json[0].char2);//渠道标识
				$("#char5").val(json[0].char5);//投连产品可追加年限				
				$("#insuranceCom").val(json[0].insuranceCom); //保险公司
				$("#riskClassify").val(json[0].riskClassify);//保险分类				
				$("#riskType").val(json[0].riskType);//产品类型				
				$("#endDate").val(json[0].endDate); //销售止期				
				$("#riskShortName").val(json[0].riskShortName);//产品状态中文显示				
				$("#risk").val(json[0].risk);//风险等级				
				$("#riskPeriod").val(json[0].riskPeriod);
				$("#char4").val(json[0].char4);//是否存在份数
				$("#char5").val(json[0].char5);
				$("#jointlife").val(json[0].jointlife); //是否支持多被保险人
				$("#checkFlag").val(json[0].checkFlag); 
				
				//$("#subRiskVer").val(json[0].subRiskVer);//产品代码简称
				//$("#riskProp").val(json[0].riskProp);//保险产品外部代码
				//$("#riskName").val(json[0].riskName);//产品简称
				//$("#StartDate").val(json[0].startDate); //销售起期
				//$("#riskCode").val(json[0].riskCode); //产品代码(@XX)
				//$("#salesChl").val(json[0].salesChl); //产品全称
				//$("#char3").val(json[0].char3); //（未启用）
				
				//最低保费
				if(json[0].premmin!=null&&json[0].premmin!=0){
					$("#premmin").val(json[0].premmin); 
					}
				//保费单位
				if(json[0].premunit!=null&&json[0].premunit!=0){
				$("#premunit").val(json[0].premunit); 
				}
				//最低保额
				if(json[0].amntmin!=null&&json[0].amntmin!=0){
				$("#amntmin").val(json[0].amntmin); 
				}
				//保额单位
				if(json[0].amntunit!=null&&json[0].amntunit!=0){
				$("#amntunit").val(json[0].amntunit); 
				}
							
				
				//被保人起始年龄
				if(json[0].agemin!=null){
				var ar=[2];
				var lea=parseInt(json[0].agemin.length);
				if(json[0].agemin!=null&&json[0].agemin.indexOf('D')!=-1||json[0].agemin!=null&&json[0].agemin.indexOf('A')!=-1){
					ar[0]=json[0].agemin.substring(0,lea-1);
					ar[1]=json[0].agemin.substring(lea-1,lea);
					$("#agemin").val(ar[0]); 
					$("input[name=agemintype][value='"+ar[1]+"']").attr("checked", 'checked');
					
				}
				}
				
				//被保人截至年龄
				if(json[0].agemax!=null){
				var ars=[2];
				var le=parseInt(json[0].agemax.length);
				if(json[0].agemax!=null&&json[0].agemax.indexOf('D')!=-1||json[0].agemax!=null&&json[0].agemax.indexOf('A')!=-1){
					ars[0]=json[0].agemax.substring(0,le-1);
					ars[1]=json[0].agemax.substring(le-1,le);
					$("#agemax").val(ars[0]); 
					$("input[name=agemaxtype][value='"+ars[1]+"']").attr("checked", 'checked');
					
				}
				}
			
				//第二被保人起始年龄
				if(json[0].agemintwo!=null){
					var ar=[2];
					var lea=parseInt(json[0].agemintwo.length);
					if(json[0].agemintwo!=null&&json[0].agemintwo.indexOf('D')!=-1||json[0].agemintwo!=null&&json[0].agemintwo.indexOf('A')!=-1){
						ar[0]=json[0].agemintwo.substring(0,lea-1);
						ar[1]=json[0].agemintwo.substring(lea-1,lea);
						$("#agemintwo").val(ar[0]); 
						$("input[name=agemintypetwo][value='"+ar[1]+"']").attr("checked", 'checked');
						
					}
					}
				
			   //第二被保人截至年龄
				if(json[0].agemaxtwo!=null){
				var ars=[2];
				var le=parseInt(json[0].agemaxtwo.length);
				if(json[0].agemaxtwo!=null&&json[0].agemaxtwo.indexOf('D')!=-1||json[0].agemaxtwo!=null&&json[0].agemaxtwo.indexOf('A')!=-1){
					ars[0]=json[0].agemaxtwo.substring(0,le-1);
					ars[1]=json[0].agemaxtwo.substring(le-1,le);
					$("#agemaxtwo").val(ars[0]); 
					$("input[name=agemaxtypetwo][value='"+ars[1]+"']").attr("checked", 'checked');
					
				}
				}
				
			    //附加险是否有被保人豁免险
				if(json[0].subRiskFlag!=null&&json[0].subRiskFlag=="S"){
					$('#otherinsured').attr("disabled",false);
				}
			
				//关闭遮罩层
				closed();
			},
			error : function() {
				//关闭遮罩层
				closed();
				alert("plus failed");
			}
		});
		
	}
