$(function () {
    $("#jqGrid").jqGrid({
        url: baseURL + 'sys/roletemp/list',
        datatype: "json",
        colModel: [			
			{ label: '角色ID', name: 'roleid', index: "roleid", width: 45, key: true },
			{ label: '角色名称', name: 'rolename', index: "rolename", width: 75 },
			{ label: '备注', name: 'remark', width: 100 },
			{ label: '审核状态', name: 'checked', width: 80, formatter: function(value, options, row){
				if(value === 1){
					return '<span class="label label-success">审核通过</span>'
				}else if(value === 0){
					return '<span class="label label-warning" @click="update">审核中</span>'
				}else{
					return '<span class="label label-danger">审核不通过</span>'
				}
			}},
			{ label: '创建时间', name: 'createtime', index: "createtime", width: 80}
        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50],
        rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});

var setting = {
	data: {
		simpleData: {
			enable: true,
			idKey: "menuid",
			pIdKey: "parentid",
			rootPId: -1
		},
		key: {
			url:"nourl"
		}
	},
	check:{
		enable:true,
		nocheckInherit:true
	}
};
var ztree;
	
var vm = new Vue({
	el:'#rrapp',
	data:{
		q:{
			roleName: null
		},
		showList: true,
		showList8: true,
		
		buttonok:true,
		buttoncheckok:true,
		buttoncheckfail:true,
		title:null,
		role:{}
	},
	methods: {
		query: function () {
			vm.reload();
		},
		add: function(){
			vm.buttonok = true;
			vm.buttoncheckok = false;
			vm.buttoncheckfail = false;
			$('#roleForm').data('bootstrapValidator').resetForm(true);
			$('input,select,textarea',$('#roleForm')).removeAttr("disabled");
			$("[name='rolename']").removeAttr("disabled");
			vm.hideremarks();
			vm.showList = false;
			vm.title = "新增";
			vm.role = {};
			vm.getMenuTree(null);
		},
		see : function() {
			$('#roleForm').data('bootstrapValidator').resetForm(true);
			$('input,select,textarea', $('#roleForm')).attr("disabled",
					"disabled");
			$("[name='rolename']").attr("disabled", "disabled");
			$("[name='goback']").removeAttr("disabled");
			var roleid = getSelectedRow();
			if (roleid == null) {
				return;
			}

			vm.showList = false;
			vm.buttonok = false;
			vm.buttoncheckok = false;
			vm.buttoncheckfail = false;
			vm.title = "查看";
			vm.getMenuTree(roleid);

		},
		update: function () {
			showList8= true;
			var roleids = getSelectedRows();
			var roleidslen=roleids.length;
			if(roleidslen!=1){
				alert('请选择一个记录');
				return ;
			}
			var checkstatus=$($("#jqGrid").jqGrid('getCell', roleids,'checked'));
			if(checkstatus.text()=='审核中'){
				alert('不能编辑，审核中');
				return ;
			}
			
			
			$('#roleForm').data('bootstrapValidator').resetForm(true);
			$('input,select,textarea',$('#roleForm')).removeAttr("disabled");
			$("[name='rolename']").attr("disabled","disabled");
			vm.hideremarks();
			vm.buttonok = true;
			vm.buttoncheckok = false;
			vm.buttoncheckfail = false;
			var roleid = getSelectedRow();
			if(roleid == null){
				return ;
			}
			
			vm.showList = false;
            vm.title = "修改";
            vm.getMenuTree(roleid);
		},
		check: function () {
			showList8 = false;
			var userIds = getSelectedRows();
			var userIdslen=userIds.length;
			if(userIdslen!=1){
				alert('请选择一个记录');
				return ;
			}
			var checkstatus=$($("#jqGrid").jqGrid('getCell', userIds,'checked'));
			if(checkstatus.text()=='审核通过'){
				alert('已审核');
			}else{
				$.ajax({
					type: "POST",
				    url: baseURL + "sys/role/check",
                    contentType: "application/json",
				    data: JSON.stringify(userIds[0]),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(){
                                vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			}
		},
		refresh: function () {
			vm.reload();
		},
		del: function (event) {
			var roleIds = getSelectedRows();
			if(roleIds == null){
				return ;
			}
			
			confirm('确定要删除选中的记录？', function(){
				$.ajax({
					type: "POST",
				    url: baseURL + "sys/role/delete",
                    contentType: "application/json",
				    data: JSON.stringify(roleIds),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(index){
								vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		},
		checkbefore: function () {
			
			var userIds = getSelectedRows();
			var userIdslen=userIds.length;
			if(userIdslen!=1){
				alert('请选择一个记录');
				return ;
			}
			var checkstatus=$($("#jqGrid").jqGrid('getCell', userIds,'checked'));
			if(checkstatus.text() !='审核中'){
				alert('非审核中无法去审核');
				return ;
			}
			
			vm.see();
			
			vm.buttonok = false;
			vm.buttoncheckok = true;
			vm.buttoncheckfail = true;
			vm.showremarks();
			$("[name='checkok']").removeAttr("disabled"); 
			$("[name='checkfail']").removeAttr("disabled"); 
			
		},
		checkok: function () {
			var url =  "sys/role/checkok";
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json", 
			    data: JSON.stringify(vm.role),
			    success: function(r){
			    	
			    	if(r.code === 0){
						alert('操作成功', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		checkfail: function () {
			var url =  "sys/role/checkfail";
			alert(vm.role.remarks)
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json", 
			    data: JSON.stringify(vm.role),
			    success: function(r){
			    	
			    	if(r.code === 0){
						alert('操作成功', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		getRole: function(roleid){
            $.get(baseURL + "sys/roletemp/info/"+roleid, function(r){
            	vm.role = r.role;
                
                //勾选角色所拥有的菜单
    			var menuids = vm.role.menuidList;
//    			alert(vm.role.menuidList);
    			for(var i=0; i<menuids.length; i++) {
    				var node = ztree.getNodeByParam("menuid", menuids[i]);
    				ztree.checkNode(node, true, false);
    			}
    		});
    		
		},
		saveOrUpdate: function () {
			$('#roleForm').bootstrapValidator('validate');
			
			if(!$("#roleForm").data('bootstrapValidator').isValid()) {				
		        return;
		    } 
			//获取选择的菜单
			var nodes = ztree.getCheckedNodes(true);
			var menuidList = new Array();
			for(var i=0; i<nodes.length; i++) {
				menuidList.push(nodes[i].menuid);
			}
			vm.role.menuidList = menuidList;
			
			var url = vm.role.roleid == null ? "sys/roletemp/save" : "sys/roletemp/update";
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json",
			    data: JSON.stringify(vm.role),
			    success: function(r){
			    	if(r.code === 0){
						alert('操作成功', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		getMenuTree: function(roleid) {
			//加载菜单树
			$.get(baseURL + "sys/menu/perms", function(r){
				ztree = $.fn.zTree.init($("#menuTree"), setting, r.menuList);
				//展开所有节点
				ztree.expandAll(true);
				
				if(roleid != null){
					vm.getRole(roleid);
				}
			});
	    },
	    reload: function () {
	    	vm.showList = true;
			var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{ 
                postData:{'rolename': vm.q.rolename},
                page:page
            }).trigger("reloadGrid");
		},
		hideremarks:function () {
			$("#remarks").hide();
		},
		showremarks:function () {
			$("#remarks").show();
			$("[name='remarks']").removeAttr("disabled");
		}
	}
});