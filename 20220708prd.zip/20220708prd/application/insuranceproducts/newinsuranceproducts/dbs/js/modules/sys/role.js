$(function() {
	$("#jqGrid")
			.jqGrid(
					{
						url : baseURL + 'sys/role/list',
						datatype : "json",
						styleUI : 'Bootstrap',
						colModel : [
								{
									label : '角色ID',
									name : 'roleid',
									index : "roleid",
									width : 45,
									key : true
								},
								{
									label : '角色名称',
									name : 'rolename',
									index : "rolename",
									width : 75
								},
								{
									label : '备注',
									name : 'remark',
									width : 100
								},
								{
									label : '审核状态',
									name : 'checked',
									width : 80,
									formatter : function(value, options, row) {
										return value === 0 ? '<span class="label label-danger">审核中</span>'
												: '<span class="label label-success">审核通过</span>';
									}
								}, {
									label : '创建时间',
									name : 'createtime',
									index : "createtime",
									width : 80
								} ],
						viewrecords : true,
						height : 385,
						rowNum : 10,
						rowList : [ 10, 30, 50 ],
						rownumbers : true,
						rownumWidth : 25,
						autowidth : true,
						multiselect : true,
						pager : "#jqGridPager",
						jsonReader : {
							root : "page.list",
							page : "page.currPage",
							total : "page.totalPage",
							records : "page.totalCount"
						},
						prmNames : {
							page : "page",
							rows : "limit",
							order : "order"
						},
						gridComplete : function() {
							// 隐藏grid底部滚动条
							$("#jqGrid").closest(".ui-jqgrid-bdiv").css({
								"overflow-x" : "hidden"
							});
						}
					});
});

var setting = {
	data : {
		simpleData : {
			enable : true,
			idKey : "menuid",
			pIdKey : "parentid",
			rootPId : -1
		},
		key : {
			url : "nourl"
		}
	},
	check : {
		enable : true,
		nocheckInherit : true
	}
};
var ztree;
var menuList;

var vm = new Vue({
	el : '#rrapp',
	data : {
		q : {
			roleName : null
		},
		showList : true,
		title : null,
		role : {}
	},
	methods : {
		query : function() {
			vm.reload();
		},
		add : function() {
			showList = true;
			$('#roleForm').data('bootstrapValidator').resetForm(true);
			$("[name='rolename']").removeAttr("disabled");
			vm.showList = false;
			vm.title = "新增";
			vm.role = {};
			vm.getMenuTree(null);
		},
		see : function() {
			$('#roleForm').data('bootstrapValidator').resetForm(true);
			$('input,select,textarea', $('#roleForm')).attr("disabled",
					"disabled");
			$("[name='rolename']").attr("disabled", "disabled");
			$("[name='goback']").removeAttr("disabled");
			var roleid = getSelectedRow();
			if (roleid == null) {
				return;
			}

			vm.showList = false;
			vm.title = "查看";
			vm.getMenuTree1(roleid);

		},
		update : function() {
			showList = true;
			$('#roleForm').data('bootstrapValidator').resetForm(true);
			$('input,select,textarea', $('#roleForm')).removeAttr("disabled");
			$("[name='rolename']").attr("disabled", "disabled");
			var roleid = getSelectedRow();
			if (roleid == null) {
				return;
			}

			vm.showList = false;
			vm.title = "修改";
			vm.getMenuTree(roleid);
		},
		refresh: function () {
			vm.reload();
		},
		check: function () {
			showList = false;
			var userIds = getSelectedRows();
			var userIdslen=userIds.length;
			if(userIdslen!=1){
				alert('请选择一个记录');
				return ;
			}
			var checkstatus=$($("#jqGrid").jqGrid('getCell', userIds,'checked'));
			if(checkstatus.text()=='审核通过'){
				alert('已审核');
			}else{
				$.ajax({
					type: "POST",
				    url: baseURL + "sys/role/check",
                    contentType: "application/json",
				    data: JSON.stringify(userIds[0]),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(){
                                vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			}
		},
		del : function(event) {
			var roleIds = getSelectedRows();
			if (roleIds == null) {
				return;
			}

			confirm('确定要删除选中的记录？', function() {
				$.ajax({
					type : "POST",
					url : baseURL + "sys/role/delete",
					contentType : "application/json",
					data : JSON.stringify(roleIds),
					success : function(r) {
						if (r.code == 0) {
							alert('操作成功', function(index) {
								vm.reload();
							});
						} else {
							alert(r.msg);
						}
					}
				});
			});
		},
		/*getRole : function(roleid) {
			$.get(baseURL + "sys/role/info/" + roleid, function(r) {
				vm.role = r.role;

				// 勾选角色所拥有的菜单
				var menuids = vm.role.menuidList;
				// alert(vm.role.menuidList);
				for (var i = 0; i < menuids.length; i++) {
					var node = ztree.getNodeByParam("menuid", menuids[i]);

					ztree.checkNode(node, true, false);
					// node.chkDisabled = true;
					// ztree.setChkDisabled(node, true);
					// ztree.updateNode(node);
				}
			});
		},*/
		getRole: function(roleid){
            $.get(baseURL + "sys/role/info/"+roleid, function(r){
            	vm.role = r.role;
                
                //勾选角色所拥有的菜单
    			var menuids = vm.role.menuidList;
//    			alert(vm.role.menuidList);
    			for(var i=0; i<menuids.length; i++) {
    				var node = ztree.getNodeByParam("menuid", menuids[i]);
    				ztree.checkNode(node, true, false);
    			}
    		});
		},
		saveOrUpdate : function() {
			$('#roleForm').bootstrapValidator('validate');

			if (!$("#roleForm").data('bootstrapValidator').isValid()) {
				return;
			}
			// 获取选择的菜单
			var nodes = ztree.getCheckedNodes(true);
			var menuidList = new Array();
			for (var i = 0; i < nodes.length; i++) {
				menuidList.push(nodes[i].menuid);
			}
			vm.role.menuidList = menuidList;

			var url = vm.role.roleid == null ? "sys/role/save"
					: "sys/role/update";
			$.ajax({
				type : "POST",
				url : baseURL + url,
				contentType : "application/json",
				data : JSON.stringify(vm.role),
				success : function(r) {
					if (r.code === 0) {
						alert('操作成功', function() {
							vm.reload();
						});
					} else {
						alert(r.msg);
					}
				}
			});
		},
		getMenuTree : function(roleid) {
			// 加载菜单树
			$.get(baseURL + "sys/menu/perms", function(r) {
				ztree = $.fn.zTree.init($("#menuTree"), setting, r.menuList);
				// 展开所有节点
				ztree.expandAll(true);
				// alert(r.menuList[1].menuid);
				if (roleid != null) {
					vm.getRole(roleid);
				}
			});
		},
		getMenuTree1 : function(roleid) {
			// 加载菜单树
			$.get(baseURL + "sys/menu/perms", function(r) {
				ztree = $.fn.zTree.init($("#menuTree"), setting, r.menuList);
				menuList = r.menuList;

				// 展开所有节点
				ztree.expandAll(true);
				// 禁用 Ztree
				// for(var i=0; i<r.menuList.length; i++ ){
				// var node = ztree.getNodeByParam("menuid",
				// r.menuList[i].menuid);
				// ztree.setChkDisabled(node, true);
				// }
				if (roleid != null) {
					vm.getRole1(roleid);
				}
			});
		},
		getRole1 : function(roleid) {
			$.get(baseURL + "sys/role/info/" + roleid, function(r) {
				vm.role = r.role;

				// 勾选角色所拥有的菜单
				var menuids = vm.role.menuidList;
				// alert(vm.role.menuidList);
				for (var i = 0; i < menuids.length; i++) {
					var node = ztree.getNodeByParam("menuid", menuids[i]);

					ztree.checkNode(node, true, false);
					// node.chkDisabled = true;
					// ztree.setChkDisabled(node, true);
					// ztree.updateNode(node);
				}

				for (var i = 0; i < menuList.length; i++) {
					var node = ztree.getNodeByParam("menuid",
							menuList[i].menuid);
					ztree.setChkDisabled(node, true);
				}

			});
		},
		reload : function() {
			vm.showList = true;
			var page = $("#jqGrid").jqGrid('getGridParam', 'page');
			$("#jqGrid").jqGrid('setGridParam', {
				postData : {
					'rolename' : vm.q.rolename
				},
				page : page
			}).trigger("reloadGrid");
		}
	}
});