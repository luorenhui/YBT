$(function () {
	
    $("#jqGrid").jqGrid({
        url: baseURL + 'sys/usertemp/list',
        //styleUI: 'Bootstrap',
        datatype: "json",
        colModel: [			
			{ label: '用户ID', name: 'userid',  width: 45, key: true },//index: "userid",
			{ label: '用户名', name: 'username', width: 75 },
			{ label: '邮箱', name: 'email', width: 90 },
			{ label: '手机号', name: 'mobile', width: 100 },
			{ label: '使用状态', name: 'status', width: 80, formatter: function(value, options, row){
				return value === 0 ? 
					'<span class="label label-danger">禁用</span>' : 
					'<span class="label label-success">正常</span>';
			}},
			{ label: '审核状态', name: 'checked', width: 80, formatter: function(value, options, row){
						if(value === 1){
							return '<span class="label label-success">审核通过</span>'
						}else if(value === 0){
							return '<span class="label label-warning" @click="update">审核中</span>'
						}else{
							return '<span class="label label-danger">审核不通过</span>'
						}
			}},
			{ label: '最后修改时间', name: 'createtime', width: 80}// index: "createtime",
        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50], 
        rownumbers: true,  
        rownumWidth: 25, 
        autowidth:true,
        multiselect:true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});


var vm = new Vue({
	el:'#rrapp',
	data:{	
		q:{
			username: null
		},
		showList: true,
		showRole1: true,
		showRole2: true,
		buttonok:true,
		buttoncheckok:true,
		buttoncheckfail:true,
		
		title:null,
		roleList:{},
		user:{
			status:1,
			roleIdList:[]
		}
	},
	methods: {
		query: function () {
			vm.reload();
		},
		add: function(){
			vm.hideremarks();
			vm.buttonok = true;
			vm.buttoncheckok = false;
			vm.buttoncheckfail = false;
			$('input,select,textarea',$('#defaultForm')).removeAttr("disabled");
			$('#defaultForm').data('bootstrapValidator').resetForm(true);
			$("[name='name']").removeAttr("disabled"); 
			$("[name='password']").removeAttr("disabled"); 
			vm.showList = false;
			vm.title = "新增";
			vm.roleList = {};
			vm.user = {status:1,roleIdList:[]};
			
			//获取角色信息
			this.getRoleList();
		},
		see: function () {
			$('#defaultForm').data('bootstrapValidator').resetForm(true);
			
			
			vm.showremarks();
			var userId = getSelectedRow();
			if(userId == null){
				return ;
			}
			
			vm.showList = false;
			vm.showRole1 = true;
			vm.showRole2 = false;
			vm.buttonok = false;
			vm.buttoncheckok = false;
			vm.buttoncheckfail = false;
            vm.title = "查看";
			
			vm.getUser(userId);
			//获取角色信息
			this.getRoleList();

			$('input,select,textarea',$('#defaultForm')).attr("disabled","disabled");
			console.log('disable finish');
			$("[name='goback']").removeAttr("disabled"); 
			
		},
		update: function () {
			
			var userIds = getSelectedRows();
			var userIdslen=userIds.length;
			if(userIdslen!=1){
				alert('请选择一个记录');
				return ;
			}
			var checkstatus=$($("#jqGrid").jqGrid('getCell', userIds,'checked'));
			if(checkstatus.text()=='审核中'){
				alert('审核中不能修改');
				return ;
			}
			$('input,select,textarea',$('#defaultForm')).removeAttr("disabled");
			$('#defaultForm').data('bootstrapValidator').resetForm(true);
			$("[name='name']").attr("disabled","disabled");
			$("[name='password']").attr("disabled","disabled");
			vm.hideremarks();
			vm.buttonok = true;
			vm.buttoncheckok = false;
			vm.buttoncheckfail = false;
			var userId = getSelectedRow();
			if(userId == null){
				return ;
			}
			
			vm.showList = false;
            vm.title = "修改";
			
			vm.getUser(userId);
			//获取角色信息
			this.getRoleList();
		},
		del: function () {
			var userIds = getSelectedRows();
			for(var i=0;i<userIds.length;i++){
				var checkstatus=$($("#jqGrid").jqGrid('getCell', userIds[i],'checked'));
				if(checkstatus.text()=='审核中'){
					alert('所选记录有审核中的状态，不能删除');
					return;
				}
			}
			
			var userIds = getSelectedRows();
			if(userIds == null){
				return ;
			}
			confirm('确定要删除选中的记录？', function(){
				$.ajax({
					type: "POST",
				    url: baseURL + "sys/usertemp/delete",
                    contentType: "application/json",
				    data: JSON.stringify(userIds),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(){
                                vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		},
		
		checkbefore: function () {
			
			var userIds = getSelectedRows();
			var userIdslen=userIds.length;
			if(userIdslen!=1){
				alert('请选择一个记录');
				return ;
			}
			var checkstatus=$($("#jqGrid").jqGrid('getCell', userIds,'checked'));
			if(checkstatus.text() !='审核中'){
				alert('非审核中无法去审核');
				return ;
			}
			
			vm.see();
			
			vm.buttonok = false;
			vm.buttoncheckok = true;
			vm.buttoncheckfail = true;
			vm.showremarks();
			$("[name='checkok']").removeAttr("disabled"); 
			$("[name='checkfail']").removeAttr("disabled"); 
			
		},
		checkok: function () {
			var url =  "sys/user/checkok";
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json", 
			    data: JSON.stringify(vm.user),
			    success: function(r){
			    	
			    	if(r.code === 0){
						alert('操作成功', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		checkfail: function () {
			var url =  "sys/user/checkfail";
			alert(vm.user.remarks)
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json", 
			    data: JSON.stringify(vm.user),
			    success: function(r){
			    	
			    	if(r.code === 0){
						alert('操作成功', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		refresh: function () {
			vm.reload();
		},
		saveOrUpdate: function () {
			//-----如果操作为修改
			$('#defaultForm').bootstrapValidator('validate');
			
			
			if(!$("#defaultForm").data('bootstrapValidator').isValid()) {
		        return;
		    } 
			
			var url =  vm.user.userid == null ? "sys/usertemp/save" : "sys/usertemp/update";
			if(vm.user.userid == null){
				vm.user.password=md5(vm.user.password);
				//alert(vm.user.password);
			}
			
			//vm.user.password=md5(vm.user.password);
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json", 
			    data: JSON.stringify(vm.user),
			    success: function(r){
			    	
			    	if(r.code === 0){
						alert('操作成功', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		getUser: function(userId){
			$.get(baseURL + "sys/usertemp/info/"+userId, function(r){
				vm.user = r.user;
				vm.user.password = null;
			});
		},
		getRoleList: function(){
			$.get(baseURL + "sys/role/select",function(r){
				vm.roleList = r.list;
				console.log('select finish')
			}); 
			
		},
		reload: function () {
			vm.showList = true;
			var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{ 
                postData:{'username': vm.q.username},
                page:page
            }).trigger("reloadGrid");
		},
		hideremarks:function () {
			$("#remarks").hide();
		},
		showremarks:function () {
			$("#remarks").show();
			$("[name='remarks']").removeAttr("disabled");
		}
	}
});