$(function () {
	
    $("#jqGrid").jqGrid({
        url: baseURL + 'sys/user/list',
        styleUI: 'Bootstrap',
        datatype: "json",
        colModel: [			
			{ label: '用户ID', name: 'userid',  width: 45, key: true },//index: "userid",
			{ label: '用户名', name: 'username', width: 75 },
			{ label: '邮箱', name: 'email', width: 90 },
			{ label: '手机号', name: 'mobile', width: 100 },
			{ label: '使用状态', name: 'status', width: 80, formatter: function(value, options, row){
				return value === 0 ? 
					'<span class="label label-danger">禁用</span>' : 
					'<span class="label label-success">正常</span>';
			}},
			{ label: '审核状态', name: 'checked', width: 80, formatter: function(value, options, row){
				return value === 0 ? 
						'<span class="label label-danger">审核中</span>':
					'<span class="label label-success">审核通过</span>';
			}},
			{ label: '创建时间', name: 'createtime', width: 80 }// index: "createtime",
        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50], 
        rownumbers: true,  
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});


var vm = new Vue({
	el:'#rrapp',
	data:{	
		q:{
			username: null
		},
		showList: true,
		showRole1: true,
		showRole2: true,
		title:null,
		roleList:{},
		user:{
			status:1,
			roleIdList:[]
		}
	},
	methods: {
		query: function () {
			vm.reload();
		},
		add: function(){
			$('#defaultForm').data('bootstrapValidator').resetForm(true);
			$('input,select,textarea',$('#defaultForm')).removeAttr("disabled");
			$('input,select,textarea',$('#defaultForm')).removeAttr("readonly");
//			$("[name='name']").removeAttr("disabled"); 
//			$("[name='password']").removeAttr("disabled"); 
			vm.showRole1 = false;
			vm.showRole2 = true;
			vm.showList = false;
			vm.title = "新增";
			vm.roleList = {};
			vm.user = {status:1,roleIdList:[]};
			
			//获取角色信息
			vm.roleList = this.getRoleList();
			$("[name='roleid']").removeAttr("disabled"); 	
	
		},
		see: function () {
			$('#defaultForm').data('bootstrapValidator').resetForm(true);
			$('input,select,textarea',$('#defaultForm')).attr("disabled","disabled");
//			$('#defaultForm').attr("disabled","disabled");
//			$("[name='password']").attr("disabled","disabled");
//			$("[name='email']").attr("disabled","disabled"); 
//			$("[name='phoneNumber']").attr("disabled","disabled"); 
//			$("[name='status']").attr("disabled","disabled"); 
			$("[name='goback']").removeAttr("disabled"); 
			var userId = getSelectedRow();
			if(userId == null){
				return ;
			}
			
			vm.showList = false;
			vm.showRole1 = true;
			vm.showRole2 = false;
            vm.title = "查看";
			
			vm.getUser(userId);
			//获取角色信息
			this.getRoleList();
		},
		update: function () {
			$('#defaultForm').data('bootstrapValidator').resetForm(true);
			$('input,select,textarea',$('#defaultForm')).removeAttr("disabled");
			$("[name='name']").attr("disabled","disabled");
			$("[name='password']").attr("disabled","disabled");
			var userId = getSelectedRow();
			if(userId == null){
				return ;
			}
			
			vm.showRole1 = false;
			vm.showRole2 = true;
			vm.showList = false;
            vm.title = "修改";
			
			vm.getUser(userId);
			//获取角色信息
			this.getRoleList();
		},
		check: function () {
			var userIds = getSelectedRows();
			var userIdslen=userIds.length;
			if(userIdslen!=1){
				alert('请选择一个记录');
				return ;
			}
			var checkstatus=$($("#jqGrid").jqGrid('getCell', userIds,'checked'));
			if(checkstatus.text()=='审核通过'){
				alert('已审核');
			}else{
				$.ajax({
					type: "POST",
				    url: baseURL + "sys/user/check",
                    contentType: "application/json",
				    data: JSON.stringify(userIds[0]),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(){
                                vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			}
		},
		del: function () {
			var userIds = getSelectedRows();
			if(userIds == null){
				return ;
			}
			confirm('确定要删除选中的记录？', function(){
				$.ajax({
					type: "POST",
				    url: baseURL + "sys/user/delete",
                    contentType: "application/json",
				    data: JSON.stringify(userIds),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(){
                                vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		},
		refresh: function () {
			vm.reload();
		}, 
		saveOrUpdate: function () {
			//-----如果操作为修改
			$('#defaultForm').bootstrapValidator('validate');
			
			
			if(!$("#defaultForm").data('bootstrapValidator').isValid()) {
		        return;
		    } 
//			alert(vm.user.password);
			alert($("[name='password']").val().trim());
			if($("[name='password']").val().trim() != ''){
				alert('1');
				vm.user.password = md5($("[name='password']").val());
			}else{
				alert('2');
				vm.user.password = '';
			}
			
			
			var url =  vm.user.userid == null ? "sys/user/save" : "sys/user/update";
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json",
			    data: JSON.stringify(vm.user),
			    success: function(r){
			    	
			    	if(r.code === 0){
						alert('操作成功', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		getUser: function(userId){
			$.get(baseURL + "sys/user/info/"+userId, function(r){
				vm.user = r.user;
				vm.user.password = null;
			});
		},
		getRoleList: function(){
			$.get(baseURL + "sys/role/select", function(r){
				vm.roleList = r.list;
			});
		},
		reload: function () {
			vm.showList = true;
			var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{ 
                postData:{'username': vm.q.username},
                page:page
            }).trigger("reloadGrid");
		}
	},
//	mounted: function (){  
//        alert("vue加载完成");                  
//    }  
});