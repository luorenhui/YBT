/**
 * @author zhixin wen <wenzhixin2010@gmail.com>
 * extensions: https://github.com/vitalets/x-editable
 */

!function ($) {

    'use strict';

    var edit_dialog =
    	"<div class='rs-dialog' id='_edit_table_dialog'><div class='rs-dialog-box'><a class='close' href='#'>&times;</a>" +
					 "<div class='rs-dialog-header' id='_edit_dialog_title'><h3>修改数据</h3></div>" +
					 "<div class='rs-dialog-body'   id='_edit_dialog_body'></div>" +
					 "<div class='rs-dialog-footer'>" +
					 "<div class='row'>" +
					 "<div class='col-md-2 col-md-offset-8'><input id='save_edit_table_dialog' type='button' " +
					 "class='btn btn-default' value='保存' /></div>" +
					 "<div class='col-md-2'><input id='close_edit_table_dialog' type='button' " +
					 "class='btn btn-default' value='关闭' /></div>" +
					 "</div>" +
					 "</div></div>" ;

    var operateEvents = {};
    
    $.extend($.fn.bootstrapTable.defaults, {
    	editfield : false,
        onEditableInit: function () {
            return false;
        },
        onEditableSave: function (field, row, oldValue, $el) {
            return false;
        },
        onEditableShown: function (field, row, $el, editable) {
            return false;
        },
        onEditableHidden: function (field, row, $el, reason) {
            return false;
        }
    });

    $.extend($.fn.bootstrapTable.Constructor.EVENTS, {
        'editable-init.bs.table': 'onEditableInit',
        'editable-save.bs.table': 'onEditableSave',
        'editable-shown.bs.table': 'onEditableShown',
        'editable-hidden.bs.table': 'onEditableHidden'
    });

    var BootstrapTable = $.fn.bootstrapTable.Constructor,
        _initTable = BootstrapTable.prototype.initTable,
        _initBody = BootstrapTable.prototype.initBody;

    
    
    BootstrapTable.prototype.initTable = function () {
        var that = this;
        //调用 主文件
        _initTable.apply(this, Array.prototype.slice.apply(arguments));
        
        var target  = that.options.target;
        if(target.attr("id").length==0){
        	alert("必须有ID");
        	return;
        	
        }
        
        $.each(this.columns, function (i, column) {
            if (!column.editfield) {
                return;
            }
            //初始化  遮罩层
            if($("body").find("#_edit_table_dialog").length==0){
            	$('body').append('<div class="rs-overlay" />');
            	$('body').append(edit_dialog);
            	
            	var rs_dialog 	= $('#_edit_table_dialog');
            	var rs_box 		= rs_dialog.find('.rs-dialog-box');
        		var rs_close = $("#close_edit_table_dialog");
        		var rs_overlay 	= $('.rs-overlay');
        		var rs_save = $("#save_edit_table_dialog");
        		
            	rs_close.click(function(e){			
            		
            		if(!closeEdit()){
            			return false;
            		}
        			rs_dialog.removeClass('in').delay(150).queue(function(){
        				rs_dialog.hide().dequeue();	
        				rs_overlay.fadeOut('slow');
        				$('html').removeClass('dialog-open');
        				$('body').css('padding-right', '');		
        			});
        			
        			return false;
        		});

        		// Close dialog when clicking outside the dialog
        		rs_dialog.click(function(e){
        			rs_close.trigger('click');		
        		});
        		rs_box.click(function(e){
        			e.stopPropagation();
        		});	
        		rs_save.click(function(e){
        			saveEdit();	
        			rs_dialog.removeClass('in').delay(150).queue(function(){
        				rs_dialog.hide().dequeue();	
        				rs_overlay.fadeOut('slow');
        				$('html').removeClass('dialog-open');
        				$('body').css('padding-right', '');		
        			});
        		});
            }
          //<!-- data-Nodefaultoperate 是否使用默认的操作  删除，修改 -->
            if(column.nodefaultoperate){
            	 column.events={};
            	//<!-- data-defineoperate 自定义函数 -->
            	 
//            	 JSON.parse(column.defineoperate);
            	var opF =  eval(column.defineoperate)
            	 for ( var key in opF) {
            		 column.events['click .'+ opF[key].opid]=opF[key].triggerfunction;
				}
            	 

                 var _formatter = column.formatter;
                 
                 if(_formatter){
                 	 
                 }else{
                 	column.formatter = function (value, row, index) {

                 		var format = "";
                 		 
                 		for ( var key in opF) {
//                 			alert(key);
                 			format = format + opF[key].showelement;
						}
                         return format;
                     };
                 }
            }else{
            	//默认的   表单操作
            	  column.events={
                          
                          'click .edit': function (e, value, row, index) {
                             // alert('You click like action, index: ' + index + "  value:"+ value);
                  	
                  			//显示遮罩层
                  			var trigger 	= $(this);
                  			var rs_dialog 	= $('#_edit_table_dialog');
              		
                  			var rs_overlay 	= $('.rs-overlay');
              		
                  			var w1 = $(window).width();
                  			$('html').addClass('dialog-open');
                  			var w2 = $(window).width();
                  			var c = w2-w1 + parseFloat($('body').css('padding-right'));
                  			if( c > 0 ) $('body').css('padding-right', c + 'px' );

                  				rs_overlay.fadeIn('fast');
                  				rs_dialog.show( 'fast', function(){
                  				rs_dialog.addClass('in');
                  			});	
                  				//显示遮罩层结束
                  			//确定遮罩层显示内容
                  				$("#_edit_dialog_body").html(" ");
                  				$("#_edit_dialog_body").html(getEditBody(that,row,index));
                  				
                  				
                              
                          },
                          'click .remove': function (e, value, row, index) {
                          	 
                          	//target.bootstrapTable("getOptions");
                          	target.bootstrapTable('remove', {
                                  field: that.options.idField,
                                  values: [row[that.options.idField]]
                              });
                          	
                          	try {
                          		//删除数据的操作
      							afterRemove(value, row, index);
      						} catch (e) {
      						}
                          }
                  }
            	  
            	  

                  var _formatter = column.formatter;
                  
                  if(_formatter){
                  	 
                  }else{
                  	column.formatter = function (value, row, index) {

                          
                          return [

                                  '<a class="edit" rel="rs-dialog" data-target="_edit_table_dialog" title="Edit">',
                                  '<i class="glyphicon glyphicon-edit">修改</i>',
                                  '</a>  ',
                                  '<a class="remove" href="javascript:void(0)" title="Remove">',
                                  '<i class="glyphicon glyphicon-remove">删除</i>',
                                  '</a>'
                              ].join('');
                      };
                  }
            	
            }
          
            
        });
    };

    BootstrapTable.prototype.initBody = function () {
        var that = this;
        _initBody.apply(this, Array.prototype.slice.apply(arguments));

        this.trigger('editable-init');
    };
    
    
    function getEditBody(element , row  ,index ){
    	
    	var columns  =element.columns ;
    	var bodyhtml = '<div class="container-fluid"><form class="form-horizontal" ><fieldset>'+
    						'<input id="_row_index" name="row_index" value="'+index+'" style="display:none">'+
    						'<input id="_table_id" name="_table_id" value="'+element.options.target.attr("id")+'" style="display:none">';
    	
    	for ( var i = 0; i < columns.length; i++) {
    		if(columns[i].field.length>0){
    			bodyhtml= bodyhtml+'<div class="form-group"><label class="col-sm-3 control-label" for="'+columns[i].field+"_row_"+index+'">'+columns[i].title+'</label>'+
    			'<div class="col-sm-6"><input type="text" ';  
    			if(!columns[i].editable){
    				bodyhtml= bodyhtml+" readonly ";
    			}
    		
    			bodyhtml= bodyhtml+'name="'+columns[i].field+"row"+index+'" field="'+columns[i].field+'" id="'+columns[i].field+"_row_"+index+'" class="form-control input-sm"  value="'+element.data[index][columns[i].field]+'"/></div></div>';
    		}
    	}
    	bodyhtml = bodyhtml + "</fieldset></form></div>";
    	return bodyhtml;
    }
    
    function closeEdit(){
    	
    	return confirm("关闭编辑页面，任何修改均不会生效！");
    }
    
    function saveEdit( ){
			var index =	$("#_edit_table_dialog").find("#_row_index").val();
			var id    = $("#_edit_table_dialog").find("#_table_id").val();
			var data  = $("#"+id).bootstrapTable("getData");
//			var rowData = data[index];
			var newData={};
			$("#_edit_table_dialog").find("input[id$='_row_"+index+"']").each(function(i){
				var $this = $(this);
				newData[$this.attr("field")]= $this.val(); 
			});
			$("#"+id).bootstrapTable("updateRow",{
				index:index,
				row:newData
			});
			
			try {
            	//修改数据之后的操作
				afterRowEdit($("#"+id), newData, index);
			} catch (e) {
			}
			
    }

}(jQuery);

 

