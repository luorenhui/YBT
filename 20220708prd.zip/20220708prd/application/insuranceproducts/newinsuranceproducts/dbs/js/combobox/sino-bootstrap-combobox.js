
/***
 * CDK
 * 根据  bootstrap-combobox.js v1.1.6  改造的
 * 中科软下拉框组件,配合  bootstrap3.3 使用
 *
 */

var alertmsg=	 "选择一个选项";
var loadmsg = 	 "数据加载中......或有前置选项未选取.";
var preNeedmsg = "需要先选择前置输入框.";
var allCommonInit = {};
var allOptions = {};

!function($) {

    "use strict";

    /*
     * COMBOBOX PUBLIC CLASS DEFINITION ================================
     */

    var Combobox = function(element, options) {
        this.$source = $(element);
        var allOption = {};
        if(element.id=="mainriskcode"){
            console.log(element.id);
        }

        if(allCommonInit[element.id]!=undefined){

            if(allCommonInit[element.id].$container!=undefined){
//				allCommonInit[element.id].$container.parent().empty();
//				allCommonInit[element.id].$container.append(this.$source);
//				allCommonInit[element.id].options = allOptions[element.id];
//				this.options =  allOptions[element.id];

                if(allCommonInit[element.id].$container.attr("inputid")==element.id
                    &&allCommonInit[element.id].$container.find('input:hidden[comboboxshowtext!="true"]').attr("id")==element.id
                    &&this.$source.parent().is("div.combobox-container")
                ){
                    console.log(element.id,allCommonInit[element.id].$container.find('input:hidden[comboboxshowtext!="true"]').attr("id"),"not rebuild combobox");
                    return ;

                }
                console.log(element.id,allCommonInit[element.id].$container.find('input:hidden[comboboxshowtext!="true"]').attr("id"),"rebuild combobox");

                if(this.$source.parent().is("div.combobox-container")){
                    allCommonInit[element.id].$container.parent().find("select,ul").remove();
                    allCommonInit[element.id].$menu.empty();
                    var  top = this.$source.parent().parent();
                    this.$source.parent().remove();
                    top.append(this.$source);
                }

//				allCommonInit[element.id].initdata(allOptions[element.id].data);
//				allCommonInit[element.id].rebuild();
            }
//			this.$container
//			this.showtext();
//			return ;
        }else{


        }



        allOption = jQuery.extend(allOption, $.fn.combobox.defaults, options);
        this.options = allOption;
        if(this.options.id){
            this.options.select_sino_id=this.options.id +"_"+Math.floor( Math.random()*1000000000);
        }else{
            this.options.select_sino_id="_"+Math.floor( Math.random()*1000000000);
        }



        if (this.$source.is("input")) {
            this.$container =this.setupInput();
//			 this.loadData();

        } else {
            this.$container = this.setup();


        }




        this.$element = this.$container.find('input[type=text][comboboxshowtext="true"]');
        this.$target = this.$container.find('input:hidden[comboboxshowtext!="true"]');
        this.$button = this.$container.find('.dropdown-toggle');
        this.$menu = $(this.options.menu).appendTo('body');
        this.template = this.options.template || this.template
        this.matcher = this.options.matcher || this.matcher;
        this.sorter = this.options.sorter || this.sorter;
        this.highlighter = this.options.highlighter || this.highlighter;
        this.shown = false;
        this.selected = false;
        this.transferAttributes();

        if (this.$source.is("input")) {
            this.loadData();
            if((this.options.needParam)&&(!this.options.param)){
                this.refresh();

            }
            this.listen();
        } else {
            this.refresh();
            this.listen();
        }

        allCommonInit[element.id]=this;
        allOptions[element.id]=this.options;

    };

    Combobox.prototype = {

        constructor : Combobox
        ,
        clearData : function() {
            this.options.data=null;
            this.options.dataflag=false;
            this.$menu.empty();
            this.$container.find("ul").empty();
            this.source=null;
//				this.listen();
//				this.transferAttributes();
//				this.listen();
        }
        ,
        setup : function() {
            var combobox = $(this.template());
            this.$source.before(combobox);
            this.$source.hide();
            return combobox;
        }

        ,
        setupInput : function() {

            if(this.$source.parent().find("div.input-group").length>0){

                return this.$source.parent();
            }else{
                var combobox = $(this.templateInput());

                this.$source.after(combobox);
                combobox.prepend(this.$source);
                this.$source.hide();

                return combobox;
            }


        }

        ,
        loadData : function() {

            var data =this.options.data;
            if(!data||(this.options.url==null||this.options.url==undefined)){
                this.loader();

            }else{
//				if(this.options.rebuildflag){
//					this.initdata(data);
//				}
            }

        },

        reLoadData : function() {

            this.options.data=null;
            this.options.dataflag=false;
            this.loadData();
            this.refresh();
            this.transferAttributes();
            this.listen();
        }
        ,
        loading : function() {

        }

        ,
        initEmpty : function() {
            var optionHTML="<option value='' selected='selected'>"+preNeedmsg+"</option>";
            var selectHTML="<select class='combobox form-control' id='"+this.options.select_sino_id+"'  style='display: none;width:auto'>" ;
            selectHTML=selectHTML+optionHTML +"</select>";
//			this.$container.parent().find("select,ul").remove();
            this.$container.after(selectHTML);
            this.refresh();
        }
        ,
        loader : function() {

            var that =this;
            if((this.options.needParam)&&(!this.options.param)){
//				that.refresh();
//				that.listen();
                return ;
            }

            var result = initURL(this.options.url,this.options, that ) ;
            if(result==undefined || result.url ==undefined){
                this.initdata(this.options.data);
            }else{

                //this.options.url= result.url;
                if(this.options.checkRelateInput){

                    if(!result.checkFlag){
                        this.initEmpty();
                        //alert();
                        return;
                    }

                }
                $.ajax( {
                    type : "post",
                    url :  result.url,
                    data : this.options.param,
                    // dataType : "json",
                    success : function(data) {

                        that.initdata(data);
                    },
                    error : function() {
                        alert("数据查询有误");
                    }
                });
            }

        }
        ,
        initdata : function(data) {


            var that = this ;
            that.$source.removeData("comboboxData");
            that.$source.data("comboboxData",data);
            if(!data){
                return ;
            }
//			that.clearData();
            that.options.data = data;
//			that.options.dataflag=true;
//			that.options.loaddataflag=false;
            that.$container.parent().find("select").remove();

            var optionHTML="<option value='' selected='selected'>"+alertmsg+"</option>";
            var selectHTML="<select class='combobox form-control' id='"+that.options.select_sino_id+"'  style='display: none;width:auto'>" ;
            var id_map={};
            for ( var i = 0; i  < data.length; i ++) {
                try {
                    optionHTML = optionHTML + "<option value='"+data[i][that.options.valueField]+"' textField='"+data[i][that.options.inputText]+"'>";
                    id_map[data[i][that.options.valueField]]=data[i];
                    if(that.options.textShow.length==0){
                        for ( var key in data[i]) {
                            if ("undefined" == typeof (data[i][key])
                                || data[i][key]==null
                                || data[i][key].length == 0) {
                                //optionHTML = optionHTML + "-";

                            } else {
                                optionHTML = optionHTML + data[i][key] + "-";
                            }
                        }

                    }else{
                        for ( var key in that.options.textShow) {
                            if ("undefined" == typeof (data[i][that.options.textShow[key]])
                                || data[i][that.options.textShow[key]]==null
                                || data[i][that.options.textShow[key]].length == 0) {
                                //optionHTML = optionHTML + "-";

                            } else {
                                optionHTML = optionHTML + data[i][that.options.textShow[key]] + "-";
                            }
                        }
                    }

                    if (optionHTML.length > 0) {
                        optionHTML = optionHTML.substring(0, optionHTML.length - 1);
                    }
                    optionHTML = optionHTML + "</option>";
                } catch (e) {
                    // TODO: handle exception
                    alert("数据格式有误");
                }

            }
            that.id_map=id_map;
//			this.options.optionHTML=optionHTML;
            selectHTML=selectHTML+optionHTML +"</select>";

//			that.$container.find("select,ul").remove();
            that.$container.after(selectHTML);
            that.refresh();
//			that.listen();
            that.transferAttributes();

            if(that.shown){
                that.clearElement();
                that.lookup();
            }


        }

        ,
        disable : function() {
            this.$element.prop('disabled', true);
            this.$button.attr('disabled', true);
            this.disabled = true;
            this.$container.addClass('combobox-disabled');
        }

        ,
        enable : function() {
            this.$element.prop('disabled', false);
            this.$button.attr('disabled', false);
            this.disabled = false;
            this.$container.removeClass('combobox-disabled');
        },
        parse : function() {
            var that = this, map = {},mapValue = {}, mapText = {}, source = [], selected = false, selectedValue = '';

            var tmpSource ;
            if (this.$source.is("input")) {
                tmpSource=$("#"+this.options.select_sino_id);
            } else {
                tmpSource=this.$source;
            }


            tmpSource.find('option').each(function() {
                var option = $(this);
                if (option.val() === '') {
                    that.options.placeholder = option.text();
                    return;
                }
                if(that.$source.is("input")){
                    map[option.attr("textField")] = option.val();
                    mapText[option.text()]=option.attr("textField");


                    //设置回显
                    if(that.$target!= undefined){
                        if( option.val() ==that.$target.val()){
                            option.prop('selected',true);
                            selected=true;
                        }

                    }

                }else{

                    map[option.text()] = option.val();

                }

                mapValue[option.val()] =option.text();
                source.push(option.text());

                if (option.prop('selected')) {
                    selected = option.text();
                    selectedValue = option.val();
                }
            })

            this.mapText = mapText;
            this.map = map;
            this.mapValue = mapValue;
            if (selected) {
                this.$element.val(selected);
                this.$target.val(selectedValue);
                this.$container.addClass('combobox-selected');
                this.selected = true;
            }
            return source;
        }

        ,
        transferAttributes : function() {
            this.options.placeholder = this.$source.attr('data-placeholder')
                || this.options.placeholder
            this.$element.attr('placeholder', this.options.placeholder)
            this.$target.prop('name', this.$source.prop('name'))
            this.$target.val(this.$source.val())
            if (this.$source.is("input")) {
            } else {
                this.$source.removeAttr('name') // Remove from source otherwise form
                // will pass parameter twice.
            }

            this.$element.attr('required', this.$source.attr('required'))
            this.$element.attr('rel', this.$source.attr('rel'))
            this.$element.attr('title', this.$source.attr('title'))
            this.$element.attr('class', this.$source.attr('class'))
            this.$element.attr('tabindex', this.$source.attr('tabindex'))
            this.$source.removeAttr('tabindex')
            if (this.$source.attr('disabled') !== undefined)
                this.disable();
        }

        ,
        select : function() {
            var val = this.$menu.find('.active').attr('data-value');
            this.$element.val(this.updater(val)).trigger('input').trigger('change').trigger('onchange');
            this.$target.val(this.map[val]);
            this.$source.val(this.map[val])		.trigger('input').trigger('change').trigger('onchange').trigger("click");
            this.$container.addClass('combobox-selected');
//			this.options.select_sino_id
//			$()
//			this.showtext();
            this.selected = true;

            try {
//				relValueAry:[],
                //对应的input的 ID
//				relInputAry:[]
                var select_Data = this.id_map[this.map[val]];
                var relValueAry =this.options.relValueAry;
                var relInputAry =this.options.relInputAry;
                for ( var i = 0; i < relValueAry.length; i++) {
                    $("#"+ relInputAry[i]).val(select_Data[relValueAry[i]]);
                }
            } catch (e) {
            }
            //选择后的 操作

            try {
                if(this.options.afterselect!=undefined){

                    this.options.afterselect(this.$element,this.$target  ,this.map[val],val,this);
                }
            } catch (e) {
                console.log(e);
            }
            try {
                //
                //this.$element为显示在页面上的框体，
                //this.$target为隐藏的框体，选中的select选项，
                //this：整个combobox标签
                afterComboboxSelect(this.$element,this.$target  ,val,this);
            } catch (e) {
            }
            return this.hide();
        }

        ,
        updater : function(item) {
            return item;
        }

        ,
        show : function() {
            var pos = $.extend( {}, this.$element.position(), {
                height : this.$element[0].offsetHeight
            });


            this.$menu.insertAfter(this.$element).css( {
                top : pos.top + pos.height,
                left : pos.left
            }).show();

            this.shown = true;
            return this;
        }

        ,
        hide : function() {
            this.$menu.hide();
            this.shown = false;
            return this;
        }

        ,
        lookup : function(event) {
            this.query = this.$element.val();
            return this.process(this.source);
        }

        ,
        process : function(items) {

            if((items==null ||typeof(items) == "undefined")||items.length==0){
                items = new Array();

                this.$menu.prepend()
                this.$menu.html("<li ><a href='#'>"+loadmsg+"</a></li>")
//				this.loadData();
                return this.show();
            }else{
                var that = this;

                items = $.grep(items, function(item) {
                    return that.matcher(item);
                })

                items = this.sorter(items);

                if (!items.length) {
                    return this.shown ? this.hide() : this;
                }

                return this.render(items.slice(0, this.options.items)).show();
            }





        }

        ,
        template : function() {
            if (this.options.bsVersion == '2') {
                return '<div class="combobox-container"><input type="hidden" /> <div class="input-append"> <input type="text" autocomplete="off" /> <span class="add-on dropdown-toggle" data-dropdown="dropdown"> <span class="caret"/> <i class="icon-remove"/> </span> </div> </div>'
            } else {
                return '<div class="combobox-container"> <input type="hidden" /> <div class="input-group"> <input type="text" autocomplete="off" /> <span class="input-group-addon dropdown-toggle" data-dropdown="dropdown"> <span class="caret" /> <span class="glyphicon glyphicon-remove" /> </span> </div> </div>'
            }
        }

        ,
        templateInput : function() {
            if (this.options.bsVersion == '2') {
                return '<div class="combobox-container" inputid="'+this.$source.attr("id")+'"> <div class="input-append"> <input id="'+this.$source.attr("id")+'_combobox" type="text" comboboxshowtext="true" autocomplete="off" /> <span class="add-on dropdown-toggle" data-dropdown="dropdown"> <span class="caret"/> <i class="icon-remove"/> </span> </div> </div>'
            } else {
                return '<div class="combobox-container" inputid="'+this.$source.attr("id")+'"> <div class="input-group"> <input id="'+this.$source.attr("id")+'_combobox" type="text" comboboxshowtext="true" autocomplete="off" /> <span class="input-group-addon dropdown-toggle" data-dropdown="dropdown"> <span class="caret" /> <span class="glyphicon glyphicon-remove" /> </span> </div> </div>'
            }
        }

        ,
        matcher : function(item) {
            return ~item.toLowerCase().indexOf(this.query.toLowerCase());
        }

        ,
        sorter : function(items) {
            var beginswith = [], caseSensitive = [], caseInsensitive = [], item;

            while (item = items.shift()) {
                if (!item.toLowerCase().indexOf(this.query.toLowerCase())) {
                    beginswith.push(item);
                } else if (~item.indexOf(this.query)) {
                    caseSensitive.push(item);
                } else {
                    caseInsensitive.push(item);
                }
            }

            return beginswith.concat(caseSensitive, caseInsensitive);
        }

        ,
        highlighter : function(item) {
            var query = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,
                '\\$&');
            return item.replace(new RegExp('(' + query + ')', 'ig'), function(
                $1, match) {
                return '<strong>' + match + '</strong>';
            })
        }

        ,
        render : function(items) {
            var that = this;
            items = $(items).map(function(i, item) {
                if (that.$source.is("input")) {

                    i = $(that.options.item).attr('data-value', that.mapText[item]);

                    i.find('a').html(that.highlighter( that.options.textShowFormat(item,that.id_map[that.map[that.mapText[item]]])));
                } else {
                    i = $(that.options.item).attr('data-value', item);
                    i.find('a').html(that.highlighter(item));
                }


                return i[0];
            })


            items.first().addClass('active');
            this.$menu.html(items);
            return this;
        }

        ,
        next : function(event) {
            var active = this.$menu.find('.active').removeClass('active'), next = active
                .next();

            if (!next.length) {
                next = $(this.$menu.find('li')[0]);
            }

            next.addClass('active');
        }

        ,
        prev : function(event) {
            var active = this.$menu.find('.active').removeClass('active'), prev = active
                .prev();

            if (!prev.length) {
                prev = this.$menu.find('li').last();
            }

            prev.addClass('active');
        }

        ,
        toggle : function() {
            if(!this.options.data){
                this.loadData();
            }

            if (!this.disabled) {
                if (this.$container.hasClass('combobox-selected')) {
                    this.clearTarget();
                    this.triggerChange();
                    this.clearElement();
                } else {
                    if (this.shown) {
                        this.hide();
                    } else {
                        this.clearElement();
                        this.lookup();
                    }
                }
            }
        }

        ,
        clearElement : function() {
            this.$element.val('').focus().trigger('input').trigger('change');
            try {
                var relInputAry =this.options.relInputAry;
                for ( var i = 0; i < relInputAry.length; i++) {
                    $("#"+ relInputAry[i]).val("");
                }
            } catch (e) {
                // TODO: handle exception
            }
        }

        ,
        clearTarget : function() {
            this.$source.val('').trigger("click").trigger('input').trigger('change');
            this.$target.val('');
            this.$container.removeClass('combobox-selected');
            try {
                if(this.options.afterselect!=undefined){

                    this.options.afterselect(this.$element,this.$target  ,'','',this);
                }
            } catch (e) {
                console.log(e);
            }
            this.selected = false;
        }

        ,
        triggerChange : function() {
            this.$source.trigger('change').trigger("click");
        }

        ,
        refresh : function() {
            this.source = this.parse();
            this.options.items = this.source.length;
        }

        ,
        listen : function() {
            this.$element.on('focus', $.proxy(this.focus, this)).on('blur',
                $.proxy(this.blur, this)).on('keypress',
                $.proxy(this.keypress, this)).on('keyup',
                $.proxy(this.keyup, this));

            if (this.eventSupported('keydown')) {
                this.$element.on('keydown', $.proxy(this.keydown, this));
            }

            this.$menu.on('click', $.proxy(this.click, this)).on('mouseenter',
                'li', $.proxy(this.mouseenter, this)).on('mouseleave',
                'li', $.proxy(this.mouseleave, this));

            this.$button.on('click', $.proxy(this.toggle, this));
        }

        ,
        eventSupported : function(eventName) {
            var isSupported = eventName in this.$element;
            if (!isSupported) {
                this.$element.setAttribute(eventName, 'return;');
                isSupported = typeof this.$element[eventName] === 'function';
            }
            return isSupported;
        }

        ,
        move : function(e) {
            if (!this.shown) {
                return;
            }

            switch (e.keyCode) {
                case 9: // tab
                case 13: // enter
                case 27: // escape
                    e.preventDefault();
                    break;

                case 38: // up arrow
                    e.preventDefault();
                    this.prev();
                    break;

                case 40: // down arrow
                    e.preventDefault();
                    this.next();
                    break;
            }

            e.stopPropagation();
        }

        ,
        keydown : function(e) {
            this.suppressKeyPressRepeat = ~$.inArray(e.keyCode, [ 40, 38, 9,
                13, 27 ]);
            this.move(e);
        }

        ,
        keypress : function(e) {
            if (this.suppressKeyPressRepeat) {
                return;
            }
            this.move(e);
        }

        ,
        keyup : function(e) {
            switch (e.keyCode) {
                case 40: // down arrow
                case 39: // right arrow
                case 38: // up arrow
                case 37: // left arrow
                case 36: // home
                case 35: // end
                case 16: // shift
                case 17: // ctrl
                case 18: // alt
                    break;

                case 9: // tab
                case 13: // enter
                    if (!this.shown) {
                        return;
                    }
                    this.select();
                    break;

                case 27: // escape
                    if (!this.shown) {
                        return;
                    }
                    this.hide();
                    break;

                default:
                    this.clearTarget();
                    this.lookup();
            }

            e.stopPropagation();
            e.preventDefault();
        }

        ,
        focus : function(e) {
            this.focused = true;
        }

        ,
        blur : function(e) {
            var that = this;
            this.focused = false;
            var val = this.$element.val();
            if (!this.selected && val !== '') {
                this.$element.val('');
                this.$source.val('').trigger('change').trigger("click");
                this.$target.val('').trigger('change');
            }
            if (!this.mousedover && this.shown) {
                setTimeout(function() {
                    that.hide();
                }, 200);
            }
        }

        ,
        click : function(e) {


            e.stopPropagation();
            e.preventDefault();
            this.select();
            this.$element.focus();
        }

        ,
        mouseenter : function(e) {
            this.mousedover = true;
            this.$menu.find('.active').removeClass('active');
            $(e.currentTarget).addClass('active');
        }

        ,
        mouseleave : function(e) {
            this.mousedover = false;
        }
        ,
        showtext : function() {
            var val = this.$source.val();
            this.$element.val(this.mapValue[val]).trigger('change');

        }

        ,
        getShowTextInput : function() {
            var $tetxelement=  this.$source.parent().find("input:visible");
            return $tetxelement;
        },
        setValue:function( newValue){
            this.$source.val(newValue);

            var tmpdata = this.options.data;

            if(tmpdata ==undefined ||
                tmpdata ==null||
                tmpdata.length==0){

                this.loadData();
            }
        }
    };

    Combobox.prototype.getOptions = function () {
        return this.options;
    };

    /*
     * COMBOBOX PLUGIN DEFINITION ===========================
     */
    $.fn.combobox = function(option) {
        var value,
            args = Array.prototype.slice.call(arguments, 1);
        this.each(function() {
            var $this = $(this), data = $this.data('combobox'), options = typeof option == 'object'
                && option;
//					if(allCommonInit[this.id]!=undefined){
//							if(allCommonInit[this.id].$container!=undefined){
//								if(allCommonInit[this.id].$container.attr("inputid")==this.id
//										&&allCommonInit[this.id].$container.find('input:hidden[comboboxshowtext!="true"]').attr("id")==this.id
//										&&data
//										&&$this.parent().is("div.combobox-container")){
//									return ;
//							}
//						}
//					}
            if(this.id=="mainriskcode"){
                console.log(this.id);
            }

            //
            if (!data||data.options==undefined||data.options.rebuildflag) {
                $this.data('combobox', (data = new Combobox(this,
                    options)));
            }
//					$this.data('combobox', (data = new Combobox(this,
//							options)));

            if (typeof option == 'string') {
//						data[option]();
                if ($.inArray(option, allowedMethods) < 0) {
                    throw new Error("Unknown method: " + option);
                }

                if (!data) {
                    return;
                }

                value = data[option].apply(data, args);
            }

            return typeof value === 'undefined' ? this : value;
        });
        return typeof value === 'undefined' ? this : value;
    };

    $.fn.combobox.defaults = {
        bsVersion : '3',
        menu : '<ul class="typeahead typeahead-long dropdown-menu"></ul>',
        item : '<li><a href="#"></a></li>',

        // 是否可编辑
        editable : false,
        //是否需要参数
        needParam : false,
        // 页面是否首次加载flag
        loadFlag : false,
        // url: '../CodeSelectEasyUI',
        // 默认new ,new采用新式codequery old 为老式
        QueryType : 'new',
        // 采用 old方式查询时有效，为valueField的查询结果列号，默认是0
        id_index : 0,
        valueField : 'value',
        // 是否加载页面后自动加载数据
        firstLoad : true,
        // 默认最后一次输入事件与执行搜索之间的延迟间隔
        delay : 200,
        // 显示在输入框的
        inputText : "text",
        // 是否显示blank行
        blankneed : false,
        panelHeight : 'auto',
        // 当value为一部分值时，text框变为可输入，搭配relatedText一起使用
        nochangeValue : [],
        // 是否显示代码
        showCode : false,
        cache : true,
        // 与Text框一样的值的文本框ID
        relatedText : "",
        // 对于CODE相似的查询是否使用已经加载的的数据源
        useSameCode : false,
        //是否检查依赖的元素值是否为空
        checkRelateInput:true,
        //随机数ID
        select_sino_id: "",
        //对应的json key
        relValueAry:[],
        //元素ID
        elementid:"",
        // 显示在下拉列表的项，默认空，空则全部显示
        textShow : ["text"],
        //是否重建
        rebuildflag:false,
        //对应的input的 ID
        relInputAry:[],
        //选中 事件后  触发
        afterSelect:undefined,
        //vue绑定的对象ID， 
//        relateType:,
//        relateVueID:{}
        //格式下拉框显示内容
        textShowFormat: function(textShow,linedata){return  textShow;}
    };

    //可支持的方法
    var allowedMethods = [
        'getOptions',
        'refresh',
        'loaddata',
        'setValue',
        "showtext",
        "clearTarget"
    ];

    $.fn.combobox.Constructor = Combobox;
    $.fn.combobox.methods = allowedMethods;

}(window.jQuery);


function getURL() {
    var ary = window.location.pathname.split("/");
    var url = "";
    if (ary.length >= 2) {
        url = "/" + ary[1];
    } else {
        url = "";
    }
    return url;
}




var urlelementAry="urlelementAry";

/**
 * 检查URL对应的值是否完成
 * @param url
 */
function checkURL(result,option){
    result["checkFlag"]=true;
    for (var i = 0; i < result[urlelementAry].length; i++) {

    	if(option.relateType&&option.relateType=="vue"){
    		
    		
    	        
    	}else{
    		 var jqexp =result[urlelementAry][i];

 	        if($(jqexp).length==0){
 	        	
// 				alert("jquery no match for :" + jqexp);
 	            result["checkFlag"]=false;
 	            break;
 	        }

 	        if($(jqexp).val()==""||$(jqexp).val()==null||$(jqexp).val()== undefined){

 	            //	alert(" no value for " + jqexp +" please select ");
// 				alert(" please select pre input !");
 	            result["checkFlag"]=false;
 	            break;
 	        }
    	}
       
    }


}


/**
 * 初始化
 * @param url
 */
function initURL(url,option, ele ){


    var result =formatURL(url,option);
    if(result!=null
        && typeof(result)=="object"
        &&typeof(result[urlelementAry])!="undefined"){
        bindElementURL(result,ele);
    }
    return result;
}


/**
 * 绑定
 * @param url
 */
function bindElementURL(result , ele){

    for (var i = 0; i < result[urlelementAry].length; i++) {

        var jqexp =result[urlelementAry][i];
        $(jqexp).bind("change",function(){
//			$(ele.$source).val("");
            ele.clearElement();
            ele.clearTarget();
//
            ele.clearData();
//			ele.$source.combobox();
//			if($(jqexp).val()==""||$(jqexp).val()== undefined){
//				ele.initEmpty();
//			}

//			ele.$source.combobox("loaddata",{});
            //ele.reLoadData();

        });
    }
}

var reg_combobox_url= new RegExp("#([\\s\\S]*?[.\\/\\\\\])|#([\\s\\S]*)?", "g");

function getVueFormDataValue(){
	
}

function formatURL(url ,option) {
    var result={};
    var newurl ;
    var elementAry = new Array();
    if(url){
    	
        try {

        	 if(option.relateType&&option.relateType=="vue"){
        		 
        		 
        		  newurl = url.replace(reg_vueform_url, function() { 
        			  var args = arguments;
        			  var exp = args[0].replace("/","").replace("\\","");
                   	
                   	var vueobjtemp ; 
                   	if(vue_config.length==1){
                   		vueobjtemp =vue_config[vue_config.length-1].vueobj;
                   	}else{
                   		vueobjtemp =vueobj[vue_config[option.vueid]];
                   	}
                   	var value = vueobjtemp.formdata;
                   	var expAry= exp.split(".");
                   	var lastKey = "";
                       for ( var index in expAry) {
                       	lastKey= expAry[index];
                       	value =  value [expAry[index].replace("#","")];
           			}
//                       if(option.relateVueID){
//                       	 elementAry.push("#"+option.relateVueID[lastKey]);
//                       }else{
//                       	
//                       }
                       elementAry.push("[name='"+lastKey+"']");
                   	return 	args[0].replace(exp,value);
                  	
                  });
             	
             }else{
            	 
            	  newurl = url.replace(reg_combobox_url, function() { 
            		  var args = arguments;
            		  var jqexp = args[0].replace(".","").replace("/","").replace("\\","");
                      elementAry.push(jqexp);
                      return 	args[0].replace(jqexp,$(jqexp).val());
                  	
                  });
            	 
            }
        	 
          
//    		var urltt = "{a}a{b}b{c}c";
    //
//    		// 方式三，采用非固定参数的回调函数
//    		var rep3 = urltt.replace(reg, function() {
//    			var args = arguments;
//    			return args;
//    		});
//    		alert(rep3);
        } catch (e) {
        	console.log(e);
            result["url"]=url
            return result;
        }
        if(option.relateType&&option.relateType=="vue"){
        	result["url"]=newurl +vueoOption.url_suffix;
        }else{
        	result["url"]=newurl;
        }
    	
    }else{
    	result["url"]=url
        return result;
    }
    
    
    result[urlelementAry] =elementAry;

    checkURL(result,option);
    return result;

}


