
var choose="";
var proposalcontno ="";
var operator ="ybt";
var customId ="";
var insurancecom="";

var parametertype="";
function selectRisk(){
	choose = $("#BX").val();
}
// 页面初始化
$(document).ready(function() {	
	
	$("#downLoad").click(function() {
		proposalcontno = $("#branchno").val();
		
		customId =$("#customId").val();
		
		insurancecom=$("#insurancecom").val();
		
		parametertype=$("#parametertype").val();
		
		if(choose==""||choose=="请选择"){
			alert("请选择测试接口");
			return;
		}else if(choose==1){
			Autoquerybyhub();
		}else if(choose==2){
			 Cancelbyhub()	;
		}else if(choose==3){
			Debitbyhub();
		}else if(choose==4){
			Querycifbyhub();
		}else if(choose==5){
			Cancelinsure();
		}else if(choose==6){
			Curdaycancelinsure();
		}else if(choose==7){
			Cutpayment();
		}else if(choose==8){
			Elepolicytransfer();
		}else if(choose==9){
			Elereceiptnotif();
		}else if(choose==10){
			Nonrealapply();
		}else if(choose==11){
			Nonrealunderwrite();
		}else if(choose==12){
			Tentative();
		}else if(choose==13){
			Uploadelepolicy();
		}else if(choose==16){
			Hesitcancelinsur();
		}else if(choose==17){
			TentativeInsh();
		}else if(choose==18){
			UploadfileILI();
		}else if(choose==19){
			ConclusionNoticeILI();
		}
		else if(choose==20){
			DebitNoticeILI();
		}
		
		
		
   });	
});
/*HUB自动查询*/
function Autoquerybyhub(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Autoquerybyhub.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	}); 
}
/*HUB当日撤单*/
function Cancelbyhub(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Cancelbyhub.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	}); 
}
/*HUB扣款*/
function Debitbyhub(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Debitbyhub.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	}); 
}
/*HUB客户查询*/
function Querycifbyhub(){
	show();		
	$.ajax({
		type : "POST",
		data : "customId="+customId+"&operator="+operator,			
		url:path+"/AllianzController/Querycifbyhub.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	}); 
}

/*Allianz取消投保*/
function Cancelinsure(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Cancelinsure.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	}); 
}
/*Allianz当日撤单*/
function Curdaycancelinsure(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Curdaycancelinsure.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});
}
/*Allianz实时扣款*/
function Cutpayment(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Cutpayment.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});
}
/*Allianz电子投保单传递*/
function Elepolicytransfer(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Elepolicytransfer.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});
}
/*Allianz电子回执*/
function Elereceiptnotif(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Elereceiptnotif.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});
}

/*Allianz非实时申请*/
function Nonrealapply(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Nonrealapply.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});
}

/*Allianz非实时同步申请*/
function Nonrealunderwrite(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Nonrealunderwrite.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});
}

/*Allianz试算*/
function Tentative(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Tentative.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});
}

/*Allianz电子保单上传*/
function Uploadelepolicy(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Uploadelepolicy.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});
}

/*安联犹豫期退保*/
function Hesitcancelinsur(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		url:path+"/AllianzController/Hesitcancelinsur.do",// 后台请求URL地址	
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});	
}



/*安联犹豫期退保*/
function TentativeInsh(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&operator="+operator,			
		   url:path+'/AllianzController/TentativeInsh.do',// 后台请求URL地址
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});	
}






/*投连追加文件上传*/
function UploadfileILI(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&paramType="+parametertype+"&insurancecom="+insurancecom,			
		   url:path+'/ILIInterfaceController',// 后台请求URL地址
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function(data) {
		 closed();
		 alert("失败");	
		 alert(data.msg);
		}
	});	
}



/*投连追加结论文件通知*/
function ConclusionNoticeILI(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&paramType="+parametertype+"&insurancecom="+insurancecom,			
		   url:path+'/ILIInterfaceController',// 后台请求URL地址
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});	
}


/*投连追加扣款通知*/
function DebitNoticeILI(){
	show();		
	$.ajax({
		type : "POST",
		data : "proposalcontno="+proposalcontno+"&paramType="+parametertype+"&insurancecom="+insurancecom,			
		   url:path+'/ILIInterfaceController',// 后台请求URL地址
		success : function(data) {
		   closed();		   
		   if(data.success){			
			alert(data.msg);	
		   }else{
			alert(data.msg);
		  }
		},
		 error : function() {
		 closed();
		 alert("失败");		 
		}
	});	
}