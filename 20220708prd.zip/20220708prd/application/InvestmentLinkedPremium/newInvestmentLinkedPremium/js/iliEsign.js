var tab_d = $('#cusTable');
var showdilog;
var tempVal = '';
var hiddenindex = []

$(document).ready(function() {
	tempVal=app.topVue.lccontInfoiliBean.esignflag;

	let flag =topUpBean.topObj.showFlag;
	if("Y"==flag){
		esignTableShow();
	}	
});
//文件列表
function query(value){
	
	if(tempVal == value){
		return;
	}else{
		tempVal = value;
	}
	
	 //交易流水号
	 let transno=$("#transno").val().trim();
	 //保险公司代码
	 let insurcecom=$("#insurcecom").val().trim();
	 //产品代码
	 let riskcode=$("#riskcode").val().trim();
	 
	 let proposalcontno =$("#proposalcontno").val().trim();
	 
	 //TODO 按钮控制
	if("P" == value){
		//停止双录
		$.ajax({
			type : "POST",
			url:path+'/SFPJsonSend/iliJsonSend.do',
			data: {"transNo": transno},
			dataType : "json",
			success:function(data) {
				try {
					var response=JSON.parse(data);
					if(response.status=="SUCCESS"){
						alert("成功/Succeed");
					}else if(response.errorInfo[0].code!="OIM0042"){
						alert("同步SFP失败/Failed to update \n"+data);
					}else{
						alert("双录停止失败！");
					}
				} catch (e) {
					alert("双录停止失败！");
				}
				
			},
			 error:function(){ 
				 alert("双录停止失败！");
			 }
		});
	}
	//check上传标记
	$.ajax({
		  url: path + "/restIliController/checkUploadFlag.do",
		  data: {"proposalContNo":proposalcontno},
		  type: "post",
		  success : function (data) {
			  if(data.success){
				var showdilog= layer.load(0, {
					  shade: [0.1,'#fff']
				   });
				//更新电子签标记
				$.ajax({
					  url: path + "/restIliController/changeEsignFlag.do",
					  data: {"transNo":transno, "esignflag":value, "proposalContNo":proposalcontno},
					  type: "post",
					  success : function (data) {
					      if(data.success){
//					    	buttonControl(lccont.proposalcontno);//TODO 按钮控制
					    	layer.close(showdilog);
					      	console.log(data.msg)

					      	esignTable('Y');//TODO 刷新表格
					      	//发送电子签名类型告知
					      	$.ajax({
				        	 	url: path + "/restIliController/sendingILIeSignType.do",
				        	 	data: {"proposalContNo" : proposalcontno},
				        	 	type: "post",
				        	 	success : function (data) {
				        	 		if(!data.success){
				        	 			alert(data.msg);
				        	 		}else{
				        	 			console.log("ILI esign Type Notice Request Send Success.");
				        	 		}
				        	 	},
				        	 	error : function (data){
				                    console.log("ILI esign Type Notice Request Send Error.");
				                }
				            });

					      }else{
					    	layer.close(showdilog);
					    	layer.alert(data.msg);
					      }
					  },
					  error : function (data){
						  layer.close(showdilog);
						  layer.alert("系统繁忙,请稍后再试！");
					  }
			    });
			  }else{
			        $("input[name='eSignFlag'][value='E']").prop("checked",true);
			        return;
			  }
		  },
		  error : function (data){
			  layer.close(showdilog);
			  layer.alert("系统繁忙,请稍后再试！");
		  }
	});
	
	
	

	
	
	var init_url = "/InsuComController/select.do";
	 var url_d = "/lccontIliController/additionalinvestment/query/"+topUpBean.insurcecom+"/"+topUpBean.transno+".do?riskcode="+topUpBean.riskcode;
		
		/**加载页面表格*/
	 
		
		var uniqueId = "id";
		var sortOrder = "id asc";		
		$('#esing_table').bootstrapTable('destroy');
		tableInit3(url_d, $('#esing_table'), col_esignTable,uniqueId,sortOrder,queryParams);

}

function esignTable(forceUpdateflag){
	 //交易流水号
	 let transno=$("#transno").val().trim();
	 //保险公司代码
	 let insurcecom=$("#insurcecom").val().trim();
	 //产品代码
	 let riskcode=$("#riskcode").val().trim();
	 
	 let proposalcontno =$("#proposalcontno").val().trim();
	
	var url_d = "/lccontIliController/additionalinvestment/query/"+topUpBean.insurcecom+"/"+topUpBean.transno+".do?riskcode="+topUpBean.riskcode;if(forceUpdateflag){
	 url_d =url_d+"&forceUpdateflag=Y"
	 }
	var uniqueId = "id";
	var sortOrder = "id asc";
	 $('#esing_table').bootstrapTable('destroy');
	 tableInit3(url_d, $('#esing_table'), col_esignTable,uniqueId,sortOrder,queryParams);
}

function esignTableShow(){
	
	var url_d = "/restIliController/getEsignBean.do?transno="+topUpBean.transno;
	var uniqueId = "id";
	var sortOrder = "id asc";
	 $('#esing_table').bootstrapTable('destroy');
	 tableInit3(url_d, $('#esing_table'), col_esignTable,uniqueId,sortOrder,queryParams);
}

function queryParams(params){
	//设置查询参数 
  var param = {
	        //这里是在ajax发送请求的时候设置一些参数 params有什么东西，
	    	//自己看看源码就知道了 limit: params.pageSize,
  		limit : params.limit,
	        offset: params.offset,
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        
	        insuID : $("#insurcecom").val().trim(),
	        riskcode : $("#riskcode").val().trim(),
	    }; 
	    return param; 
}

var filetype_jpg=".jpg,.jpeg";
var filetype_tif=".tif,.jpg";
var allPicture=".jpg,.jpeg,.tif,.tiff";
var upload_valid_type={
	"JPG"	:".jpg,.jpeg" ,
	"TIF"   :".tif,.tiff" ,
	"PDF"   :".pdf"
};
var hiddenindex =[]; 

var url_sign= path+"/restIliController/fileupload.do";
var showdilog_esign;
var dropzoneParams_esgin ={
		url: url_sign,
	    addRemoveLinks: true,
	    method: 'post',
	    timeout:600000,
	    enctype:"multipart/form-data",
	    filesizeBase: 1000,
	    dictRemoveFile:"移除文件",
	    dictCancelUpload: "取消上传",
	    autoProcessQueue:false,
	    acceptedFiles: allPicture,
	    dictInvalidFileType: "仅支持"+filetype_tif+"类型文件上传.",
	    thumbnailWidth:100,
	    thumbnailHeight:100,
	    maxThumbnailFilesize:5,
//	    maxFiles:40,
	    maxFilesize:3,
	    uploadMultiple:true,
	    parallelUploads:100,
	    previewTemplate: document.querySelector('#preview-template_esign').innerHTML,
	    sendingmultiple: function(file, xhr, topUpFormData) {
	    	
	    	var proposalcontno=topUpBean.proposalcontno;
	    	var insurancecom=topUpBean.insurcecom;
	    	var transno =topUpBean.transno;
	    	var esignflag = app.topVue.lccontInfoiliBean.esignflag;
	    	topUpFormData.append("filesize", file.size);
	    	topUpFormData.append("proposalcontno", proposalcontno);
	    	topUpFormData.append("transno", transno);
	    	topUpFormData.append("insurancecom", insurancecom);
	    	topUpFormData.append("esignflag", esignflag);

	    },
	    init: function() {
	    	var closeEsignButton=document.querySelector("#closeEsign");
	        var submitButton = document.querySelector("#upFiles_esign");
	        var upstatus = true;
	        dropzoneObj = this;
	        
	        closeEsignButton.addEventListener("click", function() {
	        	dropzoneObj.removeAllFiles();
	        });
	        
	    	submitButton.addEventListener("click", function() {
	    		if(dropzoneObj.files!=null&&dropzoneObj.files!=""){
	    			showdilog_esign= layer.load(0, {
	   			  shade: [0.1,'#fff'] //0.1透明度的白色背景
	    		   });
	    		}
					dropzoneObj.processQueue(); 
	    	
			});
	    	
	    	this.on("canceled", function(file) {

	    	
	    	});
	    	
	    	this.on("addedfile",function(file){
	    		console.info("file.type : "  + file.type );
	    		setTimeout(function(){
	    			console.info(file.accepted);
	    			if(!file.accepted){   				
	    				upstatus=false;
	    				} 			
	    		!upstatus?$("#upFiles_esign").attr("disabled",true):$("#upFiles_esign").removeAttr("disabled");
	    		},10);
	    	});
	    	
	    	this.on("removedfile", function(file) {
	    			var _ref;
	    			//仅移除单个文件
	    			(_ref = file.previewElement) != null ? _ref.parentNode!=null?_ref.parentNode.removeChild(file.previewElement):void 0 : void 0;
	        		
	    			var upfiles = this.files;
	    	    	var len = 0;
	    	    	var check = 0;
	    	    	for(var j = 0,len=upfiles.length; j < len; j++) {
	    	    		if(upfiles[j].accepted)check++;
	    	    	}
	    	    	
	    	    	if(len==check)upstatus=true;
	    	    	
	    	    	!upstatus?$("#upFiles_esign").attr("disabled",true):$("#upFiles_esign").removeAttr("disabled");
			}); 
	    	
	    	this.on("successmultiple", function(file, response, e){
	            
	    		var reg=/ /g;
				var _ref;
				var dropzoneObj =this;
				var proposalcontno=topUpBean.proposalcontno;
				var insurancecom=topUpBean.insurancecom;
				(_ref = file[0].previewElement) != null ? _ref.className!=null?$("."+_ref.className.replace(reg,'.')).remove():void 0 : void 0;
				
				uploadData=response.success?response:"";
				this.files.length=0;
	            var resultMsg = response.msg;
	            console.log("++++"+response.msg+"******");
	            if(resultMsg == 'undefined' || resultMsg == undefined){
	                alert("Time out,please login again!");
	                layer.close(showdilog);
	            }else{
	                alert(response.msg);
	                layer.close(showdilog);
	            } 
				if(response.success){
					 $("#esing_table").bootstrapTable('refresh');
					 if(response.parm){
						 app.$set(app.topVue.lcilipay,"uploadflag",response.parm);
						 topUpBean.uploadflag=response.parm;
					 }
					 //成功后处理
					$("#myModal_esign").modal('hide');
				}			 
			});
	    	this.on("completemultiple",function(){
	    		try {
	    			layer.close(showdilog_esign);
				} catch (e) {
					// TODO: handle exception
				}
	   		 
	   	    });   	  	
	  }
	    
	};

var  create

window.actionEvents = {
    //投保单复制
 
		
		
	'click .create': function (e, value, row, index) {
		
		try {
			printPol_anzl(row);
			$("#esing_table").bootstrapTable('refresh');
		} catch (e) {
			// TODO: handle exception
			alert("打印遇到问题，如果之前有生成或打印投保单，请将之前打开的投保单页面关闭");
		}
		
	    	
	},
    'click .addOrUpdate': function (e, value, row, index) {
    	var  esignBeanData  = encodeURIComponent(JSON.stringify(row));
    	//check 状态 需求不敢
    	openIframe(row.esignaturelogic.filedesc,
    			path+row.esignaturelogic.pageuri+"?esignBean="+esignBeanData);
    	
    },
    'click .updatefile': function (e, value, row, index) {
    	var context ='上传后，之前上传的文件将被覆盖，本次的文件将作为最终文件发送保险公司。请确认';
    	var totalflag = row.lcconteform.totalflag;
    	if(totalflag==2){
    		if($("#upfilezone_esign")[0].dropzone==undefined){
		    		$("#upfilezone_esign").dropzone(dropzoneParams_esgin);
		    	}
		    	//只支持多种类型
		    	if(row.esignaturelogic.filetype){
		    		$("#upfilezone_esign")[0].dropzone.options.acceptedFiles=row.esignaturelogic.filetype;
		    		$("#upfilezone_esign")[0].dropzone.options.dictInvalidFileType
		    				= "仅支持"+row.esignaturelogic.filetype + "类型文件上传.";
		    	}
		    	
//		    	var  formdate = vueobj["testdivchange"].formdata;
		    	$("#upfilezone_esign")[0].dropzone.options.url= url_sign 
		    	+"?"+"esignBean="+encodeURIComponent(JSON.stringify(row));
		    	
		    	$("#myModal_esign").modal('show');
    	}else{
    		layer.confirm(context, {
  			  btn: ['确认','取消'], //按钮
  			  title:"系统提示",
  			  closeBtn:false
  			}, function(confirmIndex){
  				layer.close(confirmIndex);
  				if($("#upfilezone_esign")[0].dropzone==undefined){
  		    		$("#upfilezone_esign").dropzone(dropzoneParams_esgin);
  		    	}
  		    	//只支持多种类型
  		    	if(row.esignaturelogic.filetype){
  		    		$("#upfilezone_esign")[0].dropzone.options.acceptedFiles=row.esignaturelogic.filetype;
  		    		$("#upfilezone_esign")[0].dropzone.options.dictInvalidFileType
  		    				= "仅支持"+row.esignaturelogic.filetype + "类型文件上传.";
  		    	}
  		    	
//  		    	var  formdate = vueobj["testdivchange"].formdata;
  		    	$("#upfilezone_esign")[0].dropzone.options.url= url_sign 
  		    	+"?"+"esignBean="+encodeURIComponent(JSON.stringify(row));
  		    	
  		    	$("#myModal_esign").modal('show');
  				}, function(){
  					
  				});	
    	}
    	
    	
		
    },
    'click .viewfile': function (e, value, row, index) {
    	
    	
    	if(row.lcconteform.localfilename){
    		
    		//开户系统上传过来得证件照，只能进行下载后进行预览
    		var filea=row.lcconteform.filetypecode;
    		var grops=row.esignaturelogic.groups;
    		if((filea.indexOf("INS-1163-1")!=-1&&grops!=""&&grops!=null)||
    				(filea.indexOf("INS-INSH-6009-1")!=-1&&grops!=""&&grops!=null)){
    				alert("请下载后进行预览！");
//    			}
    		} else {
    		
    		var urlpdf= path +"/signatureBase/printSignature.do?filePath="+row.lcconteform.localfilename;
    		
        	
        	if (!!window.ActiveXObject || "ActiveXObject" in window){
    				//ie
        			window.open('javascript:window.name;', '<script>window.location.replace("'+urlpdf+'")<\/script>');
    			}else{
    				//google
    				 window.open(urlpdf,"_blank");
    			}
    		}
    	}else{
    		alert("请先录入该信息或者上传该文件");
    	}
    	 //  打印或者预览
    }
    ,
'click .download': function (e, value, row, index) {
    	
	var transno=topUpBean.transno;
	var logicid=row.esignaturelogic.logicid;
    	if(row.lcconteform.localfilename){
    		var urlpdf= path +"/esign/esigntable/filedownload.do?filePath="+row.lcconteform.localfilename+"&logicid="+logicid+"&transno="+transno;
    		
    		window.open(urlpdf,"_blank");
    		$("#esing_table").bootstrapTable('refresh');
    	}else{
//    		if(row.esignaturelogic.elexpression.indexOf("#formData.lccont.kaihuFlag=='Y'")!=-1
//					&&row.lcconteform.totalflag=="2"){
//    		var lcconteformBean =encodeURIComponent(JSON.stringify(row.lcconteform));
//        	openIframe("预览证件照",path+"/application/newCont/jsp/idpictureDisplay.jsp?lcconteformBean="+lcconteformBean);
//    		}else{
//    		alert("请先录入该信息或者上传该文件");
//    		}
    	}
    	 //  打印或者预览
    }
    ,
    'click .getwdcID': function (e, value, row, index) {
    	var lcconteformBean =encodeURIComponent(JSON.stringify(row.lcconteform));
		openIframe_test("查阅并选择影像件",
path+"/application/InvestmentLinkedPremium/newInvestmentLinkedPremium/jsp/iliIdpictureDisplay.jsp?lcconteformBean="+lcconteformBean);   	
    }
 /*   ,
'click .confirms': function (e, value, row, index) {	
    if(confirm("确认使用自动获取的文件？")){
    	if(row.lcconteform.downloadflag !="Y"){
    		alert("请先下载预览此文件内容后再点击确认！");
    		return;
    	}
    	var transNo =vueobj["testdivchange"].formdata.newContApply.transno;
    	if(row.lcconteform.filetypecode && transNo){
     $.ajax({
		     type : "POST",
		     url: path+'/esign/esigntable/confirms.do',		       
		     data : {
        	"transNo":transNo,
        	"filetypecode":row.lcconteform.filetypecode,
        	"logicid":row.esignaturelogic.logicid,
        					},
        	dataType : "json",
		        success: function(data) { 
			        try{
			        	if(data){
			        		 if(data==1){
			        			 alert("确认成功!");
			        			 $("#esing_table").bootstrapTable('refresh');
					         }
			        	}else{
			        		alert("确认失败!");
			        	}
			        }catch(e){
			        	console.log(e);		        	
			        }   
		           
		        },
				error:function(){
					alert("确认失败了!");
				}
		   });    
    	}else{
    		alert("请先录入该信息或者上传该文件");
    	}   	
    }   
}*/
/*    ,
'click .photograph': function (e, value, row, index) {
	var insurancecom=vueobj["testdivchange"].formdata.newContApply.insurancecom;
	var transNo =vueobj["testdivchange"].formdata.newContApply.transno;
	var filetypecode=row.lcconteform.filetypecode;
	var logicid=row.esignaturelogic.logicid;
	var lcinsuredTwo=vueobj["testdivchange"].formdata.lcinsuredtwo;
	var num="";
	if(!isEmpty(lcinsuredTwo.transno)){
		num=num+1;
	}
	var lcinsureds=Number((vueobj["testdivchange"].formdata.lcinsuredmulti.length))+Number(num)+Number(1);	
	var bnfs=vueobj["testdivchange"].formdata.bnf.length;
//	var arg ='transNo='+transNo+',insurancecom='+insurancecom+',filetypecode='+filetypecode;
	var arg =transNo+','+insurancecom+','+filetypecode+','+logicid;
	var filea=row.lcconteform.filetypecode;
	var grops=row.esignaturelogic.groups;
	if((filea.indexOf("INS-1163-1")!=-1&&grops!=""&&grops!=null)||
			(filea.indexOf("INS-INSH-6009-1")!=-1&&grops!=""&&grops!=null)){

		openIframe("证件拍照",path+"/application/newCont/jsp/camera.jsp?"+arg+'&'+1);
	}
	if((filea.indexOf("INS-1163-2")!=-1&&grops!=""&&grops!=null)||
			(filea.indexOf("INS-INSH-6009-2")!=-1&&grops!=""&&grops!=null)){

		openIframe("证件拍照",path+"/application/newCont/jsp/camera2.jsp?"+arg+'&'+lcinsureds);
	}
	if((filea.indexOf("INS-1163-3")!=-1&&grops!=""&&grops!=null)||
			(filea.indexOf("INS-INSH-6009-3")!=-1&&grops!=""&&grops!=null)){

		openIframe("证件拍照",path+"/application/newCont/jsp/camera3.jsp?"+arg+'&'+bnfs);
	}
    }*/
};

var col_esignTable = [
	           			{
	           			    field : 'esignaturelogic.groups',
	           			    title : '文件类型',
	           			    formatter: esignFileGroup
	           			},{
	                          field : 'esignaturelogic.filedesc',
	                          title : '文件名' ,
	                         formatter: filedescFormatter
	                      },{
	           			    field : 'esignaturelogic.filetype',
	           			    title : '文件格式' 
	           			},{
	                          field : 'lcconteform.totalflag',
	                          title : '文件状态', 
	                          formatter: esignStatusFormat
	                      },{
	                          title: '操作',
	                          align: 'center',
	                          formatter: actionFormatter,
	                          events: actionEvents/*,
	                          switchable: false*/
	                      }];

function tableInit3( url,obj,col,uniqueId,sortOrder,queryParams){
	 obj.bootstrapTable({
		 url: path+url, // 请求后台的URL（*）
		 dataType: "json",
		 method: 'GET', // 请求方式（*）
		 contentType: "application/x-www-form-urlencoded",
		 toolbar: '#toolbar',
		 toolbar: '#toolbar2',// 工具按钮用哪个容器
		 columns:  col,
		 striped: true, // 是否显示行间隔色
		 cache: false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		 pagination: true, // 是否显示分页（*）
		 sortable: true, // 是否启用排序
		 sortOrder: "asc", // 排序方式
		 sortOrder: sortOrder, // 排序方式
		 queryParamsType : "limit",// undefined/limit
		 queryParams: queryParams,//传递参数（*）
		 //sidePagination: "server", //
		 rowStyle:function(row,index){
	        	if(((row.esignaturelogic&&row.esignaturelogic.delayuploadflag=="1"&&app.topVue.lccontInfoiliBean&&app.topVue.lccontInfoiliBean.esignflag=="E")
	        		||(row.esignaturelogic&&row.esignaturelogic.delayuploadflag=="1"&&app.topVue.lccontInfoiliBean&&app.topVue.lccontInfoiliBean.esignflag=="P"
	        			/*&&row.esignaturelogic&&row.esignaturelogic.groups!="3"*/)
	        		||(row.esignaturelogic&&row.esignaturelogic.uploadflag=="2"&&app.topVue.lccontInfoiliBean&&app.topVue.lccontInfoiliBean.esignflag=="P"))
	        		&&(row.lcconteform&&(row.lcconteform.totalflag=="1"||row.lcconteform.totalflag=="0"||row.lcconteform.totalflag=="2"))
	        		){
	        		return {css:{"background-color":"#FFFF99"}};
	        	}
	        	return "";
	        },
		 //分页方式：client客户端分页，server服务端分页（*）
		 // pageNumber:1, //初始化加载第一页，默认第一页
		 // pageSize: 10, //每页的记录行数（*）
		 //pageList: [10, 25, 50, 100], // 可供选择的每页的行数（*）
		 search: false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		 strictSearch: true,//设置为 true启用 全匹配搜索，否则为模糊搜索
		 showColumns: true, // 是否显示所有的列
		 showRefresh: true, // 是否显示刷新按钮
		 minimumCountColumns: 2, // 最少允许的列数
		 clickToSelect: true, // 是否启用点击选中行
		 // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		 uniqueId: "esignaturelogic.logicid", // 每一行的唯一标识，一般为主键列
		 uniqueId: uniqueId, // 每一行的唯一标识，一般为主键列
		// showToggle:true, // 是否显示详细视图和列表视图的切换按钮
		// cardView: false	, // 是否显示详细视图
		 //detailView: false, // 是否显示父子表
		 paginationDetailHAlign:"right",
		 onPreBody:function(){
	        	if(document.getElementsByName("refresh")&&document.getElementsByName("refresh").length>0){
	        		if(app.topVue.lccontInfoiliBean&&app.topVue.lccontInfoiliBean.esignflag){
	        			document.getElementsByName("refresh")[0].style.display='inline';
	        			document.getElementsByName("refresh")[0].innerHTML
	            		='<i class="glyphicon glyphicon-refresh icon-refresh"></i>  请按刷新按钮刷新文件状态';
	        		}else{
	        			document.getElementsByName("refresh")[0].style.display='none';
	        		}
	        		
	        	}
	        },
		 onLoadSuccess: function(data){   
	        	for(var i=0;i<hiddenindex.length;i++){
	        		$("#esing_table").bootstrapTable('hideRow', {index: hiddenindex[i]});
	        	}
	        	hiddenindex = [];	
	        	
	        	if(data){
	            	//自动打印
	    	    		try {	    	    				
	    	    				for(var i=0;i<data.length;i++){
	    	    					if(data[i].esignaturelogic
	    	    					   &&"4"==data[i].esignaturelogic.infoenterflag
	    	    					   &&data[i].lcconteform&&"0"==data[i].lcconteform.totalflag
	    	    					   &&topUpBean){
	    	    					   if(autoPrintLccont(data[i])){
	    	    						  $("#esing_table").bootstrapTable('refresh');
	    	    					   }
	    	    	        		
	    	    					}
	    	    				}
	    	    			
	    	    			
	    	    		} catch (e) {
	    	    			// TODO: handle exception
	    	    			alert("打印遇到问题，如果之前有生成或打印投保单，请将之前打开的投保单页面关闭");
	    	    		}
	        		
	    			}
	        }
	 });

};


function queryFileStatus(){
	
	 $.ajax({
		        type: "GET",
		        url: path+"/queryFlileStatus/query.do?transno="+topUpBean.transno,
		        timeout: 60000,
		        async: false,
		        success: function(data, textStatus) { 
			        try{
			        	if(data){
			        		 if(data==2){
					            	clearInterval(queryFileStatusTimer);
					            	$("#esing_table").bootstrapTable('refresh');
					         }
			        	}else{
			        		clearInterval(queryFileStatusTimer);
			        	}
			        }catch(e){
			        	console.log(e);
			        	clearInterval(queryFileStatusTimer);
			        }   
		           
		        },
				error:function(){
					clearInterval(queryFileStatusTimer); 
				}
		   });
    
}

function checkEnterButton(row,paperflag){
	
	if(row.esignaturelogic){
				
		if(topUpBean.uploadflag=="F" ||topUpBean.uploadflag=="Y"){
			return false; 
		}
		
		if(row.lcconteform.totalflag>=6){
			
			return false; 
		}
		if(row.esignaturelogic.infoenterflag=='0'){
			return true;
		}
		
	}
	
	
	
	return false;
}


/**
 * 预览跟下载按钮
 * 1.安联纸质签需要下载按钮
 * 2.汇丰、大都会下载按钮显示跟电子签保持一致
 */
function checkViewButton(row,paperflag){
	
	
	if(row.esignaturelogic){
		
		//开户系统上传过的的rules，显示预览和下载按钮
		var filea=row.lcconteform.filetypecode;
		var grops=row.esignaturelogic.groups;
		var insurance = row.esignaturelogic.insurance;
		if(paperflag&&insurance=="ANZL"){
			if(filea.indexOf("INS-1163-1")!=-1){
				return false; 
			}	
			return true; 			
		}else if(paperflag&&insurance=="MELI"){ 
			if(filea.indexOf("TEMP")!=-1||(row.lcconteform.totalflag!="2"&&filea.indexOf("INS-1163-1")!=-1)){
				return true; 
			}	
			return false; 
		}else if(paperflag&&insurance=="INSH"){ 
			if(filea.indexOf("TEMP")!=-1||(row.lcconteform.totalflag!="2"&&filea.indexOf("INSH-6009-1")!=-1)){
				return true; 
			}	
			return false; 
		}
		if((filea.indexOf("INS-1163-1")!=-1&&grops!=""&&grops!=null)||
				(filea.indexOf("INS-INSH-6009-1")!=-1&&grops!=""&&grops!=null)){
			if((topUpBean.uploadflag=="F"
				||topUpBean.uploadflag=="Y")&&row.lcconteform.totalflag=="2"){
				return false; 
			}
		}		
		if(row.lcconteform.filetypecode!="GEN-RPQ"&&row.lcconteform.filetypecode!="GEN-FPR"){
			if(row.lcconteform.localfilename!=null&&(row.lcconteform.localfilename.indexOf("pdf")+3==row.lcconteform.localfilename.length)){
				return true ; 
			}
		}else{
			//if(!paperflag){
				//电子签  RPQ FPR 文件签完名  显示预览和下载按钮
			if(row.esignaturelogic.uploadflag == '1'){
				if(row.lcconteform.totalflag>=9||row.lcconteform.totalflag==3){
					return true;
				}
			}
			//}
		}
	}
	
	return false;
}


function checkCreateButton(row,paperflag){
	
	if(row.esignaturelogic){
		
		if(row.lcconteform.totalflag>=6){
			return false; 
		}
		
		if(row.esignaturelogic.infoenterflag=='4'){
			return true;
		}
	}
	
	return false;
}

function checkUploadButton(row,paperflag){
	if (row.esignaturelogic) {
		if(paperflag){
			if($("#insurcecom").val().trim()&&$("#insurcecom").val().trim()=="ANZL"){
				return false; 
			}else{	
				if(row.lcconteform.totalflag==5){
					return false; 
				} 
				if(topUpBean.uploadflag=="F"||topUpBean.uploadflag=="Y"){
					return false; 
				}    
				return true; 										
			}
				
		}else{
			if(topUpBean.uploadflag=="F"||topUpBean.uploadflag=="Y"){
				return false; 
			}    
			
			if(row.lcconteform.totalflag>=6){ 
				return false; 
			}
			
			if ((!paperflag)&&row.esignaturelogic.uploadflag == '0') {
				return true;
			}
			// 纸质需要上传
			if (paperflag && row.esignaturelogic.uploadflag == '2') {
				return true
			}
		}
		
		
		
		
	}
	return false;
	
}
//
function checkConfirmButton(row,paperflag){
	if(row.esignaturelogic){
		if(topUpBean.uploadflag=="F"||topUpBean.uploadflag=="Y"){
			return false; 
		}
		if(row.lcconteform.localfilename){
		var filea=row.lcconteform.filetypecode;
		var grops=row.esignaturelogic.groups;
		/*if((filea.indexOf("INS-1163-1")!=-1&&grops!=""&&grops!=null)||
				(filea.indexOf("INS-INSH-6009-1")!=-1&&grops!=""&&grops!=null)){
			if(row.esignaturelogic.elexpression.indexOf("#formData.lccont.kaihuFlag=='Y'")!=-1
					&& row.lcconteform.totalflag=="2"){
				return false;
			}
		
		}*/
	}else{
		return false;
	}
	}
	return false;
}
function checkPhotographButton(row,paperflag){
	if(row.esignaturelogic){
		if(topUpBean.uploadflag=="F" ||topUpBean.uploadflag=="Y"){
			return false; 
		}		
	}
	return false;
}
function checkWdcIDButton(row, paperflag) {
	if (row.esignaturelogic) {
		var filea = row.lcconteform.filetypecode;
		var grops = row.esignaturelogic.groups;
		if ((filea.indexOf("INS-1163-1") != -1 && grops != "" && grops != null)
				|| (filea.indexOf("INS-INSH-6009-1") != -1 && grops != "" && grops != null)) {
			if (topUpBean.uploadflag == "F" || topUpBean.uploadflag == "Y") {
				return false;
			}
				if (row.lcconteform.totalflag < 5 && (!paperflag)&&row.esignaturelogic.uploadflag == '0') {
					return true;
				}
		}
	}
	return false;
}
function filedescFormatter(value, row, index) {
	 
	if(row.esignaturelogic&&row.esignaturelogic.filenametail){
		return value +row.esignaturelogic.filenametail;
	}
	return value ;
}


function actionFormatter(value, row, index) {
	//统计列数，此数列为倒数excel时应除去的列数
	//	numberX[0]  = parseInt($("tr:first")[0].childElementCount) - 1 ;
	//操作列添加按钮
	if (row.esignaturelogic) {

		var paperflag = tempVal == "P";
		var enterButtonFlag = checkEnterButton(row, paperflag);
		var viewButtonFlag = checkViewButton(row, paperflag);
		var uploadButtonFlag = checkUploadButton(row, paperflag);
		var confirmButtonFlag = checkConfirmButton(row, paperflag);
		var photographButtonFlag = checkPhotographButton(row, paperflag);
		var createFlag = checkCreateButton(row, paperflag);
		var wdcIDButtonFlag = checkWdcIDButton(row, paperflag);
		var enterButton =  '<button type="button"  class="btn addOrUpdate">录入/修改</button>';
		var viewButton =   '<button type="button"  class="btn viewfile">预览</button><button type="button"  class="btn download">下载</button>';
		var viewButtonLcappnt =   '<button type="button"  class="btn download">预览及确认</button>';
		var uploadButton = '<button type="button"  class="btn updatefile">上传</button>';
		var createButton = '<button type="button"  class="btn create">生成</button>';
		var confirmButton = '<button type="button"  class="btn confirms">确认使用此影像件</button>';
		var photographButton = '<button type="button"  class="btn photograph">拍照</button>';
		var wdcIDButton = '<button type="button"  class="btn getwdcID">从文件中心导入</button>';
		if (row.esignaturelogic.uploadflag == '0') {

		}
		var buttonStr = "";	

		if (enterButtonFlag) {
			buttonStr = buttonStr + enterButton;			
		}
		if (viewButtonFlag) {
			//如果是投保人就显示下载预览按钮,非投保人显示 预览、下载两个按钮
				 buttonStr = buttonStr + viewButton;
			 
			
		}
		if (uploadButtonFlag) {
			buttonStr = buttonStr + uploadButton;
		}
		if (wdcIDButtonFlag) {
			buttonStr = buttonStr + wdcIDButton;
		}
		return [ buttonStr ].join('');

	}
	
	return "";
}


/**
 * 发送到WDC 进行电子签名
 */
function sendToWdc(){
	 let transno=$("#transno").val().trim();
	 //保险公司代码
	 let insurcecom=$("#insurcecom").val().trim();
	 //产品代码
	 let riskcode=$("#riskcode").val().trim();
	 
	 let proposalcontno =$("#proposalcontno").val().trim();
	
	var showdilogCFL= layer.load(2, {
		shade:0.3, //0.2透明度的白色背景
	});
	$.ajax({
		type: "POST",
		url: path + '/SFPJsonSend/checkILIEsignFileList.do',
		data: {"proposalcontno": proposalcontno,"transno":transno,"insurancecom":insurcecom},
		dataType: "json",
		async: false,
		success: function (data) {
			try {
				layer.close(showdilogCFL);
				if(!data.flag){
					layer.alert(data.desc);
				}else{
					let commonchannelConFirm = "平板电子签署";
					if(confirm("请确认所有文件已填写/上传完毕，再点击\"OK\"发送文件至"+commonchannelConFirm+"。如仍有文件需要上传，请点击\"Cancel\"返回编辑。")){
							var showdilog= layer.load(2, {
								shade:0.3,
							});
							//SEND
							let tempurl = path+"/restIliController/sendILIToWdc/"+transno+".do";
							setTimeout(function(){
								$.ajax({
									type: "POST",
									url: tempurl,// 后台请求URL地址
									data: {"transno": transno,"proposalcontno":proposalcontno},
									success: function (data) {
										if (data.flag) {
											alert("成功上传" + data.desc);
											//更新状态 F 表示成功上传到WDC
											try {
												$("#btn_sendToWDC").hide();
//													buttonControl(vueobj["testdivchange"].formdata.lccont.proposalcontno);//按钮状态查询
												
											} catch (e) {
												alert("javaScript Error");
											}
											$("#cusTable").bootstrapTable('refresh');

										} else {
											alert(data.desc);
											esignTable(true);
										}
										layer.close(showdilog);
									},
									error: function () {
										layer.alert("<div>系统异常</div><div>请检查身份证扫描件格式是否错误！扫描时，请务必扫描成黑白tiff格式再上传！手工修改文件的后缀名为tiff无效！或请联系YBT support team 查询</div>")
										layer.close(showdilog);
									}
								});

							},50);

						}
				}
				
			} catch (e) {
				alert("查询文件清单状态发生错误！");
				layer.close(showdilogCFL);
			}

		},
		error: function () {
			alert("查询文件清单状态发生错误！");
			layer.close(showdilogCFL);
		}
	});
	
}

function esignFileGroup(value, row, index){
	//1-投保单，2- 银行内部销售文件，3-其他核保要求文件，4-保险建议书文件(IPS)
	if(value=="1"){
		return "投保单";
	}else if(value=="2"){		
			return "银行内部销售文件";
	}else if(value=="3"){
		return "其他核保要求文件";
	}else if(value=="4"){
		return "保险建议书文件(IPS)";
	}else{
		hiddenindex.push(index);
	}
}



function esignStatusFormat(value, row, index) {
	
	/**if(tempVal=="P"&&row.esignaturelogic.insurance=="ANZL"){
		return "N/A";
	}**/
	
	if(value=="0"){
		return "等待生成该文件";
	}
	
	if(tempVal=="E"){
		
		
		if(value=="1"){
			return "等待录入该投保资料信息";
		}
		
		if(value=="2"){
			return "等待上传到银保通系统";
		}
		
		if(value>="5"&&row.esignaturelogic.senddoc=='1'){
			return "";
		}
		
		if(value=="5"&&row.esignaturelogic.signflag!='0'){
			return "等待发送给文件中心";
		}
		
		
		
		if(value=="5"){
			return "等待发送给文件中心";
		}
		
		if(value=="4"){
			return "尚未从其他系统获得该文件";
		}
		
		if(value=="3"){
			return "成功上传";
		}
		
		if(value=="6"&&(row.esignaturelogic.filetypecode=='GEN-RPQ')){
			return "";
		}
		
		
		if(value=="6"&&(row.esignaturelogic.filetypecode=='GEN-FPR')){
			return "";
		}
		//电子签名状态显示，所有的上传不需要签署的
		if(value=="6"&&row.esignaturelogic.signflag!='0'){
			return "已发送到文件中心";
		}
		if(value=="6"){
			return "等待签署文件";
		}
		
		if(value=="7"||value=="8"){
			return "签署成功";
		}
		
		if(value=="9"){
			return "准备发送到保险公司...";
		}
		
		if(value=="10"){
			return "保险公司已收到文件并开始核保";
		}
	}else{
		
		if(row.esignaturelogic.filetypecode=='GEN-RPQ'){
			//return "<span style='color:red;'>请自行打印客户的RPQ报告作为投保资料,交接给保险公司<span>";
			return "<span style='color:red;'>请上传客户的RPQ报告<span>";
		}
		//纸质
		return "";		
	}
	
	
	  
}

function downloadallfile(){
	//<button type="button"  class="btn addOrUpdate">录入/修改</button>
	if($("button:contains('录入')").next().length!=$("button:contains('录入')").length){
		alert("有未录入的文件，请完成录入后下载")
		return;
	}
	var args="transno="+topUpBean.transno+"&insurancecom="+topUpBean.insurancecom
	window.open(path+"/esign/esigntable/allfiledownload.do?"+args,"_blank");
}


//判断字符是否为空的方法
function isEmpty(obj){
    if(typeof obj == "undefined" || obj == null || $.trim(obj) == ""){
        return true;
    }else{
        return false;
    }
}

//自动打印投保单方法
function autoPrintLccont(esignBean){
	
	var flag=false;
	

	var riskcode=topUpBean.riskcode;
	// var managecom = topUpBean.managecom;
	// var insurancecom=topUpBean.insurancecom;
	var transno = topUpBean.transno;

    var url= path+"/newContEnter/autoPrintTPLccont.do?riskCode"+"="+riskcode+"&transno="+transno;
	
	if(esignBean){
	 //电子签名
	 var  esignBeanData  = encodeURIComponent(JSON.stringify(esignBean));
		//check 状态 需求不敢
	 url =url +"&esignBean="+esignBeanData;
	}
     
     if(url){
        $.ajax({
        	  url:url,
              type:"GET",
              async: false,
        	  success:function(){
        		  flag=true;
        	  },
              error:function(e){
            	  alert("投保单打印发生错误,"+e.status+":"+e.statusText+"!");
              }
        });
    }
    return flag;

    
}

//弹出窗铺满整个父窗口  
function openIframe_test(title,url){
  layer.open({
  type: 2,
  title: title,
  content: url,
  area: ['90%', '90%'],
  closeBtn:0, 
  success: function(){
    $(':focus').blur();
  },end: function () {
   //每次关闭iframe层后解绑resize事件，这样再次打开就绑定另一次新的index。
   $(window).unbind("resize");
  }
 });
 var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
 layer.iframeAuto(index);
 //自动设置全屏尺寸
 $(window).resize(function() {
    layer.iframeAuto(index);
 });
}
