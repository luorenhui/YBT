var parm="";
var tab_d = $('#cusTable');
$(function(){

//加载参数
if(grpcontno!=null && grpcontno !="" && grpcontno !="null"){
	$("#b").val(grpcontno);
}
if(riskcode!=null && riskcode!="" && riskcode !="null"){
	$("#riskcode").val(riskcode);
}
	//保险公司
	$.ajax({
		 url:path + '/newContEnter/selectFromLacom.do',  
         type: "POST",
		 success: function(data){
		 for(var i=0;i<data.length;i++){
			var select=document.getElementById("insuID");
		    var option=document.createElement("option");
			option.value=data[i].agentcom.replace(/^\s+|\s+$/g, '');;
			option.innerHTML=data[i].agentcom+"-"+data[i].name;
			select.appendChild(option);	
			
		 	 }
		 
		 }
	});
	
});
	
    //提交
	$("#add").click(function() {
 
		//客户号
		var concatis=$("#a").val().trim()+$("#b").val().trim();
		$("#grpcontno").val(concatis.trim());
		//客户号
		var grpcontno = $("#grpcontno").val();
		var grpno=$("#b").val().trim();
		//保险公司
		var insuID=$("#insuID").val();
		//产品代码
		var riskcode = $("#riskcode").val();
		
		if(grpno==""||grpno==null){
			alert("投保人客户号不能为空");
			return false;
		}
		if(insuID==""||insuID==null){
			alert("保险公司不能为空");
			return false;
		}
		
		if(riskcode==""||riskcode==null){
			alert("保险产品不能为空");
			return false;
		}
		//打开遮罩层
		show();
		
		//查询hub信息
		$.ajax({
			type : "POST",
			url:path+"/QueryCifController/queryCif.do",// 后台请求URL地址
			data : {"bankName":$("#grpcontno").val().trim(),"YH":riskcode,"BX":insuID},
			dataType : "json",
			success : function(data) {
				//关闭遮罩层
				closed();
				//失败
				if(data.success==false){
					alert(data.msg);
					return;
				}else{
					parm=data.parm;
					//hub客户信息
					if(parm!=null&&parm!=""){
					    //查询客户权限,销售资质，风险等级
						$.ajax({
						type : "POST",
						async: false,
						url:path+"/lccontIliController/selectpower.do",// 后台请求URL地址
						data : {"grpcontno":grpcontno,"insurancecom":insuID,"riskcode":riskcode},
						dataType : "json",
						success : function(data) {
							if(data.success==false){
								alert(data.msg);
								return;
							}else{
							    var str = parm.split(";");
								var idType=str[1];//证件类型
								var idNo=str[2];//证件号码
								var sex = str[3];//客户性别
								var validYear=str[4];//证件有效期
								var name= str[5];//客户姓名
								var birthday= str[6];//出生日期
								var telephone=str[7];
								if(birthday!=null&&birthday!=''){
									birthday=birthday.replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3");
								}
								if(validYear!=null&&validYear!=''){
									validYear=validYear.replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3");
								}
								
								//sign 新单01  操作 02
								 toedit(path + "/restIliController/toAdditionPage.do?insurcecom="+encodeURI(encodeURI(insuID))+"&riskcode="+encodeURI(encodeURI(riskcode))+
											"&name="+encodeURI(name)+"&sex="+encodeURI(encodeURI(sex))+"&birthday="+birthday+"&idType="+encodeURI(encodeURI(idType))
											+"&idNo="+encodeURI(encodeURI(idNo))+"&validYear="+validYear+"&customerNo="+encodeURI(encodeURI(grpcontno))+"&sign=01&conflag=01&telephone="+encodeURI(encodeURI(telephone)));
			                   }
	
						},
						error:function(data){
							closed();
							alert("系统异常")
						}
					});

				}else{
					//关闭遮罩层
					closed();
            	    alert("未返回客户信息");
            	}
				}

			},
			error:function(data){
				//关闭遮罩层
				closed();
			}
			});
		
		

/*		   //本地测试  注释上面请求方法
			var name = "测试姓名";//客户姓名
			var sex = "0";//客户性别  0 男  1女
			var birthday= "1996-06-07";//出生日期
			var idType="P";//证件类型
			var idNo="PX202121";//证件号码
			var validYear="20991231";//证件有效期
			var telephone="17521160201";//证件有效期
		    validYear=validYear.replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3");
			//跳转到投连账户基本信息页面
			let url = path + "/restIliController/toAdditionPage.do?insurcecom="+encodeURI(encodeURI(insuID))+"&riskcode="+encodeURI(encodeURI(riskcode))+
			"&name="+encodeURI(name)+"&sex="+encodeURI(encodeURI(sex))+"&birthday="+birthday+"&idType="+encodeURI(encodeURI(idType))
			+"&idNo="+encodeURI(encodeURI(idNo))+"&validYear="+validYear+"&customerNo="+encodeURI(encodeURI(grpcontno))+"&sign=01&conflag=01&telephone="+encodeURI(encodeURI(telephone));
			toedit(url);
					*/



});

//根据保险公司查询保险产品
function selectRisk(){
		var tContNo = $("#insuID").val();
		document.getElementById("riskcode").options.length = 1;
		$("#riskcode").select2("val","");
			$.ajax({
				 url:path + '/lccontIliController/searchrisk.do',  
		         type: "POST",
		         data:{"insurancecom":tContNo,"risktype":"01"},
				 success: function(data){					 
					var select=document.getElementById("riskcode");
				 for(var i=0;i<data.length;i++){
				    var option=document.createElement("option");
					option.value=data[i].riskcode;
					option.innerHTML=data[i].riskcode+"-"+data[i].riskname;
					select.appendChild(option);
				 }
				
			}
		});
}





//查询保单
function query(){
	 
	 var url_d = "/lccontIliController/selectLccontinfoili.do";
		
		/**加载页面表格*/
		var col = [
			{
				title : '序号',
				align: 'center',
				valign : 'middle',
				visible: true,
				formatter : function(value, row, index) {
					return index + 1;
				}
			},
				   {field: 'insuID',title: '保险公司',align: 'center',valign : 'middle',visible: true},
				   {field: 'riskcode',title: '保险产品',align: 'center',valign : 'middle',visible: true},
		           {field: 'contNo',title: '保单号',align: 'center',valign : 'middle',visible: true},
				   {field: 'proposalContNo',title: '投保单号',align: 'center',valign : 'middle',visible: true},
		           {field: 'transNo',title: '交易流水号',align: 'center',valign : 'middle',visible: true},
				   {field: 'saleCode',title: '销售人员代码',align: 'center',valign : 'middle',visible: true},
		];
		
		var uniqueId = "id";
		var sortOrder = "id asc";		
	
     $("#cusTable").bootstrapTable('destroy');
		tableInit3(url_d,tab_d,col,uniqueId,sortOrder,queryParams);
}



/**
* 设置表格查询参数
* @param params
*/
function queryParams(params){
	//设置查询参数 
  var param = {
	        //这里是在ajax发送请求的时候设置一些参数 params有什么东西，
	    	//自己看看源码就知道了 limit: params.pageSize,
  		limit : params.limit,
	        offset: params.offset,
	        sortName:params.sortName,//排序列名
	        sortOrder:params.sortOrder,//排位命令（desc，asc）
	        pageSize: params.pageSize,
	        pageNumber:params.pageNumber,
	        
	        insuID : $("#insuID").val(),
	        riskcode : $("#riskcode").val(),
	    }; 
	    return param; 
}

/**
* 翻页带查询参数及列排序
* @param url
* @param obj
* @param col
* @param uniqueId 行主键
* @param sortOrder 排序方式
* @param queryParams
* @author TKW
*/
function tableInit3( url,obj,col,uniqueId,sortOrder,queryParams){
	 obj.bootstrapTable({
		 url: path+url, // 请求后台的URL（*）
		 dataType: "json",
		 method: 'post', // 请求方式（*）
		 contentType: "application/x-www-form-urlencoded",
		 toolbar: '#toolbar',
		 toolbar: '#toolbar2',// 工具按钮用哪个容器
		 columns:  col,
		 striped: true, // 是否显示行间隔色
		 cache: false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
		 pagination: true, // 是否显示分页（*）
		 sortable: true, // 是否启用排序
		 sortOrder: "asc", // 排序方式
		 sortOrder: sortOrder, // 排序方式
		 queryParamsType : "limit",// undefined/limit
		 queryParams: queryParams,//传递参数（*）
		 sidePagination: "server", //
		 
		 //分页方式：client客户端分页，server服务端分页（*）
		 // pageNumber:1, //初始化加载第一页，默认第一页
		 // pageSize: 10, //每页的记录行数（*）
		 //pageList: [10, 25, 50, 100], // 可供选择的每页的行数（*）
		 search: false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
		 strictSearch: true,//设置为 true启用 全匹配搜索，否则为模糊搜索
		 showColumns: true, // 是否显示所有的列
		 //showRefresh: false, // 是否显示刷新按钮
		 minimumCountColumns: 2, // 最少允许的列数
		 clickToSelect: true, // 是否启用点击选中行
		 // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		 uniqueId: "ID", // 每一行的唯一标识，一般为主键列
		 uniqueId: uniqueId, // 每一行的唯一标识，一般为主键列
		// showToggle:true, // 是否显示详细视图和列表视图的切换按钮
		// cardView: false	, // 是否显示详细视图
		 //detailView: false, // 是否显示父子表
		 paginationDetailHAlign:"right",
	 });

};

//获取ID
function getIdSelections() {
	return $.map($cusTable.bootstrapTable('getSelections'), function(row) {
		return row.contno;
	});
}