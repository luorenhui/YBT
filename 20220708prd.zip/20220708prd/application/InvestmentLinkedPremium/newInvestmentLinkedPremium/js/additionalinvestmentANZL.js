var tab_d = $('#cusTable');
var showdilog;
//安联保单号补零
var contnoarray=new Array('00000000000','0000000000','000000000','00000000','0000000','000000','00000','0000','000','00','0');
//大都会保单号补零
var contnoarraymeli=new Array('0000000','000000','00000','0000','000','00','0');
// 页面初始化
$(document).ready(function() {
	
	if(topUpBean.insurcecom!="ANZL"){
		//非安联隐藏移动电话
		$("#telephone_div").css("display","none");
	}
	
	if(topUpBean.insurcecom!="MELI"){
		//非大都会隐藏转账方式
		$("#transfermethod_div").css("display","none");
		if (conflag == "02"){
			$("#telephone").attr("readonly",true);
		}
	}
	
	if (topUpBean.flag == null || topUpBean.flag == "" || topUpBean.flag == "00"){
		queryic();
	}
	if (topUpBean.flag == "02" || topUpBean.flag == "03" || topUpBean.flag == "04"){
		queryic2();
		$("#sumprem").attr("disabled",true);
		//禁用form表单
		$("#form_divs").addClass("disabledbutton");
		if(topUpBean.insurcecom == "MELI"){
			$("#transfermethod").attr("disabled",true);
		}
	}
	// alert(topUpBean.flag);
	if(sign=="01"){
		selectContno();
		if (conflag == "02"){
			if (topUpBean.contnoflag == "other"){
				$("#contno").attr("readonly",false);
			}
		}
	}else{
		//未校验时查询保单号
		if(topUpBean.flag == "00"){
			//下拉框查询保单号
			selectContno();
		}else{
	    //不为空且不为其他时赋值
		if(topUpBean.contnoflag!=null&&topUpBean.contnoflag!=''&&topUpBean.contnoflag!='other'){ 
		//给下拉框赋值
		 $("#contnoflag").append("<option value='"+topUpBean.contnoflag+"'>"+topUpBean.contnoflag+"</option>");
		 
		}
		$("#contnoflag").select2("val",topUpBean.contnoflag);
		 $("#contnoflag").attr("disabled",true);
	    $("#contno").attr("disabled",true);
			
		}
		
	}
	 //提交
	$("#save").click(function() {

		 //保单号
		 var contNo=$("#contno").val().trim();
		//保险公司
		var insurcecom=$("#insurcecom").val().trim();
		//产品代码
		var riskcode=$("#riskcode").val().trim();
       //证件有效期
		var validYear=$("#validYear").val();
        //安联 投保人移动电话
		var telephone=$("#telephone").val().trim();

		 //交易流水号
		 var transno=$("#transno").val().trim();
		 //投保单号码
		 var proposalcontno=$("#proposalcontno").val().trim();
		 //产品代码
		 var riskcode=$("#riskcode").val().trim();
		 
		//保费
		 var sumprem=$("#sumprem").val().trim();
		 

		var contnoflag=$("#contnoflag").val();
			
		

		if(!(new Date(validYear)>new Date())){
			alert("证件有效期必须大于今天");
			return false;
		}
       
		
		if(contNo==null||contNo==''){
			alert("保单号不能为空");
			return false;
		}

		if(insurcecom==null||insurcecom==''){
			alert("保险公司不能为空");
			return false;
		}

		if(riskcode==null||riskcode==''){
				alert("产品代码不能为空");
				return false;
		 }
		

		 if(sumprem==0){
			alert("保费金额不能为空或0");
			return false;
		 }
		 
		 
		//如果下拉框为“其他”时判断输入保单号长度   安联 若RM录入保单号，保存时，系统自动补零为12位数字（在输入的保单号前补零）
		 if(contnoflag=="other"&&null!=insurcecom){
		 //保单号长度
		 var contnolength=contNo.length;
		  //安联12位保单号
		  if(insurcecom=='ANZL'){
			if(contnolength<12){
				//补零拼接数据
				var cont=contnoarray[contnolength-1]+contNo;
				//赋值到页面
				$("#contno").val(cont);
			}
			if(contnolength>12){
				alert('保单号输入位数有误，请重新输入！');
				return false;
			}
		  }
		  //大都会8位保单号
		  if(insurcecom=='MELI'){
				if(contnolength<8){
					//补零拼接数据
					var cont=contnoarraymeli[contnolength-1]+contNo;
					//赋值到页面
					$("#contno").val(cont);
				}
				if(contnolength>8){
					alert('保单号输入位数有误，请重新输入！');
					return false;
				}
			  }
		  
		}
		 
		 
		//投资账户个数
		var selectlength=$("#com").children().length; 
		//追加金额校验
		var sumaccrate = 0.00;
		var check = false;
		var count=0;
		for (var i = 0; i < selectlength; i++)
		{

			var accno=$("#accno\\["+i+"\\]").val().trim();
			var accrate=$("#accrate"+i).val().trim();
			//投资账户不为空
			if(accno!=null&&accno!=""&&accno!='N/A'){
				//alert("accno="+accno+"  accrate="+accrate);
				//追加金额不为空
				if(accrate!=null&&accrate!=""){
					try {
						sumaccrate=parseFloat(sumaccrate)+parseFloat(accrate);
						check = true;
					} catch (e) {
						alert("请确认各追加金额是否为数字");
						return false;
					}

				}else{
					alert("请确认各追加金额是否已录入");
					return false;
				}
				count++;
			}

		}

		//安联
		if(insurcecom=="ANZL"){
			// alert("sumaccrate=="+sumaccrate);
			if(check&&sumaccrate<1000){
				alert("所有投资账户的追加金额总和最低1000,请确认");
				return false;
			}

			if(telephone==null||telephone==''){
				alert("移动电话不能为空");
				return false;
			}
			
			
			
		}
		//大都会
		if(insurcecom=="MELI"){
			
			if(Number(sumprem) >= 200000){
				if($("#sameAppInsu").val() != "Y" && $("#sameAppInsu").val() != 'N'){
					alert("请选择投被保人是否为同一人");
					return;
				}
				
				if($("#bnfLegal").val() != "Y" && $("#bnfLegal").val() != 'N'){
					alert("请选择受益人是否法定");
					return;
				}
				
			}
			
			
			if(check&&sumaccrate%1000!=0){
				alert("所有投资账户的追加金额总和必须是1000元的整数倍");
				return false;
			}
			// alert("sumaccrate=="+sumaccrate);
			if(check&&sumaccrate<10000){
				alert("所有投资账户的追加金额总和最低10000,请确认");
				return false;
			}

		}

		if(count==0){
			alert("请至少选择一种投连账户");
			return false;
		}

		if(sumprem!=sumaccrate){
			alert("保费和追加金额总和不匹配，请重新输入！");
			return false;
		}
		
		 //调用保存方法
		 insertLccontinfoili();
	});


    //根据保险公司及保险产品查询保单号
	//  selectContno();
	 //查询证件类型
	 selectidtype();
	//查询产品名称
	selectname();

	//根据保险公司查询对应投资账户
	// queryic();

	 //加载投资账户选项
	commonCombobox_investmentaccount = {
			  url:path+"/lccontIliController/QueryParams.do?riskcode="+topUpBean.riskcode+"&paramstype=InvestmentAccount",// 后台请求URL地址
			    valueField: "paramscode",
			    cache : false,
			    mutually_exclusive:true,
			    // 显示在输入框的
			    inputText: "paramsname",
			    relateType:"commmon",
			    delayLoadDataFlag:true,
			    
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"],
	};
	

	
	
});

//保单号改变时清空保全号及流水号
function clearData(){
	//保全号
	$("#proposalcontno").val("");
	//流水号
	$("#transno").val("");

	var contnoflag=$("#contnoflag").val();
	
	//如果下拉框为“其他”时显示文本框
	if(contnoflag=="other"){
		//显示输入框
		$('#contno').attr("readonly",false);//去除contno元素的readonly属性
		$("#contno").attr("disabled",false);
		$('#contno').val('');
	}else{		
		//显示输入框
		$('#contno').attr("readonly",true)//添加contno元素的readonly属性
		$('#contno').val(contnoflag);
	}
}


//保单号输入框改变时清空保全号及流水号
function clearInputData(){
	//保全号
	$("#proposalcontno").val("");
	//流水号
	$("#transno").val("");

}

$(function(){
	var uploadData ="";
	var showdilog="";
	Dropzone.autoDiscover = false;
	var dropzoneParams ={
			url: path+"/restIliController/INSHcontDocUpload.do",
		    addRemoveLinks: true,
		    method: 'post',
		    timeout:600000,
		    enctype:"multipart/form-data",
		    filesizeBase: 1000,
		    dictRemoveFile:"移除文件",
		    dictCancelUpload: "取消上传",
		    autoProcessQueue:false,
		    acceptedFiles: ".tif,.tiff",
		    dictInvalidFileType: "仅支持.tif和.tiff类型文件上传.",
		    thumbnailWidth:100,
		    thumbnailHeight:100,
		    maxThumbnailFilesize:5,
//		    maxFiles:40,
		    maxFilesize:3,
		    uploadMultiple:true,
		    parallelUploads:100,
		    previewTemplate: document.querySelector('#preview-template').innerHTML,
		    sendingmultiple: function(file, xhr, formData) {
		    	var proposalcontno=topUpBean.proposalcontno;
		    	var insurancecom=topUpBean.insurcecom;
		    	var transno =topUpBean.transno;
		    	formData.append("filesize", file.size);
		        formData.append("proposalcontno", proposalcontno);
		        formData.append("transno", transno);
		        formData.append("insurancecom", insurancecom);
		        formData.append("contno",$("#contno").val().trim());
		    },
		    init: function() {
		        var submitButton = document.querySelector("#upFiles");
		        var upstatus = true;
		        dropzoneObj = this;
		        
		    	submitButton.addEventListener("click", function() {
		    		if(dropzoneObj.files!=null&&dropzoneObj.files!=""){
		    			showdilog= layer.load(0, {
		   			  shade: [0.1,'#fff'] //0.1透明度的白色背景
		    		   });
		    		}
						dropzoneObj.processQueue(); 
		    	
				});
		    	
		    	this.on("canceled", function(file) {
		    		var _ref;
		    		$.ajax({
		    			url:path+"/contUploadController/removeUpDoc.do",
		    			type:"POST",
		    			data:{"upcode":uploadData.map.upcode,
		    				  "contno":uploadData.map.contno},
		    			success:function(data){
		    				dropzoneObj.reset();
		    				console.log(data);
		    			}
		    		});
		    		this.files.length=0;
		    	    return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
				});
		    	
		    	this.on("addedfile",function(file){
		    		console.info("file.type : "  + file.type ); 
		    		setTimeout(function(){
		    			console.info(file.accepted);
		    			if(!file.accepted){   				
		    				upstatus=false;
		    				} 			
		    		!upstatus?$("#upFiles").attr("disabled",true):$("#upFiles").removeAttr("disabled");
		    		},10);
		    	});
		    	
		    	this.on("removedfile", function(file) {
		    			var _ref;
		    			//仅移除单个文件
		    			(_ref = file.previewElement) != null ? _ref.parentNode!=null?_ref.parentNode.removeChild(file.previewElement):void 0 : void 0;
		        		
		    			var upfiles = this.files;
		    	    	var len = 0;
		    	    	var check = 0;
		    	    	for(var j = 0,len=upfiles.length; j < len; j++) {
		    	    		if(upfiles[j].accepted)check++;
		    	    	}
		    	    	
		    	    	if(len==check)upstatus=true;
		    	    	
		    	    	!upstatus?$("#upFiles").attr("disabled",true):$("#upFiles").removeAttr("disabled");

				}); 
		    	
		    	this.on("successmultiple", function(file, response, e){
		    		console.log("ANZL upload return type ===" + typeof(response));
		    		if(typeof(response) == "string"){
		    			response = JSON.parse(response);
		    		}
					var reg=/ /g;
					var _ref;
					var dropzoneObj =this;
					var proposalcontno=topUpBean.proposalcontno;
					var insurancecom=topUpBean.insurancecom;
					(_ref = file[0].previewElement) != null ? _ref.className!=null?$("."+_ref.className.replace(reg,'.')).remove():void 0 : void 0;
					
					uploadData=response.success?response:"";
					this.files.length=0;
		            var resultMsg = response.msg;
		            console.log("++++"+response.msg+"******");
		            if(resultMsg == 'undefined' || resultMsg == undefined){
		                alert("Time out,please login again!");
		                layer.close(showdilog);
		            }else{
		                alert(response.msg);
		                layer.close(showdilog);
		                app.$set(app.topVue.lcilipay,"uploadflag","F")
		            } 		 
				});
		    	this.on("completemultiple",function(){
		    		try {
		    			layer.close(showdilog);
					} catch (e) {
						console.log(e);
					}
		   		 
		   	    }); 	  	
		  }
		    
		};
	$("#upfilezone").dropzone(dropzoneParams);
})
//查询投连账户
function queryic(){
	 //遮罩层
	 showdilog= layer.load(0, {
		  shade:0.3, //0.2透明度的白色背景
	   });

	 var insurcecom=$("#insurcecom").val().trim();
	if(insurcecom!=null&&insurcecom!=''){
	$.ajax({
		type : "POST",
		url:path+"/lccontIliController/QueryParams.do",// 后台请求URL地址
		data :"riskcode="+topUpBean.riskcode+"&paramstype=InvestmentAccount",
		dataType : "json",
		success : function(data) {
			var json=eval(data);
			if(data.length!=0){

				document.getElementById('com').style.display='';
				apendParam(json);
				layer.close(showdilog);
			}else{
				layer.close(showdilog);
			}
		},
		error : function() {
			layer.close(showdilog);
			alert("投连账户查询异常");
		}
	});
	}

}
//回显显示投资账户选择和追加金额
function queryic2() {
	let chartdiv=document.getElementById("com");
	let len = topUpBean.topObj.lccontIliBeans.length;
	for (let i=0;i<len;i++){
		let lccontIliBeans = topUpBean.topObj.lccontIliBeans;
		let div=document.createElement("div");
		div.innerHTML+="<div class='col-lg-6 col-md-6 col-xs-6 marginbottom15' id=" + 'type'+ i + ''+ "><label class='col-sm-4 control-label' for='field-3'>投资账户选择</label><div class='col-sm-7'>" +
			"<input type='text' class='form-control' name=accno"+i+"_bak1  id=accno"+i+"_bak1 value="+lccontIliBeans[i].bak1+"></div></div>";
		div.innerHTML+="<div class='col-lg-6 col-md-6 col-xs-6 marginbottom15' id=" + 'type'+ i + ''+ "><label class='col-sm-4 control-label' for='field-3'>追加金额</label><div class='col-sm-7'>" +
			"<input type='text' class='form-control' name=prem"+i+"  id=prem"+i+" value="+lccontIliBeans[i].prem+"></div></div>";
		div.innerHTML+="<div class='col-lg-6 col-md-6 col-xs-6 marginbottom15' id=" + 'type'+ i + ''+ " style='display: none'><label class='col-sm-4 control-label' for='field-3'>追加金额</label><div class='col-sm-7'>" +
			"<input type='text' class='form-control' name=accno["+i+"]  id=accno["+i+"] value="+lccontIliBeans[i].accno+"></div></div>";
		div.innerHTML+="<div class='col-lg-6 col-md-6 col-xs-6 marginbottom15' id=" + 'type'+ i + ''+ " style='display: none'><label class='col-sm-4 control-label' for='field-3'>追加金额</label><div class='col-sm-7'>" +
			"<input type='text' class='form-control' name=orderNumber"+i+"  id=orderNumber"+i+" value="+lccontIliBeans[i].orderNumber+"></div></div>";
		chartdiv.appendChild(div);
		$("#accno" + i + "_bak1").attr("disabled",true);
		$("#prem" + i).attr("disabled",true);
	}
}

//动态加载投连账户
function apendParam(json){
	var chartdiv=document.getElementById("com");
	for(var i=0;i<json.length;i++){
		var div=document.createElement("div");
		div.innerHTML+="<div class='col-lg-6 col-md-6 col-xs-6 marginbottom15' id=" + 'type'+ i + ''+ "><label class='col-sm-4 control-label' for='field-3'>投资账户选择</label><div class='col-sm-7'>" +
        	"<input type='text' class='form-control' name=accno["+i+"]  id=accno["+i+"]></div></div>";
		div.innerHTML+="<div class='col-lg-6 col-md-6 col-xs-6 marginbottom15' id=" + 'type'+ i + ''+ "><label class='col-sm-4 control-label' for='field-3'>追加金额</label><div class='col-sm-7'>" +
		"<input type='text' class='form-control' name=accrate"+i+"  id=accrate"+i+"></div></div>";
		div.innerHTML+="<div class='col-lg-6 col-md-6 col-xs-6 marginbottom15' id=" + 'type'+ i + ''+ " style='display: none' ><label class='col-sm-4 control-label' for='field-3'>排序</label><div class='col-sm-7'>" +
		"<input type='text' class='form-control' name=orderNumber"+i+"  id=orderNumber"+i+" value="+i+"></div></div>";

         chartdiv.appendChild(div);
         //加载下拉选项
       
         $("#accno\\["+i+"\\]").combobox(commonCombobox_investmentaccount)

	}
}



//传值到后台
function addproduct(showdilog){

	 //取值
	 var transno=$("#transno").val().trim();
	 var contno=$("#contno").val().trim();

	 var insurcecom=$("#insurcecom").val().trim();
	 var riskcode=$("#riskcode").val().trim();
	 var proposalcontno=$("#proposalcontno").val().trim();
	 var customerNo=$("#customerNo").val().trim();
	 //投资账户个数
	 var selectlength=$("#com").children().length;

	  var jsonData=new Array();
	for (var i = 0; i < selectlength; i++){
  	  //投资账户代码
	      var accno=$("#accno\\["+i+"\\]").val().trim();
	      //投资比例
	      var accrate=$("#accrate"+i).val().trim();
	      //排序
	      var orderNumber=$("#orderNumber"+i).val().trim();
	      //投资账户中文
	      var bak1=$("#accno\\["+i+"\\]_combobox").combobox("showtext").val();
	      //投资账户不为空
	      if(accno!=null&&accno!=""&&accno!='N/A'){
	    	  var tr = {
	    			  "transno" : transno,
	  				  "contno" : contno,
	  				  "proposalcontno"  :proposalcontno,
	  				  "insurcecom"   :insurcecom,
	  				  "riskcode"   : riskcode,
	    			  "bak1" : bak1,
	    			  "accno" :accno,
	    			  "prem" : accrate,
	    			  "orderNumber" : orderNumber,
	    			  "customerNo": customerNo
	    	  		};
	    	  jsonData.push(tr);
	      }

	}
	//请求后台
	myaddParam(jsonData,showdilog);
}


//保存基本信息
function insertLccontinfoili(jsonData){
	//遮罩层
	var showdilog= layer.load(0, {
			  shade:0.3, //0.2透明度的白色背景
	});

	//证件类型打开给后台传值
	$("#idType").attr("disabled",false);
	//性别打开给后台传值
	$("#sex").attr("disabled",false);
	//保单号
	$("#contno").attr("disabled",false);
	var ids1 =$("form").serialize();
	if(ids1.indexOf("sameAppInsu") == -1){
		//页面隐藏时
		ids1 += "&sameAppInsu=&bnfLegal="
	}
	//双录字段
	let dualRecordingStr = "&orderID=" + (topUpBean.topObj.lccontInfoiliBean.orderID == undefined ? "":topUpBean.topObj.lccontInfoiliBean.orderID)
	+"&reportID=" + (topUpBean.topObj.lccontInfoiliBean.reportID == undefined ? "":topUpBean.topObj.lccontInfoiliBean.reportID)
	+"&recordID=" + (topUpBean.topObj.lccontInfoiliBean.recordID == undefined ? "":topUpBean.topObj.lccontInfoiliBean.recordID)
	+"&FPRID=" + (topUpBean.topObj.lccontInfoiliBean.FPRID == undefined ? "":topUpBean.topObj.lccontInfoiliBean.FPRID)
	+"&prdTypeCode=" + (topUpBean.topObj.lccontInfoiliBean.prdTypeCode == undefined ? "":topUpBean.topObj.lccontInfoiliBean.prdTypeCode)
	+"&prdSubTypeCode=" + (topUpBean.topObj.lccontInfoiliBean.prdAlternativeNumber == undefined ? "":topUpBean.topObj.lccontInfoiliBean.prdAlternativeNumber)
	+"&prdAlternativeNumber=" + (topUpBean.topObj.lccontInfoiliBean.prdAlternativeNumber == undefined ? "":topUpBean.topObj.lccontInfoiliBean.prdAlternativeNumber)
	+"&prdClassificationCode=" + (topUpBean.topObj.lccontInfoiliBean.prdClassificationCode == undefined ? "":topUpBean.topObj.lccontInfoiliBean.prdClassificationCode)
	+"&countryTradableCode=" + (topUpBean.topObj.lccontInfoiliBean.countryTradableCode == undefined ? "":topUpBean.topObj.lccontInfoiliBean.countryTradableCode)
	+"&customerIndicator=" + (topUpBean.topObj.lccontInfoiliBean.customerIndicator == undefined ? "":topUpBean.topObj.lccontInfoiliBean.customerIndicator)
	+"&quotationId=" + (topUpBean.topObj.lccontInfoiliBean.quotationId == undefined ? "":topUpBean.topObj.lccontInfoiliBean.quotationId)
	+"&applicationId=" + (topUpBean.topObj.lccontInfoiliBean.applicationId == undefined ? "":topUpBean.topObj.lccontInfoiliBean.applicationId);
	//后台接口
	$.ajax({
		type : "POST",
		data : ids1 + dualRecordingStr,
		dataType : "json",
		url:path+"/lccontIliController/insertLccontinfoili.do",// 后台请求URL地址
		success : function(data) {
			//非新单禁用保单号
			if(sign!="01"){
			//保单号
			$("#contno").attr("disabled",true);
			}
			//证件类型设置为只读
			$("#idType").attr("disabled",true);
			//性别
			$("#sex").attr("disabled",true);
			if(data!=null&&data.proposalcontno!=null){
				//投保单号
				$("#proposalcontno").val(data.proposalcontno);
				//交易流水号
				$("#transno").val(data.transno);
				app.$set(app.topVue.lccontInfoiliBean,"proposalcontno",data.proposalcontno);
				app.$set(app.topVue.lccontInfoiliBean,"transno",data.transno);
				topUpBean.proposalcontno = data.proposalcontno;
				topUpBean.transno = data.transno;
				topUpBean.contno = $("#contno").val().trim();
			    //插入成功
				if(data.success){
					
				  //取值
				  var proposalcontno=$("#proposalcontno").val().trim();
				  var transno=$("#transno").val().trim();
				  //保存投资账户信息
					addproduct(showdilog);

      		  }else{
      			//关闭遮罩层
      			layer.close(showdilog);
      			alert(data.msg);
      		}

			}else{
				 //关闭遮罩层
  			 layer.close(showdilog);
				 alert(data.msg);
			}

		},error : function() {
			 $("#idType").attr("disabled",true);
			//性别
			$("#sex").attr("disabled",true);
			//非新单禁用保单号
			if(sign!="01"){
			//保单号
			$("#contno").attr("disabled",true);
			}
			//关闭遮罩层
			layer.close(showdilog);
			 alert("系统异常");
		}

	});

}

//后台存值及投连追加申请
function myaddParam(jsonData,showdilog){
	$.ajax({
		type : "POST",
		url:path+"/lccontIliController/insert.do",// 后台请求URL地址
		data : JSON.stringify(jsonData),
		dataType : "json",
		contentType : 'application/json;charset=utf-8',
		traditional : true,
		success : function(data) {
			//关闭遮罩层
			layer.close(showdilog);
			if(data=="true"){
				alert("投连追加申请成功");
				
				//追加申请成功后，置灰提交按钮
				 $("#save").attr("disabled",true);
				 //电话设为只读
				 $("#telephone").attr("readonly",true);				
				 $("input").attr("disabled",true);
				 $("select").attr("disabled",true);
                //禁用form表单
				$("#form_divs").addClass("disabledbutton");
				//禁用投资账户
				$("#com").addClass("disabledbutton");
					
				app.$set(app.topVue.lccontInfoiliBean,"flag","02");
				
			}if(data=="false"){
				alert("投连追加申请失败");
			}
			if(data!="true"&&data!="false"){
				alert(data);
			}
		},
		error : function() {
			//关闭遮罩层
			layer.close(showdilog);
			alert("plus failed");
		}
	});
}


//查询产品名称
function selectname(){
	$.ajax({
		 url:path + '/lccontIliController/selectRiskCodes.do',
		 data:"riskCode="+topUpBean.riskcode,
		 type: "POST",
		 success: function(data){
			//产品名称
			$("#riskname").val(data);
		 },error : function() {
			 alert("产品名称查询异常");
		}
	});
}


//根据保险公司及保险产品查询保单号
function selectContno(){
	 //遮罩层
	 var showdilog= layer.load(0, {
		  shade:0.3, //0.2透明度的白色背景
	   });
	 document.getElementById("contnoflag").options.length = 2; 
	 
	$.ajax({
		 url:path + '/lccontIliController/selectInspolicyByriskcode.do',  
		 data:"insurancecom="+topUpBean.insurcecom+"&riskcode="+topUpBean.riskcode+"&custnum="+topUpBean.customerNo,
       type: "POST",
		 success: function(data){	
			
			 //加载后台保单号
			 if(data!=null&&data.length!=0){
			
			  for(var i=0;i<data.length;i++){
				  var select=document.getElementById("contnoflag");
			    var option=document.createElement("option");
				option.value=data[i].acctnum;
				option.innerHTML=data[i].acctnum;
				select.appendChild(option);	
			 }
						
		 	 }
			
			    //不为空时赋值
				if(topUpBean.contnoflag!=null&&topUpBean.contnoflag!=''){ 
				$("#contnoflag").select2("val",topUpBean.contnoflag);
				
				}
			 
			//关闭遮罩层
			layer.close(showdilog);
		 },error : function() {
			    //关闭遮罩层
				layer.close(showdilog);
				alert("保单号查询异常");
		}
	});
}

//查询证件类型
function selectidtype(){
	var codetype="";
	if(topUpBean.insurcecom!=null&&topUpBean.insurcecom!==""&&topUpBean.insurcecom=="AXA"){
		codetype="axaidtype";
	}else{
		codetype="idtype";
	}

	$.ajax({
		 url:path + '/LdcodeController/selectIdTypeByCodetype.do',
		 data:"codetype="+codetype,
       type: "POST",
		 success: function(data){
			 if(data!=null&&data.length!=0){
				 document.getElementById("idType").options.length = 0;
			 }
			 for(var i=0;i<data.length;i++){
					var select=document.getElementById("idType");
				    var option=document.createElement("option");

				    option.value=data[i].code;
				    option.innerHTML=data[i].code+"-"+data[i].codename;

					select.appendChild(option);
			}
			//证件类型
			$("#idType").select2("val",topUpBean.idType);
		 },error : function() {
			 alert("证件类型查询异常");
		}
	});
}





//文件列表
function query(){
 //交易流水号
 var transno=$("#transno").val().trim();
 //保险公司代码
 var insurcecom=$("#insurcecom").val().trim();
 //产品代码
 var riskcode=$("#riskcode").val().trim();

var init_url = "/InsuComController/select.do";
 var url_d = "/lccontIliController/additionalinvestment/query/"+insurcecom+"/"+transno+".do?riskcode="+riskcode;

	/**加载页面表格*/
	var col = [{field: 'esignaturelogic.groups',title: '文件类型',align: 'center',valign : 'middle',visible: true},
				   {field: 'esignaturelogic.filedesc',title: '文件名',align: 'center',valign : 'middle',visible: true},
				   {field: 'esignaturelogic.filetype',title: '文件格式',align: 'center',valign : 'middle',visible: true},
				   {field: 'esignaturelogic.totalflag',title: '文件状态',align: 'center',valign : 'middle',visible: true},
	];

	var uniqueId = "id";
	var sortOrder = "id asc";

   $("#cusTable").bootstrapTable('destroy');
		tableInit3(url_d,tab_d,col,uniqueId,sortOrder,queryParams);
}



/**
* 设置表格查询参数
* @param params
*/
function queryParams(params){
//设置查询参数 
var param = {
        //这里是在ajax发送请求的时候设置一些参数 params有什么东西，
    	//自己看看源码就知道了 limit: params.pageSize,
		limit : params.limit,
        offset: params.offset,
        
        sortName:params.sortName,//排序列名
        sortOrder:params.sortOrder,//排位命令（desc，asc）
        
        pageSize: params.pageSize,
        pageNumber:params.pageNumber
    }; 
    return param; 
}

/**
* 翻页带查询参数及列排序
* @param url
* @param obj
* @param col
* @param uniqueId 行主键
* @param sortOrder 排序方式
* @param queryParams
* @author TKW
*/
function tableInit3( url,obj,col,uniqueId,sortOrder,queryParams){
 obj.bootstrapTable({
	 url: path+url, // 请求后台的URL（*）
	 dataType: "json",
	 method: 'post', // 请求方式（*）
	 contentType: "application/x-www-form-urlencoded",
	 toolbar: '#toolbar',
	 toolbar: '#toolbar2',// 工具按钮用哪个容器
	 columns:  col,
	 striped: true, // 是否显示行间隔色
	 cache: false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
	 pagination: true, // 是否显示分页（*）
	 sortable: true, // 是否启用排序
	 sortOrder: "asc", // 排序方式
	 sortOrder: sortOrder, // 排序方式
	 queryParamsType : "limit",// undefined/limit
	 queryParams: queryParams,//传递参数（*）
	 sidePagination: "server", //
	 
	 //分页方式：client客户端分页，server服务端分页（*）
	 // pageNumber:1, //初始化加载第一页，默认第一页
	 // pageSize: 10, //每页的记录行数（*）
	 //pageList: [10, 25, 50, 100], // 可供选择的每页的行数（*）
	 search: false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
	 strictSearch: true,//设置为 true启用 全匹配搜索，否则为模糊搜索
	 showColumns: true, // 是否显示所有的列
	 //showRefresh: false, // 是否显示刷新按钮
	 minimumCountColumns: 2, // 最少允许的列数
	 clickToSelect: true, // 是否启用点击选中行
	 // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
	 uniqueId: "ID", // 每一行的唯一标识，一般为主键列
	 uniqueId: uniqueId, // 每一行的唯一标识，一般为主键列
	// showToggle:true, // 是否显示详细视图和列表视图的切换按钮
	// cardView: false	, // 是否显示详细视图
	 //detailView: false, // 是否显示父子表
	 paginationDetailHAlign:"right",
 });

};

//获取ID
function getIdSelections() {
return $.map($cusTable.bootstrapTable('getSelections'), function(row) {
	return row.contno;
});
}

//更新topVue中对应属性value
function changeTopVal(name, value){
	app.$set(app.topVue.lccontInfoiliBean, name, value);
//	console.log(app.topVue.lccontInfoiliBean[name]);
}
