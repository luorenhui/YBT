afterloadNewElements.krisk_tabinfo = function(url, form_element) {
	
			setTimeout(function(){
				 if(($("#AutoPayFlag").is(":visible")||$("#AutoPayFlag").length>0)){
					  $("#AutoPayFlagTitle").remove();
				      $("#AutoPayFlag").parent().append("<small id='AutoPayFlagTitle' class='help-block'>" +
					      		/*"<b style='color:red'>此选项须征求客户意见后选择 ,并告知客户该选择项的实际意义和作用</b><br>" +*/
					      		"<b style='color:red'>*保险费自动垫交：</b>*投保人未按时交纳续期保费，若保单当时已具有足够现金价值，保险公司将以该合同基本保险金额对应的现金价值扣除尚未偿还的各项欠款之后的余额自动垫交到期应交的保险费，使保单继续有效。垫交保险费视作保单贷款，并自保险费自动垫交发生之日起以保单贷款利率予以计息。"
					      		+"<br><b style='color:red'>*合同中止：</b>*投保人未按时交纳续期保费，保险合同暂时失去效力。" +
					      		"</small>");
				  }
				  var riskcode = vueobj["testdivchange"].formdata.lcpol.riskcode;
				  if(riskcode != null && riskcode != undefined && riskcode != ""){
					  $.ajax({ 
							type : "POST",
							async: false,
							url:path + "/h5BeanController/getrisktype.do",// 后台请求URL地址
							data : {"riskcode":riskcode},
							dataType : "json",
							success : function(data) {						
								//投连险主险页面字段-投资生效期 下面加文字解释  
								if(($("#investmentStartDateFlag").is(":visible")||$("#investmentStartDateFlag").length>0)){
									 if("01"==data){
									  $("#investmentStartDateFlagTitle").remove();
								      $("#investmentStartDateFlag").parent().append("<small id='investmentStartDateFlagTitle' class='help-block'>"
									      	+"<b>[犹豫期后投资] 自签收保单次日0时起，您有XX天的犹豫期。犹豫期内退保保险公司将无息退还全部所缴保费。【立即投资】：自签收保单次日0时起，您有XX天的犹豫期。犹豫期内退保，除资产管理费以外，保险公司将按收到合同终止申请书后的下一个资产评估日的个人账户价值连同其他已收取的费用一并退还给您，这部分价值可能会低于您所缴的保费。</b><br>"
									      	+"<b style='color:red'>说明：</b><br>"
									      	+"<b style='color:red'>犹豫期为 15个自然日</b><br>"
									      	+"<b style='color:red'>山东（青岛除外）、浙江（宁波除外）、江苏：投保年龄男≥60岁、女≥55岁或残疾人或低保人群享有30天犹豫期</b><br>"
									      	+"<b style='color:red'>深圳：10个工作日或15个自然日犹豫期（以对客户有利者为准）</b><br>"
									      	+"</small>");
								     }
								}						
							},
						});			
				  }
				  
			},50);
	
};

//保险产品
commonCombobox_option.commonCombobox_riskcode = {
	///#lccont.insurancecom
	url:path + '/newCont/codeselect/searchrisk/#newContApply.insurancecom',
	valueField : "riskcode",
	relateType: "vue",
	// 显示在输入框的
	inputText : "riskname",
	// 显示在下拉列表的项，默认空，空则全部显示
	textShow : ["riskname"],
	
	afterselect:function(){
		var vueobjtemp =vue_config[vue_config.length-1].vueobj;
		var riskData = this.data;
		var risktype = "";
		
		riskData.forEach(function(val,index,array){
			if($("#riskcode").val()==val.riskcode){
				risktype=val.risktype;
				return;
			}
		});

		vueobjtemp.formdata['investmentrisk']=risktype=="01"?"true":"false";

	}
};

//保险期间
commonCombobox_option.commonCombobox_insuyears = {
	url :  path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/insuyear.do',
	valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"],
	afterselect:function (){
		if (vueobj["testdivchange"].formdata.lcpol.riskcode=="@Y5"){
			if (vueobj["testdivchange"].formdata.lcpol.insuyear=="65A"){
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol, "plan","2");
				$('#productplanning').attr("disabled",true);
			}else if (vueobj["testdivchange"].formdata.lcpol.insuyear=="999"){
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol, "plan","1");
				$('#productplanning').attr("disabled",true);
			}else{
				//vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol, "plan","");
				$('#productplanning').attr("disabled",false);
			}
		}
	}
};
//缴费期间
commonCombobox_option.commonCombobox_payendyears = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/payendyear.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};
//年金领取方式
commonCombobox_option.commonCombobox_BonusGetYearFlag = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/BonusGetYearFlag.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};
//缴费方式
commonCombobox_option.commonCombobox_payintvs = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/payintv.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};

//红利给付方式
commonCombobox_option.commonCombobox_bonuspayment = {
    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/bonuspayment.do',
    valueField: "paramscode",
    // 显示在输入框的
    inputText: "paramsname",
    // 显示在下拉列表的项，默认空，空则全部显示
    textShow: ["paramsname"]
};


//投资账户类型
commonCombobox_option.commonCombobox_investmentaccount = {
	    url: path + '/newCont/codeselect/searchRiskParamsdef/#newContApply.riskcode/InvestmentAccount',
	    valueField: "paramscode",
	    relateType: "vue",
	    mutually_exclusive:true,
	    // 显示在输入框的
	    inputText: "paramsname",
	    // 显示在下拉列表的项，默认空，空则全部显示
	    textShow: ["paramsname"]
};

//续期保费逾期
commonCombobox_option.commonCombobox_AutoPayFlag = {
	    url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/AutoPayFlag.do',
	    valueField: "paramscode",
	    // 显示在输入框的
	    inputText: "paramsname",
	    // 显示在下拉列表的项，默认空，空则全部显示
	    textShow: ["paramsname"]
};

//产品类型
commonCombobox_option.commonCombobox_producttype = {
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/producttype.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};

//产品计划
commonCombobox_option.commonCombobox_productplanning = {
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/productplanning.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]

};

//年金累积生息
commonCombobox_option.commonCombobox_CashAccumulation = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/CashAccumulation.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//自动申请续保
commonCombobox_option.commonCombobox_AutoRenewal = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/AutoRenewal.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//申请使用优选体费用
commonCombobox_option.commonCombobox_PremiumRate = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/PremiumRate.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
		
};

//自动转换
commonCombobox_option.commonCombobox_autorebalance = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/AutoRebalance.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};

//投资生效期
commonCombobox_option.commonCombobox_investmentStartDateFlag = {
		
		url: path + '/newCont/codeselect/searchRiskParamsdef/#riskcode/investdateformanu.do',
		valueField: "paramscode",
		// 显示在输入框的
		inputText: "paramsname",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow: ["paramsname"]
};

//年金帐户帐号开户省
commonCombobox_option.commonCombobox_areaprovince = {
		url :  path + '/newCont/codeselect/allprovinceid/province.do',
		valueField : "provinceid",
		// 显示在输入框的
		inputText : "provincename",
		textShow : [ "provincename" ]
};

//年金帐户帐号开户市
commonCombobox_option.commonCombobox_areacity = {
		url :  path + '/newCont/codeselect/allcity/#AccountAreaProvince.do',
		valueField : "cityid",
		// 显示在输入框的
		inputText : "cityname",
		textShow : [ "cityname" ]
};

commonCombobox_option.commonCombobox_PremiumRate={
		valueField : "code",
		inputText : "codename",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow : [ "codename" ],
		data : [ {
			code : 'N',
			codename : '否'
		}, {
			code : 'Y',
			codename : '是'
		} ]
	};

commonCombobox_option.commonCombobox_ifsmoke={
		valueField : "code",
		inputText : "codename",
		// 显示在下拉列表的项，默认空，空则全部显示
		textShow : [ "codename" ],
		data : [ {
			code : '0',
			codename : '否'
		}, {
			code : '1',
			codename : '是'
		} ]
	};
//premrate
afterVueSelect.PremiumRate=function(form_element) {
	if(vueobj["testdivchange"].formdata.lcpol.premrate=="Y"){
		$('#div_ifsmoke').show();
	}
		
	else{
		$('#div_ifsmoke').hide();
		vueobj["testdivchange"].formdata.lcpol.ifsmoke=""	
	}
		
}

afterVueSelect.ifsmoke=function(form_element) {
	
	
	if(vueobj["testdivchange"].formdata.lcpol.ifsmoke=="1"){
		$('#smokeyear').attr("disabled",false);
		$('#smokenums').attr("disabled",false);
		$('#div_smokeyear').show();
		$('#div_smokenums').show();
	}
		
	else{
		$('#smokeyear').attr("disabled",true);
		$('#smokenums').attr("disabled",true);
		$('#div_smokeyear').hide();
		$('#div_smokenums').hide();
		vueobj["testdivchange"].formdata.lcpol.smokeyear=""
		vueobj["testdivchange"].formdata.lcpol.smokenums=""
	}
		
}

commonCombobox_option.commonCombobox_whetherConvert={
	"data" : [ {
		"value" : "N",
		"text" : "否"
	}, {
		"value" : "Y",
		"text" : "是"
	} ]
};
afterVueSelect.whetherconvert=function(form_element) {
	var topvue=getTopvueObj(this);
	if($("#"+form_element.id).val()=="Y"){
		topvue.form_elementsBYID.krisk.uniontype.elementstatus="01";
		this.$emit("update:triggerupdate",this.triggerupdate+1);
	}else{
		topvue.form_elementsBYID.krisk.uniontype.elementstatus="02";
		topvue.form_elementsBYID.krisk.unioncontno1.elementstatus="02";
		topvue.form_elementsBYID.krisk.unioncontno2.elementstatus="02";
		this.$emit("update:triggerupdate",this.triggerupdate+1);
		//清空隐藏值
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"uniontype","");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"unioncontno1","");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"unioncontno2","");
	}
}
commonCombobox_option.commonCombobox_anzlUnionType={
	url : path + '/newCont/codeselect/common/anzluniontype',
	valueField : "code",
	relateType: "vue",
	// 显示在输入框的
	inputText : "codename",
	textShow : [ "codename" ]
};
afterVueSelect.uniontype=function(form_element) {
	var topvue=getTopvueObj(this);
	if($("#"+form_element.id).val()=="1"){
		topvue.form_elementsBYID.krisk.unioncontno1.elementstatus="01";
		topvue.form_elementsBYID.krisk.unioncontno2.elementstatus="02";
		this.$emit("update:triggerupdate",this.triggerupdate+1);
		//清空隐藏值
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"unioncontno2","");
	}else if($("#"+form_element.id).val()=="2"){
		topvue.form_elementsBYID.krisk.unioncontno1.elementstatus="02";
		topvue.form_elementsBYID.krisk.unioncontno2.elementstatus="01";
		this.$emit("update:triggerupdate",this.triggerupdate+1);
		//清空隐藏值
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"unioncontno1","");
	}else if($("#"+form_element.id).val()=="3"){
		topvue.form_elementsBYID.krisk.unioncontno1.elementstatus="01";
		topvue.form_elementsBYID.krisk.unioncontno2.elementstatus="01";
		this.$emit("update:triggerupdate",this.triggerupdate+1);

	}else{
		topvue.form_elementsBYID.krisk.unioncontno1.elementstatus="02";
		topvue.form_elementsBYID.krisk.unioncontno2.elementstatus="02";
		this.$emit("update:triggerupdate",this.triggerupdate+1);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"unioncontno1","");
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcpol,"unioncontno2","");
	}

}

commonCombobox_option.commonCombobox_unioncontno={
	url : path + '/newCont/codeselect/convertUniversalAccounts/#newContApply.transno',
	valueField : "proposalcontno",
	delayLoadDataFlag : true,
	relateType: "vue",
	// 显示在输入框的
	inputText : "proposalcontno",
	textShow : [ "proposalcontno" ]
};

//主险保存后
aftersubmitvueform.krisk_tabinfoform = function() {
	
    var topvue = getTopvueObj(this);

	////年金/生存金是否需要转入万能账户 不为空时，重新加载告知
	if(vueobj["testdivchange"].formdata.lcpol.whetherconvert!=''&&"N"==vueobj["testdivchange"].formdata.lcpol.whetherconvert
	||vueobj["testdivchange"].formdata.lcpol.whetherconvert!=''&&"Y"==vueobj["testdivchange"].formdata.lcpol.whetherconvert){
		
  
   console.info("年金/生存金是否需要转入万能账户 universalmark------"+vueobj["testdivchange"].formdata.lcpol.universalmark);  
   
	//判断告知是否已经加载过，并且两次存值不一致
	if(null!=topvue.form_elements.commonFormNotice
   &&vueobj["testdivchange"].formdata.lcpol.universalmark!=''&&"Y"==vueobj["testdivchange"].formdata.lcpol.universalmark){			

		//为N告知不显示，清空身高体重
	if("N"==vueobj["testdivchange"].formdata.lcpol.whetherconvert){
		//清空投保人身高体重
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"stature", null);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"avoirdupois", null);
		//清空被保人身高体重
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"stature", null);
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsured,"avoirdupois", null);
		try{
			//多被保人身高体重
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"stature", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcinsuredtwo,"avoirdupois", null);
			//其他被保人
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.otherinsured,"stature", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.otherinsured,"avoirdupois", null);
		}catch(e){
			
		}
		
   }

	   console.info("主险保存后 年金/生存金是否需要转入万能账户 不为空时，重新加载告知");
	   console.info(vueobj["testdivchange"].formdata.noticeinfos);
	  
		
	       //清空告知
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata,"noticeinfos", new Array());
		   //清空详细告知
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata,"noticedetails", new Array());
		   
		   //////是否饮酒
		   //清空详细告知
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo1", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo2", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo3", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo4", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo5", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo6", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo7", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo8", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo9", null);
		   //清空是否饮酒
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.noticeDrinkInsu,"noticeinfo10", null);
		   
	       console.info("commonFormNotice------------");

		   topvue.$set(topvue.form_elements,"commonFormNotice",new Array());
		  
//		   console.info(topvue.form_elements.commonFormNotice);
			   
			   
	   var elements =topvue.form_elements[topvue.formdata.newContApply.insurancecom+'H5insuranceContInput'];
		//加载告知
		loadNewElements(topvue, elements[5].relateObjectField ,elements[5]);
		
		
	}
  }
	

if(this.form_elementsBYID.ANZLH5insuranceContInput['subriskcode_tabinfo'] &&
		this.form_elementsBYID.ANZLH5insuranceContInput['subriskcode_tabinfo']["elementstatus"]!='01'){
	
	if(this.formdata.newContApply.currentSIDIndex>6){
		
	}else{
		this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
		this.$set(this.formdata.newContApply,"currentSIDIndex",6);
		$('#tab_FATACACRS_tabinfo').trigger("click");
	}
	

}
if(this.formdata.newContApply.currentSIDIndex> 6){
	
	if(!checkCRSShow.call(this)){
		this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
		this.$set(this.formdata.newContApply,"currentSIDIndex",6);
		this.$set(this.formdata.newContApply,"FATACACRS",false);
		
		$('#tab_FATACACRS_tabinfo').trigger("click");
	}
}

return true; 
};

//提交前 判断IPS
beforesubmitvueform.krisk_tabinfoform = function() {
	var topvue = getTopvueObj(this);
//	var krisk_flag=false;	
	
	if(topvue.form_elementsBYID.krisk["prem"].elementstatus=="01"){
		 var prem=$("#prem").val().trim();
		 if(prem==0){
			alert("保费输入有误，请重新输入！");
			return false;
		 }
	}
	
	//缴费方式为年缴时，续期保费逾期选项不能选择不适用
	if(topvue.form_elementsBYID.krisk["payintv"]!=undefined&&topvue.form_elementsBYID.krisk["payintv"].elementstatus=="01"&&$("#payintv").val().trim()!=null
	  &&topvue.form_elementsBYID.krisk["AutoPayFlag"]!=undefined&&topvue.form_elementsBYID.krisk["AutoPayFlag"].elementstatus=="01"&&$("#AutoPayFlag").val().trim()!=null
		){
	    var payintv=$("#payintv").val();
	    var AutoPayFlag=$("#AutoPayFlag").val();
	    if(payintv=='Y'&&AutoPayFlag==0){
		   alert("缴费方式为年交时，续期保费逾期选项不能选择不适用，请修改！");
		   return false;
	    }
	    if(payintv=='S'&&AutoPayFlag!=0){
	   	   alert("缴费方式为趸交时，续期保费逾期选项只能选择不适用，请修改！");
	   	   return false;
	    }
    }
	//ips提示
	/*if(confirm(("请注意，此页面上的产品投保信息若有修改，您可以点击【确认】保存银保通录入的投保信息，但请检查建议书系统是否需要更新建议书（IPS No:"+topvue.formdata.lccont.ipsno+"）"))){
		krisk_flag=true;
	}else{
		krisk_flag=false;
	}*/
	return true; 
};
