
afterVueSelect.otherlcinsuredidtype1 = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
	var idtype= topvue.formdata.otherinsured[index].lcinsuredidtype;
	//非本人才进来
/*	if (idtype == "X"){
		$("#otherinsuredrenewCount1\\["+index+"\\]").attr("disabled",false);			
	}else {
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.otherinsured[index],"renewCount", null);
			$("#otherinsuredrenewCount1\\["+index+"\\]").attr("disabled",true);	
	}*/
	if ((idtype !=null && idtype != "") && idtype != "I"){
	    vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.otherinsured[index],"startingDate", null);
			$("#otherinsuredstartingDate1\\["+index+"\\]").attr("disabled",true);
		}else {
			$("#otherinsuredstartingDate1\\["+index+"\\]").attr("disabled",false);
		}
		if((idtype !=null && idtype != "") && (idtype == "H" || idtype == "C")){
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.otherinsured[index],"insureidenddate", null);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.otherinsured[index],"islongitems", new Array());
			$("#otherinsureidenddate1\\["+index+"\\]").attr("disabled",true);
			$("#otherlcinsuredislongitem\\["+index+"\\]").attr("disabled",true);
		}else{
			if(vueobj["testdivchange"].formdata.otherinsured[index].islongitems.length==0){
			$("#otherinsureidenddate1\\["+index+"\\]").attr("disabled",false);
			$("#otherlcinsuredislongitem\\["+index+"\\]").attr("disabled",false);
			}
		}
};

//附加险   逻辑增加
$.fn.bootstrapValidator.validators.subriskAgeValid = {
		
	validate : function(validator, $field, options) {

		var topvueobj = getTopvueObj(options.vueobj);
		var riskbelong =options.vueobj.formdata.riskbelong;
		 
		
		var form =$(options.vueobj.$el)
			.parentsUntil("form").parent("form");
		for ( var index in riskbelong) {
			//主被保险人
			if(riskbelong[index]=="01"){
				topvueobj.formdata.lcinsured.lcinsuredbirthday;
			}
			
			//第二 被保险人
			if(riskbelong[index]=="02"){
				
			}
		}
		
		
		return true; 
	}
}; 

//是否有被保人
commonCombobox_option.commonCombobox_subrisk_otherinsuredflag = {
		url :  path + '/newCont/codeselect/common/otherinsuredflag',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText : "codename",
		textShow : ["codename"]
};







//所属被保人下拉框加载
function incuredall(){
 var mu=vueobj["testdivchange"].formdata.lcinsuredmulti.length;
	//被保人个数
	var mysize=parseInt(mu+1);
	console.log("========================");
	/*$("input\[id^='maininsured\['\]").combobox("clear");
	$("input\[id^='maininsured\['\]").combobox("clearData");*/
	
	var ar=[{
		code : '0',
		codename : '主被保险人',
	}];
	for(var a=1;a<mysize;a++){
		ar.push({
			code : a,
			codename : '其他被保险人'+a,
		});
	}
	
	$("input\[id^='maininsured\['\]").combobox("setData" ,ar);
	$("input\[id^='maininsured\['\]").combobox("loadData");
	try {
			$("input\[id^='maininsured\['\]").combobox("clear");
			$("input\[id^='maininsured\['\]").combobox("clearData");
		
		if($("#subriskcode_tabinfoform").data('bootstrapValidator')!=null&&
				$("#subriskcode_tabinfoform").data('bootstrapValidator')!=undefined){
				$("#subriskcode_tabinfoform").data('bootstrapValidator').destroy();
		        $('#subriskcode_tabinfoform').data('bootstrapValidator', null);
			}
	} catch (e) {
		// TODO: handle exception
	}
}
//证件长期有效
afterVueSelect.otherlcinsuredislongitem = function(form_element) {
	var topvue = getTopvueObj(this);
	var index = getElementIntex(this);
	var idtype= topvue.formdata.otherinsured[index].lcinsuredidtype;
	var obj = $("#otherlcinsuredislongitem\\["+index+"\\]");
	if($("#otherrelationtoappnt1\\["+index+"\\]").val() != "00" && $("#otherrelationtoappnt1\\["+index+"\\]").val() != "" 
		&& idtype != "H" && idtype != "C"){
		if (obj.is("[type='checkbox']:checked")){
			topvue.$set(topvue.formdata.otherinsured[index],"insureidenddate","9999-01-01");
			$("#otherinsureidenddate1\\["+index+"\\]").attr("disabled",true);
		}else {
			$("#otherinsureidenddate1\\["+index+"\\]").attr("disabled",false);
		}
	}
}

 
 bootstrap_valid.subriskAgeValid = function(validitem   ){
 
		var vueobj = this;
		var validobj= {
				message:"该险种对应被保险人的年龄必须",
				vueobj:vueobj
		};
	 
		return validobj;
      
};

			//多被保人，险种所属被保人：
			commonCombobox_option.commonCombobox_maininsured = {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : '0',
					codename : '主被保险人'
				}]
			},


			
			
			

			//附加险代码获取   多被保人
			commonCombobox_option.commonCombobox_subriskcode2 = {

				url : path + '/newCont/codeselect/searchsubrisk/#newContApply.insurancecom/#newContApply.riskcode',
				valueField : "riskCode",
				//oneResultAuto:false,
				//mutually_exclusive:true,
				// 显示在输入框的
				relateType: "vue",
				inputText : "riskName",
				textShow : [ "riskName" ]
				,afterselect : function($element,$target,text,val,combobox) {
					
					if(text==undefined||text==""||text==null){
						//如果 选择后 为空 清空对应数据
						var index = getRiskindex($target.attr("id"));
						vueobj["testdivchange"].formdata.sublcpols[index]={};
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.sublcpols,index,{});
						return ;
						
					}
					
					if((vueobj["testdivchange"].formdata.lcinusredtwo !=null && vueobj["testdivchange"].formdata.lcinusredtwo != undefined)
							|| (vueobj["testdivchange"].formdata.lcinsuredmulti != null && vueobj["testdivchange"].formdata.lcinsuredmulti != undefined && vueobj["testdivchange"].formdata.lcinsuredmulti.length > 0)
							&& text == '@RF'){
						//多被保人不能添加此附加险 安联附加超级随心（II）长期重大疾病保险
							alert("多被保人时，不能添加此附加险产品");
							let index = getRiskindex($target.attr("id"));
							vueobj["testdivchange"].formdata.sublcpols[index]={};
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.sublcpols,index,{});
					}
					
					var tmpid = $target.attr("id").replace("subriskcode2","maininsured");
					var type = combobox.id_map[text].riskType;
					 if(type=="15"){
						/* var ar=[{
								code : '999',
								codename : '投保人',
							}];*/
						    $("input[id^='"+tmpid+"']").combobox("clear");
						    $("input[id^='"+tmpid+"']").combobox("clearData");/*
						    $("input[id^='"+tmpid+"']").combobox("setData" ,ar);
						    $("input[id^='"+tmpid+"']").combobox("loadData");*/
						    $("input[id^='"+tmpid+"']").combobox("disable");
						    
					 }else{
						 
						 $("input[id^='"+tmpid+"']").combobox("enable");
						 var mu=vueobj["testdivchange"].formdata.lcinsuredmulti.length;
							//被保人个数
							var mysize=parseInt(mu+1);
							var ars=[{
								code : '0',
								codename : '主被保险人',
							}];
							for(var a=1;a<mysize;a++){
								ars.push({
									code : a,
									codename : '其他被保险人'+a,
								});
							}
							    $("input[id^='"+tmpid+"']").combobox("clear");
							    $("input[id^='"+tmpid+"']").combobox("clearData");
							    $("input[id^='"+tmpid+"']").combobox("setData" ,ars);
							    $("input[id^='"+tmpid+"']").combobox("loadData");
							
					 }
					
					 
					 
					 
					 
					
				},
				afterClickClear:function($element,$target) {
				
					
				}
			};

			//附加险代码获取
			commonCombobox_option.commonCombobox_subriskcode = {

				url : path + '/newCont/codeselect/searchsubrisk/#newContApply.insurancecom/#newContApply.riskcode',
				valueField : "riskCode",
				oneResultAuto:false,
				mutually_exclusive:true,
				// 显示在输入框的
				relateType: "vue",
				inputText : "riskName",
				textShow : [ "riskName" ],
				afterselect: function($element,$target,value,text,combobox){
					//多被保人不能添加此附加险 安联附加超级随心（II）长期重大疾病保险
					if((vueobj["testdivchange"].formdata.lcinusredtwo !=null && vueobj["testdivchange"].formdata.lcinusredtwo != undefined)
							|| (vueobj["testdivchange"].formdata.lcinsuredmulti != null && vueobj["testdivchange"].formdata.lcinsuredmulti != undefined && vueobj["testdivchange"].formdata.lcinsuredmulti.length > 0)
								&& value == '@RF'){
							alert("多被保人时，不能添加此附加险产品");
							let index = getRiskindex($target.attr("id"));
							vueobj["testdivchange"].formdata.sublcpols[index]={};
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.sublcpols,index,{});
					}
				}
			};
			//保险期间
			commonCombobox_option.commonCombobox_subrisk_insuyears = {
				url :  path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/insuyear',
				valueField: "paramscode",
				relateType: "vue",
				oneResultAuto:false,
			    inputText: "paramsname",
			    textShow: ["paramsname"],
			    afterselect: function($element,$target,value,text,combobox){
			    	let index = getRiskindex($target.attr("id"));
			    	//判断当前附加险为 安联附加超级随心（II）长期重大疾病保险
			    	if(value !=undefined && value !="" && value != null && vueobj["testdivchange"].formdata.sublcpols[index].riskcode == '@RF'){
						let main_insuyear = vueobj["testdivchange"].formdata.lcpol.insuyear;
						let risk_insuyear = vueobj["testdivchange"].formdata.sublcpols[index].insuyear;
//						console.log("保险期间："+vueobj["testdivchange"].formdata.lcpol.insuyear)
//						console.log("保险期间："+vueobj["testdivchange"].formdata.sublcpols[index].insuyear)
						if(risk_insuyear != main_insuyear){
							alert("当前附加险产品保险期间需要与主险相同，请重新录入");
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.sublcpols[index],"insuyear","");
						}
							
					}
			    	
			    }
			};
			//缴费期间
			commonCombobox_option.commonCombobox_subrisk_payendyears = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/payendyear',
			    valueField: "paramscode",
			    relateType: "vue",
			    oneResultAuto:false,
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"],
			    afterselect: function($element,$target,value,text,combobox){
			    	let index = getRiskindex($target.attr("id"));
			    	//判断当前附加险为 安联附加超级随心（II）长期重大疾病保险
			    	if(value !=undefined && value !="" && value != null && vueobj["testdivchange"].formdata.sublcpols[index].riskcode == '@RF'){
						let main_payendyear = vueobj["testdivchange"].formdata.lcpol.payendyear
						let risk_payendyear = vueobj["testdivchange"].formdata.sublcpols[index].payendyear;
//						console.log("缴费期间："+vueobj["testdivchange"].formdata.lcpol.payendyear)
//						console.log("缴费期间："+vueobj["testdivchange"].formdata.sublcpols[index].payendyear)
						if(risk_payendyear != main_payendyear){
							alert("当前附加险产品缴费期间需要与主险相同，请重新录入");
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.sublcpols[index],"payendyear","");
							 
						}
					}
			    	
			    }
			};

			//缴费方式
			commonCombobox_option.commonCombobox_subrisk_payintvs = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/payintv',
			    valueField: "paramscode",
			    relateType: "vue",
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};

			//红利给付方式
			commonCombobox_option.commonCombobox_subrisk_bonuspayment = {
			    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/bonuspayment',
			    valueField: "paramscode",
			    relateType: "vue",
			    // 显示在输入框的
			    inputText: "paramsname",
			    // 显示在下拉列表的项，默认空，空则全部显示
			    textShow: ["paramsname"]
			};


			//附加险险种所属 commonCombobox_subriskbelong
			commonCombobox_option.commonCombobox_subriskbelong = {
				url :  path + '/newCont/codeselect/common/subriskbelong',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : ["codename"]
			};//产品类型
			commonCombobox_option.commonCombobox_subrisk_producttype = {
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/producttype',
					valueField: "paramscode",
					relateType: "vue",
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
			};

			//产品计划
			commonCombobox_option.commonCombobox_subrisk_productplanning = {
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/productplanning',
					valueField: "paramscode",
					relateType: "vue",
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]

			};
			
			
			//备用查询
			


			//续期保费逾期
			commonCombobox_option.commonCombobox_subrisk_AutoPayFlag = {
				    url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/AutoPayFlag',
				    valueField: "paramscode",
					relateType: "vue",
				    // 显示在输入框的
				    inputText: "paramsname",
				    // 显示在下拉列表的项，默认空，空则全部显示
				    textShow: ["paramsname"]
			};

			//自动申请续保
			commonCombobox_option.commonCombobox_subrisk_AutoRenewal = {
					
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/AutoRenewal',
					valueField: "paramscode",
					relateType: "vue",
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
					
			};

			//申请使用优选体费用
			commonCombobox_option.commonCombobox_subrisk_PremiumRate = {
					
					url: path + '/newCont/codeselect/searchRiskParamsdef/#sublcpols.riskcode/PremiumRate',
					valueField: "paramscode",
					relateType: "vue",
					// 显示在输入框的
					inputText: "paramsname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["paramsname"]
					
			};

			//多被保人地址查询
			commonCombobox_option.commonCombobox_insuredpostcitymultiOther = {
					url: path + '/newCont/codeselect/allcity/#otherinsured.otherInsuredLcaddress.postprovince',
					valueField: "cityid",
					relateType: "vue",
					// 显示在输入框的
					inputText: "cityname",
					// 显示在下拉列表的项，默认空，空则全部显示
					textShow: ["cityname"]
					
			};

			//多被保人地址查询
			commonCombobox_option.commonCombobox_insuredpostdistrictmultiOther = {

				url :  path + '/newCont/codeselect/allcounty/#otherinsured.otherInsuredLcaddress.postcity',
				valueField : "countyid",
				relateType: "vue",
				// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			
			//行业代码
			commonCombobox_option.commonCombobox_lcinsuredindustrycodemultiOther = {
				url : path + '/newCont/codeselect/occupation/#otherinsured.industrytype/AL',
				valueField : "occupationcode2",
				relateType: "vue",
				// 显示在输入框的
				inputText : "occupationname2",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname2" ]
			},
			
			//职业代码
			commonCombobox_option.commonCombobox_occupationcodemultiOther = {
				url : path + '/newCont/codeselect/occupationocc/#otherinsured.occupationtype/AL',
				valueField : "occupationcode",
				relateType: "vue",
				// 显示在输入框的
				inputText : "occupationname",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname" ]
			},
			
			/**
			 * 加载险种对应的参数 加载判断
			 */
			afterVueSelect.subriskcode=function(form_element){
				
				var topvueobj = getTopvueObj(this);
//				topvueobj.$nextTick(function () {

					var url ="/newCont/common/init/subriskcode/ANZL/#newContApply.transno"; 
					var index = getRiskindex(this.elementindex);
					if(this.formdata.riskcode){
					
					     setTimeout(function(){
								if(($("#otherinsuredrenewCount1\\["+index+"\\]").is(":visible")&&$("#otherinsuredrenewCount1Title"+index+"").length<=0)){
							   		$("#otherinsuredrenewCount1\\["+index+"\\]").parent().append("<small id='otherinsuredrenewCount1Title"+index+"' class='help-block zhq' style='color: red;'>请注意，" +
							   				"请按证件上的换证次数填写，例如：01。</small>");
									 }
								     },200);
						
						
						topvueobj.formdata.newContApply.currentSubriskIndex=index;
						var elements =topvueobj.form_elements['sublcpols'
										                        +this.formdata.riskcode +'_index'+index];
						if(elements==undefined){
							topvueobj.$set(topvueobj.form_elements ,'sublcpols'
			                        +this.formdata.riskcode
			                        +'_index'+index,[]);
							
						}else{
							if(elements.length!=0 ){
								
								return ;
							}
						}
						loadNewElements(this, url ,form_element);
					}else{
						 //if(text==null||text==undefined||text==""){
//							 var index = getRiskindex($target.attr("id"));
						 //如果 选择后 为空 清空对应数据
							// vueobj["testdivchange"].formdata.sublcpols[index]={};
						 //}
					}
				
//				});
				
					
//				this.
					
			};
			
			
			function getRiskindex(elementindex){
				
				var  strindex =  elementindex.indexOf("[");
				var  endindex =  elementindex.indexOf("]");
				
				
				return elementindex.substring(strindex+1 , (endindex));
				
			}
			
			afterVueSelect.otherinsuredflag=function(form_element){
				 var  index = this.elementindex.replace("[","").replace("]","");
				 var topvueobj = getTopvueObj(this);
				 
				 if(this.formdata[form_element.name]!='Y'&&form_element.elementstatus=='01'){
					 if(topvueobj.formdata.otherinsured!=null&&topvueobj.formdata.otherinsured.length>=(index+1)){
						 delete topvueobj.formdata.otherinsured[index]; 
						 $("#normalNotice_tab").click(); 
						 $("#normalNotice_tab").addClass(" active");
						 $("#normal_notice").addClass(" active");
						 
					 }
					 
					 if(topvueobj.formdata.otherinsured.length==1
							 &&topvueobj.formdata.otherinsured[0]==undefined){
						 topvueobj.formdata.otherinsured=[];
//						 topvueobj.$set(topvueobj.formdata.otherinsured,0, "FATACACRS");
					 }
				 }
				 
				 
			}
			/**
			 * 加载多被保人险种对应的参数 加载判断
			 */
			afterVueSelect.subriskcode2=function(form_element){
				
				var topvueobj = getTopvueObj(this);
//				topvueobj.$nextTick(function () {

					var url ="/newCont/common/init/subriskcode/ANZL/#newContApply.transno"; 
					var index = getRiskindex(this.elementindex);
					if(this.formdata.riskcode){
						
						topvueobj.formdata.newContApply.currentSubriskIndex=index;
						var elements =topvueobj.form_elements['sublcpols'
										                        +this.formdata.riskcode +'_index'+index];
						if(elements==undefined){
							topvueobj.$set(topvueobj.form_elements ,'sublcpols'
			                        +this.formdata.riskcode
			                        +'_index'+index,[]);
							
						}else{
							if(elements.length!=0 ){
								
								return ;
							}
						}
						loadNewElements(this, url ,form_element);
					}else{
						 //if(text==null||text==undefined||text==""){
//							 var index = getRiskindex($target.attr("id"));
						 //如果 选择后 为空 清空对应数据
							// vueobj["testdivchange"].formdata.sublcpols[index]={};
						 //}
					}
				
//				});
				
					
//				this.
					
			};
			
//			//附加险保存后
//			aftersubmitvueform.subriskcode_tabinfoform = function() {
//			 
//				 if(this.formdata.newContApply.noticeCombineID==this.formdata.newContApply.lastnoticeCombineID){
//					 
//					 
//				 }else{
//					 topvue.$set(topvue.form_elements, commonFormNotice, []);
//				 }
//				
//				
//				return true; 
//			};
			
/**
 * 附加险保存后
 */
 aftersubmitvueform.subriskcode_tabinfoform = function() {
	 
	  var topvue = getTopvueObj(this);
	  console.info("subrisk.js===="+vueobj["testdivchange"].formdata.lccont.pageflag);
		// noticeCombineID		="N/A";//当前告知的		combineid
	    // lastnoticeCombineID	="N/A";//上一次 告知的	combineid，  两个不相等，并且主险页面年金转万能 whetherconvert字段值为否 重新加载告知
		if(vueobj["testdivchange"].formdata.lccont.pageflag>7&&vueobj["testdivchange"].formdata.lcpol.whetherconvert!=''&&"N"==vueobj["testdivchange"].formdata.lcpol.whetherconvert
		 &&vueobj["testdivchange"].formdata.newContApply.LastnoticeCombineID!=vueobj["testdivchange"].formdata.newContApply.noticeCombineID){
			
	       //清空告知
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata,"noticeinfos", new Array());
		   //清空详细告知
		   vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata,"noticedetails", new Array());
			      
		   topvue.$set(topvue.form_elements,"commonFormNotice",new Array());
				  
				   console.info(topvue.form_elements.commonFormNotice);
				   
				   console.info("commonFormNotice-----subrisk-----重新加载告知--");
				   
		   var elements =topvue.form_elements[topvue.formdata.newContApply.insurancecom+'H5insuranceContInput'];
			//加载告知
			loadNewElements(topvue, elements[5].relateObjectField ,elements[5]);
			$("#notice_submit").trigger("click");
		}
		
		var otherinsunum =this.formdata.otherinsured.length; // 附加险页面被保人个数

		if(otherinsunum>0){
		var otherinsure=this.formdata.otherinsured[0];//附加险被保人

			var  otherInsuNoID='otherNotice_'+otherinsure.lcinsuredidno;
			
		if (!this.form_elements[otherInsuNoID]) {
			console.log("hiddenOtherinsuredByid  !vue_obj.form_elements[otherInsuNoID]");
			return true;
		}
		
		hiddenOtherinsuredById(this);
		
		}
		
		if(!checkCRSShow.call(this)){
			this.$set(this.formdata.newContApply,"FATACACRS",false);
		if(this.formdata.newContApply.currentSIDIndex>6){
			this.$set(this.formdata.newContApply,"currentSIDIndex",6);
			this.$set(this.formdata.newContApply,"currentSID", "FATACACRS");
			$('#tab_FATACACRS_tabinfo').trigger("click");
		}

   
    }
		
	
	 return true;
};


			 
			
//提交前 判断是否有重复
beforesubmitvueform.subriskcode_tabinfoform = function() {
				var topvue = getTopvueObj(this);
				//获取主险代码，判断主险是否是6个被保人
			   if(initFormdata.newContApply.investment=='M'){
				   var codenames={};
					//获取附加险codenames['@R5']="附加超级随心重疾";
					for(var o in initFormdata.newContApply.subrisklist){
						var riskName=initFormdata.newContApply.subrisklist[o].riskName;
						var rela=initFormdata.newContApply.subrisklist[o].riskCode;
						codenames[rela]=riskName;
						
					}
				   
					var risknames=new Array();
					risknames[0]="主被保险人";
					var riskarray=new Array();
					riskarray[0]=0;
					
					 var mu=vueobj["testdivchange"].formdata.lcinsuredmulti.length;
						//被保人个数
						var mysize=parseInt(mu+1);
						
						for(var a=1;a<mysize;a++){
							risknames[a]="其他被保险人"+a;
							riskarray[a]=0;
						}
						var counth=0;
						var counthname="";
						
					//判断险种所属被保人是否为空
					for(var i=0;i<vueobj["testdivchange"].formdata.sublcpols.length;i++){
						//获取险种所属被保人
						if(vueobj["testdivchange"].formdata.sublcpols[i].riskcode!=""
						 &&vueobj["testdivchange"].formdata.sublcpols[i].maininsured!=""
						 &&vueobj["testdivchange"].formdata.sublcpols[i].riskcode!=undefined
						 &&vueobj["testdivchange"].formdata.sublcpols[i].maininsured!=undefined){
							var val =$("#maininsured\\["+i+"\\]_combobox").is(":disabled")
							if(val==true){
								counth++;
								counthname=vueobj["testdivchange"].formdata.sublcpols[i].riskcode;
							}else{
								 var size=vueobj["testdivchange"].formdata.sublcpols[i].maininsured;
								  riskarray[size]=parseInt(riskarray[size])+1;
									
							}
						}else {
							if(vueobj["testdivchange"].formdata.sublcpols[i].riskcode!=""
							 &&vueobj["testdivchange"].formdata.sublcpols[i].maininsured==""
						     ||vueobj["testdivchange"].formdata.sublcpols[i].riskcode!=undefined
							 &&vueobj["testdivchange"].formdata.sublcpols[i].maininsured==undefined){
								var subriskcode=vueobj["testdivchange"].formdata.sublcpols[i].riskcode;
								if(val!=true){
									if (subriskcode=='@R8'||subriskcode=='@R9'){

									}else{
										alert("附加险的险种所属被保人不能为空");
										return false;
									}
								}else{
									counth++;
									counthname=vueobj["testdivchange"].formdata.sublcpols[i].riskcode;
								}
							}
							
						}
						
					}
					
					
					if(counth>1){
						alert("附加险（"+codenames[counthname]+"）不能重复！");
						return false
						
						
					}
					//判断是否有重复
					for(var a=0;a<riskarray.length;a++){
						
						if(parseInt(riskarray[a])>1){
							var riskcarray=new Array();
							var b=0;
							for(var i in vueobj["testdivchange"].formdata.sublcpols){
								var size=vueobj["testdivchange"].formdata.sublcpols[i].maininsured;
								console.log(a+"ee=="+size);
								if(a==size){
									riskcarray[b]=vueobj["testdivchange"].formdata.sublcpols[i].riskcode;
									b++;
								}
							}
							
							for(var c=0;c<riskcarray.length-1;c++){
								for(var d=riskcarray.length-1;d>c;d--){
									console.log(riskcarray[c]+"===dd="+riskcarray[d]);
								if(riskcarray[c]==riskcarray[d]){
									alert(risknames[a]+"的附加险（"+codenames[riskcarray[c]]+"）不能重复！");
									return false;
								}
								}
							}
						}
					}
				  console.log(topvue.form_elementsBYID.subriskcode["maininsured"]);
					return true; 
				}
			   //校验证件有效起期和有效止期的规则
				var lcinsuredlist = topvue.formdata.otherinsured;
				for(var i=0;i<lcinsuredlist.length;i++){
					var date = new Date();
				    var seperator1 = "-";
				    var year = date.getFullYear();
				    var month = date.getMonth() + 1;
				    var strDate = date.getDate();
				    if (month >= 1 && month <= 9) {
				        month = "0" + month;
				    }
				    if (strDate >= 0 && strDate <= 9) {
				        strDate = "0" + strDate;
				    }
				    var currentdate = year + seperator1 + month + seperator1 + strDate;
					if(lcinsuredlist[i].lcinsuredidtype!=null && lcinsuredlist[i].lcinsuredidtype!=""){
					if(lcinsuredlist[i].lcinsuredidtype!= "H" && lcinsuredlist[i].lcinsuredidtype!= "C"){
						if(!(new Date(lcinsuredlist[i].insureidenddate)>new Date(currentdate))){
							alert("证件有效止期必须大于今天");
							return false;
						}
					}
					if(lcinsuredlist[i].lcinsuredidtype== "I"){
						if(lcinsuredlist[i].startingDate==null 
								|| lcinsuredlist[i].startingDate=="" ){
							alert("证件有效起期不可为空");
							return false;
						}
												
						if(new Date(lcinsuredlist[i].startingDate)>new Date(currentdate)){
							alert("有效起期必须小于等于当前日期");
							return false;
						}
						if((new Date(lcinsuredlist[i].startingDate))>=
							(new Date(lcinsuredlist[i].insureidenddate))){
							alert("有效起期必须小于有效止期");
							return false;
						}	
						}
						
					}
/*					if(lcinsuredlist[i].lcinsuredidtype== "X"){
						if(lcinsuredlist[i].renewCount==null 
								|| lcinsuredlist[i].renewCount=="" ){
							alert("证件为港澳台通行证，换证次数不可为空");
							return false;
						}
						var newrenewcount = (Array(2).join(0) + parseInt(lcinsuredlist[i].renewCount)).slice(-2);//01
						topvue.$set(lcinsuredlist[i],"renewCount",newrenewcount);
					}*/
				}
			return true; 
 };